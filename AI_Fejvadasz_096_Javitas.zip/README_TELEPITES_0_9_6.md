# AI Fejvadász 0.9.6 – egylépcsős helyválasztó és szemantikus AI-illesztés

Ez **frissítő ZIP, nem APK**, és a **0.9.5-ös Android + Render kiadásra** épül. A korábbi ZIP-eket NE töröld. A telefonos adatoknak nem szabad elveszniük; hibás APK aláírás esetén ne töröld a régi alkalmazást mentés nélkül.

## 1. Mi változik?

- **Egyetlen látható keresési helymező** az Állások oldalon. Város, vármegye vagy régió megadható; a mező kiválasztás/elhagyás után automatikusan ment. A régi profiloldali helymező láthatatlanná válik, de megmarad a kompatibilis adattároláshoz.
- **Vármegye esetén először a nagyvárosokban keresünk**, és csak **utána** a vármegyére jellemző `megye` / `vármegye` változatokkal. Régió esetén a vármegyék nagyvárosai arányosan kerülnek sorra.
- **Több elkülönített Brave-keresés**: eddig alapból 2 keresés/forrás, most 8, testre szabható `JOB_SMART_QUERIES_PER_SOURCE` (1–12). Ez a Brave-kvótát és az időigényt növelheti.
- **Az AI a feladatokat és átvihető készségeket pontozza**, a munkakörcím/kulcsszavak pontos egyezése helyett. A kötelező végzettség, jogosítvány és a felhasználó kizárásai továbbra is kemény feltételek. A sikertelen AI-hívások újrapróbálkozási kerete 28-ról 48-ra nő.
- A hitelesített `JobPosting` közzétételi dátum korlátja **20-ról 30 napra** bővül. Továbbra is csak bizonyíthatóan dátumozott, elérhető hirdetések kerülnek az igazolt főlistába; a forrásoldal elérhetősége önmagában NEM bizonyítja a jelentkezés nyitottságát.

**Korlát:** A ZIP nem teszi hitelessé a dátum nélküli vagy strukturált `JobPosting` nélküli találatokat. Ha a `rejectionReasons.missingEvidence` továbbra is magas, egy külön, világosan *ellenőrizendő* hirdetés-listát kell megtervezni; az igazolt főlistába ellenőrizetlen linkek nem kerülhetnek. Nincs garantált állásszám.

## 2. GitHub – Android APK építése

1. Töltsd fel a repository **gyökerébe** ezt a ZIP-et: `AI_Fejvadasz_v096_Egylepcsos_AI_Javitas.zip`. A ZIP-et ne bontsd ki a repository-ban.
2. A `.github/workflows/build-apk.yml` `ZIP kibontasa` szakaszába a `v095` unzip-sor **után** kerüljön ez a két sor:

```bash
unzip -oq AI_Fejvadasz_v096_Egylepcsos_AI_Javitas.zip -d project
node project/apply-v096-android.js
```

3. Commit után a GitHub Actions → **AI Fejvadasz APK** legújabb sikeres futásánál töltsd le az `AI-Fejvadasz-APK` artefaktumot. Ez nem történik meg automatikusan pusztán a ZIP letöltésével.

## 3. Render – szerverfrissítés

Render → `ai-fejvadasz-android` → Settings → Build Command. A v0.9.5-ös `apply-v095-server.js` parancs **után, de a `cd ai-server && npm install` elé** kerüljön:

```bash
unzip -oq AI_Fejvadasz_v096_Egylepcsos_AI_Javitas.zip -d ai-server && node ai-server/apply-v096-server.js &&
```

A teljes 0.9.6-os Build Command a 0.9.5-ös korábbi parancs megtartásával:

```bash
unzip -oq AI_Fejvadasz_AI_Szerver_v0821_Brave_Javitas.zip -d ai-server && unzip -oq AI_Fejvadasz_v090_Alkalmazas_Szerver_Frissites.zip -d ai-server && node ai-server/apply-v09-server.js && unzip -oq AI_Fejvadasz_v091_Teruleti_Duplikatum_AI_Javitas.zip -d ai-server && node ai-server/apply-v091-server.js && sed -i "s/trim();if(!city/trim().replace('főváros','Budapest');if(!city/" ai-server/prepare-hu-geo.js && node ai-server/prepare-hu-geo.js && unzip -oq AI_Fejvadasz_v092_Bovitett_Allasforrasok.zip -d ai-server && node ai-server/apply-v092-server.js && unzip -oq AI_Fejvadasz_v094_Szelesebb_Kereso_Javitas.zip -d ai-server && node ai-server/apply-v094-server.js && sed -i 's/values()].slice(0,220);/values()].slice(0,360);/' ai-server/v09-verify.js && unzip -oq AI_Fejvadasz_v095_Regio_Megye_Cimke_Javitas.zip -d ai-server && node ai-server/apply-v095-server.js && unzip -oq AI_Fejvadasz_v096_Egylepcsos_AI_Javitas.zip -d ai-server && node ai-server/apply-v096-server.js && cd ai-server && npm install --omit=dev
```

Start Command változatlan: `cd ai-server && npm start`. Titkos API-kulcsot ne tegyél a ZIP-be vagy GitHubra. Az új szerver várható `/health` verziója: `0.9.6`.

## 4. Ellenőrzés

- Keresés: `Zala vármegye` – előbb Zalaegerszeg, Nagykanizsa, Keszthely, Hévíz stb. lekérdezései, aztán vármegyei keresés. Megjelenés: egyetlen mező, változtatás után automatikus mentés.
- Keresés: `Nagykanizsa` – városi keresés, nem egész Zala vármegye.
- Keresés: `Nyugat-Dunántúl` – Győr-Moson-Sopron, Vas és Zala vármegye nagyvárosai és megyei keresései.
- Azonos URL többszöri találata ne duplikálódjon.
- Szakmai teszt: üzletvezetői tapasztalat és készletkezelési / értékesítési készség legyen releváns más megnevezésű kereskedelmi hirdetésnél; a hiányzó kötelező engedély maradjon kizáró ok.
- Render Logs: `AI Fejvadasz verified job counts` → checked / verified / rejected kategóriák; ettől látszik, **hol** vesznek el találatok. Nem elég csak az alkalmazásban látható darabszám.

Egységteszt: a megfelelő könyvtárban `node --test test/v096.test.js`.

A csomag **helyi egységtesztekkel** ellenőrzött, de a GitHub Actions APK-fordítása, a Render deploy és az élő Brave/OpenAI keresés **nem futott le** a csomag kiadásakor.
