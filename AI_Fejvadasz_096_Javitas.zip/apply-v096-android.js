'use strict';
/** Build-time overlay: one visible location input with optional suggestions.
 * Run from the extracted Android project's root, AFTER v0.9.5 HTML overlay.
 */
const fs=require('node:fs');
const path=require('node:path');
const files=['app/src/main/assets/index.html','pwa/index.html'];
const appFiles=['app/src/main/assets/app.js','pwa/app.js'];
const extraCities=['Budapest','Érd','Dunakeszi','Gödöllő','Vác','Szentendre','Budaörs','Győr','Sopron','Mosonmagyaróvár',
 'Szombathely','Sárvár','Körmend','Zalaegerszeg','Nagykanizsa','Keszthely','Hévíz','Lenti',
 'Pécs','Komló','Kaposvár','Siófok','Székesfehérvár','Dunaújváros','Veszprém','Pápa',
 'Tatabánya','Esztergom','Miskolc','Kazincbarcika','Eger','Gyöngyös','Salgótarján',
 'Debrecen','Hajdúszoboszló','Nyíregyháza','Szolnok','Jászberény','Kecskemét','Baja','Békéscsaba','Gyula','Szeged','Hódmezővásárhely'];
const esc=s=>String(s).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;');
for(const rel of files){
 const full=path.join(__dirname,rel),original=fs.readFileSync(full,'utf8');
 if(original.includes('data-v096-single-location')){console.log(rel+': már kész');continue;}
 if(!original.includes('id="v091AreaPreset"')||!original.includes('id="v09RegionPanel"')||!original.includes('id="pLocations"'))throw Error(rel+': nem 0.9.5 Android HTML');
 const select=original.match(/<select id="v091AreaPreset"[\s\S]*?<\/select>/);
 if(!select)throw Error(rel+': a 0.9.5-ös megyeválasztó hiányzik');
 const items=[...select[0].matchAll(/<option value="([^"]+)"/g)].map(x=>x[1]).filter(Boolean);
 const suggestions=[...new Set([...items,...extraCities])];
 const datalist='<datalist id="v096LocationSuggestions">'+suggestions.map(v=>'<option value="'+esc(v)+'"></option>').join('')+'</datalist>';
 const panel=`<div class="white bigmargin" id="v09RegionPanel" data-v096-single-location="true" style="border:2px solid #cab5ef">
  <h3>📍 Hol keressünk állásokat?</h3>
  <p class="tiny muted">Egyetlen mező: válassz vagy írj be várost, vármegyét, esetleg régiót. A vármegyénél először a nagyvárosokban keresünk, majd a vármegye egészében. Több helyet vesszővel adhatsz meg.</p>
  <div class="field"><label for="v09Region">Keresési város vagy vármegye</label>
   <input id="v09Region" type="text" list="v096LocationSuggestions" placeholder="pl. Zala vármegye vagy Nagykanizsa" onchange="v09SaveRegion()" onkeydown="if(event.key==='Enter'){event.preventDefault();v09SaveRegion();this.blur();}">
   ${datalist}
   <small>Automatikusan mentjük, amint kiválasztod vagy beírod. „Megye” és „vármegye” egyenértékű.</small>
  </div>
 </div>`;
 let html=original.replace(/<div class="white bigmargin" id="v09RegionPanel"[\s\S]*?(?=<div class="banner purple" id="aiJobRegionInfo")/,panel);
 if(html===original)throw Error(rel+': régiópanel-csere nem sikerült');
 // Keep an invisible field for the existing profile-save/restore logic. Only one visible location control remains.
 const previous=html;
 html=html.replace(/<div class="field"><label>Elfogadott települések \/ területek<\/label><input id="pLocations"[^>]*><small>[^<]*<\/small><\/div>/,
                   '<input type="hidden" id="pLocations">');
 if(previous===html)throw Error(rel+': profiloldali második helymező nem található');
 html=html.replace(/20 napnál/g,'30 napnál').replace(/20 napos/g,'30 napos');
 html=html.replace('Keresési régió: állítsd be a Profil → Elfogadott települések / területek mezőben.',
                   'Keresési hely: add meg a fenti egyetlen mezőben.');
 fs.writeFileSync(full,html,'utf8');
 console.log(rel+': egyetlen helyválasztó készen');
}
for(const rel of appFiles){const full=path.join(__dirname,rel);if(!fs.existsSync(full))continue;
 let source=fs.readFileSync(full,'utf8'),changed=source.replace(/20 napnál/g,'30 napnál').replace(/20 napos/g,'30 napos').replace('Nincs beállítva: Profil → Elfogadott települések / területek',
                                                 'Nincs beállítva: Állások → Keresési város vagy vármegye');
 if(changed!==source)fs.writeFileSync(full,changed,'utf8');
}
