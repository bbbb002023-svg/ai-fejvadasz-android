'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),vm=require('node:vm'),{spawnSync}=require('node:child_process');
const ROOT=path.resolve(__dirname,'..');
const fakeGeo={
 norm:s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim(),
 parsePreferences(p){
  const input=String(p.locations||''), cities=new Set(),counties=new Set();
  for(const x of input.split(/[,;\n]/).map(x=>x.trim()).filter(Boolean)){
   if(x==='Nyugat-Dunántúl')for(const c of ['Győr-Moson-Sopron','Vas','Zala'])counties.add(c);
   else if(/Zala (vár)?megye|Zala megye/.test(x))counties.add('Zala');
   else if(/Vas (vár)?megye|Vas megye/.test(x))counties.add('Vas');
   else if(x==='Nagykanizsa'||x==='Keszthely'||x==='Győr')cities.add(x.toLowerCase());
   else if(x==='Budapest')counties.add('Budapest');
  }
  return {cities,counties};
 }
};
function smart(){const mod={exports:{}},code=fs.readFileSync(path.join(ROOT,'smart-discovery.js'),'utf8');
 vm.runInNewContext(code,{module:mod,exports:mod.exports,require:p=>{if(p==='./hu-geo')return fakeGeo;throw Error(p);},console});return mod.exports;}
test('vármegyét a nagyvárosok keresése követi, és csak aztán jön a megyei kör',()=>{
 const S=smart(),plans=S.buildSearchPlans({locations:'Zala vármegye',targetRoles:'üzletvezető'});
 assert.equal(plans[0].kind,'city');assert.deepEqual([...plans[0].places],['Zalaegerszeg','Nagykanizsa']);
 const countyIdx=plans.findIndex(p=>p.kind==='county');assert.ok(countyIdx>0);
 assert.ok(plans.slice(0,countyIdx).every(p=>p.kind==='city'));
 assert.ok(plans[countyIdx].places.includes('Zala megye')&&plans[countyIdx].places.includes('Zala vármegye'));
 assert.ok(plans.length<=8);
});
test('egyetlen beállítás város, megye vagy régió lehet; több megyénél a városok váltakoznak',()=>{
 const S=smart(),p=S.buildSearchPlans({locations:'Nyugat-Dunántúl'});
 assert.deepEqual([...p[0].places],['Győr','Szombathely']);
 const c=p.filter(x=>x.kind==='county').flatMap(x=>x.places);
 for(const n of ['Győr-Moson-Sopron','Vas','Zala']){assert.ok(c.includes(n+' megye'));assert.ok(c.includes(n+' vármegye'));}
 const city=S.buildSearchPlans({locations:'Nagykanizsa'});assert.equal(city[0].kind,'city');assert.ok(city[0].places.includes('nagykanizsa'));
});
test('az alap indexQuery továbbra is tartalmazza a két megyei megnevezést',()=>{
 const S=smart();for(const m of ['broad','role']){
  const q=S.indexQuery({locations:'Zala megye',__smartMode:m,targetRoles:'értékesítő'},'profession.hu');
  assert.match(q,/"Zala megye"/);assert.match(q,/"Zala vármegye"/);assert.ok(q.length<=275);
 }
 assert.throws(()=>S.indexQuery({locations:'Zala megye'},'https://evil.host/x'));
});
test('minden felfedezett URL egyszer szerepel, vármegye előtt tényleges városkeresés fut',async()=>{
 const S=smart(),kinds=[],urls=[];
 const links=await S.fetchExpandedLinks({key:'example',src:{domain:'profession.hu'},profile:{locations:'Zala megye'},queryCount:8,
  fetchIndexedLinks:async(_k,_src,profile)=>{kinds.push(profile.__smartPlan.kind);let q=S.indexQuery(profile,'profession.hu');urls.push(q);
   return [{url:'https://example.hu/allas/1'},{url:'https://example.hu/allas/1'}];}});
 assert.equal(links.length,1);assert.ok(kinds.indexOf('county')>kinds.indexOf('city'));
 assert.ok(urls.some(q=>q.includes('Nagykanizsa')));assert.ok(urls.some(q=>q.includes('Zala megye')));
 assert.equal(S.queryCount({}),8);assert.equal(S.queryCount({JOB_SMART_QUERIES_PER_SOURCE:'4'}),4);
});
test('nem dob el puha kulcsszó-eltérést a kemény kizáró feltételekkel együtt',()=>{
 const S=smart();assert.equal(S.notHardExcluded({fit:{eligible:false,blockers:['más munkakör megnevezés']}}),true);
 assert.equal(S.notHardExcluded({fit:{blockers:['Kötelező jogosítvány hiánya']}}),false);
});
test('a UI-átalakító egy látható, automatikusan mentett helymezőt hagy meg',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'fv096-ui-'));
 const src=`<html><div class="field"><label>Elfogadott települések / területek</label><input id="pLocations" placeholder="pl. Budapest, Budaörs"><small>Vesszővel elválasztva. Az eltérő helyszínt a motor kizárja.</small></div><div class="white bigmargin" id="v09RegionPanel" style="border:2px solid #cab5ef"><h3>1. lépés</h3><select id="v091AreaPreset"><option value="Zala vármegye">Zala vármegye</option><option value="Zala megye">Zala megye</option></select><input id="v09Region"></div><div class="banner purple" id="aiJobRegionInfo">Keresési régió: állítsd be a Profil → Elfogadott települések / területek mezőben.</div></html>`;
 try{
  fs.copyFileSync(path.join(ROOT,'apply-v096-android.js'),path.join(dir,'apply-v096-android.js'));
  for(const prefix of ['app/src/main/assets','pwa']){fs.mkdirSync(path.join(dir,prefix),{recursive:true});fs.writeFileSync(path.join(dir,prefix,'index.html'),src);}
  const run=()=>spawnSync(process.execPath,[path.join(dir,'apply-v096-android.js')],{encoding:'utf8'});
  const first=run();assert.equal(first.status,0,first.stderr);
  const html=fs.readFileSync(path.join(dir,'app/src/main/assets/index.html'),'utf8');
  assert.match(html,/data-v096-single-location/);assert.match(html,/id="pLocations" type="hidden"|type="hidden" id="pLocations"/);
  assert.equal((html.match(/id="v09Region"/g)||[]).length,1);assert.ok(!html.includes('id="v091AreaPreset"'));
  assert.match(html,/onchange="v09SaveRegion\(\)"/);
  assert.equal(run().status,0,'idempotent');
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
test('a szerver patch a meglévő AI promptot szemantikusra cseréli és nem települ kétszer',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'fv096-server-'));
 try{
  for(const file of ['apply-v096-server.js','smart-discovery.js'])fs.copyFileSync(path.join(ROOT,file),path.join(dir,file));
  fs.writeFileSync(path.join(dir,'hu-geo.js'),`module.exports={norm:${fakeGeo.norm.toString()},parsePreferences:${fakeGeo.parsePreferences.toString().replace(/^parsePreferences\(/,'function(')}};`);
  fs.writeFileSync(path.join(dir,'job-search.js'),`const SMART=require('./smart-discovery');\nconst instructions=\`Régi egyszavas AI\`;\nconst x=REPAIR.rankWithRecovery(p,scored,{maxCalls:28});`);
  fs.writeFileSync(path.join(dir,'server.js'),"const VERSION='0.9.5';");
  fs.writeFileSync(path.join(dir,'v09-verify.js'),"const MAX_HTML=1_200_000, FRESH_DAYS=20;");
  const run=()=>spawnSync(process.execPath,[path.join(dir,'apply-v096-server.js')],{encoding:'utf8'});
  const first=run();assert.equal(first.status,0,first.stderr||first.stdout);
  const job=fs.readFileSync(path.join(dir,'job-search.js'),'utf8');assert.match(job,/AI_FV_SEMANTIC_V096/);
  assert.match(job,/átvihető/);assert.match(job,/maxCalls:48/);assert.equal(run().status,0);
  assert.match(fs.readFileSync(path.join(dir,'server.js'),'utf8'),/0\.9\.6/);
  assert.match(fs.readFileSync(path.join(dir,'v09-verify.js'),'utf8'),/FRESH_DAYS=30/);
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
