# AI Fejvadász – OpenAI szerver, 0.6 teszt

Ez a csomag a saját OpenAI API-kulcsoddal használható **teszt háttérszerver**. Az API-kulcsot SOHA ne töltsd GitHubra, ne írd az Android APK-ba, és ne küldd el chatben.

## Mire képes?
- `/health` ellenőrző végpont: konfiguráció állapota (nem hívja meg az OpenAI-t).
- `/api/ai` hitelesített végpont: CV-elemzés, támogató AI-üzenet, CV-tervezet, interjúkérdések, csevegés.
- Az OpenAI Responses API-t használja; `store: false`.
- Csak a felhasználó kifejezett engedélyével küldj CV-szöveget.

## Render telepítés a telefonról
1. Töltsd fel az `AI_Fejvadasz_AI_Szerver.zip` fájlt a GitHub `bbbb002023-svg/ai-fejvadasz-android` tároló gyökerébe. A meglévő Android ZIP-et ne töröld.
2. A render.com oldalon **New > Web Service**, csatlakoztasd az adott GitHub tárolót.
3. Runtime: **Node**. Build command: `unzip -oq AI_Fejvadasz_AI_Szerver.zip -d ai-server && cd ai-server && npm install --omit=dev`
4. Start command: `cd ai-server && npm start`
5. Secret environment variables a Render **Environment** felületen:
   - `OPENAI_API_KEY`: a titkos API-kulcs; csak ide írd be.
   - `AI_APP_ACCESS_TOKEN`: külön, erős véletlen titok, legalább 20 karakter. NEM az OpenAI API-kulcs. Ezt majd az Android tesztalkalmazás kapcsolati beállításánál is meg kell adni.
   - `OPENAI_MODEL`: `gpt-6-luna` (csak ha a projekthez hozzáférhető; szükség esetén más engedélyezett modell)
   - `AI_MAX_DAILY_REQUESTS`: `20` (tesztkeret, nem pénzbeli kemény limit).
6. A nyilvános Render HTTPS címet nyisd meg `/health` útvonallal; `configured:true` jelzi, hogy a két titok be van állítva. A HTTP végpontot ne tedd nyilvános tesztoldalhoz hozzáférhetővé az app-token nélkül.
7. A **0.6-os Android-appban** add meg a Render HTTPS címet és a *külön* `AI_APP_ACCESS_TOKEN` értéket (nem az OpenAI-kulcsot). A 0.5.1-es appban még nincs ilyen beállítás.

## Biztonsági korlátok
- Ez **egyetlen tesztelőre** készült minimális proxy, nem kész többfelhasználós regisztrációs rendszer. Az app-token megosztása tilos; éles üzem előtt fiókonkénti szerveroldali hitelesítés, sebességkorlát, adatkezelési tájékoztató, naplózási és törlési szabályzat szükséges.
- A szerver nem tárol önéletrajzot, nem jelentkezik állásokra automatikusan.
- Render ingyenes szolgáltatása alvó módba kerülhet; az ingyenesség és a hozzáférési feltételek változhatnak.
- API-díjazás az OpenAI-fiókhoz tartozik, a ChatGPT-előfizetéstől függetlenül.
