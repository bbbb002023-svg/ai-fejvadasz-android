# AI Fejvadász 0.7 – Render telepítés a meglévő szerverre

A szerver `server.js`, `job-search.js` és `engine.js` modulokból áll. A ZIP a szerverfájlokat gyökérszinten tartalmazza.

A Render Web Service Build Command beállítása:
`unzip -oq AI_Fejvadasz_AI_Szerver_v07.zip -d ai-server && cd ai-server && npm install --omit=dev`

Start Command:
`cd ai-server && npm start`

Environment: `OPENAI_API_KEY`, `AI_APP_ACCESS_TOKEN`, `OPENAI_MODEL` (`gpt-5-mini`), `AI_MAX_DAILY_REQUESTS` (`20`). Ezeket nem szabad a projekt ZIP-be vagy GitHubra írni.

`/health` – nyilvános konfigurációs jelzés.
`POST /api/ai` – hitelesített AI-asszisztens, CV elemzés.
`POST /api/jobs/start` – hitelesített keresés indítása.
`GET /api/jobs/status?id=<uuid>` – hitelesített keresés állapota.

A forráslista `JOB_SOURCES` környezeti változóban definiálható, pl. `lever:qualysoft,greenhouse:wise`. A kezdőforrások csak részleges országos lefedettséget adnak; a keresés nem képes az internet összes állásportálját bejárni.

**Korlát:** keresések jelenleg memóriában tárolódnak. Render újraindításkor elvesznek, nincs push, nincs per-user auth, nincs multi-user adatbázis. Publikus kiadás előtt ezeket feltétlenül pótolni kell. A titkos hozzáférési token nem tehető az APK forráskódjába; Android Keystore-ban tároljuk helyben.
