'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {searchManager,hungarian,standardize}=require('../job-search');
const mockFetch=async (url)=>({ok:true,json:async()=>{
 if(String(url).includes('qualysoft'))return [
  {id:'hu-it-1',text:'Java fejlesztő',hostedUrl:'https://jobs.lever.co/qualysoft/hu-it-1',categories:{location:'Budapest'},descriptionPlain:'Backend fejlesztés, ügyfél-egyeztetés, Java.',lists:[]},
  {id:'hu-mechanic',text:'Autószerelő',hostedUrl:'https://jobs.lever.co/qualysoft/hu-mechanic',categories:{location:'Budapest'},descriptionPlain:'Gépjármű javítása; szakirányú végzettség.'},
  {id:'it-foreign',text:'Software developer',hostedUrl:'https://jobs.lever.co/qualysoft/it-foreign',categories:{location:'London'}}];
 return [];
 }});
const waitUntil=async (fn,max=1500)=>{const start=Date.now();while(Date.now()-start<max){const x=fn();if(x.status!=='running')return x;await new Promise(r=>setTimeout(r,15));}throw Error('Search did not finish');};
test('Hungarian place filter rejects foreign jobs',()=>{assert.equal(hungarian('Budapest, Hungary'),true);assert.equal(hungarian('London, UK'),false);});
test('search engine collects real-URL Hungarian jobs, excludes unrelated profession and reports real progress',async()=>{
 const engine=searchManager({env:{JOB_SOURCES:'lever:qualysoft'},fetchImpl:mockFetch,rankFn:async()=>[{id:'lever_qualysoft_hu-it-1',score:92,reason:'Szakmailag megfelelő Java tapasztalat',missing:[],excluded:false}]});
 const started=engine.start({targetRoles:'Java fejlesztő',pastRoles:'Java programozó',skills:['Java'],city:'Budapest',locations:'Budapest',years:6,education:'egyetem'});
 assert.equal(started.status,'running');
 const done=await waitUntil(()=>engine.status(started.id));
 assert.equal(done.status,'done');assert.equal(done.progress,100);assert.equal(done.checked,1);
 assert.equal(done.found,2);assert.equal(done.jobs.length,1);assert.equal(done.jobs[0].title,'Java fejlesztő');assert.equal(done.jobs[0].score,92);
 assert.match(done.jobs[0].url,/^https:\/\//);
 assert.equal(done.aiAnalyzed,true);
});
test('error in public source yields a completed search with source error, never invented postings',async()=>{
 const engine=searchManager({env:{JOB_SOURCES:'greenhouse:wise'},fetchImpl:async()=>({ok:false,status:503}),rankFn:async()=>[]});
 const s=engine.start({targetRoles:'sales manager'});const done=await waitUntil(()=>engine.status(s.id));
 assert.equal(done.progress,100);assert.deepEqual(done.jobs,[]);assert.equal(done.errors.length,1);
});
