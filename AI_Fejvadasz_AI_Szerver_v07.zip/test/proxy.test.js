const test=require('node:test');const assert=require('node:assert/strict');
const {createApp,normalizeInput,resultFromResponse,PATCH_KEYS}=require('../server');
const makePatch=()=>Object.fromEntries(PATCH_KEYS.map(k=>[k,k==='skills'?[]:'']));
test('CV szöveg validálása és nem kívánt személyes mezők szűrése',()=>{
 const x=normalizeInput({action:'analyze_resume',resumeText:'Kereskedelmi tapasztalat, értékesítési vezető és ügyfélkapcsolati munkatapasztalat.',profile:{name:'Teszt',photo:'BASE64_SECRET',password:'szigorúan titkos',skills:['értékesítés']}});
 assert.equal(x.profile.password,undefined);assert.equal(x.profile.photo,undefined);assert.equal(x.profile.name,'Teszt');
});
test('API hitelesítés, strukturált AI-válasz és store:false',async()=>{
 const secret='local-test-app-token-very-secret-123';let forwarded;
 const mock=async (_u,options)=>{forwarded=JSON.parse(options.body);return {ok:true,json:async()=>({output:[{content:[{type:'output_text',text:JSON.stringify({message:'Értékesítési tapasztalatod jól hasznosítható.',profile_patch:{...makePatch(),pastRoles:'üzletvezető'},missing:['végzettség'],suggested_roles:['értékesítési vezető'],cv_draft:'',interview_questions:[]})}]}]})}};
 const app=createApp({OPENAI_API_KEY:'test-key',AI_APP_ACCESS_TOKEN:secret,OPENAI_MODEL:'gpt-6-luna'},mock);
 await new Promise(r=>app.listen(0,'127.0.0.1',r));const u=`http://127.0.0.1:${app.address().port}`;
 try {
  const no=await fetch(u+'/api/ai',{method:'POST',body:'{}'});assert.equal(no.status,401);
  const r=await fetch(u+'/api/ai',{method:'POST',headers:{Authorization:`Bearer ${secret}`,'Content-Type':'application/json'},body:JSON.stringify({action:'analyze_resume',resumeText:'Üzletvezetői tapasztalat, értékesítési eredmények, tanácsadás.'})});
  assert.equal(r.status,200);assert.equal((await r.json()).result.profile_patch.pastRoles,'üzletvezető');
  assert.equal(forwarded.store,false);assert.equal(forwarded.model,'gpt-6-luna');assert.equal(forwarded.text.format.type,'json_schema');
 } finally {await new Promise(r=>app.close(r));}
});
test('Chat üres kérdés elutasítása',()=>{assert.throws(()=>normalizeInput({action:'chat',message:''}));});
