AI Fejvadász 0.8.1 – Render

A ZIP a Renderen a repository gyökerében található. A Build Command:
  unzip -oq AI_Fejvadasz_AI_Szerver_v081_CV_Javitas.zip -d ai-server && cd ai-server && npm install --omit=dev
A Start Command:
  cd ai-server && npm start

A meglévő OPENAI_API_KEY és AI_APP_ACCESS_TOKEN titkokat NEM kell módosítani.
AI_MAX_DAILY_REQUESTS: az alkalmazás összes AI-hívásának szerverenkénti napi korlátja.
OPENAI_CV_MODEL: opcionális, alapértelmezése gpt-4.1-mini.
OPENAI_MODEL: más AI-funkciók modellje (például gpt-5-mini).

Sikeres telepítés ellenőrzése (titok nélkül):
  https://ai-fejvadasz-android.onrender.com/health
A válasz tartalmazza: "version":"0.8.1","cvAsync":true.

Az /api/cv/start egy rövid, hozzáférési tokennel védett POST kérés, az
/api/cv/status?id=... védett GET végpont. A Render ingyenes példánya újraindulhat,
így a háttérfeladatok memóriából elveszhetnek. Nyilvános, többfelhasználós kiadás
előtt tartós tárolás és felhasználónkénti hozzáférés szükséges.
