'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {createApp,PATCH_KEYS}=require('../server');
const token='TEST_ACCESS_TOKEN_2026_FOR_CV_TESTING';
const resume='Értékesítési koordinátor, Szeged. 2020-2025 csapatok beosztásának szervezése, megrendelések követése, ügyfélpanaszok megoldása.';
const base={action:'analyze_resume',resumeText:resume,profile:{city:'Szeged'}};
const patch=Object.fromEntries(PATCH_KEYS.map(k=>[k,k==='skills'?[]:'']));
const evidence=Object.fromEntries(PATCH_KEYS.map(k=>[k,'']));
const answer={message:'A koordináció erősséged.',profile_patch:{...patch,pastRoles:'Értékesítési koordinátor'},field_evidence:{...evidence,pastRoles:'Értékesítési koordinátor'},missing:[],suggested_roles:[],cv_draft:'',interview_questions:[]};
async function withServer(mock,fn){const app=createApp({OPENAI_API_KEY:'TEST',AI_APP_ACCESS_TOKEN:token,OPENAI_MODEL:'gpt-5-mini'},mock);await new Promise(r=>app.listen(0,'127.0.0.1',r));const url=`http://127.0.0.1:${app.address().port}`;try{await fn(url)}finally{await new Promise(r=>app.close(r))}}
const post=(url,data)=>fetch(url+'/api/cv/start',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify(data)}).then(async r=>({status:r.status,body:await r.json()}));
const status=(url,id)=>fetch(url+'/api/cv/status?id='+id,{headers:{Authorization:`Bearer ${token}`}}).then(async r=>({status:r.status,body:await r.json()}));
test('Async CV: immediate job ID, later structured result, no duplicate paid request',async()=>{
 let calls=0,used;
 const mock=async(_url,options)=>{calls++;used=JSON.parse(options.body);await new Promise(r=>setTimeout(r,90));return {ok:true,json:async()=>({output:[{content:[{type:'output_text',text:JSON.stringify(answer)}]}]})}};
 await withServer(mock,async url=>{
  const initial=await post(url,base);assert.equal(initial.status,202);assert.equal(initial.body.job.status,'running');
  const id=initial.body.job.id;assert.match(id,/^[a-f0-9-]{36}$/);
  const again=await post(url,base);assert.equal(again.body.job.id,id);assert.equal(calls,1);
  const pending=await status(url,id);assert.equal(pending.body.job.status,'running');
  await new Promise(r=>setTimeout(r,110));
  const finished=await status(url,id);assert.equal(finished.body.job.status,'completed');
  assert.equal(finished.body.job.result.profile_patch.pastRoles,'Értékesítési koordinátor');
  const cached=await post(url,base);assert.equal(cached.body.job.id,id);assert.equal(calls,1);
  assert.equal(used.model,'gpt-4.1-mini');assert.equal(used.store,false);
 });
});
test('Async CV: no secrets, quota errors are differentiated, retry allowed after failure',async()=>{
 let calls=0;
 const mock=async()=>{calls++;return {ok:false,status:429,json:async()=>({error:{code:'insufficient_quota'}})}};
 await withServer(mock,async url=>{
  const noAuth=await fetch(url+'/api/cv/start',{method:'POST',body:'{}'});assert.equal(noAuth.status,401);
  const initial=await post(url,base),id=initial.body.job.id;
  await new Promise(r=>setTimeout(r,30));
  const failed=await status(url,id);
  assert.equal(failed.body.job.status,'error');assert.match(failed.body.job.error,/egyenleg/i);
  const again=await post(url,base);assert.notEqual(again.body.job.id,id);assert.equal(calls,2);
  const health=await fetch(url+'/health').then(r=>r.json());assert.equal(health.version,'0.8.1');assert.equal(health.cvAsync,true);
 });
});
