AI Fejvadász – 0.8.2.1 | BRAVE HTTP 422 HIBAJAVÍTÁS
======================================================

A 0.8.2-es szerverben a Brave keresés country=HU paramétert küldött.
A Brave Web Search API ezt az országkódot NEM támogatja a kereséshez.
Javítás: country=ALL, search_lang=hu, továbbra is site:profession.hu,
site:cvonline.hu, site:whc.hu és site:hsa.hu célzott keresések.

Kijavítottuk a 100%-os ál-sikert is: ha minden forrás hibázik, akkor
status=failed és progress=0, nem sikeres 100%-os keresés jelenik meg.
Az API 422-es hibánál a szerver a hibás paraméter nevét jelzi a titkos
API-kulcs és a személyes CV-adatok megjelenítése nélkül.

Csak a SZERVER javult, a 0.8.2-es Android APK maradhat.

Telepítés:
1. ZIP feltöltése a GitHub repo gyökerébe:
   AI_Fejvadasz_AI_Szerver_v0821_Brave_Javitas.zip
2. Render > ai-fejvadasz-android > Settings > Build & Deploy:
   Build Command: unzip -oq AI_Fejvadasz_AI_Szerver_v0821_Brave_Javitas.zip -d ai-server && cd ai-server && npm install --omit=dev
   Start Command: cd ai-server && npm start
3. Mentés és új deploy; health endpoint: /health
   A válaszban version=0.8.2.1 és jobIndexSources=true legyen.
4. Az első ellenőrző álláskeresést az appban indítsd el.

Titkos API kulcsokat NE másolj az APK-ba, a GitHubra, ide vagy képernyőképre.

Teszt: node --test (a szervermappában). Az élő Brave-hívás csak a
felhasználó már beállított kulcsával, telepítés után ellenőrizhető.
A Profession/CVonline linkek továbbra sem bizonyítottan aktív hirdetések.
