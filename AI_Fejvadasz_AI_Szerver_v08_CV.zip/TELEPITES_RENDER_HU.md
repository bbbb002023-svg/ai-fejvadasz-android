# AI Fejvadász 0.7.1 – Render telepítés a meglévő szerverre

A szerver `server.js`, `job-search.js` és `engine.js` modulokból áll. A ZIP a szerverfájlokat gyökérszinten tartalmazza.

A Render Web Service Build Command beállítása:
`unzip -oq AI_Fejvadasz_AI_Szerver_v071_HU.zip -d ai-server && cd ai-server && npm install --omit=dev`

Start Command:
`cd ai-server && npm start`

Environment: `OPENAI_API_KEY`, `AI_APP_ACCESS_TOKEN`, `OPENAI_MODEL` (`gpt-5-mini`), `AI_MAX_DAILY_REQUESTS` (`20`). Ezeket nem szabad a projekt ZIP-be vagy GitHubra írni.

`/health` – nyilvános konfigurációs jelzés.
`POST /api/ai` – hitelesített AI-asszisztens, CV elemzés.
`POST /api/jobs/start` – hitelesített keresés indítása.
`GET /api/jobs/status?id=<uuid>` – hitelesített keresés állapota.

A forráslista `JOB_SOURCES` környezeti változóban definiálható, pl. `lever:qualysoft,greenhouse:wise`. A kezdőforrások csak részleges országos lefedettséget adnak; a keresés nem képes az internet összes állásportálját bejárni.

**Korlát:** keresések jelenleg memóriában tárolódnak. Render újraindításkor elvesznek, nincs push, nincs per-user auth, nincs multi-user adatbázis. Publikus kiadás előtt ezeket feltétlenül pótolni kell. A titkos hozzáférési token nem tehető az APK forráskódjába; Android Keystore-ban tároljuk helyben.

## Magyar portál bekapcsolása
A korábbi öt külföldi ATS próbaállásforrás NINCS alapértelmezetten bekapcsolva. A magyar Jooble.hu keresése a hivatalos REST API-n keresztül működik, ha a Render Environment Variables résznél beállítod a `JOOBLE_API_KEY` változót (nem az OpenAI API-kulcsot!).

Hivatalos kulcsigénylés: https://hu.jooble.org/api/about . A szolgáltató ingyenes kulcsa 500 lekérdezést enged összesen (nem havonta). Minden keresési indítás egy Jooble API-lekérdezést használ. A kulcsot ne töltsd fel GitHubra és ne oszd meg chatben.

A Profession.hu automatizált adatgyűjtését a szolgáltatási feltételek tiltják engedély nélkül, ezért az NINCS bekötve. A CVonline integrációhoz is megfelelő jogosult hozzáférés kell. Opcionális engedélyezett céges Lever/Greenhouse boardokat `JOB_SOURCES=lever:cegazonosito,greenhouse:cegazonosito` formában lehet hozzárendelni. A keresés eredményében láthatóak a tényleges források és forráshibák.

A Render Auto-Deploy minden GitHub commitnál fut, ez nem kívánatos; kapcsold ki és kézzel telepítsd, amikor szerverkódot változtatsz.
