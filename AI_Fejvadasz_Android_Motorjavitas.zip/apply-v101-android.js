'use strict';
/** Apply AFTER the v0.9.7 Android patch. Fail without overwriting on changed UI. */
const fs=require('node:fs'),path=require('node:path');
const root=__dirname;
const panel=`<div class="white bigmargin" id="aiCVPortalsV101" data-ai-cv-portals-v101="true" style="border:2px solid #b8a0f7;padding:16px;margin:12px 0">
 <h3>🔎 Két külön CV-portálkereső</h3>
 <p class="tiny muted">A Profession és a CVonline keresése a CV-ből jóváhagyott munkakörökkel, készségekkel és helyszínekkel. A portálokon megnyitott keresés nem garantál aktív hirdetést.</p>
 <label class="checkrow"><input type="checkbox" id="aiExternalPortalConsent" onchange="aiPortalConsentChanged(this.checked)"><span><b>Engedélyezem a portálok külső keresőindexének használatát.</b> Csak a kiválasztott munkakörök, készségek és helyszínek kerülnek ki; a teljes CV, név és elérhetőség nem. A kiegészítő Brave-keresés a szolgáltatói kvótát fogyaszthatja.</span></label>
 <div class="flow" style="gap:8px;margin-top:12px;flex-wrap:wrap">
  <button class="button secondary" style="flex:1" type="button" onclick="aiPortalOpen('profession')">Profession keresése ↗</button>
  <button class="button secondary" style="flex:1" type="button" onclick="aiPortalOpen('cvonline')">CVonline keresése ↗</button>
 </div>
 <p class="tiny muted">A saját országos index és a portálkereső előtalálatai lent, külön <b>nem ellenőrzött linkekként</b> láthatók, ha a v1.0.1-es régi AI-szerverhíd is telepítve van. A fő, ellenőrzött álláslistába nem kerülnek át automatikusan.</p>
</div>`;
function updateHtml(data,dir){
 if(data.includes('data-ai-cv-portals-v101'))return data;
 const anchor='<div class="white bigmargin" id="aiJobSearchPanel">';
 if(data.split(anchor).length!==2)throw Error(dir+': nem ismert Állások-panel');
 const script='<script src="ai-job-search.js"></script>';
 if(data.split(script).length!==2)throw Error(dir+': nem ismert script sorrend');
 return data.replace(anchor,panel+anchor).replace(script,'<script src="cv-portals-ui.js"></script>'+script);
}
function updateSearchJS(data,dir){
 if(data.includes('AI_FV_APP_NATIONAL_V101_RENDER'))return data;
 const start="const profile=window.getSearchProfile?.();";
 if(data.split(start).length!==2)throw Error(dir+': nem ismert keresésindító');
 const box=`// AI_FV_APP_NATIONAL_V101_RENDER: unverified links appear ONLY in a labeled research list.
function showDiscovered(links){
 const root=$('aiJobLinkResults');if(!root)return;root.replaceChildren();root.classList.add('hide');
 const engineStatus=lastEngineStatus;
 if(engineStatus){
  const labels={ok:'Elérhető',searched:'Lefutott',empty:'Nincs találat',failed:'Hiba',unavailable:'Nem elérhető',disabled:'Nincs beállítva',not_configured:'Nincs beállítva',no_explicit_consent:'Hozzájárulás szükséges',profile_incomplete:'Hiányos szakmai profil',skipped:'Kihagyva',active:'Aktív',awaiting_verified_training:'Ellenőrzött tanítómintákra vár'};
  const rows=[
   ['Profession.hu',engineStatus.boardStatuses?.profession_cv||engineStatus.cvPortalsStatus],
   ['CVonline.hu',engineStatus.boardStatuses?.cvonline_cv||engineStatus.cvPortalsStatus],
   ['Országos index',engineStatus.nationalStatus],
   ['AI CV-illesztő',engineStatus.matcherStatus],
   ['Szemantikus keresés',engineStatus.semanticStatus]
  ];
  const list=document.createElement('ul');
  list.setAttribute('aria-label','Keresőmotorok állapota');
  for(const [name,state] of rows){
   const row=document.createElement('li');
   row.textContent=name+' – '+(labels[state]||'Nincs állapotadat');
   list.appendChild(row);
  }
  root.appendChild(list);
  root.classList.remove('hide');
 }
 const seen=new Set(),items=[];
 for(const item of (Array.isArray(links)?links:[])){
  try{const u=new URL(String(item?.url||''));if(u.protocol!=='https:'||u.username||u.password||u.port||seen.has((item.category||'')+'|'+u.href))continue;
    seen.add((item.category||'')+'|'+u.href);items.push({...item,url:u.href});}catch{}
  if(items.length>=85)break;
 }
 if(!items.length)return;
 const groups=[['profession_cv','Profession.hu – CV-kereső'],['cvonline_cv','CVonline.hu – CV-kereső'],['national_index','Saját országos állásindex'],['other','További felderített linkek']];
 for(const [type,title] of groups){
  const rows=items.filter(x=>(x.category||'other')===type);if(!rows.length)continue;
  const details=document.createElement('details');details.style.marginBottom='10px';
  const summary=document.createElement('summary');summary.textContent=title+' ('+rows.length+') – még nem ellenőrzött';details.appendChild(summary);
  const info=document.createElement('p');info.className='tiny muted';info.textContent='Az eredeti hirdetés érvényességét, dátumát, helyét és feltételeit külön ellenőrizd. Ez nem igazolt állás és nem AI-egyezési százalék.';details.appendChild(info);
  for(const j of rows){const link=document.createElement('a');link.href=j.url;link.target='_blank';link.rel='noopener noreferrer';link.style.cssText='display:block;padding:10px;margin:5px 0;border:1px solid #d8dce8;border-radius:10px';
   const strong=document.createElement('strong');strong.textContent=String(j.title||'Hirdetés').slice(0,140);link.appendChild(strong);
   const meta=document.createElement('div');meta.className='tiny muted';meta.textContent=String(j.source||'Keresőindex').slice(0,130);link.appendChild(meta);details.appendChild(link);}
  root.appendChild(details);
 }
 root.classList.remove('hide');
}
`;
 const old=/function showDiscovered\(links\)\{[\s\S]*?\n\}\n\nfunction configured\(/;
 if(!old.test(data))throw Error(dir+': nem ismert találatmegjelenítő');
 if(!data.includes('lastLinks=[];')||!data.includes('showDiscovered(lastLinks);'))throw Error(dir+': nem ismert keresési állapot');
 data=data.replace('lastLinks=[];','lastLinks=[],lastEngineStatus=null;');
 data=data.replace('lastLinks=links.slice(0,35);showDiscovered(lastLinks);','lastLinks=links.slice(0,35);lastEngineStatus=s.nationalBridge||null;showDiscovered(lastLinks);');
 data=data.replace(old,box+'\nfunction configured(');
 data=data.replace(start,start+"if(profile&&window.aiPortalConsent?.())profile.externalSearchConsent=true;");
 if(!data.includes('lastLinks=links.slice(0,35)'))throw Error(dir+': nem ismert linkkorlát');
 data=data.replace('lastLinks=links.slice(0,35)','lastLinks=links.slice(0,85)');
 const oldMsg="status(s.sourceCount===0?'⚠ Nincs bekötött keresési forrás.':jobs.length?`✓ Ellenőrzés kész: ${jobs.length} friss, dátumozott állás. Az ajánlottak felül.`:'Nincs igazolhatóan friss állás a kiválasztott régióban. Ellenőrizetlen linkeket nem mutatunk.',100,";
 const newMsg="status(s.sourceCount===0&&!links.length?'⚠ Nincs bekötött keresési forrás.':jobs.length?`✓ Ellenőrzés kész: ${jobs.length} friss, dátumozott állás. Az ajánlottak felül.`:links.length?`ℹ ${links.length} előtalálat külön listában. Ezek még nem ellenőrzött hirdetések.`:'Nincs igazolhatóan friss állás a kiválasztott régióban.',100,";
 if(data.split(oldMsg).length!==2)throw Error(dir+': státuszfelirat eltért');
 data=data.replace(oldMsg,newMsg);
 return data;
}
const paths=['app/src/main/assets','pwa'];const staged=[];
for(const dir of paths){
 const html=path.join(root,dir,'index.html'),js=path.join(root,dir,'ai-job-search.js'),ui=path.join(root,dir,'cv-portals-ui.js');
 const uiContent=path.join(root,'pwa','cv-portals-ui.js');
 if(!fs.existsSync(html)||!fs.existsSync(js)||!fs.existsSync(uiContent))throw Error(dir+': az alap Android-projektfájl vagy CV kereső UI hiányzik');
 if(!fs.existsSync(ui))staged.push([ui,fs.readFileSync(uiContent,'utf8')]);
 staged.push([html,updateHtml(fs.readFileSync(html,'utf8'),dir)]);
 staged.push([js,updateSearchJS(fs.readFileSync(js,'utf8'),dir)]);
}
for(const [file,data] of staged)fs.writeFileSync(file,data,'utf8');
console.log('AI Fejvadász Android v1.0.1: két külön CV-portálpanel, engedélyezett indexkeresés és biztonságos országos linklista.');
