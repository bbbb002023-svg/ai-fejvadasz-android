'use strict';
/** Server-only bridge from the existing authenticated Android job search to
 * the separate protected national API. No API credentials enter APK/JS.
 * Both portal search and the national index are RESEARCH LINKS, not verified
 * live job cards. No CV text/name/contact info is sent to the national API.
 */
const DEFAULT_ORIGIN='https://ai-fejvadasz-national-api.onrender.com';
function tidy(v,max=100){return String(v==null?'':v).replace(/[\r\n\t<>"'`{}\[\]|]/g,' ').replace(/\s+/g,' ').trim().slice(0,max)}
function values(raw,{max=5,size=80}={}){
 const xs=Array.isArray(raw)?raw:String(raw||'').split(/[,;\n]+/);
 return [...new Set(xs.map(x=>tidy(x,size)).filter(x=>x.length>1&&!/@|\b(?:tel|telefon|email|e-mail|lakcím|születési|útlevél)\b/i.test(x)))].slice(0,max);
}
function safeProfile(input={}){
 const obj=input&&typeof input==='object'&&!Array.isArray(input)?input:{};
 return {targetRoles:values(obj.targetRoles||obj.targetRole,{max:3,size:70}).join(', '),skills:values(obj.skills,{max:8,size:50}),locations:values(obj.locations||obj.region||obj.city,{max:3,size:55}).join(', '),excludedRoles:values(obj.excludedRoles,{max:5,size:70}).join(', ')};
}
function httpsLink(link,allowedDomain){try{
 const u=new URL(String(link||''));if(u.protocol!=='https:'||u.username||u.password||u.port)return null;
 if(allowedDomain&&!(u.hostname===allowedDomain||u.hostname.endsWith('.'+allowedDomain)))return null;
 u.hash='';return u.toString();
}catch{return null}}
async function postJson(path,body,{origin,token,request,timeoutMs=8500}={}){
 const c=new AbortController(), timer=setTimeout(()=>c.abort(),timeoutMs);
 try{
  const r=await request(origin+path,{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify(body),signal:c.signal});
  if(!r.ok){
   if(path==='/api/v3/cv-portal-search'&&r.status===503){
    const data=await r.json();
    if(['not_configured','unavailable'].includes(data?.status))return data;
   }
   throw Error('national API status '+r.status);
  }
  return await r.json();
 }finally{clearTimeout(timer)}
}
function fromNational(data){
 const list=Array.isArray(data?.jobs)?data.jobs:[];
 return list.slice(0,65).map(x=>({
  url:httpsLink(x.canonical_url||x.url),title:tidy(x.title,140),
  source:'Országos állásindex – eredeti hirdetés ellenőrzendő',verified:false,
  preliminaryRelevance:Number(x.matchedSkillCount)||0,category:'national_index'
 })).filter(x=>x.url&&x.title.length>=3);
}
function fromPortals(data){
 return (Array.isArray(data?.boards)?data.boards:[]).flatMap(b=>{
  const domain=b?.id==='profession_cv'?'profession.hu':b?.id==='cvonline_cv'?'cvonline.hu':null;
  if(!domain)return[];
  return (Array.isArray(b.jobs)?b.jobs:[]).slice(0,12).map(x=>({
   url:httpsLink(x.url,domain),title:tidy(x.title,140),
   source:(domain==='profession.hu'?'Profession.hu':'CVonline.hu')+' – keresőindex, nem ellenőrzött',
   verified:false,preliminaryRelevance:Number(x.preliminaryRelevance)||0,category:b.id
  })).filter(x=>x.url&&x.title.length>=3);
 });
}
function distinct(links,max=85){const urls=new Set();return links.filter(x=>{if(urls.has(x.url))return false;urls.add(x.url);return true}).slice(0,max)}
async function expand(profile,{env=process.env,request=globalThis.fetch,timeoutMs=8500}={}){
 const token=String(env.NATIONAL_API_TOKEN||'').trim();const p=safeProfile(profile);
 if(!p.targetRoles&&!p.skills.length)return {status:'profile_incomplete',links:[],nationalStatus:'skipped',portalsStatus:'skipped'};
 if(!token)return {status:'not_configured',links:[],nationalStatus:'not_configured',portalsStatus:'not_configured'};
 let base;try{const u=new URL(String(env.NATIONAL_API_URL||DEFAULT_ORIGIN));if(u.protocol!=='https:'||u.username||u.password||u.search||u.hash||u.pathname!=='/')throw Error('Invalid URL');base=u.origin}catch{return {status:'invalid_origin',links:[],nationalStatus:'failed',portalsStatus:'failed'}};
 const ctx={origin:base,token,request,timeoutMs};
 const tasks=[postJson('/api/v3/ai/recommend',{...p,limit:65},ctx)];
 // Strictly opt-in to the potentially paid external portal-index queries.
 const permitted=profile?.externalSearchConsent===true;
 if(permitted)tasks.push(postJson('/api/v3/cv-portal-search',{externalSearchConsent:true,profile:p},ctx));
 const results=await Promise.allSettled(tasks);const national=results[0],portal=results[1];
 const nationalStatus=national.status==='fulfilled'?'ok':'failed';
 const portalsStatus=!permitted?'no_explicit_consent':portal.status==='fulfilled'?(portal.value.status||'ok'):'failed';
 const portalBoards=portal?.status==='fulfilled'&&Array.isArray(portal.value.boards)?portal.value.boards:[];
 const boardStatuses=Object.fromEntries(['profession_cv','cvonline_cv'].map(id=>{
  const board=portalBoards.find(item=>item?.id===id);
  return [id,board?.status==='searched'?(board.jobs?.length?'searched':'empty'):board?.status||portalsStatus];
 }));
 const meta=national.status==='fulfilled'?national.value.meta:null;
 const matcherStatus=meta?.ownModel?.key==='matcher'?'active':meta?.ownModel||'unknown';
 const semanticStatus=meta?.semanticStatus||'unknown';
 const portalAvailable=['searched','partial'].includes(portalsStatus);
 const aiReady=matcherStatus==='active'&&semanticStatus==='ok';
 const complete=nationalStatus==='ok'&&aiReady&&(!permitted||portalsStatus==='searched');
 return {status:complete?'ok':nationalStatus==='ok'||portalAvailable?'partial':'unavailable',
   boardStatuses,matcherStatus,semanticStatus,
   links:distinct([...(portal?.status==='fulfilled'?fromPortals(portal.value):[]),...(national.status==='fulfilled'?fromNational(national.value):[])]),
   nationalStatus,portalsStatus,personalDataStored:false,jobDetailsVerified:false};
}
module.exports={tidy,values,safeProfile,httpsLink,postJson,fromNational,fromPortals,distinct,expand};
