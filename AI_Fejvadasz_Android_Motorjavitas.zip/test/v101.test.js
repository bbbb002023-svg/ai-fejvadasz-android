'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),os=require('node:os'),vm=require('node:vm'),{spawnSync}=require('node:child_process');
const root=path.resolve(__dirname,'..'),B=require('../national-bridge');
function fakeFetch({national=[],boards=[]}={}){const calls=[];const fetch=async(u,init)=>{
 calls.push({url:u,init});return {ok:true,status:200,json:async()=>u.includes('/cv-portal-search')?{boards,status:'searched'}:{jobs:national}};
};return {calls,fetch}}
test('Full CV, name and contact details are excluded from server-to-server payload',()=>{
 const p=B.safeProfile({name:'Private Person',email:'private@example.com',phone:'061234',oldCV:'SECRET FULL CV',targetRoles:'Értékesítő',skills:['CRM','MS Excel'],locations:'Budapest'});
 assert.deepEqual(Object.keys(p).sort(),['excludedRoles','locations','skills','targetRoles'].sort());assert.ok(!JSON.stringify(p).includes('SECRET'));assert.ok(!JSON.stringify(p).includes('private'));
});
test('No API key => no network access and no fabricated results',async()=>{
 const {fetch,calls}=fakeFetch();const r=await B.expand({targetRoles:'Projektvezető'},{env:{},request:fetch});assert.equal(r.status,'not_configured');assert.equal(r.links.length,0);assert.equal(calls.length,0);
});
test('National jobs included as research links only; never marked verified',async()=>{
 const {fetch,calls}=fakeFetch({national:[{title:'Senior Sales',canonical_url:'https://jobs.ashbyhq.com/acme/abc',matchedSkillCount:4},{title:'Bad',canonical_url:'javascript:evil()'}]});
 const r=await B.expand({name:'No send',targetRoles:'Senior Sales',skills:['CRM']},{env:{NATIONAL_API_TOKEN:'server-secret'},request:fetch});
 assert.equal(calls.length,1);assert.match(calls[0].url,/\/api\/v3\/ai\/recommend$/);assert.equal(JSON.parse(calls[0].init.body).name,undefined);assert.equal(calls[0].init.headers.Authorization,'Bearer server-secret');assert.equal(r.links.length,1);assert.equal(r.links[0].verified,false);
});
test('Profession and CVonline external research requires explicit opt-in and enforces domain',async()=>{
 const boards=[{id:'profession_cv',jobs:[{title:'Üzletvezető',url:'https://www.profession.hu/allas/egy',preliminaryRelevance:14},{title:'Other',url:'https://evil.com/job'}]},{id:'cvonline_cv',jobs:[{title:'Területi képviselő',url:'https://www.cvonline.hu/hu/allas/abc',preliminaryRelevance:12}]}];
 const x=fakeFetch({boards});const env={NATIONAL_API_TOKEN:'secret'};
 const without=await B.expand({targetRoles:'Üzletvezető'}, {env,request:x.fetch});assert.equal(x.calls.length,1);assert.equal(without.portalsStatus,'no_explicit_consent');
 const withYes=await B.expand({targetRoles:'Üzletvezető',externalSearchConsent:true},{env,request:x.fetch});assert.equal(x.calls.length,3);assert.equal(withYes.links.length,2);
 assert.equal(JSON.parse(x.calls[2].init.body).externalSearchConsent,true);assert.equal(withYes.links.every(y=>y.verified===false),true);
});
test('Partial upstream failure still preserves national results',async()=>{
 const request=async u=>{if(u.includes('cv-portal-search'))throw Error('blocked');return{ok:true,json:async()=>({jobs:[{title:'Adat elemző',canonical_url:'https://jobs.example.com/abc'}]})}};
 const r=await B.expand({targetRoles:'Adat elemző',externalSearchConsent:true},{env:{NATIONAL_API_TOKEN:'secret'},request});
 assert.equal(r.status,'partial');assert.equal(r.portalsStatus,'failed');assert.deepEqual(r.boardStatuses,{profession_cv:'failed',cvonline_cv:'failed'});assert.equal(r.links.length,1);
});
test('An unavailable portal and inactive AI are visible even with a successful national response',async()=>{
 const request=async url=>url.includes('cv-portal-search')
  ?new Response(JSON.stringify({status:'not_configured',boards:[]}),{status:503})
  :Response.json({jobs:[],meta:{semanticStatus:'unavailable',ownModel:'awaiting_verified_training'}});
 const result=await B.expand({targetRoles:'Könyvelő',externalSearchConsent:true},{env:{NATIONAL_API_TOKEN:'test'},request});
 assert.equal(result.status,'partial');
 assert.deepEqual(result.boardStatuses,{profession_cv:'not_configured',cvonline_cv:'not_configured'});
 assert.equal(result.matcherStatus,'awaiting_verified_training');
 assert.equal(result.semanticStatus,'unavailable');
});
test('Invalid URLs and duplicate links are rejected',()=>{
 assert.equal(B.httpsLink('http://www.profession.hu/job', 'profession.hu'),null);
 assert.equal(B.httpsLink('https://profession.hu.evil.com/j','profession.hu'),null);
 assert.equal(B.httpsLink('https://user:pass@profession.hu/j','profession.hu'),null);
 assert.equal(B.distinct([{url:'https://one.test',title:'a'},{url:'https://one.test',title:'b'}]).length,1);
});
test('Android asset overlay works twice with the actual v0.9.7 APK assets',()=>{
 const temporary=fs.mkdtempSync(path.join(os.tmpdir(),'app101-'));
 try{
 for(const d of ['app/src/main/assets','pwa']){const out=path.join(temporary,d);fs.mkdirSync(out,{recursive:true});
  const z=fs.readFileSync(path.join(root,'test/fixtures/index.html'));fs.writeFileSync(path.join(out,'index.html'),z);
  const j=fs.readFileSync(path.join(root,'test/fixtures/ai-job-search.js'));fs.writeFileSync(path.join(out,'ai-job-search.js'),j);
  if(d==='pwa')fs.copyFileSync(path.join(root,d,'cv-portals-ui.js'),path.join(out,'cv-portals-ui.js')); 
 }
 fs.copyFileSync(path.join(root,'apply-v101-android.js'),path.join(temporary,'apply-v101-android.js'));
 const run=()=>spawnSync(process.execPath,[path.join(temporary,'apply-v101-android.js')],{encoding:'utf8'});
 assert.equal(run().status,0);assert.equal(run().status,0);
 for(const d of ['app/src/main/assets','pwa']){
  const html=fs.readFileSync(path.join(temporary,d,'index.html'),'utf8'),js=fs.readFileSync(path.join(temporary,d,'ai-job-search.js'),'utf8');
  assert.equal((html.match(/data-ai-cv-portals-v101/g)||[]).length,1);assert.match(js,/AI_FV_APP_NATIONAL_V101_RENDER/);
  assert.match(js,/externalSearchConsent=true/);assert.match(js,/verified/);assert.ok(fs.existsSync(path.join(temporary,d,'cv-portals-ui.js')));assert.ok(html.indexOf('cv-portals-ui.js')<html.indexOf('ai-job-search.js'));
  assert.equal(spawnSync(process.execPath,['--check',path.join(temporary,d,'ai-job-search.js')]).status,0);
 }
 }finally{fs.rmSync(temporary,{recursive:true,force:true})}
});
test('Legacy service overlay is fail-closed, idempotent and syntactically checked',()=>{
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'server101-'));
 try{
 fs.copyFileSync(path.join(root,'apply-v101-legacy-server.js'),path.join(temp,'apply-v101-legacy-server.js'));
 fs.copyFileSync(path.join(root,'national-bridge.js'),path.join(temp,'national-bridge.js'));
 fs.writeFileSync(path.join(temp,'server.js'),"const VERSION='0.9.7';\n");
 fs.writeFileSync(path.join(temp,'job-search.js'),"const E = require('./engine');\nfunction start(rawProfile){const p=sanitizeProfile(rawProfile);return p;}\nfunction snapshot(s){return {linkCount:s.links.length,links:s.links};}\n// AI_FV_MULTILINGUAL_V097\nasync function run(p,env,fetchImpl,s,checkedJobs){s.rejectedCount=checkedJobs.rejected.length;}\n");
 const run=()=>spawnSync(process.execPath,[path.join(temp,'apply-v101-legacy-server.js')],{encoding:'utf8'});
 assert.equal(run().status,0);assert.equal(run().status,0);
 const source=fs.readFileSync(path.join(temp,'job-search.js'),'utf8');assert.match(source,/NATIONAL\.expand/);assert.match(source,/nationalBridge:s.nationalBridge/);assert.match(source,/externalSearchConsent=rawProfile/);assert.match(source,/s\.links\.unshift/);
 assert.equal(spawnSync(process.execPath,['--check',path.join(temp,'job-search.js')]).status,0);
 }finally{fs.rmSync(temp,{recursive:true,force:true})}
});
