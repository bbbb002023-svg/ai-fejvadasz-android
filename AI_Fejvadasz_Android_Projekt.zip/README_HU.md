# AI Fejvadász – Android alkalmazás (demó)

**Ez nem kész APK, hanem egy teljes Android Studio/Gradle-projekt, amiből telepíthető APK készíthető.**
A projekt tartalmazza a korábban kipróbált magyar offline interaktív felületet, az Android WebView-burkot,
saját alkalmazásikont, helyi adatmegőrzést és natív szövegfájl-mentést.

## Mit tud most?
- Android kezdőképernyőről indul, saját ikonnal, önálló alkalmazásként.
- Interaktív magyar demóadatok: profilűrlap, képességlista, százalékos állásegyezés-szűrés,
  sablon-CV, külön motivációs levelek, demó jelentkezésnapló, fejlesztési állapotjelentés.
- Helyben menti a kitöltött demóadatokat, nem küldi őket szerverre.
- A letöltött szövegeket Android 10+ rendszeren a Letöltések / AI_Fejvadasz mappába menti.

## Mi nincs még?
**NINCS** élő állásportál-integráció, éles AI-s CV-elemzés, automatikus jelentkezés,
valós ütemezett háttérellenőrzés, email-olvasási visszaigazolás vagy ChatGPT-bekötés.
A hirdetések és a pályázatok kitalált DEMÓ-adatok. Nem fordítható a kód összekötés nélkül éles szolgáltatássá.

## 1. APK elkészítése ingyen GitHub Actions-szel
1. Hozz létre egy **privát** GitHub-tárolót (repository).
2. Töltsd fel **a ZIP-ben lévő projektfájlokat** a tároló gyökérkönyvtárába úgy, hogy az `app`, `.github`, `settings.gradle`, `build.gradle` közvetlenül ott legyenek.
3. Nyisd meg a GitHub **Actions** lapját; a `Android APK építés` nevű folyamatot futtasd (Run workflow), ha nem indult automatikusan.
4. A sikeres futás alján található `AI-Fejvadasz-Android-APK` csomagot töltsd le.
5. Csomagold ki a ZIP-et; az `app-debug.apk` telepíthető Androidra, az Android figyelmeztetését csak akkor engedélyezd, ha ellenőrizted a forrást.

A GitHub futtatásnak és a telepítésnek saját limitjei, feltételei és biztonsági kockázatai lehetnek.
A projektet ebben a környezetben nem lehetett Android SDK híján APK-vá fordítani, ezért **az APK sikeres összeállítását és készüléken futását még nem ellenőriztem**.

## 2. Android Studio-val
- Android Studio: Open → projekt gyökérmappája → `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
- Java 17, Android SDK 35, Gradle 8.9 szükséges; az Android Gradle Plugin 8.7.3.

## 3. Alternatív telepíthető webalkalmazás
A `pwa` mappát HTTPS-t használó statikus tárhelyre kell feltölteni. Androidos Chrome-ban a menü →
`Alkalmazás telepítése` lehetőséggel külön ikonnal telepíthető. Ez **nem APK** és nem Google Play alkalmazás.
Az offline HTML-fájl megnyitása önmagában nem teszi telepíthetővé a PWA-t.
