package hu.allasradar.demo;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_PICKER = 42;

    @Override public void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        web = new WebView(this);
        web.setBackgroundColor(0xfff3f5f4);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setDatabaseEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowFileAccessFromFileURLs(false);
        web.getSettings().setAllowUniversalAccessFromFileURLs(false);
        web.addJavascriptInterface(new AndroidBridge(), "AndroidApp");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equals(uri.getScheme()) && "/android_asset/index.html".equals(uri.getPath())) return false;
                if ("https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView webView,
                    ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent;
                try { intent = params.createIntent(); }
                catch (Exception ex) { intent = new Intent(Intent.ACTION_GET_CONTENT); intent.setType("*/*"); }
                try { startActivityForResult(intent, FILE_PICKER); return true; }
                catch (Exception ex) { fileCallback = null; return false; }
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_PICKER && fileCallback != null) {
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n=data.getClipData().getItemCount();
                    results=new Uri[n];
                    for(int i=0;i<n;i++) results[i]=data.getClipData().getItemAt(i).getUri();
                } else if (data.getData()!=null) results=new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(results); fileCallback=null;
        }
    }

    @Override public void onBackPressed() {
        web.evaluateJavascript("(function(){var m=document.getElementById('modal');" +
            "if(m&&m.style.display==='block'){closeModal();return 'closed'};" +
            "var a=document.querySelector('.page.active');" +
            "if(a&&a.id!=='dashboard'){go('dashboard');return 'home'}" +
            "return 'exit'})()", result -> {
                if (result != null && result.contains("exit")) MainActivity.super.onBackPressed();
            });
    }

    @Override protected void onDestroy() {
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }

    public class AndroidBridge {
        @JavascriptInterface public void copyText(String text) {
            runOnUiThread(() -> {
                ClipboardManager cb=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                cb.setPrimaryClip(ClipData.newPlainText("AI Fejvadász",text));
                Toast.makeText(MainActivity.this,"Szöveg másolva",Toast.LENGTH_SHORT).show();
            });
        }
        @JavascriptInterface public void saveFile(String filename, String content) {
            new Thread(() -> {
                String safe = filename == null ? "allasradar.txt" : filename.replaceAll("[^a-zA-Z0-9._-]","_");
                if (safe.isEmpty()) safe="allasradar.txt";
                boolean ok=false; String message;
                try {
                    byte[] bytes=content.getBytes(StandardCharsets.UTF_8);
                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentValues v=new ContentValues();
                        v.put(MediaStore.Downloads.DISPLAY_NAME,safe);
                        v.put(MediaStore.Downloads.MIME_TYPE,"text/plain");
                        v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/AI_Fejvadasz");
                        Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
                        if(uri==null) throw new Exception("Nem sikerült a fájlt létrehozni.");
                        try(OutputStream output=getContentResolver().openOutputStream(uri)) {
                            if(output==null) throw new Exception("Nem érhető el a fájl írásra.");
                            output.write(bytes);
                        }
                        message="Mentve a Letöltések / AI_Fejvadasz mappába";
                    } else {
                        File folder=getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
                        if(folder==null) throw new Exception("A tárhely nem érhető el.");
                        try(FileOutputStream fos=new FileOutputStream(new File(folder,safe))) { fos.write(bytes); }
                        message="Mentve az alkalmazás dokumentumai közé";
                    }
                    ok=true;
                } catch(Exception e){ message="Nem sikerült a mentés: "+e.getMessage(); }
                final String result=message;
                runOnUiThread(() -> Toast.makeText(MainActivity.this,result,Toast.LENGTH_LONG).show());
            }).start();
        }
    }
}
