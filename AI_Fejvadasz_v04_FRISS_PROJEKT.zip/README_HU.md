# AI Fejvadász 0.4 – színes Android-demó saját magyar állásillesztő motorral

2026. november – MUNKAVERZIÓ / helyi teszt. **Az alkalmazás telepíthető, de nem felhős fiók, nem élő álláskereső és nem küld jelentkezéseket.**

## Mi működik az APK-ban?

- Színes, mobilon kényelmes felület: regisztrációs bemutató + három fő funkció: Adatok feltöltése, Álláskeresés, Interjúfelkészítés.
- **Helyi demóprofil**: név, e-mail, telefonszám, fénykép, végzettség, igazolások, munkatörténet, készségek, keresési igények. Kilépés után az adatlap helyben megmarad. Ez nem titkosított felhős felhasználói fiók. Az itt begépelt jelszó csak próbaellenőrzésre szolgál, és nem kerül tárolásra.
- Aktív, **szabályalapú** segítség a hiányzó adatokhoz és a keresési profilhoz; OpenAI/ChatGPT API még nincs bekötve.
- Szerkeszthető, megtekinthető CV, csak felhasználói jóváhagyás után menthető. Androidon a jóváhagyott CV egy szöveges, kereshető PDF-ként az alkalmazás privát tárába kerül; külön gombbal a Letöltések/AI_Fejvadasz mappába exportálható. Profilfotó külön engedéllyel kerülhet a PDF-be.
- **Saját állásmotor** (`engine.js`): magyar szakmacsalád és készségek; 35+20+20+15+10 súlyú egyezés; kizárások a kötelező végzettségre, képesítésre és helyszínre; százalékos küszöb; miért-illik/mi-hiányzik magyarázat.
- Álláslista: fiktív minták + kézzel megadott vagy JSON-ból importált álláshirdetések (max. 300/fájl). A tesztimport: `samples/allas_import_minta.json`.
- 90% felett **csak jelölés**, automatikus beküldés nem aktív. Jelentkezési levél előkészítése, demónapló és interjúgyakorló kérdések.
- Magyar portálok megnyitása külső böngészőben: Profession, CVonline, Jooble, Jobline. Ezt nem szabad automatikus aggregátorként értelmezni.

## Fontos korlátok

**Nem kész:** valódi regisztráció/felhő, e-mail-ellenőrzés, titkosított privát szervertár, teljes magyar állásportál-/céges karrieroldal-index, napi 2 automatikus adatgyűjtés, OpenAI-szerverkapcsolat, valódi kézbesítés és visszajelzés. Ezekhez engedélyezett források, központi háttérrendszer és hitelesítés szükséges. A felhasználó adatait a demó nem osztja meg külső portálokkal.

A PDF a privát alkalmazásfájlok között tárolódik, de a felhasználó által exportált példány már a telefon Letöltések mappájába kerül. A helyi profiladatok WebView-tárolóban vannak, ezért éles személyes adatokkal való használatra a fiók-titkosítás és a backend elkészültéig nem ajánlott.

## A GitHubon új APK készítése

A projekt ZIP-gyökerében `build.gradle`, `settings.gradle`, `app/`, `pwa/` található, ugyanúgy, mint az előző változatban. A korábban létrehozott GitHub-tárhelyre az `AI_Fejvadasz_Android_Projekt.zip` nevű új ZIP-et kell feltölteni a régi azonos nevű fájl helyére.

A tárhely `.github/workflows/build-apk.yml` állománya a feltöltésre reagál és Gradle `:app:assembleDebug` parancsot futtat. Android SDK telepítője **`android-actions/setup-android@v4`** legyen.

**Figyelem:** az új `applicationId` `hu.allasradar.demo.v04` (a tesztverziók egymás mellé telepíthetők). A GitHub Actions futásonként új debug-aláírást használhat; ez éles kiadásra nem alkalmas. Az APK csak GitHub-fordítás után keletkezik, a ZIP önmagában nem APK.

## Tesztek

`node tests/matcher.test.js` – szakmacsalád, kötelező képesítés, kizárás, egyezés és deduplikáció.

`python tests/ui_smoke.py` – Chromium alapú kezelőfelületi smoke-teszt a tesztkörnyezetben.

Fejlesztési részletek: `docs/motor_integracio_terv.md`.
