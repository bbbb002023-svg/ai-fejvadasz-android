package hu.allasradar.demo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private String exportPendingFilename;
    private static final int FILE_PICKER = 42;
    private static final int EXPORT_PDF = 43;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.setBackgroundColor(0xfff6f7ff);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowFileAccessFromFileURLs(false);
        web.getSettings().setAllowUniversalAccessFromFileURLs(false);
        web.addJavascriptInterface(new AndroidBridge(), "AndroidApp");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri uri = req.getUrl();
                String scheme = uri.getScheme();
                if ("file".equals(scheme) && "/android_asset/index.html".equals(uri.getPath())) return false;
                if ("https".equals(scheme)) {
                    openLink(uri.toString());
                }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), FILE_PICKER);
                    return true;
                } catch (Exception ex) {
                    fileCallback = null;
                    return false;
                }
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_PICKER && fileCallback != null) {
            Uri[] result = null;
            if (resultCode == Activity.RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    result = new Uri[n];
                    for (int i=0; i<n; i++) result[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) result = new Uri[] { data.getData() };
            }
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        } else if (requestCode == EXPORT_PDF) {
            if (resultCode == Activity.RESULT_OK && data != null && exportPendingFilename != null) {
                try (FileInputStream fis = new FileInputStream(privateCvFile(exportPendingFilename));
                     OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new Exception("Nem nyitható meg a PDF fájl.");
                    byte[] buffer = new byte[8192]; int count;
                    while ((count = fis.read(buffer)) > 0) out.write(buffer,0,count);
                    info("PDF exportálva.");
                } catch (Exception ex) { info("PDF-hiba: " + ex.getMessage()); }
            }
            exportPendingFilename = null;
        }
    }

    private void info(String s) { runOnUiThread(() -> Toast.makeText(this, s, Toast.LENGTH_LONG).show()); }
    private void openLink(String url) {
        if (url == null || !url.startsWith("https://")) { info("Csak HTTPS-link nyitható meg."); return; }
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { info("Nincs alkalmas böngésző a telefonon."); }
    }
    private File privateCvFile(String filename) {
        String safe=filename.replaceAll("[^a-zA-Z0-9._-]", "_");
        return new File(new File(getFilesDir(),"approved_cv"),safe);
    }
    private String createCvPdf(String filename, String content, String photoData) throws Exception {
        File dir = new File(getFilesDir(), "approved_cv");
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("A privát dokumentummappa nem hozható létre.");
        PdfDocument pdf = new PdfDocument();
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        final int W=595,H=842,left=44,right=44,bottom=805;
        int pageN=1,y=60;
        PdfDocument.Page page=pdf.startPage(new PdfDocument.PageInfo.Builder(W,H,pageN).create());
        Canvas canvas=page.getCanvas();
        paint.setColor(Color.rgb(100,66,229));paint.setTextSize(20);paint.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));
        canvas.drawText("AI FEJVADÁSZ • ÖNÉLETRAJZ",left,37,paint);
        paint.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
        if (photoData != null && photoData.startsWith("data:image/")) {
            try {
                int comma=photoData.indexOf(',');
                byte[] data=Base64.decode(photoData.substring(comma+1),Base64.DEFAULT);
                Bitmap b=BitmapFactory.decodeByteArray(data,0,data.length);
                if (b!=null) { canvas.drawBitmap(b,null,new android.graphics.Rect(477,54,545,122),paint); b.recycle(); }
            } catch (Exception ignored) { /* fotó nélkül is érvényes a CV */ }
        }
        paint.setTextSize(11);paint.setColor(Color.rgb(37,47,78));
        String[] lines=content.replace("\r","").split("\n",-1);
        for (String row:lines) {
            if (row.trim().isEmpty()) {y+=10;continue;}
            boolean heading=row.equals(row.toLocaleUpperCase(new Locale("hu","HU"))) && row.length()<60 && !row.matches(".*[a-z].*");
            paint.setTypeface(Typeface.create("sans-serif",heading?Typeface.BOLD:Typeface.NORMAL));
            paint.setTextSize(heading?12f:11f);
            StringBuilder segment=new StringBuilder();
            for (String word:row.split("\\s+")) {
                String trial=segment.length()==0?word:segment+" "+word;
                if (paint.measureText(trial)>W-left-right-7 && segment.length()>0) {
                    if (y>bottom) {pdf.finishPage(page);pageN++;page=pdf.startPage(new PdfDocument.PageInfo.Builder(W,H,pageN).create());canvas=page.getCanvas();y=55;}
                    canvas.drawText(segment.toString(),left,y,paint);y+=heading?19:16;segment.setLength(0);segment.append(word);
                } else {segment.setLength(0);segment.append(trial);}
            }
            if (segment.length()>0) {
                if (y>bottom) {pdf.finishPage(page);pageN++;page=pdf.startPage(new PdfDocument.PageInfo.Builder(W,H,pageN).create());canvas=page.getCanvas();y=55;}
                canvas.drawText(segment.toString(),left,y,paint);y+=heading?21:16;
            }
        }
        pdf.finishPage(page);
        File file=privateCvFile(filename);
        try(FileOutputStream out=new FileOutputStream(file)){pdf.writeTo(out);}finally{pdf.close();}
        return filename;
    }
    @Override public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("(function(){var s=document.getElementById('overlay');if(s&&s.classList.contains('show')){closeSheet();return 'closed';}var a=document.querySelector('.page.active');if(a&&a.id!=='dashboard'){go('dashboard');return 'home';}return 'exit'})()",result->{
            if (result!=null&&result.contains("exit")) MainActivity.super.onBackPressed();
        });
    }
    @Override protected void onDestroy() {if(web!=null){web.destroy();web=null;}super.onDestroy();}

    public class AndroidBridge {
        @JavascriptInterface public void openExternal(String url){runOnUiThread(()->openLink(url));}
        @JavascriptInterface public void copyText(String content) {
            runOnUiThread(()->{
                ClipboardManager manager=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                manager.setPrimaryClip(ClipData.newPlainText("AI Fejvadász",content));info("Szöveg másolva.");
            });
        }
        @JavascriptInterface public String savePrivateCvPdf(String fullname,String text,String photo){
            try{
                if (text==null||text.length()<70) return "ERROR: Üres önéletrajz.";
                String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());
                String filename="AI_Fejvadasz_CV_"+stamp+".pdf";
                return createCvPdf(filename,text,photo);
            }catch(Exception e){return "ERROR: PDF mentési hiba: "+e.getMessage();}
        }
        @JavascriptInterface public void exportPrivateCvPdf(String filename){
            if (filename==null||!filename.matches("AI_Fejvadasz_CV_[0-9_]+\\.pdf")){info("Érvénytelen dokumentumnév.");return;}
            File saved=privateCvFile(filename);
            if (!saved.isFile()){info("A mentett PDF ezen a telefonon már nem található.");return;}
            runOnUiThread(()->{
                if (Build.VERSION.SDK_INT>=29) {
                    try(FileInputStream in=new FileInputStream(saved)) {
                        ContentValues values=new ContentValues();
                        values.put(MediaStore.Downloads.DISPLAY_NAME,filename);
                        values.put(MediaStore.Downloads.MIME_TYPE,"application/pdf");
                        values.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/AI_Fejvadasz");
                        Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
                        if(uri==null)throw new Exception("Nem hozható létre a letöltés.");
                        try(OutputStream out=getContentResolver().openOutputStream(uri)) {
                            if(out==null)throw new Exception("Nincs írási jogosultság.");
                            byte[] buffer=new byte[8192];int count;
                            while((count=in.read(buffer))>0)out.write(buffer,0,count);
                        }
                        info("PDF exportálva: Letöltések / AI_Fejvadasz");
                    }catch(Exception e){info("PDF exporthiba: "+e.getMessage());}
                }else {
                    exportPendingFilename=filename;
                    Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.setType("application/pdf");intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.putExtra(Intent.EXTRA_TITLE,filename);
                    startActivityForResult(intent,EXPORT_PDF);
                }
            });
        }
    }
}
