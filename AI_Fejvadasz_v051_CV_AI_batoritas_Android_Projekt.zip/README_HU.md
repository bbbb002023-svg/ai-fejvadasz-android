# AI Fejvadász 0.5.1 – önéletrajz-feltöltés és proaktív szakmai bátorítás

**Első képernyő regisztráció, utána automatikusan a CV-feltöltés oldal jelenik meg.**

## Mit tud ez a működő helyi demó?

- PDF/DOCX/TXT kiválasztása Android fájlválasztóval, legfeljebb 10 MB.
- PDF szöveg kinyerése helyben a PDFBox-Android könyvtárral; DOCX XML szöveg és média kinyerése; TXT olvasás.
- Magyar CV-ből felismerhető mezők előkitöltése, az eredeti kézzel beírt adatok védelme.
- Feltöltés után automatikusan felugró, bizonyítékhoz kötött személyes dicséret és szakmai lehetőség-javaslat a segítő ikonnál. Nem ígér biztos alkalmasságot.
- Hiányzó/bizonytalan adatok külön jelzése, célzott mezőre ugrás és segítségszöveg.
- PDF/DOCX-be ágyazott portré jellegű kép **jelöltként** megjeleníthető, csak felhasználói megerősítés után tárolható profilképként.
- Szerkeszthető CV-tervezet. Felhasználói jóváhagyás után privát PDF és elsődleges önéletrajz lesz.
- A korábbi magyar állásillesztő pontozó motor és színes felület megmarad.

## Jelenlegi korlátok

Ez **nem generatív AI**, hanem offline, forrásalapú szabálymotor. Nem találhat ki tényeket vagy hiányzó adatokat; a felismerés ellenőrzendő. A képként szkennelt PDF OCR nélkül nem olvasható. Az új PDF-ben található kép nem feltétlenül portré – ezért kér megerősítést. Böngészős bemutatóban a TXT működik, PDF/DOCX olvasás csak az Android-appban. Nem létezik még felhős felhasználói fiók, OpenAI-integráció, élő állásgyűjtés vagy automatikus beküldés. A CV PDF privát Android-tárhelyben kerül mentésre, és exportálható.

## GitHub Actions build

A gyökérből: `gradle --no-daemon :app:assembleDebug`
A GitHub-repó workflow-jának ZIP-fájlnevét át kell írni az új `AI_Fejvadasz_v05_CV_IMPORT.zip` fájlnévre. Az előző fordításba tett `sed -i` workaroundra nincs már szükség, az eredeti Java-forrásban a metódushiba javítva.
