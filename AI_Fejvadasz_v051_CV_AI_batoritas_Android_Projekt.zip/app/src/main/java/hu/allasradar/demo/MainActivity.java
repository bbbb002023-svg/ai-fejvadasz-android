package hu.allasradar.demo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.File;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipEntry;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.graphics.Rect;
import android.graphics.Matrix;
import org.json.JSONObject;
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;
import com.tom_roush.pdfbox.pdmodel.PDPage;
import com.tom_roush.pdfbox.pdmodel.PDResources;
import com.tom_roush.pdfbox.pdmodel.graphics.PDXObject;
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject;
import com.tom_roush.pdfbox.cos.COSName;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private String exportPendingFilename;
    private static final int FILE_PICKER = 42;
    private static final int EXPORT_PDF = 43;
    private static final int IMPORT_RESUME = 44;
    private static final int RESUME_MAX_BYTES = 10 * 1024 * 1024;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.setBackgroundColor(0xfff6f7ff);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowFileAccessFromFileURLs(false);
        web.getSettings().setAllowUniversalAccessFromFileURLs(false);
        web.addJavascriptInterface(new AndroidBridge(), "AndroidApp");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri uri = req.getUrl();
                String scheme = uri.getScheme();
                if ("file".equals(scheme) && "/android_asset/index.html".equals(uri.getPath())) return false;
                if ("https".equals(scheme)) {
                    openLink(uri.toString());
                }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), FILE_PICKER);
                    return true;
                } catch (Exception ex) {
                    fileCallback = null;
                    return false;
                }
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_PICKER && fileCallback != null) {
            Uri[] result = null;
            if (resultCode == Activity.RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    result = new Uri[n];
                    for (int i=0; i<n; i++) result[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) result = new Uri[] { data.getData() };
            }
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        } else if (requestCode == IMPORT_RESUME) {
            if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
                Uri chosen = data.getData();
                new Thread(() -> readResume(chosen)).start();
            }
        } else if (requestCode == EXPORT_PDF) {
            if (resultCode == Activity.RESULT_OK && data != null && exportPendingFilename != null) {
                try (FileInputStream fis = new FileInputStream(privateCvFile(exportPendingFilename));
                     OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new Exception("Nem nyitható meg a PDF fájl.");
                    byte[] buffer = new byte[8192]; int count;
                    while ((count = fis.read(buffer)) > 0) out.write(buffer,0,count);
                    info("PDF exportálva.");
                } catch (Exception ex) { info("PDF-hiba: " + ex.getMessage()); }
            }
            exportPendingFilename = null;
        }
    }

    private void info(String s) { runOnUiThread(() -> Toast.makeText(this, s, Toast.LENGTH_LONG).show()); }
    private void openLink(String url) {
        if (url == null || !url.startsWith("https://")) { info("Csak HTTPS-link nyitható meg."); return; }
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { info("Nincs alkalmas böngésző a telefonon."); }
    }
    private File privateCvFile(String filename) {
        String safe=filename.replaceAll("[^a-zA-Z0-9._-]", "_");
        return new File(new File(getFilesDir(),"approved_cv"),safe);
    }
    private String createCvPdf(String filename, String content, String photoData) throws Exception {
        File dir = new File(getFilesDir(), "approved_cv");
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("A privát dokumentummappa nem hozható létre.");
        PdfDocument pdf = new PdfDocument();
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        final int W=595,H=842,left=44,right=44,bottom=805;
        int pageN=1,y=60;
        PdfDocument.Page page=pdf.startPage(new PdfDocument.PageInfo.Builder(W,H,pageN).create());
        Canvas canvas=page.getCanvas();
        paint.setColor(Color.rgb(100,66,229));paint.setTextSize(20);paint.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));
        canvas.drawText("AI FEJVADÁSZ • ÖNÉLETRAJZ",left,37,paint);
        paint.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
        if (photoData != null && photoData.startsWith("data:image/")) {
            try {
                int comma=photoData.indexOf(',');
                byte[] data=Base64.decode(photoData.substring(comma+1),Base64.DEFAULT);
                Bitmap b=BitmapFactory.decodeByteArray(data,0,data.length);
                if (b!=null) { canvas.drawBitmap(b,null,new android.graphics.Rect(477,54,545,122),paint); b.recycle(); }
            } catch (Exception ignored) { /* fotó nélkül is érvényes a CV */ }
        }
        paint.setTextSize(11);paint.setColor(Color.rgb(37,47,78));
        String[] lines=content.replace("\r","").split("\n",-1);
        for (String row:lines) {
            if (row.trim().isEmpty()) {y+=10;continue;}
            boolean heading=row.equals(row.toUpperCase(new Locale("hu","HU"))) && row.length()<60 && !row.matches(".*[a-z].*");
            paint.setTypeface(Typeface.create("sans-serif",heading?Typeface.BOLD:Typeface.NORMAL));
            paint.setTextSize(heading?12f:11f);
            StringBuilder segment=new StringBuilder();
            for (String word:row.split("\\s+")) {
                String trial=segment.length()==0?word:segment+" "+word;
                if (paint.measureText(trial)>W-left-right-7 && segment.length()>0) {
                    if (y>bottom) {pdf.finishPage(page);pageN++;page=pdf.startPage(new PdfDocument.PageInfo.Builder(W,H,pageN).create());canvas=page.getCanvas();y=55;}
                    canvas.drawText(segment.toString(),left,y,paint);y+=heading?19:16;segment.setLength(0);segment.append(word);
                } else {segment.setLength(0);segment.append(trial);}
            }
            if (segment.length()>0) {
                if (y>bottom) {pdf.finishPage(page);pageN++;page=pdf.startPage(new PdfDocument.PageInfo.Builder(W,H,pageN).create());canvas=page.getCanvas();y=55;}
                canvas.drawText(segment.toString(),left,y,paint);y+=heading?21:16;
            }
        }
        pdf.finishPage(page);
        File file=privateCvFile(filename);
        try(FileOutputStream out=new FileOutputStream(file)){pdf.writeTo(out);}finally{pdf.close();}
        return filename;
    }

    // A választott önéletrajzot kizárólag az alkalmazás olvassa; a dokumentum nem megy szerverre.
    private void readResume(Uri uri) {
        JSONObject result = new JSONObject();
        try {
            String filename = nameForUri(uri);
            String lower = filename.toLowerCase(Locale.ROOT);
            String mime = getContentResolver().getType(uri);
            byte[] data;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new IOException("A fájl nem nyitható meg.");
                data = limitedRead(in, RESUME_MAX_BYTES);
            }
            if (data.length == 0) throw new IOException("A fájl üres.");
            String text = "", candidatePhoto = "", mode = "";
            if (lower.endsWith(".pdf") || "application/pdf".equals(mime) || isPdf(data)) {
                PDFBoxResourceLoader.init(getApplicationContext());
                try (PDDocument pdf = PDDocument.load(new ByteArrayInputStream(data))) {
                    if (pdf.isEncrypted()) throw new IOException("Jelszóval védett PDF-et nem lehet automatikusan feldolgozni.");
                    PDFTextStripper stripper = new PDFTextStripper();
                    stripper.setSortByPosition(true);
                    text = stripper.getText(pdf);
                    candidatePhoto = photoFromPdf(pdf);
                }
                mode = "PDF helyi szöveg- és képfeldolgozás";
            } else if (lower.endsWith(".docx") || (mime != null && mime.contains("wordprocessingml"))) {
                String[] parsed = textAndPhotoFromDocx(data);
                text=parsed[0];candidatePhoto=parsed[1];mode="DOCX helyi szöveg- és képfeldolgozás";
            } else if (lower.endsWith(".txt") || "text/plain".equals(mime)) {
                text=new String(data,StandardCharsets.UTF_8);
                mode="TXT helyi olvasás";
            } else throw new IOException("Csak PDF, DOCX vagy TXT önéletrajzot választhatsz.");
            result.put("ok",true);result.put("filename",filename);result.put("text",text.length()>150000?text.substring(0,150000):text);
            result.put("photo",candidatePhoto);result.put("method",mode);
        } catch (Exception ex) {
            try {result.put("ok",false);result.put("message","A beolvasás nem sikerült: " + ex.getMessage());}catch(Exception ignored){}
        }
        final String json = result.toString();
        runOnUiThread(() -> {
            if(web!=null) web.evaluateJavascript("window.receiveImportedResume(JSON.parse("+JSONObject.quote(json)+"))",null);
        });
    }
    private String nameForUri(Uri uri) {
        try (Cursor cursor=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)) {
            if(cursor!=null&&cursor.moveToFirst()) {
                int col=cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if(col>=0&&cursor.getString(col)!=null) return cursor.getString(col).substring(0,Math.min(cursor.getString(col).length(),120));
            }
        }catch(Exception ignored){}
        String last=uri.getLastPathSegment();return last!=null?last:"önéletrajz";
    }
    private static boolean isPdf(byte[] data) {
        return data.length>=5 && data[0]=='%'&&data[1]=='P'&&data[2]=='D'&&data[3]=='F'&&data[4]=='-';
    }
    private static byte[] limitedRead(InputStream input,int max) throws IOException {
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int len;
        while((len=input.read(buffer))!=-1){if(out.size()+len>max)throw new IOException("A dokumentum túl nagy (max. 10 MB).");out.write(buffer,0,len);}
        return out.toByteArray();
    }
    private String photoFromPdf(PDDocument pdf) {
        // Nem biztos, hogy a PDF-ben található kép a felhasználó portréja: csak jelöltként adjuk vissza.
        String best="";int score=0;
        int pages=Math.min(pdf.getNumberOfPages(),3);
        for(int idx=0;idx<pages;idx++) {
            try {
                PDPage page=pdf.getPage(idx);PDResources resources=page.getResources();if(resources==null)continue;
                for(COSName key:resources.getXObjectNames()) {
                    PDXObject item=resources.getXObject(key);
                    if(item instanceof PDImageXObject) {
                        PDImageXObject picture=(PDImageXObject)item;
                        int w=picture.getWidth(),h=picture.getHeight();
                        if(!portraitLike(w,h))continue;
                        int quality=Math.min(w,h);
                        if(quality>score) {
                            Bitmap bm=picture.getImage();String next=toSmallPortrait(bm);
                            if(!next.isEmpty()){best=next;score=quality;}
                        }
                    }
                }
            }catch(Exception ignored){}
        }
        return best;
    }
    private static boolean portraitLike(int w,int h) {
        if(w<90||h<90||w>3500||h>3500)return false;
        double ratio=(double)w/h;return ratio>=0.62&&ratio<=1.55;
    }
    private static String toSmallPortrait(Bitmap bmp) {
        if(bmp==null)return "";
        try {
            int side=Math.min(bmp.getWidth(),bmp.getHeight());
            if(side<70)return "";
            int offsetX=(bmp.getWidth()-side)/2,offsetY=(bmp.getHeight()-side)/2;
            Bitmap cropped=Bitmap.createBitmap(bmp,offsetX,offsetY,side,side);
            Bitmap mini=Bitmap.createScaledBitmap(cropped,280,280,true);
            ByteArrayOutputStream buffer=new ByteArrayOutputStream();mini.compress(Bitmap.CompressFormat.JPEG,74,buffer);
            if(cropped!=bmp)cropped.recycle();mini.recycle();
            return "data:image/jpeg;base64,"+Base64.encodeToString(buffer.toByteArray(),Base64.NO_WRAP);
        }catch(Exception ignored){return "";}
    }
    private static String[] textAndPhotoFromDocx(byte[] bytes)throws Exception {
        String xml="",photo="";int quality=0,entries=0;
        try(ZipInputStream zip=new ZipInputStream(new ByteArrayInputStream(bytes))) {
            ZipEntry entry;
            while((entry=zip.getNextEntry())!=null){entries++;if(entries>1000)throw new IOException("A DOCX túl sok fájlrészt tartalmaz.");
                String name=entry.getName();if(name.equals("word/document.xml")) {
                    xml=new String(limitedRead(zip,3*1024*1024),StandardCharsets.UTF_8);
                } else if(name.startsWith("word/media/") && name.matches("(?i).*\\.(png|jpg|jpeg|webp)$")) {
                    byte[] raw=limitedRead(zip,3*1024*1024);
                    BitmapFactory.Options opt=new BitmapFactory.Options();opt.inJustDecodeBounds=true;
                    BitmapFactory.decodeByteArray(raw,0,raw.length,opt);
                    if(portraitLike(opt.outWidth,opt.outHeight)&&Math.min(opt.outWidth,opt.outHeight)>quality){
                        BitmapFactory.Options down=new BitmapFactory.Options();down.inSampleSize=Math.max(1,Math.min(opt.outWidth,opt.outHeight)/600);
                        Bitmap image=BitmapFactory.decodeByteArray(raw,0,raw.length,down);
                        String candidate=toSmallPortrait(image);if(!candidate.isEmpty()){photo=candidate;quality=Math.min(opt.outWidth,opt.outHeight);}
                        if(image!=null)image.recycle();
                    }
                }
                zip.closeEntry();
            }
        }
        if(xml.isEmpty())throw new IOException("A DOCX dokumentumszöveg nem található.");
        DocumentBuilderFactory f=DocumentBuilderFactory.newInstance();f.setNamespaceAware(true);f.setExpandEntityReferences(false);
        f.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true);
        f.setFeature("http://xml.org/sax/features/external-general-entities",false);
        f.setFeature("http://xml.org/sax/features/external-parameter-entities",false);
        Document dom=f.newDocumentBuilder().parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
        NodeList paragraphs=dom.getElementsByTagNameNS("*","p");StringBuilder buffer=new StringBuilder();
        for(int i=0;i<paragraphs.getLength();i++) {
            Node paragraph=paragraphs.item(i);NodeList child=((org.w3c.dom.Element)paragraph).getElementsByTagNameNS("*","t");
            StringBuilder line=new StringBuilder();for(int j=0;j<child.getLength();j++)line.append(child.item(j).getTextContent());
            if(line.length()>0){buffer.append(line).append('\n');if(buffer.length()>150000)break;}
        }
        return new String[]{buffer.toString(),photo};
    }

    @Override public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("(function(){var s=document.getElementById('overlay');if(s&&s.classList.contains('show')){closeSheet();return 'closed';}var a=document.querySelector('.page.active');if(a&&a.id!=='dashboard'){go('dashboard');return 'home';}return 'exit'})()",result->{
            if (result!=null&&result.contains("exit")) MainActivity.super.onBackPressed();
        });
    }
    @Override protected void onDestroy() {if(web!=null){web.destroy();web=null;}super.onDestroy();}

    public class AndroidBridge {
        @JavascriptInterface public void pickResume(){
            runOnUiThread(() -> {
                Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.setType("*/*");intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/pdf","application/vnd.openxmlformats-officedocument.wordprocessingml.document","text/plain"});
                try {startActivityForResult(intent, IMPORT_RESUME);}
                catch(Exception e){info("Nem érhető el a dokumentumválasztó.");}
            });
        }
        @JavascriptInterface public void openExternal(String url){runOnUiThread(()->openLink(url));}
        @JavascriptInterface public void copyText(String content) {
            runOnUiThread(()->{
                ClipboardManager manager=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                manager.setPrimaryClip(ClipData.newPlainText("AI Fejvadász",content));info("Szöveg másolva.");
            });
        }
        @JavascriptInterface public String savePrivateCvPdf(String fullname,String text,String photo){
            try{
                if (text==null||text.length()<70) return "ERROR: Üres önéletrajz.";
                String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());
                String filename="AI_Fejvadasz_CV_"+stamp+".pdf";
                return createCvPdf(filename,text,photo);
            }catch(Exception e){return "ERROR: PDF mentési hiba: "+e.getMessage();}
        }
        @JavascriptInterface public void exportPrivateCvPdf(String filename){
            if (filename==null||!filename.matches("AI_Fejvadasz_CV_[0-9_]+\\.pdf")){info("Érvénytelen dokumentumnév.");return;}
            File saved=privateCvFile(filename);
            if (!saved.isFile()){info("A mentett PDF ezen a telefonon már nem található.");return;}
            runOnUiThread(()->{
                if (Build.VERSION.SDK_INT>=29) {
                    try(FileInputStream in=new FileInputStream(saved)) {
                        ContentValues values=new ContentValues();
                        values.put(MediaStore.Downloads.DISPLAY_NAME,filename);
                        values.put(MediaStore.Downloads.MIME_TYPE,"application/pdf");
                        values.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/AI_Fejvadasz");
                        Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
                        if(uri==null)throw new Exception("Nem hozható létre a letöltés.");
                        try(OutputStream out=getContentResolver().openOutputStream(uri)) {
                            if(out==null)throw new Exception("Nincs írási jogosultság.");
                            byte[] buffer=new byte[8192];int count;
                            while((count=in.read(buffer))>0)out.write(buffer,0,count);
                        }
                        info("PDF exportálva: Letöltések / AI_Fejvadasz");
                    }catch(Exception e){info("PDF exporthiba: "+e.getMessage());}
                }else {
                    exportPendingFilename=filename;
                    Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.setType("application/pdf");intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.putExtra(Intent.EXTRA_TITLE,filename);
                    startActivityForResult(intent,EXPORT_PDF);
                }
            });
        }
    }
}
