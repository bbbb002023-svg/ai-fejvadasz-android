# AI Fejvadász 0.6.1 – élő AI-kapcsolatra előkészített Android-projekt

## Mi új?
- A meglévő színes app és saját állásillesztő motor megmaradt.
- Androidon aktív AI-szolgáltatás a felhasználó Render szerverén át: `https://ai-fejvadasz-android.onrender.com` (a címet az alkalmazás előre megadja).
- Külön hozzáférési kódot (Render `AI_APP_ACCESS_TOKEN`) a felhasználó csak a telefonon ad meg; Android Keystore-ral titkosítva tárolódik. **Ez NEM az OpenAI API-kulcs!**
- A chat, CV-elemzés, valós tapasztalatra alapozott bátorítás, CV-tervezet, interjúkérdések élő OpenAI-kéréssel működhet, ha a szerver konfigurált és az API-hívás sikerül.
- A CV szövege, illetve szakmai adatok csak engedélyezés után kerülhetnek ki HTTPS-en a saját proxyra, majd az OpenAI-hoz.
- Az új CV adatjavaslatai kizárólag külön kiválasztás/jóváhagyás után kerülnek a profilba. A CV-tervezet csak jóváhagyás után menthető elsődleges PDF-ként.
- Beállított kapcsolat+korábbi engedély esetén CV-feltöltés után az AI elemzés magától elindul.

## Változat korlátai
- Ez egy **egyetlen tesztfelhasználóra** szánt prototípus. A szerver `AI_APP_ACCESS_TOKEN` közös adminisztrátori titok; többfelhasználós appba nem adható át, éles verzióhoz felhasználónkénti hitelesítés, szerveroldali szabályozás, revokáció és audit szükséges.
- A nyilvános /health csak azt igazolja, hogy a szerver fut és a titkok léteznek; valódi AI-választ külön tesztelni kell.
- Nincs valódi online állásportál-gyűjtés, automatikus jelentkezés, felhős regisztráció vagy munkavállalói adatbázis.
- PDF/DOCX import helyi Android könyvtárral; szkennelt PDF OCR nélkül nem olvasható.
- Az API használata pénzbe kerülhet; a Render ingyenes szervere inaktivitás után leállhat és ébredéskor lassabb.

## GitHub Actions
A projekt ZIP gyökerében `app/build.gradle`, `settings.gradle` található. Kibontás után `gradle --no-daemon :app:assembleDebug`. Az új projekt nevét a GitHub workflow `unzip` sorában kell megadni.
