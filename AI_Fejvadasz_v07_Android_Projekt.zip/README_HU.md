# AI Fejvadász 0.7 – színes Android app + saját AI-álláskereső motor

A csomag az előző 0.6.1-es app forráskódjára épül. Külön biztonságos OpenAI proxy-szerver ZIP szükséges a szerveroldali állásgyűjtéshez (AI_Fejvadasz_AI_Szerver_v07.zip). A szerver beállításai továbbra is a Renderben vannak, titkos API-kulcs nélkül a ZIP-ekben.

## Elkészült és tesztelt
- CV feltöltés PDF, DOCX vagy TXT dokumentumból; az elérhető szöveg helyben beolvasódik.
- Korábban engedélyezett AI-adatküldés esetén a szerveren keresztüli *szemantikus* CV-elemzés automatikusan megpróbál elindulni; a javasolt mezők jóváhagyása a felhasználóé. A bizonytalan/hiányzó mezők nem kerülnek kitalálásra.
- Feltöltés után a nagy kék feltöltési panel eltűnik, helyette kompakt "CV cseréje" gomb marad.
- A színes bátorító AI-buborék egyszer jelenik meg, legfeljebb 30 másodpercig, oldalra húzva bezárható.
- Három saját kialakítású, nyomtatható A4-es PDF megjelenés (modern, elegáns, klasszikus), automatikus oldaltöréssel, jóváhagyással és helyi PDF-mentéssel.
- CV véglegesítése után a saját, céges nyilvános ATS-forrásokra támaszkodó álláskeresés indulhat a Render-szerveren. Valós állapotjelző, forrásellenőrzés és OpenAI-alapú rangsorolás, ha az API válaszol.
- A keresés nem egy webes portálra irányít át: az eredmények az alkalmazás saját listájában jelennek meg, forrásmegjelöléssel.

## Amit a 0.7 *még nem tud*
- NEM az összes magyar állásportált ellenőrzi. Csak a konfigurált, nyilvános céges karrierforrásokat, néhány kezdő ATS-boarddal; ebből akár nulla megfelelő állás is származhat.
- NINCS tartós adatbázisos háttérütemezés, nincs garantált keresés szerverújraindítás után, nincs mobil push-értesítés.
- NINCS automatikus jelentkezésküldés, nincs tényleges többfelhasználós regisztrációs háttérrendszer. A helyi regisztráció csak demó.
- A beépített PDF/DOCX szövegkinyerés OCR nélkül nem kezeli a szkennelt, kép alapú CV-ket. Fénykép-jelöltet csak felhasználói jóváhagyás után fogad el.
- Az A4 sablonok saját UI-n belüli sablonok, nem külső Word/PDF sablonok licencelt könyvtára.
- A Render 0.6-os szerverén még nincsenek ott az új álláskereső API-k, **amíg fel nem töltöd az új szervercsomagot és frissíted a Build Commandot**.

## Android fordítás (GitHub Actions)
A ZIP gyökerében `app/build.gradle`, `settings.gradle` van. A tárolódba az `AI_Fejvadasz_v07_Android_Projekt.zip` nevű fájlt töltsd fel.
A meglévő `.github/workflows/build-apk.yml` fájl ZIP-kibontó sorát állítsd át:

```
unzip -q AI_Fejvadasz_v07_Android_Projekt.zip -d project
```

A Gradle építési lépés maradhat. A fordítás `:app:assembleDebug` céllal készít teszt APK-t.

## Render frissítés
A külön `AI_Fejvadasz_AI_Szerver_v07.zip` fájlt töltsd fel a GitHub tárolód gyökerébe. A Render Web Service Build Command legyen:

```
unzip -oq AI_Fejvadasz_AI_Szerver_v07.zip -d ai-server && cd ai-server && npm install --omit=dev
```

Start Command: `cd ai-server && npm start`.
A már Renderben beállított `OPENAI_API_KEY` és `AI_APP_ACCESS_TOKEN` maradjon ott; semmit ne ossz meg a chatben vagy nyilvános repóban.

A Render és az Android is ugyanazt a külön (nem OpenAI API-) hozzáférési kódot használja. Egy felhasználós tesztmód, nem biztonságos többfelhasználós publikálásra.

## Tesztek
- Node.js: `node --test backend/test/*.test.js tests/*.test.js` (8 sikeres).
- Telefonméretű Chromium UI-teszt: regisztráció, CV-feltöltés, panel eltűnése, elhúzható buborék, sablonok, CV-tervezet (sikeres).
- Az új APK tényleges GitHub/Android fordítása és a teljes OpenAI API-beszélgetés még nem lett most ellenőrizve; ezekhez a szerverfrissítés és fordítás után külön próba szükséges.
