/* AI Fejvadász 0.6.1 – Android → Render → OpenAI, nincs kliensben API-kulcs. */
(function(){'use strict';
const HOST='https://ai-fejvadasz-android.onrender.com';
const CONSENT='ai_fv_live_ai_share_consent_v061';
const L=id=>document.getElementById(id);
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const native=()=>window.AndroidApp&&typeof window.AndroidApp.requestAi==='function';
const conn=()=>{if(!native())return {configured:false,url:HOST};try{return JSON.parse(window.AndroidApp.getAiConnection())}catch{return {configured:false,url:HOST}}};
const consent=()=>{try{return localStorage.getItem(CONSENT)==='yes'}catch{return false}};
let latest=null,lastAction='',lastRequest='',busy=false,lastRenderedHtml='',autoProcessing=false;
const UI_FIELDS={name:'pName',email:'pEmail',phone:'pPhone',city:'pCity',pastRoles:'pPastRoles',targetRoles:'pTargetRoles',years:'pYears',education:'pEducation',experience:'pExperience',certificates:'pCertificates',licenses:'pLicenses',languages:'pLanguages'};
const LABELS={name:'Név',email:'E-mail',phone:'Telefon',city:'Település',pastRoles:'Korábbi munkakörök',targetRoles:'Célmunkakörök',years:'Tapasztalat (év)',education:'Végzettség',experience:'Szakmai tapasztalat',certificates:'Képesítések',licenses:'Jogosítvány',languages:'Nyelvtudás',skills:'Készségek'};
function profile(){const out={};Object.keys(UI_FIELDS).forEach(k=>{if(['name','email','phone'].includes(k))return;out[k]=(L(UI_FIELDS[k])?.value||'').slice(0,1500)});out.skills=[...document.querySelectorAll('#skills .chip.selected')].map(el=>el.dataset.skill).slice(0,30);return out;}
function importedResume(){return String(L('oldCV')?.value||L('resumePastedText')?.value||'').trim().slice(0,42000)}
function markStatus(){const s=document.querySelector('.top-status');if(s){s.textContent=conn().configured?'✦ AI kapcsolat beállítva':'✦ AI beállítás szükséges';s.title='A kapcsolat beállítása önmagában még nem igazol sikeres AI választ';}}
function sheet(title,body){L('sheetTitle').textContent=title;L('sheetBody').innerHTML=body;L('overlay').classList.add('show');document.body.style.overflow='hidden';}
function assistant(){markStatus();const c=conn();const txt=importedResume();sheet('✦ Aktív AI Fejvadász',`
<div class="ail-hero"><strong>✦ A személyes szakmai segítőd</strong><p>Értelmezem az önéletrajzodat, segítek a hiányok pótlásában, a CV-ben és az interjúban. A javaslataimat mindig ellenőrizheted.</p></div>
<div class="ail-status">${c.configured?'🟢 Szerverkapcsolat beállítva':'🟠 AI-kapcsolat beállítandó'} <span>· ${esc(HOST)}</span></div>
${!native()?'<div class="banner orange">A valódi AI-kapcsolat csak az Android-alkalmazásban működik, böngészőben a demó marad.</div>':''}
<button class="button secondary full" onclick="aiLiveSetup()">⚙ ${c.configured?'AI-kapcsolat módosítása':'AI-kapcsolat beállítása'}</button>
<label class="checkrow"><input id="aiShareConsent" type="checkbox" ${consent()?'checked':''} onchange="aiLiveConsent(this.checked)"><span><b>Engedélyezem az AI-elemzést.</b><br>Megértettem, hogy a szakmai adataim, illetve külön CV-elemzés esetén a feltöltött önéletrajz szövege a Render szerverünkön keresztül az OpenAI API-hoz kerül. Fényképet és jelszót nem küldünk.</span></label>
<div class="ail-grid"><button class="button" onclick="aiLiveRun('coach')">🌟 Személyes javaslat</button><button class="button" onclick="aiLiveRun('analyze_resume')" ${txt?'':'disabled'}>📄 Önéletrajz elemzése</button><button class="button" onclick="aiLiveRun('draft_cv')">✍️ Profi CV-tervezet</button><button class="button" onclick="aiLiveRun('interview')">🎤 Interjúfelkészítés</button></div>
<div class="field"><label>Kérdezz az AI-tól</label><textarea id="aiMessage" placeholder="Például: mely vezetői erősségeimet emeljem ki?"></textarea></div>
<button class="button green full" onclick="aiLiveRun('chat')">✦ Küldés az AI-segítőnek</button>
<div id="aiLiveResult" role="status" aria-live="polite" style="margin-top:15px"></div>
<div class="tiny muted" style="margin-top:15px">Az AI nem találhat ki képesítést, és nem jelentkezik állásokra a nevedben. A szerver egyfelhasználós tesztkapcsolat; többfelhasználós működéshez külön hitelesítés szükséges.</div>`);if(lastRenderedHtml&&L('aiLiveResult'))L('aiLiveResult').innerHTML=lastRenderedHtml;}
function setup(){const c=conn();sheet('🔐 AI-kapcsolat beállítása',`
<div class="banner green">A Render szervered nyilvános állapotjelzője elérhető. Az OpenAI-kulcsodat <b>soha ne írd be ide</b>.</div>
<div class="field"><label>Saját szerver címe</label><input id="aiServer" value="${esc(c.url||HOST)}" autocomplete="off"></div>
<div class="field"><label>AI_APP_ACCESS_TOKEN · a Renderen létrehozott külön titok</label><input id="aiToken" type="password" placeholder="Legalább 20 karakter" autocomplete="off" autocapitalize="off" spellcheck="false"><small>Ez nem az OpenAI API-kulcs. Androidon titkosított tárolóba kerül; a szerver nem adja vissza.</small></div>
<button class="button full" onclick="aiLiveSave()">✓ Kapcsolat mentése</button>
<button class="button secondary full" style="margin-top:10px" onclick="aiLiveOpen()">← Vissza a segítőhöz</button>
<div class="tiny muted" style="margin-top:12px">A hozzáférési kód az alkalmazás tesztpéldányához való. Nyilvános kiadás előtt valódi felhasználói hitelesítést kell megvalósítani.</div>`);}
function save(){if(!native()){sheet('AI kapcsolat','<p class="banner orange">A beállítást az Android-alkalmazásban tudod elmenteni.</p><button class="button" onclick="aiLiveOpen()">Vissza</button>');return;}
const url=(L('aiServer')?.value||'').trim(),token=L('aiToken')?.value||'';
const x=window.AndroidApp.configureAi(url,token);
if(x==='OK'){L('aiToken').value='';markStatus();assistant();const el=L('aiLiveResult');if(el)el.innerHTML='<div class="banner green">✓ Beállítás elmentve. Kattints a Személyes javaslat gombra az első valódi AI-kéréshez.</div>';}else alert(String(x).replace(/^ERROR:\s*/,''));}
function setConsent(x){try{if(x)localStorage.setItem(CONSENT,'yes');else localStorage.removeItem(CONSENT);}catch{} }
function run(action,auto=false){
 if(busy)return;
 if(!native()){if(!auto)alert('A valódi AI az Android-alkalmazásból érhető el.');return;}
 if(!conn().configured){if(!auto)setup();return;}
 if(!consent()){if(!auto)alert('Előbb engedélyezd a szükséges szakmai adatok továbbítását.');return;}
 const resume=importedResume();if(action==='analyze_resume'&&resume.length<35){if(!auto)alert('Először tölts fel önéletrajzot.');return;}
 const message=(L('aiMessage')?.value||'').trim();if(action==='chat'&&message.length<2){alert('Írd le a kérdésedet.');return;}
 busy=true;autoProcessing=!!auto;lastAction=action;lastRequest='req_'+Date.now()+'_'+Math.floor(Math.random()*1e6);
 const box=L('aiLiveResult');if(box)box.innerHTML='<div class="banner purple">⏳ Az AI elemzi az adatokat... Az első válasz a Render ingyenes szerverén lassabb lehet.</div>';if(auto){L('aiResumeFeedback')?.classList.remove('hide');if(L('aiResumeFeedbackText'))L('aiResumeFeedbackText').textContent='Az AI a dokumentum teljes szövegkörnyezetét elemzi. A javaslatokat jóváhagyás előtt átnézheted.';}
 const payload={action,profile:profile(),resumeText:action==='analyze_resume'?resume:'',message:action==='chat'?message:'',job:action==='interview'?(L('interviewJob')?.selectedOptions?.[0]?.textContent||''):''};
 window.AndroidApp.requestAi(JSON.stringify({requestId:lastRequest,payload}));
}
function result(x){if(!x||x.requestId!==lastRequest)return;busy=false;
 const box=L('aiLiveResult');
 if(!x.ok){lastRenderedHtml='<div class="banner orange">⚠ '+esc(x.error||'A kapcsolat nem sikerült')+'</div>';if(box)box.innerHTML=lastRenderedHtml;if(autoProcessing&&L('aiResumeFeedbackText'))L('aiResumeFeedbackText').textContent='Az élő AI-elemzés most nem sikerült. A helyi adatok megmaradtak. Nyisd meg az AI-segítőt az újrapróbáláshoz.';autoProcessing=false;return;}
 const r=x.data||{};let html='<div class="ail-answer"><strong>✦ Az AI javaslata</strong><p>'+esc(r.message||'')+'</p></div>';
 if(Array.isArray(r.suggested_roles)&&r.suggested_roles.length)html+='<div class="feedcard"><b>Lehetséges munkakörök</b><p>'+r.suggested_roles.map(esc).join(' • ')+'</p></div>';
 if(Array.isArray(r.missing)&&r.missing.length)html+='<div class="feedcard"><b>Érdemes pontosítani</b><ul>'+r.missing.map(z=>'<li>'+esc(z)+'</li>').join('')+'</ul></div>';
 if(lastAction==='analyze_resume'){
 latest=r.profile_patch||{};const changes=Object.entries(latest).filter(([key,value])=>LABELS[key]&&(Array.isArray(value)?value.length>0:String(value||'').trim().length>0));
 if(changes.length){html+='<div class="feedcard"><b>Javasolt adatok – csak jóváhagyás után mentjük</b><p class="tiny muted">A már meglévő mezőket nem írjuk felül automatikusan.</p>';
 html+=changes.map(([k,v])=>{const current=UI_FIELDS[k]?(L(UI_FIELDS[k])?.value||'').trim():'';const val=Array.isArray(v)?v.join(', '):String(v);return '<label class="ail-change"><input type="checkbox" data-ai-field="'+esc(k)+'" '+(current?'':'checked')+'><span><b>'+esc(LABELS[k])+'</b><br>'+esc(val).slice(0,750)+(current?'<br><small>Van meglévő adat – alapértelmezetten nincs kijelölve.</small>':'')+'</span></label>'}).join('');
 html+='<button class="button green full" onclick="aiLiveApply()">✓ Kiválasztott mezők átvétele</button></div>';
 }}
 if(lastAction==='draft_cv'&&r.cv_draft){latest={cv_draft:r.cv_draft};html+='<div class="feedcard"><b>CV-tervezet</b><p class="tiny muted">A modell által készített szöveget jóváhagyás előtt szerkesztheted. Nem lett automatikusan elsődleges.</p><button class="button green full" onclick="aiLiveUseDraft()">✍️ Tervezet átvétele a CV-szerkesztőbe</button></div>'}
 if(lastAction==='interview'&&Array.isArray(r.interview_questions)&&r.interview_questions.length)html+='<div class="feedcard"><b>Gyakorlókérdések</b><ol>'+r.interview_questions.map(esc).map(s=>'<li>'+s+'</li>').join('')+'</ol></div>';
 lastRenderedHtml=html;if(box)box.innerHTML=html;
 if(autoProcessing&&L('aiResumeFeedbackText'))L('aiResumeFeedbackText').textContent=(r.message||'Az AI-elemzés elkészült.').slice(0,320)+' — A részletes javaslatokat az AI-segítőben tudod ellenőrizni.';
 autoProcessing=false;
}
function apply(){if(!latest)return;let count=0;const values=latest;document.querySelectorAll('[data-ai-field]:checked').forEach(node=>{const key=node.dataset.aiField,v=values[key];if(!v)return;
 if(key==='skills'&&Array.isArray(v)){const existing=new Set([...document.querySelectorAll('#skills .chip.selected')].map(e=>e.dataset.skill.toLocaleLowerCase('hu-HU')));v.forEach(item=>{const x=[...document.querySelectorAll('#skills .chip')].find(e=>e.dataset.skill.toLocaleLowerCase('hu-HU')===String(item).toLocaleLowerCase('hu-HU'));if(x&&!existing.has(x.dataset.skill.toLocaleLowerCase('hu-HU'))){window.toggleSkill(x);existing.add(x.dataset.skill.toLocaleLowerCase('hu-HU'));count++;}});return;}
 const id=UI_FIELDS[key],el=id?L(id):null;if(!el)return;el.value=String(v).slice(0,1500);count++;
 });window.saveProfile(true);const el=L('aiLiveResult');if(el)el.innerHTML='<div class="banner green">✓ '+count+' adat átvéve. Ellenőrizd a profilmezőket; az AI-javaslatot nem tekintjük hitelesített bizonyítéknak.</div><button class="button secondary full" style="margin-top:10px" onclick="aiLiveGotoProfile()">Profil megnyitása</button>';latest=null;}
function useDraft(){if(!latest?.cv_draft)return;const draft=latest.cv_draft;window.closeSheet();window.go('cv');const editor=L('cvEditor');if(editor){editor.value=draft;editor.focus();}latest=null;alert('Az AI CV-tervezete a szerkesztőben van. Mentés és elsődlegessé tétel csak a külön jóváhagyás után történik.');}
function gotoProfile(){window.closeSheet();window.go('profile');}
function imported(text){
 // Ha a felhasználó korábban engedélyezte a CV szövegének továbbítását, az AI automatikusan elemzi.
 if(!consent()||!conn().configured||!native())return;
 run('analyze_resume',true);
}
window.aiLiveOpen=assistant;window.aiLiveSetup=setup;window.aiLiveSave=save;window.aiLiveConsent=setConsent;window.aiLiveRun=run;window.aiLiveApply=apply;window.aiLiveUseDraft=useDraft;window.aiLiveGotoProfile=gotoProfile;window.aiOnResumeImported=imported;window.receiveAIResult=result;window.openAssistant=assistant;
window.addEventListener('DOMContentLoaded',markStatus);
})();