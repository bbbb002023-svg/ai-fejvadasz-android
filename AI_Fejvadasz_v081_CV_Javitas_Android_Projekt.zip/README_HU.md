AI FEJVADÁSZ 0.8.1 – CV AI-KAPCSOLATI JAVÍTÁS
=========================================

Ez egy teljes Android-projekt. A GitHub Actions által fordítandó ZIP gyökerében a
settings.gradle, build.gradle és app/ könyvtár található.

JAVÍTÁSOK
- Hozzájárulás: pipa után OK / Mégse, OK esetén bezáruló ablak.
- A pipa önmagában nem jogosítja fel az alkalmazást az adatok továbbítására.
- A telefon nem vár egyetlen hosszú OpenAI-kapcsolatra: /api/cv/start és /api/cv/status.
- Az eredmények lekérése rövid, ismételhető kérésekkel történik.
- Átmeneti mobilhálózati hiba után ugyanazt a feladatot kérdezi újra; nem indít rögtön új fizetős AI-kérést.
- Ugyanazzal a CV-vel 20 percen belül az elkészült eredményt visszaadhatja a szerver,
  nem ismétli meg automatikusan az OpenAI-lekérdezést.
- Az OpenAI számlázási keret és a sebességkorlát hibája külön jelenik meg.
- Az elemzés eredményét a profiloldalon lehet ellenőrizni, csak jóváhagyás után kerül át.
- A jóváhagyás után az elemzési panel eltűnik, a CV-csere és az eredeti szöveg ellenőrzése megmarad.
- A CV-modell alapértelmezetten gpt-4.1-mini; Renderben OPENAI_CV_MODEL változóval módosítható.
- A szerver /health válaszában version: 0.8.1, cvAsync: true jelenik meg.

TELEPÍTÉSI SORREND
1. Az Android ZIP-et és a külön szerver ZIP-et töltsd fel a korábbi GitHub tárolóba.
2. A GitHub Actions .github/workflows/build-apk.yml ZIP kibontó sorát állítsd erre:
   unzip -q AI_Fejvadasz_v081_CV_Javitas_Android_Projekt.zip -d project
3. A Render Build Command legyen:
   unzip -oq AI_Fejvadasz_AI_Szerver_v081_CV_Javitas.zip -d ai-server && cd ai-server && npm install --omit=dev
   Start Command: cd ai-server && npm start
4. Renderen Deploy latest commit. Ellenőrzés: https://ai-fejvadasz-android.onrender.com/health
   Itt 0.8.1 verziót és cvAsync:true értéket kell látnod.
5. A GitHub Actions sikeres buildje után az APK-t telepítsd.
6. A régi tokent az alkalmazás megőrzi frissítéskor azonos alkalmazásazonosító esetén.

FONTOS KORLÁTOK
- Ez az Android-projekt és Node.js-szerver javítása, NEM helyben lefordított APK.
- A tesztek helyi modellezett OpenAI-válaszokon futottak; valós, titkos API-kulccsal
  a teljes kérés nem volt tesztelhető. A működést csak sikeres Render-telepítés és
  telefonos próba után szabad élesnek tekinteni.
- A CV-feladatok a Render folyamatának memóriájában vannak. Szerver-újraindításkor
  elveszhetnek; többfelhasználós, tartós változathoz adatbázis/queue szükséges.
- A CV tartalmát és az API-kulcsokat a projekt ZIP-ek nem tartalmazzák. A
  Render környezeti változóihoz nem kell hozzányúlni, ha a korábbi kulcsok működtek.
- A Profession/CVonline/fejvadász állásforrások további fejlesztései ettől függetlenek.
