AI FEJVADÁSZ 0.8.2 – CV FELÜLET + MAGYAR KERESŐMOTOR ALAP
=========================================================

EZ EGY TELJES ANDROID-PROJEKT, NEM KÉSZ APK.
A felépítés az eredeti, meglévő alkalmazásra épül. A korábbi 0.8.1-es CV-elemzés
(asyncron feladatindítás /api/cv/start, lekérdezés /api/cv/status) változatlanul megmarad.

MI ÚJ AZ ANDROIDON?
- A nagy AI-hozzájárulási panel eltűnik, ha a token biztonságosan el van mentve
  ÉS a felhasználó OK-val már jóváhagyta az adatkezelést.
- Mégse esetén nem rögzítünk hozzájárulást.
- A korábbi AI_APP_ACCESS_TOKEN változatlanul a telefon Android Keystore-titkosított
  tárolójában marad. Nem kell újra megadni; az APK-ba nincs titok beégetve.
- A CV-elemzési javaslatpanel csak a jóváhagyás után tűnik el, az
  újraelemzés lehetősége külön elérhető marad.
- A profil elmentése után az álláskeresés automatikusan elindul, ha vannak
  keresési adatok és a szerverhozzáférés be van állítva.
- A felfedezett Profession/CVonline/fejvadász hivatkozások külön listába kerülnek,
  az AI-egyezési és aktív hirdetési pontszámoktól elkülönítve.
- A keresés nem ugratja a képernyőt a tetejére; valós forrás-állapotot jelez.

MI ÚJ A RENDER SZERVEREN?
- 0.8.2-es verzió; /health: jobIndexSources és joobleSource jelzők.
- BRAVE_SEARCH_API_KEY esetén célzott HU nyelvű webes LINKFELDERÍTÉS:
  profession.hu, cvonline.hu, whc.hu, hsa.hu.
- JOOBLE_API_KEY esetén a korábbi HU Jooble adatkapcsolat.
- JOB_SOURCES beállítással a korábbi nyilvános Lever/Greenhouse ATS álláscsatornák.
- JOB_INDEX_DOMAINS=domain.hu,masik.hu beállítással további kisebb közvetítők
  nyilvános KERESŐINDEXÉBEN is kereshet. Legfeljebb 16 extra domain.
- Forrásonként tényleges előrehaladás; a közel azonos keresést 5 percen belül
  nem ismétli meg újra költséges API-hívással.
- Az indexből származó linkeket a program NEM jelöli aktív állásnak.
- A keresőindex találatait csak átmenetileg tároljuk a futó alkalmazáshoz,
  nem építünk belőlük tartós adatbázist.

FONTOS TECHNIKAI ÉS JOGI KORLÁTOK
- Nem a Profession/CVonline hivatalos adatbázis-API-jait használjuk. A Brave
  keresőindex linkjei hiányosak, régiek vagy lejártak lehetnek.
- A két portál automatizált scrapingjét NEM végezzük; technikai korlátozásokat
  vagy bejelentkezési védelmeket nem kerülünk meg.
- Az indexben felfedezett linkek NEM kapnak AI-alapú, teljes hirdetéses pontszámot.
- A Brave API-hoz saját kulcs szükséges, amelyet a Render Environment mezőibe kell
  biztonságosan beírni. A kereső-API külön költségkerettel működhet.
- A Jooble magyar API-hoz külön JOOBLE_API_KEY kell. Az OpenAI kulcsa egyikhez sem jó.
- Ez első tesztváltozat, nincs tartós feladat-queue, garantált háttérkeresés,
  telefonos push, teljes Profession/CVonline lefedettség vagy automatikus jelentkezés.
- Valós élő Brave API és OpenAI teszt NEM történt; a tesztek modellen kívüli
  szimulált válaszokat használtak. Az APK-t GitHub Actions-ben kell lefordítani.

FRISSÍTÉS – CSAK EGYMÁS UTÁN
1. Ezt és a külön AI-szerver ZIP-et töltsd fel a GitHub gyökérkönyvtárába.
2. A .github/workflows/build-apk.yml unzip sora:
   unzip -q AI_Fejvadasz_v082_CV_Keresok_Android_Projekt.zip -d project
3. Render Build Command:
   unzip -oq AI_Fejvadasz_AI_Szerver_v082_Keresok.zip -d ai-server && cd ai-server && npm install --omit=dev
   Start Command: cd ai-server && npm start
4. Render Environment (minden külön titkos):
   BRAVE_SEARCH_API_KEY=... (csak ha a keresőindex-elérést aktiválod)
   JOOBLE_API_KEY=... (csak ha magyar Jooble API-hozzáférésed van)
   JOB_INDEX_DOMAINS=... (opcionális extra magyar közvetítői domainlista)
   OPENAI_API_KEY és AI_APP_ACCESS_TOKEN változatlan marad.
5. Render /health: version 0.8.2, majd tesztprofilos élő keresés.

TESZT: node --test backend/test/*.test.js tests/*.test.js
17 Node-teszt + mobilméretű Chromium felületi teszt sikeres, de éles külső
szolgáltatásokkal integrációs teszt még szükséges.
