/* AI Fejvadász v0.5: óvatos, offline önéletrajz-adatfelismerés. Nem generatív AI. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.ResumeAssistant=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const FIELDS=[
 ['phone','Telefonszám','Adj meg olyan telefonszámot, amin a munkaadók elérnek.'],
 ['city','Lakóhely','Írd be a lakóhelyed települését; a keresési körzetet külön állíthatod.'],
 ['pastRoles','Korábbi munkakörök','Sorold fel a ténylegesen betöltött munkaköröket.'],
 ['targetRoles','Keresett munkakörök','Milyen állások érdekelnek? Az előző munkakör nem feltétlenül a következő célod.'],
 ['years','Szakmai tapasztalat évei','Add meg a tényleges, releváns évek számát.'],
 ['experience','Tapasztalatok és eredmények','Írd le, hol, mikor, mit végeztél és mit értél el.'],
 ['education','Végzettség','Add meg a legmagasabb befejezett iskolai végzettségedet.'],
 ['skills','Készségek','Jelöld csak azokat, amelyeket valóban használtál munkában.'],
 ['locations','Munkavégzési terület','Mely településeken vállalnál munkát?'],
 ['languages','Nyelvtudás','Add meg a nyelveket és a tudásod szintjét.'],
 ['certificates','Bizonyítványok','Add meg a tényleges képesítéseket és igazolásokat.']
];
const LABELS={...Object.fromEntries(FIELDS.map(([k,n])=>[k,n])),name:'Név',email:'E-mail',linkedin:'Szakmai weboldal',licenses:'Jogosítvány'};
function norm(s){return String(s||'').toLocaleLowerCase('hu-HU').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,' ').trim()}
function uniq(xs){return [...new Set(xs.filter(Boolean))]}
function block(lines,heads){const lower=lines.map(norm);const start=lower.findIndex(s=>heads.some(h=>s===norm(h)||s.startsWith(norm(h)+ ' :')));if(start<0)return '';
 let result=[];for(let i=start+1;i<lines.length&&result.length<25;i++){const raw=lines[i].trim(),n=lower[i];if(!raw){if(result.length) result.push('');continue;}if(n.length<48&&/^(tanulmany|iskola|vegzettseg|kepesites|keszseg|nyelvtudas|jogositvany|referencia|kapcsolat|szemelyes|hobb|erdeklodes|szakmai osszefoglal|munkatapasztalat|szakmai tapasztalat|munkahely|munkakor|tap asztalat)/.test(n))break;result.push(raw)}return result.join('\n').trim()}
function parse(text, skillsDictionary=[]){const raw=String(text||'').replace(/\r/g,'').replace(/\u00a0/g,' ').slice(0,160000);const lines=raw.split('\n').map(s=>s.trim()).filter((s,i,arr)=>s.length<400).slice(0,2000);const values={}, evidence={};function add(k,v,from){if(v!==undefined&&v!==null&&String(v).trim()&&!Object.prototype.hasOwnProperty.call(values,k)){values[k]=v;evidence[k]=from}}
 const email=raw.match(/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[A-Za-z]{2,}/);if(email)add('email',email[0],'CV e-mail cím');
 const phone=raw.match(/(?:\+36|0036|06)[\s.\-/]?(?:\d[\s.\-/]?){8,10}/);if(phone)add('phone',phone[0].replace(/\s+/g,' ').trim(),'CV telefonszám');
 const linkedin=raw.match(/(?:https?:\/\/)?(?:www\.)?linkedin\.com\/in\/[a-zA-Z0-9_%\-]+/i);if(linkedin)add('linkedin',linkedin[0].startsWith('http')?linkedin[0]:'https://'+linkedin[0],'Szakmai link');
 for(const line of lines.slice(0,35)){const name=line.replace(/^(nev|name|teljes nev)\s*[:\-]\s*/i,'').trim();if(!/\d|@|http|önéletrajz|cv\b|resume|profil/i.test(name)&&!/^(szakmai|munka|tanulmány|végzettség|személyes|egyéb|keresett|megpályázott|nyelvtudás|jogosítvány|tapasztalat|elérhetőség)/i.test(name)&&/^[\p{Lu}][\p{L}.'-]+(?:\s+[\p{Lu}][\p{L}.'-]+){1,3}$/u.test(name)&&name.length<60){add('name',name,'CV fejléc');break}}
 const cityLine=lines.find(l=>/^(lak[oó]hely|telep[uü]l[eé]s|lakc[ií]m|c[ií]m)\s*[:\-]/i.test(l));if(cityLine){const s=cityLine.split(/[:\-]/).slice(1).join('-').trim();if(s&&s.length<80)add('city',s,'Lakóhely mező')}
 const exp=block(lines,['Szakmai tapasztalat','Munkatapasztalat','Szakmai előélet','Munkahelyek','Munkaviszonyok','Korábbi munkahelyek']);if(exp.length>15)add('experience',exp,'Tapasztalat szakasz');
 const past=lines.find(l=>/^(kor[aá]bbi munkak[oö]r[oö]k|bet[oö]lt[oö]tt poz[ií]ci[oó]k)\s*[:\-]/i.test(l));if(past)add('pastRoles',past.split(/[:\-]/).slice(1).join('-').trim(),'Munkakörök mező');
 const target=lines.find(l=>/^(megp[aá]ly[aá]zott munkak[oö]r|keresett munkak[oö]r|c[eé]lzott poz[ií]ci[oó])\s*[:\-]/i.test(l));if(target)add('targetRoles',target.split(/[:\-]/).slice(1).join('-').trim(),'Célzott munkakör');
 const year=raw.match(/(?:tapasztalat|szakmai m[uú]lt)\s*[:\-]?\s*(\d{1,2})\s*[eé]v/i)||raw.match(/(\d{1,2})\s*[eé]v\s+(?:szakmai\s+)?tapasztalat/i);if(year&&Number(year[1])<=60)add('years',Number(year[1]),'Kimondott időtartam');
 const textNorm=norm(raw);const ed=[['egyetem',/egyetem|mesterfokozat|msc|bsc|diploma/],['főiskola',/foiskola/],['szakmunkás',/szakmunkas|szakmai bizonyitvany|szakkepesites/],['középfokú',/erettsegi|kozepiskola|gimnazium|szakgimnazium/],['általános',/altalanos iskola/]];for(const [k,rx]of ed)if(rx.test(textNorm)){add('education',k,'Végzettségre utaló szöveg');break}
 const langs=[];for(const language of ['angol','német','francia','olasz','spanyol','orosz']){if(new RegExp('(?:^|\\W)'+norm(language)+'(?:\\W|$)','i').test(textNorm))langs.push(language)}if(langs.length)add('languages',langs.join(', '),'Nyelv említése – szint ellenőrizendő');
 const dl=raw.match(/(?:jogos[ií]tv[aá]ny|vezet[oő]i enged[eé]ly)\s*[:\-]?\s*([ABCE]{1,4}\s*(?:kateg[oó]ria)?)/i);if(dl)add('licenses',dl[1].trim(),'Jogosítványra utaló szöveg');
 const matched=uniq(skillsDictionary.filter(x=>{const key=norm(x);if(key.length<3)return false;return (' '+textNorm+' ').includes(' '+key+' ')}));if(matched.length)add('skills',matched,'A CV-ben név szerint szereplő készségek');
 // Nincs automatikus jogosítvány- vagy képesítés-kitalálás, és nincs helyszín-inferencia lakóhelyből.
 return {values,evidence,characters:raw.length,lines:lines.length};}

// Bizonyíték-alapú, bátorító visszajelzés: nem állít biztos alkalmasságot, és nem minősít személyes tulajdonságokat.
function encouragement(rawText,parsed){
 const t=norm(rawText), v=parsed&&parsed.values||{}, skills=Array.isArray(v.skills)?v.skills:[];
 const has=(re)=>re.test(t);
 const sales=has(/ertekesit|kereskedel|sales|b2b|ugyfelkapcsolat|vevokiszolgal/);
 const lead=has(/csapatvezet|uzletvezet|ertekesitesi vezet|teruleti vezet|vezeto|iranyit|menedzs/);
 const shop=has(/bolti elado|elelmiszer elado|penztaros|kasszakezel|aruhaz|uzletvezeto/);
 const logistic=has(/raktar|logisztik|keszletkezel|szallitmany/);
 const tech=has(/szoftverfejlesz|javascript|programoz|informatik|rendszergazda/);
 const years=Number(v.years)||0;
 if(sales&&lead)return {title:'Erős szakmai alapokra építhetünk! 🌟',text:'Az önéletrajzodban értékesítési és vezetői feladatokra utaló tapasztalatot találtam. Érdemes sales management vagy értékesítési vezetői állásokat is megvizsgálnunk. A pontos megfelelést az egyes hirdetések követelményei alapján ellenőrizzük.',reason:'Azonosított témák: értékesítés és vezetés.'};
 if(sales)return {title:'Van mire építenünk! ✨',text:'Az önéletrajzodban értékesítéssel vagy ügyfelekkel kapcsolatos tapasztalatot találtam. Ez jó kiindulópont lehet kereskedelmi vagy értékesítési állásokhoz. Nézzük meg, milyen eredményeket tudunk kiemelni!',reason:'Azonosított téma: értékesítés / ügyfélkapcsolat.'};
 if(shop)return {title:'Jó alapokat találtam! 🌟',text:'A CV-d bolti vagy kereskedelmi feladatokat említ. Ezekből célzott, hiteles önéletrajzot állíthatunk össze eladói és üzleti pozíciókhoz. A képesítéseket és a konkrét elvárásokat még ellenőrzöm.',reason:'Azonosított téma: üzleti / bolti munka.'};
 if(logistic)return {title:'Értékes tapasztalati terület! ✨',text:'Raktározáshoz vagy logisztikához kapcsolódó feladatokat találtam. Ebből jó kiindulópontunk van a megfelelő raktári és logisztikai állások kereséséhez.',reason:'Azonosított téma: raktározás / logisztika.'};
 if(tech)return {title:'Szuper, találtam egy szakmai irányt! ✨',text:'A CV-d informatikai vagy fejlesztési tapasztalatot említ. Ezekre építve kereshetünk szakmailag kapcsolódó lehetőségeket; a konkrét technológiákat és gyakorlatot még pontosítjuk.',reason:'Azonosított téma: informatika / fejlesztés.'};
 if(years>=5)return {title:'Erre már lehet építeni! 🌟',text:`Az önéletrajzod ${years} év szakmai tapasztalatot említ. Ez értékes kiindulópont lehet! Segítek megmutatni, milyen feladatokat és eredményeket érdemes kiemelni.`,reason:`A CV-ben szereplő tapasztalat: ${years} év.`};
 if(skills.length)return {title:'Találtam használható erősségeket! ✨',text:`A CV-ben szerepel például a(z) ${skills.slice(0,2).join(' és ')}. Ezek jó kiindulópontok lehetnek az álláskereséshez, ha megerősíted a tényleges tapasztalatodat.`,reason:'A dokumentumban megnevezett készségek.'};
 return {title:'Jó lépés, hogy feltöltötted a CV-det! 💜',text:'Most elkezdjük rendszerezni a tapasztalataidat. Amit biztosan felismerünk, beillesztjük a profilodba; ahol nincs elég adat, ott együtt pontosítunk.',reason:'A dokumentumból még kevés szakmai részletet sikerült felismerni.'};
}
function missing(profile){return FIELDS.filter(([k])=>k==='skills'?!(profile.skills||[]).length:!(profile[k]&&String(profile[k]).trim())).map(([field,label,help])=>({field,label,help}));}
return {parse,missing,encouragement,FIELDS,LABELS};
});
