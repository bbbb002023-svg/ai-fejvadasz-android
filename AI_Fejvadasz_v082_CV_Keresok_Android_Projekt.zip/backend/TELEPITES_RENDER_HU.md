AI FEJVADÁSZ 0.8.2 – Render telepítés
=====================================
Build Command:
unzip -oq AI_Fejvadasz_AI_Szerver_v082_Keresok.zip -d ai-server && cd ai-server && npm install --omit=dev

Start Command:
cd ai-server && npm start

Environment (titok csak Renderen!):
- OPENAI_API_KEY (meglévő)
- AI_APP_ACCESS_TOKEN (meglévő, Android Keystore-ban mentve)
- OPENAI_CV_MODEL=gpt-4.1-mini (opcionális)
- BRAVE_SEARCH_API_KEY (új, Profession/CVonline/WHC/HSA linkkeresés, külön Brave szolgáltatás)
- JOOBLE_API_KEY (opcionális, külön magyar Jooble API-kulcs)
- JOB_INDEX_DOMAINS (opcionális, kisebb közvetítői domainek, csak validált hostnevek)
- JOB_SOURCES (opcionális, Lever/Greenhouse public boardok)

Elérhetőség ellenőrzése: https://ai-fejvadasz-android.onrender.com/health
Ha sikeres: version=0.8.2, cvAsync=true, jobIndexSources=true (csak Brave-kulccsal).

NINCS portáladatbázis-másolás, nincs aktív státusz ellenőrzés keresőindex-linknél,
NINCS háttér-worker/push; a Render Free újraindulása megszakíthatja a keresést.
