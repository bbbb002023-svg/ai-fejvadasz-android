'use strict';
const test=require('node:test'), assert=require('node:assert/strict');
const {fetchIndexedLinks,validIndexedUrl,indexQuery,searchManager,publicSources}=require('../job-search');
const wait=async manager=>{const start=Date.now();while(Date.now()-start<2000){const r=manager.status(manager.start({targetRoles:'Raktáros',city:'Budapest'}).id);if(r.status!=='running')return r;await new Promise(res=>setTimeout(res,15));}throw Error('timeout');};
test('Profession and CVonline index sources appear only with Brave key',()=>{
 assert.equal(publicSources({}).filter(x=>x.type==='index').length,0);
 const arr=publicSources({BRAVE_SEARCH_API_KEY:'MOCK_SECRET'});
 assert.deepEqual(arr.filter(x=>x.type==='index').map(x=>x.domain),['profession.hu','cvonline.hu','whc.hu','hsa.hu']);
});
test('Additional small recruitment domains are configurable safely',()=>{const a=publicSources({BRAVE_SEARCH_API_KEY:'A',JOB_INDEX_DOMAINS:'regionalis-fejvadasz.hu,masikallas.hu'});assert.equal(a.filter(x=>x.type==='index').length,6);assert.throws(()=>publicSources({BRAVE_SEARCH_API_KEY:'A',JOB_INDEX_DOMAINS:'example.com/path'}),/Érvénytelen/);});
test('Index link validation blocks forged domains, http and login pages',()=>{
 assert.equal(validIndexedUrl('https://www.profession.hu/allas/teszt-123','profession.hu'),true);
 assert.equal(validIndexedUrl('https://profession.hu.attacker.com/allas/123','profession.hu'),false);
 assert.equal(validIndexedUrl('http://www.profession.hu/allas/123','profession.hu'),false);
 assert.equal(validIndexedUrl('https://www.profession.hu/login','profession.hu'),false);
 assert.match(indexQuery({targetRoles:'Raktáros',city:'Győr'},'cvonline.hu'),/site:cvonline\.hu Raktáros Győr állás/);
});
test('Brave search fetch uses Hungary language, key stays in headers and results are unverified',async()=>{
 const calls=[];
 const mock=async(url,opts)=>{calls.push({url,headers:opts.headers});return {ok:true,json:async()=>({web:{results:[
  {title:'Raktáros – Profession.hu',url:'https://www.profession.hu/allas/raktaros-123',description:'Állás Budapest, targoncavezető'},
  {title:'Raktáros hamis oldal',url:'https://www.profession.hu.evil.example/allas/123',description:'Nem a Profession'}
 ]}})};};
 const src=publicSources({BRAVE_SEARCH_API_KEY:'SECRET'}).find(x=>x.domain==='profession.hu');
 const links=await fetchIndexedLinks('SECRET',src,{targetRoles:'Raktáros',city:'Budapest'},mock);
 assert.equal(links.length,1);assert.equal(links[0].verified,false);assert.equal(links[0].kind,'index_link');
 assert.equal(calls.length,1);assert.equal(new URL(calls[0].url).searchParams.get('country'),'HU');
 assert.equal(calls[0].headers['X-Subscription-Token'],'SECRET');assert.ok(!calls[0].url.includes('SECRET'));
});
test('Parallel multi-source workflow records four completed sources, keeps links separate from verified jobs',async()=>{
 let count=0;
 const mock=async(url)=>{count++;const host=new URL(url).searchParams.get('q')||'';
  const domain=host.match(/site:([\w.]+)/)?.[1]||'profession.hu';
  return {ok:true,json:async()=>({web:{results:[{title:'Raktáros állás',url:'https://www.'+domain+'/allas/raktaros-012',description:'Raktárosi pozíció'}]}})};};
 const mgr=searchManager({env:{BRAVE_SEARCH_API_KEY:'SECRET'},fetchImpl:mock,rankFn:async()=>[]});
 const s=mgr.start({targetRoles:'Raktáros',city:'Budapest'});
 let result=mgr.status(s.id);for(let i=0;i<120&&result.status==='running';i++){await new Promise(r=>setTimeout(r,12));result=mgr.status(s.id);}
 assert.equal(result.status,'done');assert.equal(result.progress,100);assert.equal(result.sourceCount,4);
 assert.equal(result.checked,4);assert.equal(result.jobs.length,0);assert.equal(result.links.length,4);assert.equal(result.indexConnected,true);assert.equal(result.portalConnected,false);
 const again=mgr.start({targetRoles:'Raktáros',city:'Budapest'});assert.equal(again.id,s.id);
 assert.equal(count,4,'same user request must not spend another 4 API calls immediately');
});
