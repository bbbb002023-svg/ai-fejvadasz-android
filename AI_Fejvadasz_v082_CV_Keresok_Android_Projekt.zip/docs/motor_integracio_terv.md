# Saját AI Fejvadász motor – integrációs terv (0.4)

## Elkészült és működik az alkalmazásban
- `pwa/engine.js` (azonosan `app/src/main/assets/engine.js`): magyar szakmacsalád-felismerés és -kizárás, kompetenciák összevetése, kötelező végzettség/jogosultság ellenőrzése, helyszínszűrés, 100 pontos magyarázható egyezési score.
- A pontszám nem a felvételi esély százaléka, hanem a megadott munkakör követelményeihez való illeszkedés.
- Az eredményekben látható, mi egyezik és mi hiányzik. A kizárt hirdetés nem ajánlott és nem kerül automatikus küldésre.
- A motor fiktív mintaállásokon és a felhasználó által kézzel vagy JSON-ból importált hirdetéseken működik. Importált hirdetéseket nem tekint automatikusan ellenőrzöttnek.
- A 90%-os auto-jelölt jelző már megvan; éles elküldés soha nem történik.

## Következő szerveres komponensek
1. **Biztonságos felhasználói fiók:** valódi e-mailes regisztráció, ellenőrzés, jelszóhash, jelszó-visszaállítás, GDPR-adatkezelés, fiókonkénti privát CV-, fénykép- és jelentkezéstár. A telefonon most kizárólag helyi demóprofil van, nem valódi fiók.
2. **Jogszerű állásforrás-regiszter:** portálonként engedélyezett API/partneradatfolyam vagy munkáltatói ATS publikus állás-feed; hozzáférési szabályok és forrás-állapotjelző.
3. **Központi keresőindex:** hirdetések normalizálása, deduplikálása, lejárat, magyarországi telephely és kötelező feltételek. A helyi motor az egységes hirdetésmodellt már ismeri.
4. **Kétszeri ütemezés:** 08:00 és 20:00, időzóna Europe/Budapest, ellenőrzési naplóval és értesítésekkel. Hosszabb lekérdezések nem a telefonon futnak.
5. **OpenAI/API asszisztens:** kizárólag szerveroldali kulccsal; adatminimalizálás, felhasználói hozzájárulás, személyes megfogalmazási javaslatok. Az appbeli segítő jelenleg helyi, szabályalapú funkció.
6. **Jelentkezéskezelő:** külön felhatalmazás, 90% és kapufeltételek, engedélyezett munkáltatói integráció, idempotens beküldés, CAPTCHA/robottilalom tiszteletben tartása, hiteles visszaigazolások.

## Normalizált hirdetés példa

```json
{"id":"trusted_123","title":"Élelmiszer-eladó","company":"Példa Kft.","city":"Budapest","skills":["kasszakezelés","vevőkiszolgálás"],"education":"középfokú","requiredCertificates":[],"license":[],"minYears":2,"workMode":"teljes munkaidő","salaryMin":420000,"description":"...","url":"https://munkaltato.hu/karrier/123","source":"Munkáltató – engedélyezett feed"}
```

A HTML-es kereső nem tárolhat OpenAI- vagy munkaadói API-kulcsot. Éles üzemhez a jogosultságokat és a feldolgozást a szervernek kell érvényesítenie; a mobilos szabályellenőrzés önmagában nem elég a küldés védelméhez.
