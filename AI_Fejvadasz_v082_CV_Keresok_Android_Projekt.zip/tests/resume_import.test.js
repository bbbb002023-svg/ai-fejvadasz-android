const assert=require('node:assert/strict');
const R=require('../pwa/resume.js');
const E=require('../pwa/engine.js');
const sample=`Kiss Anna
Lakóhely: Budapest
Telefon: +36 30 123 4567
E-mail: anna.kiss@pelda.hu
Keresett munkakör: Élelmiszer-eladó
5 év szakmai tapasztalat
SZAKMAI TAPASZTALAT
Bolti eladó, 2020–2025
Vásárlók kiszolgálása, kasszakezelés, készletkezelés.
TANULMÁNYOK
Érettségi, 2019.
Nyelvtudás: német alapfok`;
const report=R.parse(sample,E.SKILL_DICTIONARY);console.log(report);
assert.equal(report.values.name,'Kiss Anna');
assert.equal(report.values.city,'Budapest');
assert.match(report.values.phone,/36 30/);
assert.equal(report.values.email,'anna.kiss@pelda.hu');
assert.equal(report.values.targetRoles,'Élelmiszer-eladó');
assert.equal(report.values.years,5);
assert.equal(report.values.education,'középfokú');
assert.ok(report.values.skills.includes('kasszakezelés'));
assert.ok(report.values.skills.includes('készletkezelés'));
assert.ok(!report.values.skills.includes('autószerelés'));
assert.ok(!('locations' in report.values)); // Lakóhely nem egyenlő a vállalt munkavégzési hellyel.
const miss=R.missing(report.values).map(x=>x.field);assert.ok(miss.includes('locations'));
const scans=R.parse('SZAKMAI TAPASZTALAT\n2022–2026 gépszerelőként dolgoztam.\nTANULMÁNYOK\nKözépfokú végzettség',E.SKILL_DICTIONARY);
assert.ok(!scans.values.name,'fejléc nem tekinthető névnek');

const leadershipCV='Nagy Éva\n8 év értékesítési tapasztalat\nTerületi értékesítési vezető, csapatvezetés és B2B tárgyalás';
const leadership=R.parse(leadershipCV,E.SKILL_DICTIONARY);
const encouragement=R.encouragement(leadershipCV,leadership);
assert.match(encouragement.text,/sales management|értékesítési vezetői/);
assert.match(encouragement.reason,/értékesítés és vezetés/);
const unrelated=R.encouragement('Kiss Pál\nKerékpár javítás és kertészkedés',R.parse('Kiss Pál\nKerékpár javítás és kertészkedés',E.SKILL_DICTIONARY));
assert.ok(!/sales management/i.test(unrelated.text),'nem dicséri tévesen sales vezetőként');
console.log('✓ CV felismerési és bátorító visszajelzési tesztek sikeresek');
