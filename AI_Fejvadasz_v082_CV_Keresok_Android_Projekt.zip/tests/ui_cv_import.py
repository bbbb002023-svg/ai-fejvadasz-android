from playwright.sync_api import sync_playwright
from pathlib import Path
p=Path('/mnt/data/AI_Fejvadasz_v05_project/pwa')
with sync_playwright() as pw:
    br=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    page=br.new_page(viewport={'width':390,'height':844},device_scale_factor=2)
    problems=[]
    page.on('pageerror',lambda err:problems.append(str(err)))
    page.set_content((p/'index.html').read_text().replace('<script src="engine.js"></script><script src="resume.js"></script><script src="app.js"></script>',''))
    for f in ['engine.js','resume.js','app.js']:page.add_script_tag(content=(p/f).read_text())
    page.evaluate("window.dispatchEvent(new Event('DOMContentLoaded'))")
    assert page.locator('#auth').is_visible()
    page.locator('#regName').fill('Kiss Anna')
    page.locator('#regEmail').fill('anna.kiss@pelda.hu')
    page.locator('#regPass').fill('a-test-password-for-demo')
    page.locator('#regConsent').check()
    page.locator('button',has_text='Profil indítása').click()
    assert page.locator('#profile').is_visible()
    assert page.locator('.resume-first').is_visible()
    page.screenshot(path='/mnt/data/AI_Fejvadasz_v05_CV_feltoltes.png',full_page=True)
    text='''Kiss Anna
Lakóhely: Budapest
Telefon: +36 30 123 4567
E-mail: anna.kiss@pelda.hu
Keresett munkakör: Élelmiszer-eladó
5 év szakmai tapasztalat
SZAKMAI TAPASZTALAT
Bolti eladó, 2020–2025
Vevők kiszolgálása, kasszakezelés, készletkezelés.
TANULMÁNYOK
Érettségi
Nyelvtudás: német - alapfok'''
    page.evaluate("(text) => window.receiveImportedResume({ok:true,filename:'cv_teszt.txt',method:'TXT',text,photo:''})",text)
    assert page.locator('#resumeStatus').is_visible()
    assert 'cv_teszt.txt' in page.locator('#resumeStatus').inner_text()
    assert page.locator('#pPhone').input_value().startswith('+36')
    assert page.locator('#pCity').input_value()=='Budapest'
    assert page.locator('#pTargetRoles').input_value()=='Élelmiszer-eladó'
    assert 'kasszakezelés' in page.locator('button.selected').all_text_contents()[0] or any('kasszakezelés' in k for k in page.locator('button.selected').all_text_contents())
    assert page.locator('#pLocations').input_value()==''
    assert 'Munkavégzési terület' in page.locator('#resumeMissing').inner_text()
    page.screenshot(path='/mnt/data/AI_Fejvadasz_v05_Kitoltott_profil.png',full_page=True)
    page.locator('button',has_text='Önéletrajz készítése').click()
    assert page.locator('#cv').is_visible()
    page.locator('button',has_text='CV összeállítása').click()
    assert 'KISS ANNA' in page.locator('#cvEditor').input_value()
    assert 'kasszakezelés' in page.locator('#cvEditor').input_value()
    assert '[Nincs' not in page.locator('#cvEditor').input_value()
    page.screenshot(path='/mnt/data/AI_Fejvadasz_v05_CV_elonezet.png',full_page=True)
    assert not problems, problems
    print('✓ Siker: regisztráció -> CV-feltöltés -> űrlap kitöltése -> hiánypótlás -> CV előnézet')
    br.close()
