# AI Fejvadász 0.8 – AI az első a CV-feldolgozásban

**Tesztverzió – nem kész végleges termék.**

## Mit javítottunk?
- A PDF / DOCX / TXT fájlt a telefon olvassa be; az adatok elsődleges értelmezését az OpenAI végzi az appból a saját Render szerveren át, ha a hozzáférés és a kifejezett hozzájárulás adott.
- Az offline, kulcsszavas felismerő többé nem tölti ki automatikusan a profilt; csak külön választott tartalék.
- Az AI javaslatai közvetlenül a profilban látszanak, rövid szó szerinti CV-bizonyítékokkal. A felhasználó választja ki és hagyja jóvá őket.
- A dokumentum beolvasása és a **sikeres AI-elemzés** külön státusz. A ténylegesen kiolvasott szöveg egy gombbal megtekinthető.
- A már felvitt profilmezőket a rendszer nem írja felül csendben; az új CV elemzést indít.
- Az AI nem találhat ki munkaviszonyt, képesítést vagy időtartamot.

## Fontos korlátok
- Szkennelt, kép-alapú PDF-ekhez még nincs OCR. Ha a szöveg nem olvasható ki, azt jelezzük; a szöveg kézi beillesztése lehetséges.
- A 42 000 karakternél hosszabb CV-k szövege korlátozott, ezt bővíteni kell.
- Nem végeztünk hiteles, végponttól végpontig tartó OpenAI-tesztet titkos API-kulccsal; mockolt felületi és szervertesztek sikeresek.
- A valós, többplatformos magyar állásgyűjtés és a háttérben garantált push még nincs kész.
- A szerver teszt-tokenre épül, többfelhasználós nyilvános kiadáshoz külön auth kell.

## Android projekt fordítása GitHub Actions-szel
A projekt ZIP teljes Gradle-projektet tartalmaz, nem közvetlen APK-t.
`AI_Fejvadasz_v08_AI_Elso_Android_Projekt.zip`
A GitHub workflow kibontó sora:
`unzip -q AI_Fejvadasz_v08_AI_Elso_Android_Projekt.zip -d project`

## Render szerverfrissítés
A szerver ZIP kizárólag a backend fájlokat tartalmazza gyökérszinten.
`AI_Fejvadasz_AI_Szerver_v08_CV.zip`
Build Command:
`unzip -oq AI_Fejvadasz_AI_Szerver_v08_CV.zip -d ai-server && cd ai-server && npm install --omit=dev`
Start Command:
`cd ai-server && npm start`

**Titkos értéket ne tölts fel GitHubra!** A meglévő `OPENAI_API_KEY` és `AI_APP_ACCESS_TOKEN` Render Environment értékek maradhatnak. `OPENAI_MODEL` legyen egy ténylegesen elérhető kompatibilis modell, pl. `gpt-5-mini`.

## Tesztek
`node --test backend/test/*.test.js tests/*.test.js`
`python /mnt/data/_test_v08_ai_first.py` (helyi Chromium próbateszt)
