/* AI Fejvadász 0.7.1 – szerveroldali saját álláskeresés mobilos vezérlője.
 * Az API titkos hozzáférési kódja NEM érhető el JS-ből; csak az Android Keystore-ban él.
 */
(function(){'use strict';
const IDKEY='ai_fejvadasz_job_search_id_v07';
const $=id=>document.getElementById(id);
let current='',pollTimer=null,awaiting=false;
function status(message,percentage,details){
 const s=$('aiJobSearchText'),p=$('aiJobSearchPercent'),bar=$('aiJobProgress'),fill=$('aiJobProgressFill'),info=$('aiJobSearchDetails');
 if(s)s.textContent=message;if(p)p.textContent=Math.max(0,Math.min(100,percentage||0))+'%';
 if(fill)fill.style.width=Math.max(0,Math.min(100,percentage||0))+'%';
 if(bar)bar.setAttribute('aria-valuenow',String(percentage||0));if(info&&details)info.textContent=details;
}
function configured(){try{return Boolean(JSON.parse(window.AndroidApp?.getAiConnection?.()||'{}').configured);}catch{return false;}}
function schedule(){clearTimeout(pollTimer);if(current)pollTimer=setTimeout(poll,2600);}
function poll(){if(!current||awaiting)return;awaiting=true;window.AndroidApp?.pollJobSearch?.(JSON.stringify({requestId:'poll_'+Date.now(),searchId:current}));}
function start(automatic){
 if(!window.AndroidApp?.startJobSearch){if(!automatic)status('Az automatikus élő keresés az Android 0.7-es verziójában érhető el.',0);return;}
 if(!configured()){status('Először állítsd be a külön AI-szerver hozzáférést.',0,'A keresés a CV véglegesítése után automatikus; nincs minden keresés előtt új jóváhagyás.');return;}
 const profile=window.getSearchProfile?.();if(!profile?.targetRoles&&!profile?.pastRoles&&!profile?.skills?.length){status('Még nincs elegendő szakmai adat a kereséshez.',0);return;}
 current='';clearTimeout(pollTimer);awaiting=true;
 status('A saját AI keresőmotor elindítása…',1,'Magyarországi céges karrieroldalak ellenőrzése.');
 window.AndroidApp.startJobSearch(JSON.stringify({requestId:'start_'+Date.now(),profile}));
}
function refresh(){if(!current){try{current=localStorage.getItem(IDKEY)||'';}catch{}}
 if(current&&window.AndroidApp?.pollJobSearch&&!awaiting)poll();}
function receive(x){awaiting=false;
 if(!x||!x.ok){
   const msg=String(x?.error||'Nem sikerült lekérni a keresés állapotát.');
   status('Keresési hiba: '+msg,0,'A következő próbálkozás előtt ellenőrizd a Render-szerver elérhetőségét.');
   if(/nem található|újraindulhatott/.test(msg)){current='';try{localStorage.removeItem(IDKEY);}catch{}}return;
 }
 const s=x.search||{};if(!s.id)return;
 current=s.id;try{localStorage.setItem(IDKEY,current);}catch{}
 const progress=Number(s.progress)||0,errors=Array.isArray(s.errors)?s.errors:[];
 const portal=s.portalConnected?'Jooble.hu magyar portál bekötve':'⚠ Nincs aktív magyar állásportál API-kapcsolat';
 const sources=Array.isArray(s.sourceNames)?s.sourceNames.join(', '):'';
 const details=`${portal} · ${s.checked||0}/${s.sourceCount||0} forrás · ${s.found||0} hirdetés · ${sources||'nincs adatforrás'}${errors.length?' · '+errors.join(' / ').slice(0,280):''}`;
 if(s.status==='running'){
   status('✦ '+(s.stage||'Az AI a hirdetéseket elemzi'),progress,details);schedule();
 }else if(s.status==='done'){
   const jobs=Array.isArray(s.jobs)?s.jobs:[];
   window.ingestLiveJobSearch?.(jobs);
   const ai=jobs.some(j=>j.aiAnalyzed);
   status(`✓ A keresés befejeződött: ${jobs.length} előszűrt magyarországi állás.`,100,
     details+(ai?' · AI-szövegértelmezés elkészült.':' · A modell nem volt elérhető minden találatnál; szabályalapú pontozás.'));
   // Ne navigáljunk újra: a go('jobs') ablakgörgetést nulláz, így használhatatlan volt az állásmonitor.
   current='';try{localStorage.removeItem(IDKEY);}catch{}
 }else{
   status('A keresés megszakadt vagy hibára futott.',progress,errors.join(' · ')||'Ellenőrizd a keresési forrásokat.');
   current='';try{localStorage.removeItem(IDKEY);}catch{}
 }
}
window.aiJobSearchStart=start;window.aiJobSearchRefresh=refresh;window.receiveJobSearch=receive;
window.addEventListener('DOMContentLoaded',()=>{setTimeout(refresh,600);});
})();
