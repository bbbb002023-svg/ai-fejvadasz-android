/* AI Fejvadász – saját, magyarázható magyar állásillesztési motor v0.4.
 * Kliensoldali szabálymotor, NEM OpenAI, NEM élő portálgyűjtő és NEM felvételi esély.
 * UMD, hogy Android WebView és Node.js alatt azonos tesztek fussanak.
 */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.AIJobEngine=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const FAMILIES={
 retail:{label:'Kereskedelem és bolti munka',terms:['elado','bolti','penztaros','aruhaz','elelmiszer','uzletvezeto','boltvezeto','bolt','arufeltolto','ertekesito uzlet','kereskedelmi munkatars'],skills:['vevokiszolgalas','kasszakezeles','keszletkezeles','aruatarvetel','arufeltoltes','kereskedelem','ertekesites','vasarloi kommunikacio']},
 sales:{label:'Értékesítés és üzletfejlesztés',terms:['ertekesitesi','ertekesites','sales','uzletkoto','key account','b2b','teruleti kepviselo','kereskedelmi vezeto','regionalis vezeto'],skills:['ertekesites','ugyfelkapcsolat','b2b','targyalastechnika','crm','vezetes','strategia','partnerkapcsolatok']},
 logistics:{label:'Logisztika és raktár',terms:['raktaros','raktar','logisztika','beszerzo','szallitmany','targonc','keszletgazdalkodas','fulfillment'],skills:['logisztika','raktarozas','keszletkezeles','targoncavezetes','beszerzes','szallitmanyozas']},
 mechanic:{label:'Autószerelés és műszaki szerviz',terms:['autoszerelo','gepjarmuszerelo','autoszerviz','autotechnikus','jarmudiagnosztika','szerelo','motorszerelo'],skills:['autoszereles','jarmudiagnosztika','muschaki javitas','szerviz','muszaki rajz']},
 it:{label:'Informatika',terms:['fejleszto','programozo','software','szoftver','informatikus','devops','rendszergazda','frontend','backend','it support'],skills:['javascript','python','java','sql','teszteles','fejlesztes','it tamogatas']},
 admin:{label:'Adminisztráció és iroda',terms:['adminisztrator','irodai','asszisztens','adatrögz','ugyintezo','recepcios','titkar'],skills:['adminisztracio','excel','ugyfelkapcsolat','dokumentumkezeles','kommunikacio']},
 hospitality:{label:'Vendéglátás',terms:['pincer','felszolgalo','szakacs','konyhai','vendeglatas','barista','recepcios szalloda'],skills:['vendeglatas','kasszakezeles','vevokiszolgalas','fozes','higienia']},
 healthcare:{label:'Egészségügy',terms:['apolo','orvos','asszisztens egeszseg','egeszsegugy','gyogytornasz'],skills:['apolas','egeszsegugy','betegellatas']},
 education:{label:'Oktatás',terms:['tanar','pedagogus','oktat','tanito','kepzo'],skills:['oktatas','kommunikacio','pedagogia']},
 manufacturing:{label:'Gyártás és termelés',terms:['gepkezelo','operator','termeles','minosegellenor','gyartosori','ossz eszerelo'],skills:['gyartas','minosegellenorzes','gepkezeles','muszakvezetes']}
};
const SKILL_DICTIONARY=['értékesítés','vevőkiszolgálás','kasszakezelés','készletkezelés','árufeltöltés','kereskedelem','ügyfélkapcsolat','B2B','tárgyalástechnika','CRM','vezetés','stratégia','partnerkapcsolatok','logisztika','raktározás','targoncavezetés','beszerzés','szállítmányozás','autószerelés','járműdiagnosztika','szerviz','JavaScript','Python','Java','SQL','tesztelés','fejlesztés','IT támogatás','adminisztráció','Excel','dokumentumkezelés','kommunikáció','vendéglátás','főzés','higiénia','ápolás','egészségügy','betegellátás','oktatás','pedagógia','gyártás','minőségellenőrzés','gépkezelés','műszakvezetés'];
function norm(s){return String(s||'').toLocaleLowerCase('hu-HU').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,' ').trim().replace(/\s+/g,' ')}
function array(v){return Array.isArray(v)?v:(v?String(v).split(/[,;\n]+/):[])}
function tokens(v){return array(v).map(x=>norm(x)).filter(Boolean)}
function includesPhrase(text,term){const t=norm(term);return !!t && (' '+norm(text)+' ').includes(' '+t+' ')}
function detectFamily(title,skills){const titleN=norm(title);const s=norm(array(skills).join(' '));let best=null,points=0;for(const [key,f] of Object.entries(FAMILIES)){let score=0;for(const x of f.terms){const a=norm(x);if(titleN.includes(a))score+=a.length>=9?5:3}for(const x of f.skills){if(s.includes(norm(x)))score+=0.65}if(score>points){best=key;points=score}}return points>=1.5?best:null}
function skillAliasesMatch(sk1,sk2){const a=norm(sk1),b=norm(sk2);return !!a&&!!b&&(a===b || (a.length>=6&&b.length>=6&&(a.includes(b)||b.includes(a))))}
function matchingSkills(have,requires){const h=tokens(have),r=array(requires).filter(Boolean);return {matched:r.filter(s=>h.some(t=>skillAliasesMatch(t,s))),missing:r.filter(s=>!h.some(t=>skillAliasesMatch(t,s))),count:r.length}}
const EDU_LEVELS={'nincs':0,'alapfoku':1,'altalanos':1,'kozepfoku':2,'szakmunkas':2,'szakkepzett':2,'erettsegi':2,'felsooktatasi':3,'felsooktatas':3,'foiskola':3,'egyetem':4,'diploma':4};
function level(s){if(!s)return -1;const n=norm(s);for(const [k,v] of Object.entries(EDU_LEVELS))if(n.includes(k))return v;return -1}
function fitJob(profile,job){const p=profile||{},j=job||{},reasons=[],warnings=[],blockers=[];
const pSkills=array(p.skills),jSkills=array(j.skills),match=matchingSkills(pSkills,jSkills),pRole=String(p.targetRoles||p.title||''),pFamily=detectFamily(pRole,pSkills)||detectFamily(p.pastRoles,pSkills),jFamily=j.family||detectFamily(j.title,jSkills);
const excluded=tokens(p.excludedRoles);if(excluded.some(x=>norm(j.title).includes(x))){blockers.push('A munkakört kifejezetten kizártad.');}
const knownFamily=!!pFamily&&!!jFamily;const wanted=tokens(pRole);let familyOK=!knownFamily||pFamily===jFamily;
if(!familyOK){const allowed=tokens(p.allowedFamilies);if(allowed.includes(norm(jFamily)))familyOK=true;}
if(knownFamily&&!familyOK){blockers.push('Eltérő szakmacsalád: '+FAMILIES[pFamily].label+' ↔ '+FAMILIES[jFamily].label+'.');}
const certs=tokens(p.certificates);const requiredCerts=array(j.requiredCertificates);for(const cert of requiredCerts)if(!certs.some(x=>skillAliasesMatch(x,cert))){blockers.push('Hiányzó kötelező igazolás: '+cert+'.');}
const jobEdu=level(j.education),personEdu=level(p.education);if(jobEdu>=0){if(personEdu<0)blockers.push('Nem igazolt a megkövetelt végzettség: '+j.education+'.');else if(personEdu<jobEdu)blockers.push('A megadott végzettség nem éri el az előírt szintet.');}
const requiredLicense=array(j.license);const licenses=tokens(p.licenses);for(const lic of requiredLicense)if(!licenses.some(x=>skillAliasesMatch(x,lic)))blockers.push('Kötelező jogosítvány/engedély hiányzik: '+lic+'.');
const minYears=Number(j.minYears)||0,years=Number(p.years)||0;if(minYears&&years<minYears)warnings.push('A hirdetés '+minYears+' év tapasztalatot kér; nálad '+years+' év szerepel.');
const city=norm(j.city||j.location),preferred=tokens(p.locations||p.city);const remote=!!j.remote||/tavmunka|remote|home office|orszagos/.test(city);const locationKnown=preferred.length>0&&city.length>0;const locationOK=j.regionVerified===true||remote||!locationKnown||preferred.some(k=>city.includes(k)||k.includes(city));
if(locationKnown&&!locationOK){blockers.push('A hirdetés helyszíne eltér a választott keresési területtől.');}
if(!locationKnown)warnings.push('A területi megfeleléshez további adat szükséges.');
const desiredWork=norm(p.workMode),jobWork=norm(j.workMode);const workOK=!desiredWork||desiredWork==='mindegy'||!jobWork||jobWork.includes(desiredWork)||desiredWork.includes(jobWork);
if(!workOK)warnings.push('A munkarend eltérhet a preferenciádtól.');
const desiredSalary=Number(p.salaryMin)||0,offerSalary=Number(j.salaryMin)||0;const payOK=!desiredSalary||!offerSalary||offerSalary>=desiredSalary;if(desiredSalary&&!offerSalary)warnings.push('A hirdetés nem tartalmaz ellenőrizhető béradatot.');else if(!payOK)warnings.push('A megadott bérsáv a kívánt minimum alatt van.');
const skillsScore=match.count?35*match.matched.length/match.count:16;
const yearsScore=minYears?20*Math.min(1,years/minYears):(years>0?18:7);
const familyScore=knownFamily?(familyOK?20:0):(wanted.length&&includesPhrase(j.title,pRole)?20:10);
const locationScore=locationOK?(locationKnown||remote?15:7):0;
const preferenceScore=(workOK?5:0)+(payOK?5:0);
const score=Math.max(0,Math.min(100,Math.round(skillsScore+yearsScore+familyScore+locationScore+preferenceScore)));
if(match.matched.length)reasons.push('Egyező készségek: '+match.matched.join(', ')+'.');
if(match.missing.length)warnings.push('Nem igazolt készségek: '+match.missing.join(', ')+'.');
if(knownFamily&&familyOK)reasons.push('A szakmacsalád illeszkedik a profilodhoz.');
if(minYears&&years>=minYears)reasons.push('A tapasztalat eléri a hirdetésben kért szintet.');
if(locationKnown&&locationOK)reasons.push('A helyszín megfelel a beállított területnek.');
const autoThreshold=Math.max(90,Math.min(100,Number(p.autoThreshold)||90));
return {score,blockers,warnings,reasons,matchedSkills:match.matched,missingSkills:match.missing,family:jFamily||null,eligible:blockers.length===0,autoCandidate:score>=autoThreshold&&blockers.length===0,canAutoSend:false,decision:blockers.length?'kizárt':score>=autoThreshold?'kiemelten ajánlott':'megfontolandó',components:{skills:Math.round(skillsScore),experience:Math.round(yearsScore),family:Math.round(familyScore),location:Math.round(locationScore),preferences:Math.round(preferenceScore)}};
}
function normalizedJob(raw,index){const a=raw||{};const url=/^https:\/\//i.test(String(a.url||''))?String(a.url):'';const title=String(a.title||'').trim(),company=String(a.company||'').trim();return {id:String(a.id||'import_'+index+'_'+norm(title+company).replace(/ /g,'_').slice(0,26)).replace(/[^a-zA-Z0-9_-]/g,'_').slice(0,64),title,company,city:String(a.city||a.location||''),location:String(a.city||a.location||''),workMode:String(a.workMode||''),salaryMin:Number(a.salaryMin)||0,minYears:Number(a.minYears)||0,education:String(a.education||''),requiredCertificates:array(a.requiredCertificates),license:array(a.license),skills:array(a.skills),description:String(a.description||''),url,source:String(a.source||'Felhasználói import'),verified:false,isDemo:false,remote:!!a.remote};}
function uniqueJobs(items){const seen=new Set();return items.filter(j=>{if(!j.title||!j.company)return false;const key=j.url||norm(j.title+' '+j.company+' '+j.city);if(seen.has(key))return false;seen.add(key);return true})}
function searchTerms(p){const words=[...(tokens(p.targetRoles).slice(0,3)),...(tokens(p.skills).slice(0,3)),...(tokens(p.locations||p.city).slice(0,2))];return words.filter(Boolean).join(' ')}
return Object.freeze({FAMILIES,SKILL_DICTIONARY,norm,detectFamily,matchingSkills,fitJob,normalizedJob,uniqueJobs,searchTerms});
});
