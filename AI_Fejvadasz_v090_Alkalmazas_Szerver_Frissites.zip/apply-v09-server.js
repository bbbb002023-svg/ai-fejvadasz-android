'use strict';
// Idempotent source-level overlay for AI Fejvadász server 0.8.2.1.
// Run AFTER unzipping the official 0.8.2.1 server archive.
const fs=require('node:fs'),path=require('node:path');
const file=path.resolve(__dirname,'job-search.js');
let js=fs.readFileSync(file,'utf8');
if(js.includes('require(\'./v09-verify\')')){console.log('0.9 verified-search patch already installed');process.exit(0);}
function once(before,after,desc){if(!js.includes(before))throw Error('A 0.8.2.1 forrás váratlanul megváltozott: '+desc);js=js.replace(before,after);}
once("const E = require('./engine');", "const E = require('./engine');\nconst V09 = require('./v09-verify');",'engine import');
// Brave Web Search accepts up to 20 results per request. Prefer recently indexed pages,
// but NEVER use Brave age as the original job publication date.
once("u.searchParams.set('q',q);u.searchParams.set('country','ALL');u.searchParams.set('search_lang','hu');u.searchParams.set('count','12');",
  "u.searchParams.set('q',q);u.searchParams.set('country','ALL');u.searchParams.set('search_lang','hu');u.searchParams.set('count','20');u.searchParams.set('freshness','pm');",'Brave recent 20 results');
once('return list.map((r,i)=>standardizeIndexed(r,src,i)).filter(Boolean).slice(0,12);',
  'return list.map((r,i)=>standardizeIndexed(r,src,i)).filter(Boolean).slice(0,20);','index page count');
once("s.links=[...new Map(s.links.map(x=>[x.url,x])).values()].slice(0,75);",`s.links=[...new Map(s.links.map(x=>[x.url,x])).values()].slice(0,150);`,'link dedup');
once('const unique=E.uniqueJobs(collected).slice(0,300);',`// 0.9: REGION FIRST → ORIGINAL JOB POSTING → DATE ≤ 20 DAYS → AI RANKING.
     // Index links never become job suggestions until verified from the original page.
     s.stage='Eredeti hirdetések ellenőrzése (régió, megjelenés, elérhetőség)';
     s.progress=66;
     const candidates=[...s.links,...collected.map(j=>({title:j.title,url:j.url,source:j.source,snippet:j.description}))];
     const checkedJobs=await V09.verifyLinks(candidates,p,{request:fetchImpl,onProgress:(done,total)=>{
       s.stage='Hirdetések ellenőrzése: '+done+'/'+total;
       s.progress=66+Math.floor(done/Math.max(1,total)*9);
     }});
     s.links=[]; // No unchecked Brave links in the main results or a separate misleading listing.
     s.rejectedCount=checkedJobs.rejected.length;
     s.verifiedCount=checkedJobs.jobs.length;
     s.found=checkedJobs.jobs.length;
     collected.length=0;
     collected.push(...checkedJobs.jobs);
     const unique=E.uniqueJobs(collected).slice(0,150);`,'verification gate');
once('.filter(j=>j.fit.eligible).sort((a,b)=>b.fit.score-a.fit.score).slice(0,30);', '.filter(j=>j.fit.eligible).sort((a,b)=>b.fit.score-a.fit.score).slice(0,80);','rank count');
once(`let ranked=[];
     try{ranked=await rankFn(p,scored.slice(0,18),{key:env.OPENAI_API_KEY,model:env.OPENAI_MODEL||'gpt-5-mini',request:fetchImpl});s.aiAnalyzed=Array.isArray(ranked)&&ranked.length>0;}catch(e){s.errors.push('AI-elemzés átmenetileg sikertelen; a szabálymotor pontszámai látszanak.');}`,`let ranked=[];
     // Analyze EVERY eligible, verified listing in small batches, not just the first 18.
     // Errors are explicit: model failures are never disguised as AI-verified rankings.
     for(let i=0;i<scored.length;i+=12){
       s.stage='Szakmai AI-elemzés '+Math.min(i+12,scored.length)+'/'+scored.length;
       s.progress=81+Math.floor((i/scored.length)*16);
       try{
         const batch=await rankFn(p,scored.slice(i,i+12),{key:env.OPENAI_API_KEY,model:env.OPENAI_MODEL||'gpt-5-mini',request:fetchImpl});
         if(Array.isArray(batch))ranked.push(...batch);
       }catch(e){s.errors.push('Egy AI-elemzési csoport sikertelen; ezek az állások nem kapnak AI-ajánlást.');}
     }
     s.aiAnalyzed=ranked.length>0;`,'AI batches');
once(`return {id:j.id,title:j.title,company:j.company,city:j.city,description:j.description,url:j.url,source:j.source,score,eligible:!excluded,reason:a?.reason?trim(a.reason,500):j.fit.reasons.join(' '),missing:Array.isArray(a?.missing)?a.missing.slice(0,8).map(x=>trim(x,120)):j.fit.warnings.slice(0,8),aiAnalyzed:!!a};`,`return {id:j.id,title:j.title,company:j.company,city:j.city,county:j.county,description:j.description,url:j.url,source:j.source,score:!!a?score:null,eligible:!excluded,reason:a?.reason?trim(a.reason,500):'AI-értékelés nem érkezett erre a hirdetésre.',missing:Array.isArray(a?.missing)?a.missing.slice(0,8).map(x=>trim(x,120)):[],aiAnalyzed:!!a,verified:true,publishedAt:j.publishedAt,publicationAgeDays:j.publicationAgeDays,activityCheckedAt:j.activityCheckedAt,applicationConfirmed:false,verificationMethod:j.verificationMethod,regionReason:j.regionReason,regionVerified:true,activityStatus:'active'};`,'result metadata');
// Trusted region verification must survive the older matcher's city-only check.
const engineFile=path.resolve(__dirname,'engine.js');
let engine=fs.readFileSync(engineFile,'utf8');
const oldLocation='const locationOK=remote||!locationKnown||preferred.some(k=>city.includes(k)||k.includes(city));';
if(engine.includes(oldLocation)){
 engine=engine.replace(oldLocation,'const locationOK=j.regionVerified===true||remote||!locationKnown||preferred.some(k=>city.includes(k)||k.includes(city));');
 fs.writeFileSync(engineFile,engine,'utf8');
}
js=js.replace(/module\.exports\s*=\s*\{/,'module.exports = {');
const snapshotOld='found:s.found,linkCount:s.links.length,links:';
if(js.includes(snapshotOld))js=js.replace(snapshotOld,'found:s.found,verifiedCount:s.verifiedCount||0,rejectedCount:s.rejectedCount||0,linkCount:s.links.length,links:');
const serverFile=path.resolve(__dirname,'server.js');
let server=fs.readFileSync(serverFile,'utf8');
if(!server.includes("VERSION='0.8.2.1';") && !server.includes("VERSION='0.9.0';"))throw Error('Váratlan szerververzió');
server=server.replace("VERSION='0.8.2.1';","VERSION='0.9.0';");
fs.writeFileSync(serverFile,server,'utf8');
fs.writeFileSync(file,js,'utf8');
console.log('AI Fejvadász 0.9 server search patch applied.');
