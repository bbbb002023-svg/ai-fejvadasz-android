'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const preview=path.join(__dirname,'android_overlay/app/src/main/assets/app.js');
const deployed=path.join(__dirname,'../app/src/main/assets/app.js');
const ui=fs.readFileSync(fs.existsSync(deployed)?deployed:preview,'utf8');
const code=ui.slice(ui.indexOf('function v09DayAge'),ui.indexOf('function renderJobs'));
const today=new Date(),day=n=>new Date(Date.UTC(today.getUTCFullYear(),today.getUTCMonth(),today.getUTCDate()-n)).toISOString().slice(0,10);
function job(score,age,aiAnalyzed=true){return {title:'Területi vezető',company:'Teszt Kft.',publishedAt:day(age),isLive:true,verified:true,activityStatus:'active',regionVerified:true,activityCheckedAt:new Date().toISOString(),aiAnalyzed,fit:{score,eligible:true}}}
function groups(jobs){return vm.runInNewContext(code+';v09Groups();',{matchedJobs:()=>jobs,Date,escape:s=>String(s)});}
test('AI 81% and 95% recommended sorted top; 80% remains ordinary',()=>{const x=groups([job(80,2),job(95,5),job(81,1)]);assert.deepEqual(Array.from(x.recommended,j=>j.fit.score),[95,81]);assert.deepEqual(Array.from(x.others,j=>j.fit.score),[80]);});
test('21-day or unknown-date job never appears in either group',()=>{const x=groups([job(99,21),{...job(97,1),publishedAt:''},job(78,20)]);assert.equal(x.recommended.length,0);assert.equal(x.others.length,1);});
test('unverified and outside region jobs do not enter recommendations',()=>{const x=groups([{...job(98,2),regionVerified:false},{...job(95,3),activityStatus:'closed'}, {...job(95,3),verified:false}]);assert.equal(x.recommended.length,0);assert.equal(x.others.length,0);});
test('verified but not AI-analyzed job has no fabricated recommendation',()=>{const x=groups([job(97,2,false)]);assert.equal(x.recommended.length,0);assert.equal(x.waiting.length,1);});
