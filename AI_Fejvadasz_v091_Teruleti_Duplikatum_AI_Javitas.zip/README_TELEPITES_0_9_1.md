# AI Fejvadász 0.9.1 – régiók, vármegyék, duplikációk és automatikus AI-helyreállítás

**A csomag forráskód-frissítés, nem APK.** A már működő 0.9.0-ás Android projekt és Render-szerver után kell telepíteni. Éles bevezetés előtt futtass GitHub Actions-fordítást, Render-deployt és telefonos tesztet. A meglévő APK-t ne töröld, a helyi CV-t és beállításokat mentsd. Ha a régi és az új debug APK aláírása eltér, az Android nem engedi frissítésként telepíteni; ezeket biztonságosan csak stabil aláírással lehet egymásra telepíteni.

## Mit változtat?

1. A **vármegye** az összes benne lévő települést jelenti, a **régió** az összes hozzátartozó vármegyét és települést. A nyolc hivatalos NUTS2 egység támogatott (Budapest és Pest külön).
2. A település–vármegye összerendeléshez a KSH 2025-ös Helységnévtárán alapuló, Ferenci Tamás által 2026. február 9-én előállított IrszHnk.csv adatállományt dolgozza fel a **Render buildjében**. Több mint 3100 település és mind a húsz vármegye/főváros meglétét ellenőrzi, hiányos adattal nem végez bizonytalan szűrést. A nyilvántartás nem minden esetben tudja értelmezni a többértelmű vagy szabad szöveges álláshelyszíneket – ezeket óvatosan kizárja.
3. Kétirányú duplikátumszűrés a szerveren és az Android listájában: egyazon munkakör+cég+település több portálon csak egyszer látszik, és a forrásadatok megmaradhatnak. Különböző településeken lévő önálló állásokat nem von össze.
4. AI-kéréseknél az átmeneti hibákat korlátozottan újrapróbálja, a túl nagy vagy hiányosan értékelt csoportot kisebb részekre osztja. A maximum 28 AI-kérés **egy keresésnél felső korlát**, nem jellemző használat; a költség az OpenAI-fiókot terheli. Nem ígér hibamentességet és nem talál ki százalékot.
5. A főlistában továbbra is csak eredeti oldalon igazolt dátumú, legfeljebb 20 napos, régióban lévő hirdetések jelennek meg. Az elérhető JobPosting-oldal **nem garantálja**, hogy az adott pillanatban is fogadnak jelentkezést.

## 1. GitHub – új APK fordítása

Töltsd fel a ZIP-et a `bbbb002023-svg/ai-fejvadasz-android` tároló gyökerébe.

`.github/workflows/build-apk.yml` → `ZIP kibontasa` szakasz:

```yaml
      - name: ZIP kibontasa
        run: |
          mkdir -p project
          unzip -q AI_Fejvadasz_v082_CV_Keresok_Android_Projekt.zip -d project
          unzip -oq AI_Fejvadasz_v090_Alkalmazas_Szerver_Frissites.zip -d project
          unzip -oq AI_Fejvadasz_v091_Teruleti_Duplikatum_AI_Javitas.zip -d project
```

Mentés után a GitHub Actions új `AI-Fejvadasz-APK` csomagot hoz létre. A meglévő projektre épül, így a meglévő alkalmazásazonosító megmarad, de **az aláírás ütközése továbbra is előfordulhat**.

## 2. Render – szerverfrissítés

A Build Command **teljes tartalma**:

```bash
unzip -oq AI_Fejvadasz_AI_Szerver_v0821_Brave_Javitas.zip -d ai-server && unzip -oq AI_Fejvadasz_v090_Alkalmazas_Szerver_Frissites.zip -d ai-server && node ai-server/apply-v09-server.js && unzip -oq AI_Fejvadasz_v091_Teruleti_Duplikatum_AI_Javitas.zip -d ai-server && node ai-server/apply-v091-server.js && node ai-server/prepare-hu-geo.js && cd ai-server && npm install --omit=dev
```

**Start Command** változatlan: `cd ai-server && npm start`.

Az OpenAI-, Brave- és alkalmazás-token környezeti változóihoz **ne nyúlj**.

**Fontos:** a `prepare-hu-geo.js` a deploy során a nyilvánosan hozzáférhető forrásállományt letölti (https://raw.githubusercontent.com/ferenci-tamas/IrszHnk/master/IrszHnk.csv). Az alkalmazás személyes profilját nem küldi az adatforrásnak. Ha az adatforrás nem érhető el vagy sérült, a deploy megáll; ez szándékos biztonsági intézkedés. A szerverre nem kerülnek titkos kulcsok a ZIP-ből.

Sikeres deploy után a `/health` JSON-ban a `version` értéke `0.9.1` lesz.

## 3. Telefon / alkalmazás

Állások → „Válassz régiót vagy vármegyét” → például **Zala vármegye** vagy **Nyugat-Dunántúl** → **Régió mentése** → Új keresés indítása.

Megjelenés: munkakör, cég, település; 80% feletti, **valódi AI-val értékelt** egyezés felül; portál a részletek végén. Azoknál az állásoknál, amelyekhez az automatikus újrapróbálás után sincs értékelés, százalék helyett „Értékelés nélkül” látszik.

## Ellenőrzés

- 32 lokális automatizált teszt: `node --test test/v091.test.js test/v091-ui.test.js` (a ZIP-ben a gyökér `test` mappájába csomagolva).
- Forrás-szintű build-szkript mintán tesztelve, de az **éles 0.9.1 Render-deploy és GitHub APK fordítás még nincs kipróbálva**.
- Szükséges platform: Node.js 20+ (a Render projektnél már Node 22 használható).

Adatforrás: KSH és [Ferenci Tamás / IrszHnk](https://github.com/ferenci-tamas/IrszHnk), Magyarország NUTS2 regionális besorolása: [KSH Területi atlasz](https://www.ksh.hu/teruletiatlasz_regiok).
