/* AI Fejvadász 0.5. CV-első helyi adatfelismerés; nem generatív AI és nem automatizált álláspályázat. */
(function(){'use strict';
const E=window.AIJobEngine,$=id=>document.getElementById(id),STORE='ai_fejvadasz_v05_local';
const DEMO_JOBS=[
{id:'d_food',title:'Élelmiszer-eladó',company:'Szivárvány ABC (minta)',city:'Budapest',skills:['vevőkiszolgálás','kasszakezelés','készletkezelés'],minYears:1,education:'középfokú',salaryMin:420000,workMode:'teljes munkaidő',description:'Vevők kiszolgálása, pénztár, áruk átvétele és készletnyilvántartás.',isDemo:true},
{id:'d_cash',title:'Pénztáros',company:'Friss Kosár Kft. (minta)',city:'Budapest',skills:['kasszakezelés','vevőkiszolgálás'],minYears:1,education:'középfokú',salaryMin:390000,workMode:'teljes munkaidő',description:'Pénztárgép kezelése, vásárlók segítése.',isDemo:true},
{id:'d_retaillead',title:'Boltvezető',company:'Duna Market (minta)',city:'Budapest',skills:['kereskedelem','vezetés','készletkezelés'],minYears:5,education:'középfokú',salaryMin:570000,workMode:'teljes munkaidő',description:'Üzlet napi működése, csapatvezetés és rendelés.',isDemo:true},
{id:'d_mech',title:'Autószerelő',company:'Motorműhely (minta)',city:'Budapest',skills:['autószerelés','járműdiagnosztika'],minYears:3,requiredCertificates:['autószerelő bizonyítvány'],education:'szakmunkás',salaryMin:520000,workMode:'teljes munkaidő',description:'Autók szerelése, diagnosztika és javítás.',isDemo:true},
{id:'d_log',title:'Raktáros',company:'RaktárPont (minta)',city:'Budapest',skills:['raktározás','készletkezelés'],minYears:1,education:'középfokú',salaryMin:430000,workMode:'teljes munkaidő',description:'Áruátvétel, raktári készlet kezelés.',isDemo:true},
{id:'d_it',title:'Szoftverfejlesztő',company:'KódTér (minta)',city:'Budapest',skills:['JavaScript','SQL','fejlesztés'],minYears:3,education:'egyetem',salaryMin:850000,workMode:'teljes munkaidő',description:'Webalkalmazások fejlesztése.',isDemo:true},
{id:'d_sales',title:'Területi értékesítési vezető',company:'PartnerHálózat (minta)',city:'Győr',skills:['értékesítés','B2B','vezetés','tárgyalástechnika'],minYears:6,education:'középfokú',salaryMin:780000,workMode:'teljes munkaidő',description:'Partnerek fejlesztése, vezetői feladatok, ügyféltalálkozók.',isDemo:true},
{id:'d_admin',title:'Irodai adminisztrátor',company:'Irodavilág (minta)',city:'Debrecen',skills:['adminisztráció','Excel','dokumentumkezelés'],minYears:1,education:'középfokú',salaryMin:380000,workMode:'teljes munkaidő',description:'Dokumentumok, irodai feladatok, adatkezelés.',isDemo:true}
];
const emptyProfile={name:'',email:'',phone:'',city:'',linkedin:'',pastRoles:'',targetRoles:'',years:0,education:'',experience:'',certificates:'',licenses:'',languages:'',skills:[],locations:'',excludedRoles:'',salaryMin:0,workMode:'',autoConsent:false,autoThreshold:90,photo:''};
let state={registered:false,profile:{...emptyProfile},jobs:[],applications:[],threshold:65,cvDraft:'',cvApproved:'',cvPdfFile:'',cvDate:'',cvPhoto:false,cvPrimaryFile:'',cvHistory:[],cvTemplate:'modern',resumeMeta:null,resumePhotoCandidate:''},page='dashboard',currentJob=null,toastT=null,praiseTimer=null;
function escape(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function val(id){return ($(id)?.value||'').trim()}
function toList(s){return String(s||'').split(/[,;\n]+/).map(x=>x.trim()).filter(Boolean)}
function n(s){return Number(s)||0}
function load(){try{const saved=JSON.parse(localStorage.getItem(STORE)||'null');if(saved&&typeof saved==='object'){state={...state,...saved,profile:{...emptyProfile,...saved.profile},jobs:Array.isArray(saved.jobs)?saved.jobs:[],applications:Array.isArray(saved.applications)?saved.applications:[]};}}catch(e){}}
function persist(){try{localStorage.setItem(STORE,JSON.stringify(state));}catch(e){toast('Nem sikerült elmenteni a helyi adatokat. Ellenőrizd a tárhelyet.');}}
function toast(msg){const el=$('toast');el.textContent=msg;el.classList.add('show');clearTimeout(toastT);toastT=setTimeout(()=>el.classList.remove('show'),3500)}
function setup(){load();if(state.registered){$('auth').classList.add('hide');$('app').classList.remove('hide');fillProfile();renderAll();}else{$('auth').classList.remove('hide');$('app').classList.add('hide');}wireAutosave();}
function registerDemo(){const name=val('regName'),email=val('regEmail'),password=$('regPass').value;if(name.length<3){toast('Írd be a teljes neved.');return}if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){toast('Adj meg érvényes e-mail-címet.');return}if(password.length<12){toast('A próba-regisztrációhoz is legalább 12 karaktert írj.');return}if(!$('regConsent').checked){toast('Előbb olvasd el és fogadd el a demó feltételeit.');return}state.registered=true;state.profile.name=name;state.profile.email=email;$('regPass').value='';persist();$('auth').classList.add('hide');$('app').classList.remove('hide');fillProfile();renderAll();go('profile');toast('Következő lépés: töltsd fel az önéletrajzodat! A fiók még helyi próba-profil.');}
function go(dest){if(!$(''+dest))return;closeSheet();page=dest;document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id===dest));document.querySelectorAll('[data-nav]').forEach(x=>x.classList.toggle('active',x.dataset.nav===(dest==='cv'?'profile':dest)));if(dest==='jobs'){renderJobs();if(typeof window.aiJobSearchRefresh==='function')window.aiJobSearchRefresh();}if(dest==='interview')renderInterview();if(dest==='applications')renderApplications();if(dest==='cv')renderCV();if(dest==='profile')renderResumePanels();window.scrollTo(0,0);}
function wireAutosave(){document.querySelectorAll('#profile input:not([type=file]),#profile textarea,#profile select').forEach(input=>{input.addEventListener('change',()=>saveProfile(false));});$('photoInput').addEventListener('change',handlePhoto);}
const fields={pName:'name',pEmail:'email',pPhone:'phone',pCity:'city',pLinkedin:'linkedin',pPastRoles:'pastRoles',pTargetRoles:'targetRoles',pYears:'years',pEducation:'education',pExperience:'experience',pCertificates:'certificates',pLicenses:'licenses',pLanguages:'languages',pLocations:'locations',pExcludedRoles:'excludedRoles',pSalary:'salaryMin',pWorkMode:'workMode'};
function fillProfile(){const p=state.profile;for(const [id,key] of Object.entries(fields)){$(id).value=p[key]??'';}$('pAutoConsent').checked=!!p.autoConsent;renderSkillChips();renderPhoto();}
function saveProfile(announce){const p=state.profile;for(const [id,key]of Object.entries(fields)){p[key]=['years','salaryMin'].includes(key)?n($(id).value):val(id);}p.autoConsent=$('pAutoConsent').checked;persist();renderAll();if(announce){toast('A szakmai profil helyben elmentve.');if((p.targetRoles||p.pastRoles||p.skills?.length)&&typeof window.aiJobSearchStart==='function')window.aiJobSearchStart(true);}}
function renderSkillChips(){const chosen=new Set(state.profile.skills||[]);const dictionary=[...new Set([...E.SKILL_DICTIONARY,...chosen])];$('skills').innerHTML=dictionary.map(s=>`<button class="chip ${chosen.has(s)?'selected':''}" data-skill="${escape(s)}" onclick="toggleSkill(this)">${chosen.has(s)?'✓ ':''}${escape(s)}</button>`).join('')}
function toggleSkill(node){const s=node.dataset.skill,skills=new Set(state.profile.skills||[]);if(skills.has(s))skills.delete(s);else skills.add(s);state.profile.skills=[...skills];persist();renderSkillChips();renderAll()}
function renderPhoto(){const el=$('photoPreview');if(state.profile.photo){el.innerHTML=`<img src="${state.profile.photo}" alt="Profilkép">`;}else el.textContent='👤'}
function handlePhoto(e){const f=e.target.files?.[0];if(!f)return;if(!f.type.startsWith('image/')){toast('Csak képet lehet feltölteni.');return}if(f.size>7*1024*1024){toast('A kép túl nagy. Legfeljebb 7 MB lehet.');return}const reader=new FileReader();reader.onload=()=>{const im=new Image();im.onload=()=>{const size=320,c=document.createElement('canvas');c.width=size;c.height=size;const ctx=c.getContext('2d');const side=Math.min(im.width,im.height),sx=(im.width-side)/2,sy=(im.height-side)/2;ctx.drawImage(im,sx,sy,side,side,0,0,size,size);state.profile.photo=c.toDataURL('image/jpeg',0.75);persist();renderPhoto();renderAll();toast('Fénykép hozzáadva a helyi profilhoz.');};im.src=reader.result;};reader.readAsDataURL(f);}
function completion(){const p=state.profile;const keys=['name','email','city','targetRoles','experience','education','skills','locations','years','phone'];let done=keys.filter(k=>k==='skills'?(p.skills?.length>0):!!p[k]).length;return Math.round(100*done/keys.length)}
function coachText(){const p=state.profile;if(!state.resumeMeta)return '✦ Első lépésként tölts fel egy PDF, DOCX vagy TXT önéletrajzot. Segítek kitölteni a profilodat.';if(!p.targetRoles)return '✦ Milyen állásokat keresel? Add meg a célzott munkaköröket.';if(!p.experience)return '✦ Írd le a korábbi feladataidat; ettől lesz hitelesebb a CV-d.';if(!(p.skills||[]).length)return '✦ Jelöld a valódi készségeidet, hogy pontosan tudjak pontozni.';if(!p.locations)return '✦ Válaszd ki a településeket, ahová szívesen járnál dolgozni.';if(!p.education)return '✦ Töltsd ki a végzettségedet, hogy ne ajánljak irreleváns munkát.';if(!state.cvApproved)return '✦ A profilod már használható: készítsük el és hagyjuk jóvá a CV-t!';return '✦ A profilod készen áll. A találatoknál megmutatom a megfelelés okait és a hiányokat.';}
function renderAll(){const c=completion();$('homeProgress').textContent=c+'%';$('profileProgress').textContent=c+'%';$('progressBar').style.width=c+'%';$('homeHint').textContent=coachText().replace('✦ ','');$('profileHint').textContent=coachText();showPraiseBubble();$('threshold').value=state.threshold;$('thresholdLabel').textContent=state.threshold+'%';renderJobs();renderApplications();renderCV();renderInterview();renderResumePanels();}
function buildCVText(){
 const p=state.profile,parts=[];
 if(p.name)parts.push(p.name.toLocaleUpperCase('hu-HU'));else parts.push('ÖNÉLETRAJZ');
 if(p.targetRoles)parts.push(p.targetRoles);
 const contact=[p.city,p.phone,p.email,p.linkedin].filter(Boolean);if(contact.length)parts.push(contact.join('  •  '));
 const summary=[];
 if(p.years)summary.push(`${p.years} év igazolt szakmai tapasztalat`);
 if(p.pastRoles)summary.push(`Korábbi munkakörök: ${p.pastRoles}`);
 if(p.skills&&p.skills.length)summary.push(`Megadott készségek: ${p.skills.slice(0,9).join(', ')}`);
 if(summary.length)parts.push('SZAKMAI PROFIL\n'+summary.join('. ')+'.');
 if(p.experience)parts.push('SZAKMAI TAPASZTALAT\n'+p.experience);
 if(p.education||p.certificates)parts.push('TANULMÁNYOK ÉS KÉPESÍTÉSEK\n'+[p.education,p.certificates].filter(Boolean).join('\n'));
 if(p.skills&&p.skills.length)parts.push('SZAKMAI KÉSZSÉGEK\n'+p.skills.join('  •  '));
 if(p.languages)parts.push('NYELVTUDÁS\n'+p.languages);
 if(p.licenses)parts.push('JOGOSÍTVÁNYOK ÉS ENGEDÉLYEK\n'+p.licenses);
 return parts.join('\n\n').trim();
}
function generateCV(){saveProfile(false);state.cvDraft=buildCVText();$('cvEditor').value=state.cvDraft;persist();toast('A szerkeszthető CV-javaslat elkészült. Nézd át a mentés előtt.');}
function renderCV(){if($('cvTemplate'))$('cvTemplate').value=state.cvTemplate||'modern';updateCvTemplate(false);$('cvEditor').value=state.cvDraft||'';$('cvPhoto').checked=!!state.cvPhoto;$('cvPrimaryInfo').textContent=state.cvPrimaryFile?'★ ELSŐDLEGES ÖNÉLETRAJZ: '+state.cvPrimaryFile:'Még nincs elsődleges PDF önéletrajz.';$('cvSaveInfo').textContent=state.cvApproved?`Jóváhagyva: ${state.cvDate||'helyi profil'}${state.cvPdfFile?' · PDF tárolva az alkalmazásban':''}`:'Még nincs jóváhagyott CV. Előbb generáld és ellenőrizd.';}
function updateCvTemplate(save=true){const select=$('cvTemplate'),preview=$('cvA4Preview');if(!select||!preview)return;state.cvTemplate=select.value;preview.className='cv-a4-mini '+(state.cvTemplate||'modern');if(save)persist();}
function approveCV(){const text=val('cvEditor');if(text.length<70){toast('A CV még túl rövid. Előbb töltsd ki a profilod.');return}if(!confirm('Átnézted a teljes önéletrajzot, és jóváhagyod ezt a verziót?'))return;const p=state.profile;let file='';if(window.AndroidApp?.savePrivateCvPdf){file=window.AndroidApp.savePrivateCvPdf(p.name||'oneletrajz',text,$('cvPhoto').checked?p.photo:'',state.cvTemplate||'modern');if(file.startsWith('ERROR:')){toast(file);return;}}state.cvDraft=text;state.cvApproved=text;state.cvPdfFile=file;state.cvDate=new Date().toLocaleString('hu-HU');state.cvPhoto=$('cvPhoto').checked;if(file){state.cvPrimaryFile=file;state.cvHistory=Array.isArray(state.cvHistory)?state.cvHistory:[];state.cvHistory.unshift({file,date:state.cvDate,primary:true});state.cvHistory=state.cvHistory.slice(0,20);}persist();renderCV();if(typeof window.aiJobSearchStart==='function')window.aiJobSearchStart(true);toast(file?'Jóváhagyva! A PDF a telefon privát alkalmazástárában mentve.':'Jóváhagyva. Böngészőben a PDF-hez Android-app szükséges.');}
function exportCV(){if(!state.cvApproved){toast('Előbb jóvá kell hagynod az önéletrajzot.');return}if(state.cvPdfFile&&window.AndroidApp?.exportPrivateCvPdf){window.AndroidApp.exportPrivateCvPdf(state.cvPdfFile);return}const w=window.open('','_blank');if(!w){toast('A PDF exporthoz nyisd meg az Android-alkalmazást.');return}w.document.write(`<html><meta charset="UTF-8"><title>CV</title><body><pre style="white-space:pre-wrap;font:13px/1.6 sans-serif">${escape(state.cvApproved)}</pre></body></html>`);w.document.close();w.print();}
function compareCV(){const old=val('oldCV'),now=val('cvEditor');if(!old){$('cvCompare').textContent='Másold be az eredeti önéletrajzot az összehasonlításhoz.';return}$('cvCompare').textContent=`Eredeti: ${old.split(/\s+/).length} szó · Javasolt: ${now.trim().split(/\s+/).length} szó. Az egyező tényeket és a hiányzó munkáltatókat ellenőrizd kézzel; automatikus PDF/DOCX-olvasás még nincs.`;}
function v091Norm(s){return String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim().replace(/\s+/g,' ')}
function v091UniqueJobs(items){
 const out=[];
 for(const j of items){if(!j?.title||!j?.company)continue;
  const co=v091Norm(j.company).replace(/\b(?:kft|zrt|bt|rt|ltd|group|hungary)\b/g,'').trim();
  const title=v091Norm(j.title).replace(/\b(?:budapest|teljes munkaido|allas)\b/g,'').trim();
  const city=v091Norm(j.city||j.county);
  const day=x=>{const t=Date.parse(String(x.publishedAt||'').slice(0,10));return Number.isFinite(t)?t:null};
  const canon=url=>{try{const u=new URL(url);u.hash='';for(const k of [...u.searchParams.keys()])if(/^(utm_|fbclid|gclid|ref|source)/i.test(k))u.searchParams.delete(k);return u.hostname.replace(/^www\./,'').toLowerCase()+u.pathname.replace(/\/+$/,'')+u.search}catch{return ''}};
  const dupe=out.findIndex(x=>{
   const sameUrl=canon(j.url)&&canon(j.url)===canon(x.url);if(sameUrl)return true;
   const same=co===v091Norm(x.company).replace(/\b(?:kft|zrt|bt|rt|ltd|group|hungary)\b/g,'').trim()&&title===v091Norm(x.title).replace(/\b(?:budapest|teljes munkaido|allas)\b/g,'').trim()&&city===v091Norm(x.city||x.county);
   const a=day(j),b=day(x);return !!co&&!!title&&!!city&&same&&(a!=null&&b!=null&&Math.abs(a-b)<=7*86400000);
  });
  if(dupe<0)out.push(j);else{
   const old=out[dupe],quality=x=>(x.verified?500:0)+(x.aiAnalyzed?200:0)+Math.min(200,String(x.description||'').length);
   if(quality(j)>quality(old))out[dupe]=j;
  }
 }
 return out;
}
function allJobs(){return v091UniqueJobs([...state.jobs,...(state.jobs.some(j=>j.isLive)?[]:DEMO_JOBS)]);}

function matchedJobs(){return allJobs().map(j=>{const fit=E.fitJob(state.profile,j);if(j.isLive&&Number.isFinite(j.aiScore)&&fit.eligible){fit.score=Math.max(0,Math.min(100,j.aiScore));fit.reasons=j.aiReason?[j.aiReason]:fit.reasons;fit.warnings=j.aiMissing||fit.warnings;}return {...j,fit};}).sort((a,b)=>(a.fit.blockers.length?1:0)-(b.fit.blockers.length?1:0)||b.fit.score-a.fit.score);}
function setThreshold(v){state.threshold=Number(v);persist();$('thresholdLabel').textContent=v+'%';renderJobs();}
function v09DayAge(s){
 if(!/^\d{4}-\d{2}-\d{2}$/.test(String(s||'')))return null;
 const d=new Date(s+'T00:00:00Z'),now=new Date();if(!Number.isFinite(d.getTime())||d.toISOString().slice(0,10)!==s)return null;
 const today=Date.UTC(now.getUTCFullYear(),now.getUTCMonth(),now.getUTCDate());
 return Math.floor((today-d.getTime())/86400000);
}
function v09Fresh(j){
 if(!j.isLive||j.verified!==true||j.activityStatus!=='active'||j.regionVerified!==true)return false;
 const age=v09DayAge(j.publishedAt);if(age===null||age<0||age>20)return false;
 const checked=new Date(j.activityCheckedAt||'');
 return Number.isFinite(checked.getTime())&&checked.getTime()<=Date.now()&&Date.now()-checked.getTime()<24*3600*1000;
}
function v09Groups(){
 const all=matchedJobs().filter(j=>v09Fresh(j)&&j.fit.eligible);
 const sort=(a,b)=>b.fit.score-a.fit.score||(v09DayAge(a.publishedAt)-v09DayAge(b.publishedAt));
 return {recommended:all.filter(j=>j.aiAnalyzed&&j.fit.score>80).sort(sort),
   others:all.filter(j=>j.aiAnalyzed&&j.fit.score<=80).sort(sort),
   waiting:all.filter(j=>!j.aiAnalyzed).sort((a,b)=>v09DayAge(a.publishedAt)-v09DayAge(b.publishedAt))};
}
function v09JobCard(j){
 const score=j.aiAnalyzed&&Number.isFinite(j.aiScore)?j.fit.score+'%':'Értékelés nélkül';
 const age=v09DayAge(j.publishedAt);
 return `<div class="jobitem" role="button" tabindex="0" onclick="openJob('${escape(j.id)}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();openJob('${escape(j.id)}')}" style="cursor:pointer"><div class="jobtop"><div><h3 style="font-size:17px;margin:0 0 5px">${escape(j.title)}</h3><p style="font-size:14px;font-weight:700;margin:0">${escape(j.company)}</p><p class="tiny muted" style="margin-top:5px">📍 ${escape(j.city||j.county||'Helyszín nem megadott')} · ${age} napos hirdetés</p></div><div class="score" style="font-size:15px;white-space:nowrap">${escape(score)}</div></div><div class="jobfoot"><small>${j.aiAnalyzed?'✦ AI által elemzett szakmai egyezés':'Friss, ellenőrzött forrás · Pontszám még nincs'}</small><span class="button sm secondary">Részletek →</span></div></div>`;
}
function renderJobs(){
 const g=v09Groups(),items=[...g.recommended,...g.others,...g.waiting];
 $('homeJobs').textContent=items.length;$('jobCount').textContent=items.length+' friss, ellenőrzött találat';
 const p=state.profile,region=String(p.locations||'').trim(),label=region||'Nincs beállítva: Profil → Elfogadott települések / területek';
 if($('aiJobRegionInfo'))$('aiJobRegionInfo').textContent='📍 Keresési régió: '+label;
 if($('v09Region')&&document.activeElement!==$('v09Region'))$('v09Region').value=region;
 const section=(title,description,arr)=>`<section style="margin:14px 0 22px"><div class="sectionline"><h2>${title}</h2><span class="pill">${arr.length}</span></div><p class="tiny muted" style="padding:0 5px 6px">${description}</p>${arr.map(v09JobCard).join('')||'<div class="empty">Ebben a csoportban jelenleg nincs megfelelő, igazolt hirdetés.</div>'}</section>`;
 $('jobList').innerHTML=section('⭐ Ajánlott állások · 80% felett','AI által elemzett, 20 napnál nem régebbi, régión belüli hirdetések. A százalék szakmai illeszkedés, nem felvételi esély.',g.recommended)
  +section('További friss állások','80%-os vagy annál alacsonyabb AI-illeszkedés, csökkenő sorrendben.',g.others)
  +(g.waiting.length?section('AI-elemzésre váró állások','A forrás és a dátum ellenőrzött, de nincs megalapozott AI-százalék.',g.waiting):'')
  +(!items.length?'<div class="banner orange">Nincs a régióban igazolhatóan friss hirdetés. A dátum nélküli vagy ellenőrizhetetlen linkeket szándékosan nem jelenítjük meg; ez nem azt jelenti, hogy nincs állás.</div>':'');
}
function toggleImport(){$('importSection').classList.toggle('hide')}
function addManualJob(){const title=val('iTitle'),company=val('iCompany'),city=val('iCity');if(!title||!company){toast('Munkakör és cégnév szükséges.');return}const j=E.normalizedJob({id:'own_'+Date.now(),title,company,city,skills:val('iSkills'),requiredCertificates:val('iCert'),description:val('iDesc'),url:val('iUrl'),source:'Kézzel felvett állás'},Date.now());state.jobs=E.uniqueJobs([j,...state.jobs]);persist();renderAll();$('importSection').classList.add('hide');toast('Állás hozzáadva. A saját motor kiértékelte.');}
function importJobsFile(input){const f=input.files?.[0];if(!f)return;if(f.size>1024*1024){toast('Maximum 1 MB-os JSON importálható.');return}const reader=new FileReader();reader.onload=()=>{try{const source=JSON.parse(reader.result),items=Array.isArray(source)?source:source.jobs;if(!Array.isArray(items))throw Error('Tömb szükséges');const converted=items.slice(0,300).map((j,i)=>E.normalizedJob(j,i));const before=state.jobs.length;state.jobs=E.uniqueJobs([...converted,...state.jobs]).slice(0,350);persist();renderAll();toast((state.jobs.length-before)+' új állás importálva, saját motorral pontozva.');}catch(e){toast('Hibás JSON-formátum. Várható: [{"title":"...","company":"..."}].');}input.value='';};reader.readAsText(f,'UTF-8');}
function sourceSearch(domain){const p=state.profile;const q='site:'+domain+' állás '+(p.targetRoles||'állás')+' '+(p.locations||p.city||'Magyarország');const url='https://www.google.com/search?q='+encodeURIComponent(q);if(window.AndroidApp?.openExternal)window.AndroidApp.openExternal(url);else window.open(url,'_blank');}
function openJob(id){
 currentJob=allJobs().find(j=>j.id===id);if(!currentJob)return;
 const j=currentJob,f=matchedJobs().find(x=>x.id===id)?.fit||E.fitJob(state.profile,j),age=v09DayAge(j.publishedAt);
 $('sheetTitle').textContent='Állás részletei';
 const warnings=Array.isArray(j.aiMissing)?j.aiMissing:[];
 $('sheetBody').innerHTML=`<h2 style="margin:9px 0 5px">${escape(j.title)}</h2><div style="font-weight:700;font-size:16px">🏢 ${escape(j.company)}</div><p>📍 ${escape(j.city||j.county||'Helyszín ismeretlen')}</p><div class="flow"><span class="pill">${j.aiAnalyzed?f.score+'% szakmai egyezés':'AI-elemzés nincs'}</span><span class="pill">${age===null?'Dátum nem ismert':age+' napos'}</span></div><div class="separator"></div><h3>📋 A hirdetés részletei</h3><p style="font-size:14px;white-space:pre-line">${escape(j.description||'Nem áll rendelkezésre ellenőrzött állásleírás.')}</p><h3>✦ AI szakmai értékelése</h3><p>${escape(j.aiAnalyzed?(j.aiReason||'AI-elemzés elkészült, de nem érkezett indoklás.'):'Ehhez a hirdetéshez még nincs AI-szövegelemzés.')}</p>${warnings.length?'<h3>⚠ Tisztázandó feltételek</h3><ul>'+warnings.map(x=>'<li>'+escape(x)+'</li>').join('')+'</ul>':''}<div class="separator"></div><h3>🛡 Ellenőrzés</h3><p class="tiny">Megjelenés: <b>${escape(j.publishedAt||'nem ismert')}</b><br>Eredeti oldal ellenőrzése: ${escape(j.activityCheckedAt?new Date(j.activityCheckedAt).toLocaleString('hu-HU'):'nem ismert')}<br>${escape(j.verificationMethod||'Forrásadatok ellenőrzése')}</p><div class="banner orange">Az eredeti oldal elérhetősége és a hirdetés dátuma ellenőrzött. Azt, hogy a munkáltató a jelentkezést még fogadja-e, nem lehet minden portálnál biztosan megállapítani.</div><div class="spacer"></div><button class="button full" onclick="prepareApplication()">✉ Jelentkezés előkészítése (nem küld)</button><p class="tiny muted" style="margin-top:10px">A szakmai egyezés nem jelent biztos felvételi esélyt.</p><div class="separator"></div><p class="tiny muted">Hirdetés forrása: ${escape(j.source||new URL(j.url).hostname)}</p>${j.url?'<button class="button secondary full" onclick="openJobSource()">↗ Eredeti hirdetés megnyitása</button>':''}`;
 openSheet();
}

function openJobSource(){const url=currentJob?.url;if(!url)return;if(window.AndroidApp?.openExternal)window.AndroidApp.openExternal(url);else window.open(url,'_blank');}
function makeLetter(j){const p=state.profile,match=E.fitJob(p,j).matchedSkills;return `Tárgy: Jelentkezés – ${j.title}\n\nTisztelt Toborzási Csapat!\n\nSzeretném megpályázni a(z) ${j.title} pozíciót. A szakmai profilomban szereplő tapasztalatom alapján a következő készségeim lehetnek relevánsak: ${match.join(', ')||'[ide írj valós tapasztalatot]'} .\n\nKorábbi feladataim: ${p.experience||'[egészítsd ki pontos adatokkal]'}\n\nÖrömmel mutatom be részletesebben, hogyan tudnék hozzájárulni a csapat munkájához.\n\nÜdvözlettel,\n${p.name||'[név]'}\n\n[Előkészített minta – nincs elküldve.]`}
function prepareApplication(){if(!currentJob)return;const j=currentJob;if(state.applications.some(a=>a.jobId===j.id)){toast('Ehhez az álláshoz már készítettél jelentkezést.');return}const fit=E.fitJob(state.profile,j);state.applications.unshift({id:'a_'+Date.now(),jobId:j.id,title:j.title,company:j.company,date:new Date().toLocaleString('hu-HU'),status:'Előkészítve, nem elküldve',letter:makeLetter(j),fit:fit.score});persist();closeSheet();go('applications');toast('A jelentkezési vázlat elkészült. Nem történt küldés.');}
function renderApplications(){const arr=state.applications;$('appCount').textContent=arr.length;$('homeApps').textContent=arr.length;$('applicationList').innerHTML=arr.length?arr.map(a=>`<div class="white" style="margin:11px 0"><div class="flow"><span class="status orange">${escape(a.status)}</span><span class="pill">${a.fit}%</span></div><h3 style="margin:11px 0 5px">${escape(a.title)}</h3><p class="tiny muted">${escape(a.company)} · ${escape(a.date)}</p><div class="flow"><button class="button sm secondary" onclick="viewApplication('${escape(a.id)}')">Levél megnézése</button><button class="button sm secondary" onclick="removeApplication('${escape(a.id)}')">Törlés</button></div></div>`).join(''):'<div class="empty">Még nincs előkészített jelentkezés. Az Állások menüben tudsz egyet létrehozni.</div>'}
function viewApplication(id){const a=state.applications.find(a=>a.id===id);if(!a)return;$('sheetTitle').textContent='Motivációs levél';$('sheetBody').innerHTML=`<p class="banner orange">Ez csak a helyben előkészített levél. Nem ment el munkáltatóhoz.</p><textarea id="letterEdit" style="width:100%;min-height:310px;border:1px solid #e6e3f5;border-radius:14px;padding:12px;line-height:1.5">${escape(a.letter)}</textarea><div class="spacer"></div><button class="button full" onclick="saveLetter('${escape(a.id)}')">✓ Levél javításainak mentése</button>`;openSheet();}
function saveLetter(id){const a=state.applications.find(a=>a.id===id);if(a){a.letter=val('letterEdit');persist();toast('Motivációs levél helyben mentve.')}closeSheet();}
function removeApplication(id){if(!confirm('Törlöd az előkészített jelentkezést?'))return;state.applications=state.applications.filter(x=>x.id!==id);persist();renderAll();}
function renderInterview(){const items=allJobs();const el=$('interviewJob'),prev=el.value;el.innerHTML='<option value="">Általános felkészülés</option>'+items.map(j=>`<option value="${escape(j.id)}">${escape(j.title)} · ${escape(j.company)}</option>`).join('');if(items.some(j=>j.id===prev))el.value=prev;const j=items.find(j=>j.id===el.value);const target=j?.title||state.profile.targetRoles||'választott munkakör';const questions=[`Miért szeretnél ${target} területen dolgozni?`,`Mondj egy valós példát arra, amikor megoldottál egy nehéz helyzetet a munkádban.`,`Mely készségeid hasznosak leginkább a(z) ${target} pozícióban?`,...(j?.skills?.length?[`Hogyan használtad a(z) ${j.skills[0]} készségedet korábban?`]:[])];$('interviewQuestions').innerHTML=questions.map((q,i)=>`<div class="feedcard"><strong>${i+1}. ${escape(q)}</strong><p>Írd össze a konkrét helyzetet, a tettedet és az eredményt. Csak valós tapasztalatot használj.</p></div>`).join('');}
function openAssistant(){const p=state.profile,c=completion(),fitItems=matchedJobs().filter(x=>x.fit.eligible).slice(0,1);$('sheetTitle').textContent='✦ Helyi segítőd';const praise=state.resumeMeta?.praise; if($('coachPraiseBubble'))$('coachPraiseBubble').classList.add('hide'); if(state.resumeMeta?.praise){state.resumeMeta.praiseSeen=true;persist();} $('sheetBody').innerHTML=`${praise?`<div class="praise-card" style="margin-bottom:12px"><span class="coach-icon">✦</span><div><strong>${escape(praise.title)}</strong><p>${escape(praise.text)}</p><small>${escape(praise.reason)}</small></div></div>`:''}<div class="coach" style="margin:0"><span class="coach-icon">✦</span><div><strong>Személyes javaslat</strong><p>${escape(coachText())}</p></div></div><div class="spacer"></div><div class="feedcard"><strong>👤 A profilod ${c}%-os</strong><p>${!p.education?'Végzettség: nincs megadva. ':''}${!p.locations?'Keresési terület: nincs megadva. ':''}${!p.experience?'Szakmai eredmények: hiányoznak.':''}</p></div><div class="feedcard"><strong>🔎 Saját motor státusza</strong><p>${fitItems.length?`Legmagasabb jelenlegi illeszkedés: ${fitItems[0].fit.score}% (${escape(fitItems[0].title)}).`:'A profil pontosítása után az állásokra indokolt pontszámot számolok.'} Az aktuális keresés szerveroldalon ellenőrzi az élő álláshirdetéseket.</p></div><div class="feedcard"><strong>🛡 Mit nem teszek a beleegyezésed nélkül?</strong><p>Nem írok át igazolt adatot, nem küldök jelentkezést, és nem osztok meg önéletrajzot külső szolgáltatóval.</p></div><div class="spacer"></div><button class="button full" onclick="closeSheet();go('profile')">Profil pontosítása →</button><p class="tiny muted">Ez jelenleg automatikus, szabályalapú segítség. A ChatGPT/OpenAI API-kapcsolatot biztonságos szerveroldali szolgáltatásként kell külön bekötni.</p>`;openSheet();}
function openSheet(){$('overlay').classList.add('show');document.body.style.overflow='hidden'}function closeSheet(){$('overlay').classList.remove('show');document.body.style.overflow=''}

// CV-első onboarding: a PDF/DOCX szövegét Android oldalon, a TXT-t böngészőben olvassuk.
function pickResume(){if(window.AndroidApp&&typeof window.AndroidApp.pickResume==='function'){window.AndroidApp.pickResume();return;}$('resumeFile').click();}
function loadResumeWeb(input){const file=input.files&&input.files[0];if(!file)return;
 if(file.size>10*1024*1024){toast('Legfeljebb 10 MB-os dokumentumot válassz.');return;}
 if(!/\.txt$/i.test(file.name)){toggleResumePaste(true);toast('Böngészőben a PDF/DOCX olvasása még nem elérhető. Az Android-appban közvetlenül működik, itt illeszd be a szöveget.');return;}
 const reader=new FileReader();reader.onload=()=>receiveImportedResume({ok:true,filename:file.name,text:String(reader.result||''),photo:'',method:'TXT helyi olvasás'});reader.onerror=()=>toast('Nem sikerült beolvasni a szöveget.');reader.readAsText(file,'UTF-8');}
function toggleResumePaste(force){const show=force===true||$('resumeTextFallback').classList.contains('hide');$('resumeTextFallback').classList.toggle('hide',!show);}
function parsePastedResume(){const text=val('resumePastedText');if(text.length<50){toast('Illessz be legalább 50 karaktert az önéletrajzból.');return;}receiveImportedResume({ok:true,filename:'Beillesztett önéletrajz',text,method:'Kézi szövegbeillesztés',photo:''});}
// CV import: a helyi parser csak tartalék. Az elsődleges elemzés OpenAI-hívás, hozzájárulással.
function receiveImportedResume(result){if(typeof result==='string'){try{result=JSON.parse(result)}catch(e){toast('Nem értelmezhető a dokumentum.');return;}}
 if(!result||!result.ok){toast((result&&result.message)||'Az önéletrajz nem olvasható.');toggleResumePaste(true);return;}
 const text=String(result.text||'').slice(0,150000);
 if(text.trim().length<35){toast('Nem találtam kiolvasható szöveget. Képként szkennelt PDF-hez OCR kell, vagy illeszd be a szöveget.');toggleResumePaste(true);return;}
 state.resumeMeta={praiseExpiresAt:0,filename:String(result.filename||'Önéletrajz').slice(0,120),method:result.method||'Helyi olvasás',date:new Date().toLocaleString('hu-HU'),filled:[],conflicts:[],characters:text.length,praise:null,praiseSeen:true,aiStatus:'waiting'};
 if(result.photo&&String(result.photo).startsWith('data:image/'))state.resumePhotoCandidate=String(result.photo).slice(0,160000);
 $('oldCV').value=text.slice(0,42000);
 if($('aiResumeReview'))$('aiResumeReview').innerHTML='';
 if($('aiResumeFeedbackText'))$('aiResumeFeedbackText').textContent='A dokumentum beolvasva; az élő AI-elemzés státuszát itt fogod látni.';
 fillProfile();persist();renderAll();go('profile');
 toast('CV beolvasva. Most az AI-elemzés következik, az adatok jóváhagyásával.');
 if(typeof window.aiOnResumeImported==='function')window.aiOnResumeImported(text);
}
// Az offline felismerő soha nem állítja magáról, hogy OpenAI, csak kifejezett felhasználói kérésre tölt ki mezőt.
function previewExtractedResume(){
 const original=$('oldCV')?.value||'';
 if(!original.trim()){toast('Még nincs kiolvasható önéletrajzszöveg.');return;}
 $('sheetTitle').textContent='📄 Amit az AI a CV-ből lát';
 $('sheetBody').innerHTML='<p class="tiny muted">Ez a telefon által kiolvasott szöveg ('+original.length+' karakter). Ha valami már innen hiányzik, az AI nem tudja megbízhatóan felismerni. A szöveg itt csak megtekinthető.</p><textarea readonly style="width:100%;min-height:360px;border:1px solid #d3d8e5;border-radius:12px;padding:12px;line-height:1.5">'+escape(original)+'</textarea><button class="button secondary full" style="margin-top:10px" onclick="closeSheet()">Bezárás</button>';
 openSheet();
}
function useOfflineResume(){const text=$('oldCV')?.value||'';if(!text.trim())return;
 const parsed=window.ResumeAssistant.parse(text,E.SKILL_DICTIONARY),p=state.profile,filled=[];
 for(const [key,value] of Object.entries(parsed.values)){const current=p[key];if(key==='skills'?!Array.isArray(current)||!current.length:!String(current??'').trim()&&!Number(current)){p[key]=value;filled.push(window.ResumeAssistant.LABELS[key]||key);}}
 state.resumeMeta.aiStatus='offline';state.resumeMeta.filled=filled;
 fillProfile();persist();renderAll();
 if($('aiResumeFeedbackText'))$('aiResumeFeedbackText').textContent='Csak helyi, kulcsszavas tartalékfelismerés történt. Ez nem AI-elemzés. Az eredmény hiányos lehet; ellenőrizd az adatokat.';
 toast('Helyi előnézet: '+filled.length+' mező. Valódi AI-elemzés továbbra is szükséges.');
}
function setResumeAiStatus(status,details){if(!state.resumeMeta)return;state.resumeMeta.aiStatus=status;persist();renderResumePanels();
 if($('aiResumeFeedbackText'))$('aiResumeFeedbackText').textContent=String(details||'');}
function dismissPraiseBubble(){
 const bubble=$('coachPraiseBubble');if(bubble)bubble.classList.add('hide');
 if(state.resumeMeta&&!state.resumeMeta.praiseSeen){state.resumeMeta.praiseSeen=true;persist();}
 if(praiseTimer){clearTimeout(praiseTimer);praiseTimer=null;}
}
function showPraiseBubble(){
 const bubble=$('coachPraiseBubble');if(!bubble)return;
 const m=state.resumeMeta,praise=m?.praise;
 const remain=Math.max(0,Number(m?.praiseExpiresAt||0)-Date.now());
 if(!praise||m.praiseSeen||remain<=0){bubble.classList.add('hide');if(praise&&remain<=0&&!m.praiseSeen){m.praiseSeen=true;persist();}return;}
 bubble.innerHTML='<b>✦ '+escape(praise.title)+'</b><span>'+escape(praise.text)+'</span><small>Húzd oldalra az eltüntetéshez · részletek érintésre</small>';
 bubble.classList.remove('hide');
 if(praiseTimer)clearTimeout(praiseTimer);
 praiseTimer=setTimeout(dismissPraiseBubble,remain);
}
function renderResumePanels(){const el=$('resumeStatus'),missingEl=$('resumeMissing');if(!el||!missingEl)return;
 const first=$('resumeFirstBlock'),uploaded=$('resumeUploadedPanel'),summary=$('resumeUploadedStatus'),ai=$('aiResumeFeedback');
 if(first)first.classList.toggle('hide',!!state.resumeMeta);
 if(uploaded)uploaded.classList.toggle('hide',!state.resumeMeta);
 if(ai)ai.classList.toggle('hide',!state.resumeMeta||state.resumeMeta.aiStatus==='approved');
 if(summary&&state.resumeMeta){const m=state.resumeMeta;const labels={waiting:'AI-elemzés indítására vár',running:'AI-elemzés folyamatban',review:'AI-javaslatok ellenőrzésre várnak',approved:'AI-adatok jóváhagyva',error:'AI-hiba, újrapróbálható',offline:'Helyi tartalék, nem AI'};summary.textContent=m.filename+' · '+(labels[m.aiStatus]||'AI-elemzésre vár')+' · '+Number(m.characters||0)+' kiolvasott karakter';}
 if(state.resumeMeta){const m=state.resumeMeta;el.innerHTML='<h4>✓ Beolvasva: '+escape(m.filename)+'</h4><div class="tiny">'+escape(m.method)+' · '+escape(m.date)+'</div>'+(m.aiStatus==='approved'?'<div class="found">✓ Az AI-javaslatok jóváhagyását rögzítettük.</div>':'<div class="tiny">A dokumentum beolvasása még nem jelenti a sikeres AI-elemzést.</div>');
 }else el.textContent='Még nem töltöttél fel önéletrajzot.';
 const incomplete=window.ResumeAssistant.missing(state.profile);missingEl.innerHTML=incomplete.length?incomplete.map(m=>'<button class="missing-item" onclick="gotoMissing(\''+escape(m.field)+'\')"><span><strong>⚠ '+escape(m.label)+'</strong><br>'+escape(m.help)+'</span><span>›</span></button>').join(''):'<div class="cv-primary">✓ Az alapadatok megvannak. Ellenőrizd az összes mezőt, majd generáld a CV-t!</div>';
 const cand=$('candidatePhoto');if(state.resumePhotoCandidate){cand.classList.remove('hide');cand.innerHTML='<div class="photo-candidate"><img src="'+state.resumePhotoCandidate+'" alt="Felismerésre váró kép"><div><b>Találtam egy képet a CV-ben</b><p style="font-size:11px;margin:4px 0">Ellenőrizd: valóban rólad készült? Csak jóváhagyás után használom.</p><button class="button sm" onclick="confirmResumePhoto()">✓ Ez az én képem</button><button class="button secondary sm" onclick="dismissResumePhoto()">Nem az</button></div></div>';}else{cand.innerHTML='';cand.classList.add('hide');}
}
function gotoMissing(field){const id=Object.keys(fields).find(x=>fields[x]===field)||(field==='skills'?'skills':'pTargetRoles');const node=$(id);if(node){node.scrollIntoView({behavior:'smooth',block:'center'});if(node.focus)node.focus();}}
function confirmResumePhoto(){if(!state.resumePhotoCandidate)return;state.profile.photo=state.resumePhotoCandidate;state.cvPhoto=true;state.resumePhotoCandidate='';persist();renderPhoto();renderResumePanels();toast('A profilkép mentve. A CV-ben csak a saját döntésedre jelenik meg.');}
function dismissResumePhoto(){state.resumePhotoCandidate='';persist();renderResumePanels();toast('A képet nem állítottam be profilképnek.');}


function ingestLiveJobSearch(jobs){
 if(!Array.isArray(jobs))return;
 const normalized=jobs.slice(0,150).filter(j=>j&&typeof j.title==='string'&&typeof j.company==='string'&&/^https:\/\//.test(String(j.url||''))).map((j,i)=>({
  ...E.normalizedJob(j,i),id:String(j.id||'').slice(0,62),isLive:true,verified:j.verified===true,
  aiScore:typeof j.score==='number'&&Number.isFinite(j.score)?j.score:null,aiReason:String(j.reason||''),aiMissing:Array.isArray(j.missing)?j.missing:[],
  aiAnalyzed:!!j.aiAnalyzed,publishedAt:String(j.publishedAt||''),county:String(j.county||''),
  activityStatus:String(j.activityStatus||''),activityCheckedAt:String(j.activityCheckedAt||''),verificationMethod:String(j.verificationMethod||''),
  applicationConfirmed:j.applicationConfirmed===true,regionVerified:j.regionVerified===true,source:String(j.source||''),publicationAgeDays:Number(j.publicationAgeDays)||0
 }));
 state.jobs=v091UniqueJobs([...normalized,...state.jobs.filter(j=>!j.isLive)]).slice(0,200);
 persist();renderAll();
}
function v09SaveRegion(){
 const value=String($('v09Region')?.value||'').trim().slice(0,300);
 if(!value){toast('Adj meg legalább egy települést vagy vármegyét.');return;}
 state.profile.locations=value;
 if($('pLocations'))$('pLocations').value=value;
 persist();renderJobs();toast('A keresési régió elmentve. Indíts új álláskeresést.');
}
function v091SelectArea(value){if($('v09Region'))$('v09Region').value=String(value||'');}
window.v091SelectArea=v091SelectArea;
window.v09SaveRegion=v09SaveRegion;
window.ingestLiveJobSearch=ingestLiveJobSearch;
window.getSearchProfile=()=>{const {name,email,phone,photo,linkedin,...rest}=state.profile;return rest;};

window.previewExtractedResume=previewExtractedResume;window.useOfflineResume=useOfflineResume;window.setResumeAiStatus=setResumeAiStatus;window.pickResume=pickResume;window.loadResumeWeb=loadResumeWeb;window.receiveImportedResume=receiveImportedResume;window.parsePastedResume=parsePastedResume;window.toggleResumePaste=toggleResumePaste;window.confirmResumePhoto=confirmResumePhoto;window.dismissResumePhoto=dismissResumePhoto;window.gotoMissing=gotoMissing;window.registerDemo=registerDemo;window.go=go;window.saveProfile=saveProfile;window.toggleSkill=toggleSkill;window.generateCV=generateCV;window.updateCvTemplate=updateCvTemplate;window.approveCV=approveCV;window.exportCV=exportCV;window.compareCV=compareCV;window.setThreshold=setThreshold;window.toggleImport=toggleImport;window.addManualJob=addManualJob;window.importJobsFile=importJobsFile;window.sourceSearch=sourceSearch;window.openJob=openJob;window.openJobSource=openJobSource;window.prepareApplication=prepareApplication;window.viewApplication=viewApplication;window.saveLetter=saveLetter;window.removeApplication=removeApplication;window.renderInterview=renderInterview;window.openAssistant=openAssistant;window.closeSheet=closeSheet;
window.addEventListener('DOMContentLoaded',()=>{setup();
 const searchPanel=$('aiJobSearchPanel'),jobList=$('jobList');if(searchPanel&&jobList&&jobList.previousElementSibling)jobList.parentNode.insertBefore(searchPanel,jobList.previousElementSibling);
 const bubble=$('coachPraiseBubble');let initialX=null;
 bubble?.addEventListener('touchstart',e=>{initialX=e.touches?.[0]?.clientX??null;},{passive:true});
 bubble?.addEventListener('touchend',e=>{const dx=(e.changedTouches?.[0]?.clientX??initialX)-initialX;if(initialX!==null&&Math.abs(dx)>60){e.preventDefault();e.stopPropagation();dismissPraiseBubble();}initialX=null;},{passive:false});
 bubble?.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse'||e.pointerType==='pen')initialX=e.clientX;});
 bubble?.addEventListener('pointerup',e=>{if(initialX!==null&&Math.abs(e.clientX-initialX)>60){e.stopPropagation();dismissPraiseBubble();}initialX=null;});
});window.addEventListener('keydown',e=>{if(e.key==='Escape')closeSheet()});
})();
