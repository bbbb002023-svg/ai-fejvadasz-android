'use strict';
/* Apply only after AI Fejvadasz 0.8.2.1 + v0.9.0 overlays and apply-v09-server.js.
 * Forwards a safe 0.9.1 upgrade and preserves secret env keys + legacy CV endpoints.
 */
const fs=require('node:fs'),path=require('node:path');
const file=path.join(__dirname,'job-search.js');let source=fs.readFileSync(file,'utf8');
if(source.includes("require('./rank-repair')")){console.log('0.9.1 backend already patched');process.exit(0);}
function replaceExactly(before,after,label){if(!source.includes(before))throw Error('Váratlan szerver-forrás / nem alkalmazható v0.9.1: '+label);source=source.replace(before,after);}
replaceExactly("const V09 = require('./v09-verify');",
 "const V09 = require('./v09-verify');\nconst DEDUP = require('./dedup');\nconst GEO = require('./hu-geo');\nconst REPAIR = require('./rank-repair');",'új motorok importja');
replaceExactly('const unique=E.uniqueJobs(collected).slice(0,150);',
 'const unique=E.uniqueJobs(DEDUP.dedupeJobs(collected)).slice(0,150);','azonos hirdetések összevonása');
const start=source.indexOf('     let ranked=[];\n     // Analyze EVERY eligible, verified listing');
const end=source.indexOf('     const byId=new Map((ranked||[]).map(r=>[String(r.id),r]));',start);
if(start<0||end<0)throw Error('0.9-es AI-elemzés nem található a szerveren');
source=source.slice(0,start)+`     // Bounded recovery: retry transient failures, split incomplete AI batches.
     // Absent AI response is never a fabricated match percentage.
     const repair=await REPAIR.rankWithRecovery(p,scored,{rankFn,key:env.OPENAI_API_KEY,model:env.OPENAI_MODEL||'gpt-5-mini',request:fetchImpl,maxCalls:28});
     const ranked=repair.ranked;
     s.aiAnalyzed=ranked.length>0;
     s.aiPendingCount=repair.unranked;
`+source.slice(end);
replaceExactly('s.jobs=scored.map(j=>{','s.jobs=DEDUP.dedupeJobs(scored.map(j=>{','frontend-eredmények deduplikálása');
replaceExactly('}).filter(j=>j.eligible).sort((a,b)=>b.score-a.score);',
 '}).filter(j=>j.eligible)).sort((a,b)=>(b.score??-1)-(a.score??-1));','eredmény lezárása');
source=source.replace('verifiedCount:s.verifiedCount||0,rejectedCount:s.rejectedCount||0,linkCount:',
 'verifiedCount:s.verifiedCount||0,rejectedCount:s.rejectedCount||0,aiPendingCount:s.aiPendingCount||0,linkCount:');
// Expand the query to actual towns relevant to the selected administrative scope.
// The complete KSH lookup is used in the strict POST-filter, not inferred from city strings.
const old=`const city=trim(String(profile.locations||profile.city||'Magyarország').split(/[,;\\n]+/)[0],55).replace(/[^\\p{L}\\p{N} \\-]/gu,' ').trim()||'Magyarország';`;
const replacement=`const geoPrefs=GEO.parsePreferences(profile);
 const countyCities={"Zala":["Nagykanizsa","Zalaegerszeg","Keszthely","Lenti"],"Vas":["Szombathely","Sárvár","Körmend"],"Győr-Moson-Sopron":["Győr","Sopron","Mosonmagyaróvár"],"Pest":["Érd","Szentendre","Gödöllő"],"Budapest":["Budapest"],"Fejér":["Székesfehérvár","Dunaújváros"],"Baranya":["Pécs","Mohács"],"Somogy":["Kaposvár","Siófok"],"Tolna":["Szekszárd","Paks"],"Veszprém":["Veszprém","Pápa"],"Komárom-Esztergom":["Tatabánya","Esztergom"],"Borsod-Abaúj-Zemplén":["Miskolc","Kazincbarcika"],"Heves":["Eger","Gyöngyös"],"Nógrád":["Salgótarján","Balassagyarmat"],"Hajdú-Bihar":["Debrecen","Hajdúszoboszló"],"Jász-Nagykun-Szolnok":["Szolnok","Jászberény"],"Szabolcs-Szatmár-Bereg":["Nyíregyháza","Kisvárda"],"Bács-Kiskun":["Kecskemét","Baja"],"Békés":["Békéscsaba","Gyula"],"Csongrád-Csanád":["Szeged","Hódmezővásárhely"]};
 const explicit=[...geoPrefs.cities].slice(0,2);
 const citySet=[...new Set([...explicit,...[...geoPrefs.counties].flatMap(c=>countyCities[c]||[]).slice(0,5)])];
 const city=citySet.length?'('+citySet.map(x=>x.replace(/[^\\p{L}\\p{N} \\-]/gu,'')).join(' OR ')+')':'Magyarország';`;
if(!source.includes(old))throw Error('Keresési régió-lekérdezés eredeti sora nem található');
source=source.replace(old,replacement);
fs.writeFileSync(file,source,'utf8');
const serverFile=path.join(__dirname,'server.js');let server=fs.readFileSync(serverFile,'utf8');
if(!server.includes("VERSION='0.9.0';")&&!server.includes("VERSION='0.9.1';"))throw Error('0.9.0-es szerver szükséges');
server=server.replace("VERSION='0.9.0';","VERSION='0.9.1';");fs.writeFileSync(serverFile,server,'utf8');
console.log('0.9.1: régiók, vármegyék, deduplikáció és AI-helyreállítás beállítva.');
