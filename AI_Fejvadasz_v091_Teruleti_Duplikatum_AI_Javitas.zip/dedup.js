'use strict';
// One application opening, one card – despite multiple discovery sources/URLs.
const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim().replace(/\s+/g,' ');
const keyCompany=s=>norm(s).replace(/\b(?:kft|zrt|bt|rt|ltd|inc|llc|group|hungary|magyarorszag|kftje)\b/g,'').replace(/\s+/g,' ').trim();
const keyTitle=s=>norm(s).replace(/\b(?:allas|allashirdetes|munka|budapest|teljes munkaido|foallas|teljes allas)\b/g,'').replace(/\s+/g,' ').trim();
function canonicalUrl(value){try{const u=new URL(value);if(!['https:','http:'].includes(u.protocol))return '';u.hash='';u.hostname=u.hostname.replace(/^www\./,'').toLowerCase();u.searchParams.forEach((v,k)=>{if(/^(utm_|fbclid|gclid|msclkid|source|ref|campaign|tracking|session)/i.test(k))u.searchParams.delete(k);});u.pathname=u.pathname.replace(/\/+$/,'')||'/';return u.toString();}catch{return '';}}
function daysBetween(a,b){const x=Date.parse(String(a||'').slice(0,10)),y=Date.parse(String(b||'').slice(0,10));return Number.isFinite(x)&&Number.isFinite(y)?Math.abs(x-y)/86400000:null;}
function overlap(a,b){const x=new Set(norm(a).split(' ').filter(s=>s.length>2)),y=new Set(norm(b).split(' ').filter(s=>s.length>2));if(!x.size||!y.size)return 0;const inter=[...x].filter(t=>y.has(t)).length;return inter/Math.min(x.size,y.size);}
function duplicate(a,b){
 const ua=canonicalUrl(a.url),ub=canonicalUrl(b.url);
 if(ua&&ub&&ua===ub)return true;
 const ca=keyCompany(a.company),cb=keyCompany(b.company);if(!ca||ca!==cb)return false;
 const ta=keyTitle(a.title),tb=keyTitle(b.title);if(!ta||!tb)return false;
 if(ta!==tb&&overlap(ta,tb)<.92)return false; // do not merge different roles
 const locA=norm(a.city||a.county),locB=norm(b.city||b.county);
 if(!locA||!locB||locA!==locB)return false; // never merge jobs in distinct cities
 const age=daysBetween(a.publishedAt,b.publishedAt);if(age!=null&&age>7)return false; // reopened roles count as new postings
 if(age==null){const descA=norm(a.description),descB=norm(b.description);return descA.length>100&&descB.length>100&&overlap(descA,descB)>.93;}
 return true;
}
function quality(j){const url=String(j.url||''),host=(()=>{try{return new URL(url).hostname}catch{return ''}})();const portal=/(profession\.hu|cvonline\.hu|jooble\.org|indeed\.|linkedin\.)/i.test(host);return (j.verified?10000:0)+(j.aiAnalyzed?5000:0)+(!portal?1000:0)+Math.min(4500,String(j.description||'').length)+((j.activityStatus==='active')?300:0);}
function merge(a,b){const primary=quality(b)>quality(a)?b:a,secondary=primary===a?b:a;
 return {...primary,
  sources:[...new Set([].concat(a.sources||[],b.sources||[],[a.source,b.source]).filter(Boolean))],
  alternateUrls:[...new Set([].concat(a.alternateUrls||[],b.alternateUrls||[],[a.url,b.url]).filter(Boolean))],
  // Retain the strongest verified date/AI evidence, not an unsupported new score.
  ...(primary.aiAnalyzed?{}:secondary.aiAnalyzed?{score:secondary.score,aiAnalyzed:true,reason:secondary.reason,missing:secondary.missing}:{}),
 };
}
function dedupeJobs(items){const out=[];
 for(const j of Array.isArray(items)?items:[]){if(!j?.title||!j?.company)continue;
 const i=out.findIndex(x=>duplicate(x,j));if(i<0)out.push({...j});else out[i]=merge(out[i],j);
 }return out;}
module.exports={dedupeJobs,duplicate,canonicalUrl,keyCompany,keyTitle};
