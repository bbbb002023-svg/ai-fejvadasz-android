'use strict';
/* Download KSH-derived settlement/county lookup once AT BUILD TIME. No personal data or
 * secret is sent; a missing/corrupted source fails deployment rather than guessing counties.
 * Data: Ferenci Tamás / IrszHnk.csv (2026-02-09), sourced from KSH 2025 Helységnévtár.
 */
const fs=require('node:fs'),path=require('node:path'),https=require('node:https');
const {norm,COUNTIES}=require('./hu-geo');
const SOURCE='https://raw.githubusercontent.com/ferenci-tamas/IrszHnk/master/IrszHnk.csv';
function convert(csv){const [first,...rows]=csv.replace(/^\uFEFF/,'').split(/\r?\n/),columns=first.split(';');
 const iCity=columns.indexOf('Helység.megnevezése'),iCounty=columns.indexOf('Vármegye.megnevezése');
 if(iCity<0||iCounty<0)throw Error('A település-adatbázis oszlopai megváltoztak');
 const byName={};const allowed=new Set(COUNTIES);
 for(const row of rows){if(!row)continue;const cols=row.split(';'),city=norm(cols[iCity]),county=String(cols[iCounty]||'').trim();if(!city||!allowed.has(county))continue;
 if(!byName[city])byName[city]=county;else if(byName[city]!==county)byName[city]=[...new Set([].concat(byName[city],county))];}
 const count=Object.keys(byName).length,counties=new Set(Object.values(byName).flat());
 if(count<3100||counties.size<20||byName[norm('Nagykanizsa')]!=='Zala'||byName[norm('Szombathely')]!=='Vas'||byName[norm('Szeged')]!=='Csongrád-Csanád'||byName[norm('Győr')]!=='Győr-Moson-Sopron'||byName[norm('Pécs')]!=='Baranya')throw Error('A település-adatbázis nem teljes vagy hibás: '+count+' település; '+counties.size+' vármegye');
 return byName;
}
function download(){return new Promise((resolve,reject)=>{https.get(SOURCE,{timeout:20000,headers:{'User-Agent':'AI-Fejvadasz/0.9.1 geography bootstrap'}},res=>{
 if(res.statusCode!==200){res.resume();return reject(Error('Földrajzi adatforrás HTTP '+res.statusCode));}
 const buf=[];let n=0;res.on('data',chunk=>{n+=chunk.length;if(n>2_000_000){res.destroy(Error('Földrajzi adatforrás túl nagy'));return;}buf.push(chunk)});res.on('end',()=>resolve(Buffer.concat(buf).toString('utf8')));res.on('error',reject);
 }).on('timeout',function(){this.destroy(Error('Földrajzi adatforrás időtúllépés'));}).on('error',reject);});}
if(require.main===module){download().then(text=>{const data=convert(text);fs.writeFileSync(path.join(__dirname,'hu-settlements.json'),JSON.stringify(data));console.log('Település–vármegye adatbázis betöltve:',Object.keys(data).length,'település');}).catch(e=>{console.error(e.message);process.exitCode=1;});}
module.exports={convert,download};
