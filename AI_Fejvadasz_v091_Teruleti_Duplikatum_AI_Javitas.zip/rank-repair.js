'use strict';
// Recover transient/model-output failures without inventing scores or hiding missing evidence.
const transient=e=>!/(?:\b(?:401|403|400|402)\b|invalid.api.key|not configured)/i.test(String(e?.message||''));
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const validResult=(batch,r)=>{const ids=new Set(batch.map(j=>String(j.id)));const seen=new Set();
 return (Array.isArray(r)?r:[]).filter(x=>{
 const id=String(x?.id||'');if(!ids.has(id)||seen.has(id)||!Number.isFinite(x?.score)||x.score<0||x.score>100||typeof x?.reason!=='string'||!x.reason.trim())return false;
 seen.add(id);return true;
 });};
async function rankWithRecovery(profile,jobs,{rankFn,key,model,request,maxCalls=28,delay=sleep}={}){
 if(!key||!jobs?.length)return {ranked:[],unranked:jobs?.length||0,calls:0};
 const collected=new Map();let calls=0;
 const run=async(batch,depth)=>{
  if(!batch.length||calls>=maxCalls)return;
  for(let attempt=0;attempt<2&&calls<maxCalls;attempt++){
   calls++;
   try{const returned=validResult(batch,await rankFn(profile,batch,{key,model,request}));for(const r of returned)collected.set(String(r.id),r);
    const missing=batch.filter(j=>!collected.has(String(j.id)));
    if(!missing.length)return;
    if(depth<3){if(missing.length===batch.length&&attempt===0){await delay(650);continue;}
      const size=Math.ceil(missing.length/2);await run(missing.slice(0,size),depth+1);await run(missing.slice(size),depth+1);}
    return;
   }catch(e){if(!transient(e))return;if(attempt===0){await delay(700);continue;}
    if(depth<3&&batch.length>1){const mid=Math.ceil(batch.length/2);await run(batch.slice(0,mid),depth+1);await run(batch.slice(mid),depth+1);}return;
   }
  }
 };
 for(let i=0;i<jobs.length&&calls<maxCalls;i+=8)await run(jobs.slice(i,i+8),0);
 return {ranked:[...collected.values()],unranked:jobs.length-collected.size,calls};
}
module.exports={rankWithRecovery,validResult};
