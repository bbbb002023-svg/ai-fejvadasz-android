'use strict';
// AI Fejvadász: szigorú területi és frissességi előszűrés a szakmai AI-rangsorolás ELŐTT.
// Telepítés előtt integrálni és éles állásforrásokkal külön ellenőrizni szükséges.
const GEO=require('./hu-geo');
const EXACT_DATE_SOURCES = new Set(['original_listing','employer_ats','jobposting_jsonld','partner_api']);
const CLOSED = new Set(['closed','expired','filled','withdrawn','not_found','deleted']);
function norm(s){return String(s??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('hu-HU').replace(/[^a-z0-9]+/g,' ').trim().replace(/\s+/g,' ')}
function allowedRegions(p){return {
 cities:(Array.isArray(p.allowedCities)?p.allowedCities:[]).map(norm).filter(Boolean),
 counties:(Array.isArray(p.allowedCounties)?p.allowedCounties:[]).map(norm).filter(Boolean),
 allowFullyRemote:Boolean(p.allowFullyRemote),
 maxDistanceKm: Number.isFinite(Number(p.maxDistanceKm)) && Number(p.maxDistanceKm)>0?Math.min(300,Number(p.maxDistanceKm)):null,
 homeCoordinates: p.homeCoordinates||null
}}
function hasCoords(o){return o&&Number.isFinite(o.lat)&&Number.isFinite(o.lon)&&Math.abs(o.lat)<=90&&Math.abs(o.lon)<=180;}
function km(a,b){const rad=Math.PI/180,dLat=(b.lat-a.lat)*rad,dLon=(b.lon-a.lon)*rad,h=Math.sin(dLat/2)**2+Math.cos(a.lat*rad)*Math.cos(b.lat*rad)*Math.sin(dLon/2)**2;return 6371*2*Math.asin(Math.min(1,Math.sqrt(h)))}
function regionGate(job,rawPrefs){
 const geo=GEO.regionMatches(job,rawPrefs||{});
 if(geo.pass)return geo;
 // A távolság csak akkor engedélyezett, ha két megbízható koordinátát adott meg a rendszer.
 const prefs=allowedRegions(rawPrefs||{});
 if(prefs.maxDistanceKm&&hasCoords(prefs.homeCoordinates)&&hasCoords(job.coordinates)){
   const d=km(prefs.homeCoordinates,job.coordinates);
   if(d<=prefs.maxDistanceKm)return {pass:true,reason:`Kb. ${Math.round(d)} km légvonalban`};
 }
 return geo;
}

function dateGate(job, now=new Date()){
 if(CLOSED.has(norm(job.activityStatus)))return {pass:false,reason:'A hirdetés lezárt vagy nem található.'};
 // A "felfedezés" és keresőindex-kor nem bizonyítja a közzététel napját.
 if(!EXACT_DATE_SOURCES.has(job.publicationDateSource))return {pass:false,reason:'A közzététel dátuma nem igazolt.'};
 if(!/^\d{4}-\d{2}-\d{2}$/.test(job.publishedAt||''))return {pass:false,reason:'Az eredeti közzétételi dátum hiányzik.'};
 const today=new Date(Date.UTC(now.getUTCFullYear(),now.getUTCMonth(),now.getUTCDate()));
 const date=new Date(job.publishedAt+'T00:00:00Z');
 if(!Number.isFinite(date.getTime())||date.toISOString().slice(0,10)!==job.publishedAt)return {pass:false,reason:'Érvénytelen közzétételi dátum.'};
 const days=Math.round((today.getTime()-date.getTime())/86400000);
 if(days<0||days>20)return {pass:false,reason:'A hirdetés nem a megengedett 0–20 napos időszakból származik.'};
 if(job.activityStatus!=='active'||job.activityCheckedAt==null)return {pass:false,reason:'Nem igazolt, hogy az eredeti álláshirdetés jelenleg aktív.'};
 const checked=new Date(job.activityCheckedAt);
 if(!Number.isFinite(checked.getTime())||checked>now||now-checked>24*3600*1000)return {pass:false,reason:'Az aktivitásellenőrzés régi vagy hiányzik.'};
 return {pass:true,days,reason:'Friss, aktívnak ellenőrzött hirdetés'};
}
function preFilter(jobs,region,now=new Date()){
 const passed=[],pending=[];
 for(const job of Array.isArray(jobs)?jobs:[]){
  const rg=regionGate(job,region);if(!rg.pass){pending.push({job,reason:rg.reason,stage:'régió'});continue;}
  const dg=dateGate(job,now);if(!dg.pass){pending.push({job,reason:dg.reason,stage:'frissesség/aktivitás'});continue;}
  if(!String(job.title||'').trim()||!String(job.company||'').trim()){pending.push({job,reason:'Munkakör vagy munkáltató neve hiányzik.',stage:'azonosítás'});continue;}
  passed.push({...job,publicationAgeDays:dg.days,regionReason:rg.reason});
 }
 return {passed,pending};
}
function recommend(scoredJobs){
 // A „80% felett” szigorúan több mint 80%-ot jelent, nem >=80-at.
 const eligible=(Array.isArray(scoredJobs)?scoredJobs:[]).filter(j=>j.aiAnalyzed===true&&j.eligible!==false&&Number.isFinite(j.score));
 const sort=(a,b)=>b.score-a.score||a.publicationAgeDays-b.publicationAgeDays;
 return {recommended:eligible.filter(j=>j.score>80).sort(sort),others:eligible.filter(j=>j.score<=80).sort(sort)};
}
module.exports={regionGate,dateGate,preFilter,recommend};
