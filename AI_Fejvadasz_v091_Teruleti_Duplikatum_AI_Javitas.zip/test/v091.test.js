'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const GEO=require('../server/hu-geo');
const {regionGate}=require('../server/region-policy');
const {parseJob,verifyLinks}=require('../server/v09-verify');
const {dedupeJobs}=require('../server/dedup');
const {rankWithRecovery}=require('../server/rank-repair');
const {convert}=require('../server/prepare-hu-geo');
const now=new Date('2026-11-10T15:00:00Z');
GEO.injectGeoForTest({nagykanizsa:'Zala',zalaegerszeg:'Zala',keszthely:'Zala',zalakaros:'Zala', szombathely:'Vas',sopron:'Győr-Moson-Sopron',gyor:'Győr-Moson-Sopron',szeged:'Csongrád-Csanád',budapest:'Budapest',erd:'Pest',szentendre:'Pest'});
for(const [where,city,want] of [
 ['Zala vármegye','Zalakaros',true],['Zala megye','Zalaegerszeg',true],['Nyugat-Dunántúl','Szombathely',true],['Nyugat-Dunántúl régió','Sopron',true],['Nyugat-Dunántúl','Szeged',false],['Pest vármegye','Érd',true],['Pest vármegye','Budapest',false],['Budapest','Budapest',true],['Közép-Magyarország','Budapest',true],['Dél-Alföld','Szeged',true]]){
 test(`${where} → ${city}: ${want}`,()=>assert.equal(regionGate({city},{locations:where}).pass,want));
}
test('Unknown settlement must not be falsely assigned to a county',()=>assert.equal(regionGate({city:'TelepulesX'},{locations:'Zala vármegye'}).pass,false));
test('Contradictory city and county metadata is rejected',()=>assert.equal(regionGate({city:'Szeged',county:'Zala'},{locations:'Zala vármegye'}).pass,false));
test('Remote matches only when configured and explicitly available in Hungary',()=>assert.equal(regionGate({workMode:'remote',remoteIsFullyRemote:true,remoteAvailableInHungary:true},{locations:'Zala vármegye',allowFullyRemote:true}).pass,true));
test('KSH-derived settlement data parser handles county and postcode columns',()=>{
 let h='Helység.megnevezése;IRSZ;Településrész;Helység.KSH.kódja;Helység.jogállása;Vármegye.megnevezése\n';
 const counties=GEO.COUNTIES;for(let i=0;i<3140;i++)h+=`Teszttelepules${i};1000;;${i};varos;${counties[i%20]}\n`;
 h+='Nagykanizsa;8800;;;város;Zala\nSzombathely;9700;;;város;Vas\nSzeged;6720;;;város;Csongrád-Csanád\nGyőr;9020;;;város;Győr-Moson-Sopron\nPécs;7600;;;város;Baranya\n';
 const geo=convert(h);assert.ok(Object.keys(geo).length>3140);assert.equal(geo['nagykanizsa'],'Zala');
});
const mk=(x={})=>({title:'Területi értékesítő',company:'Minta Kft.',city:'Nagykanizsa',county:'Zala',publishedAt:'2026-11-09',description:'Szakmai kapcsolatok fejlesztése a régióban. B2B ügyfelek és értékesítési tevékenységek koordinálása.',url:'https://profession.hu/a?id=3',verified:true,...x});
test('One vacancy from two portals appears once; preserves both sources',()=>{
 const j=dedupeJobs([mk({source:'Profession',url:'https://profession.hu/a?id=3'}),mk({source:'CVonline',url:'https://cvonline.hu/a?id=4'})]);
 assert.equal(j.length,1);assert.deepEqual(j[0].sources.sort(),['CVonline','Profession']);assert.equal(j[0].alternateUrls.length,2);
});
test('Tracking-tag URLs canonicalized and deduplicated',()=>assert.equal(dedupeJobs([mk({url:'https://profession.hu/job?id=123&utm_source=xx'}),mk({url:'https://profession.hu/job?id=123'})]).length,1));
test('Different job cities, companies or titles stay distinct',()=>assert.equal(dedupeJobs([mk(),mk({city:'Zalaegerszeg',url:'https://example.org/a'}),mk({company:'Más Kft.',url:'https://example.org/b'}),mk({title:'Pénzügyi elemző',url:'https://example.org/c'})]).length,4));
test('Reposted job dates more than seven days apart stay distinct',()=>assert.equal(dedupeJobs([mk(),mk({publishedAt:'2026-10-29',url:'https://cvonline.hu/a?id=4'})]).length,2));
test('Missing original date must not be treated as same role without text evidence',()=>assert.equal(dedupeJobs([mk({publishedAt:'',description:'short'}),mk({publishedAt:'',description:'other',url:'https://cvonline.hu/a?id=4'})]).length,2));
test('AI recovery retries failed response and uses evidence-backed rank only',async()=>{
 let attempts=0;const jobs=[{id:'1'},{id:'2'}],rankFn=async(_p,js)=>{attempts++;if(attempts===1)throw Error('AI HTTP 503');return js.map(x=>({id:x.id,score:85,reason:'A CV szakmai tapasztalata illeszkedik a feladatokhoz.',excluded:false,missing:[]}));};
 const result=await rankWithRecovery({},jobs,{rankFn,key:'test',delay:async()=>{}});assert.equal(result.unranked,0);assert.equal(result.calls,2);
});
test('No API key => no model call and no invented scores',async()=>{let count=0;const r=await rankWithRecovery({},[{id:'1'}],{key:'',rankFn:async()=>{count++}});assert.equal(count,0);assert.equal(r.ranked.length,0);});
test('Invalid key 401 -> no uncontrolled retries',async()=>{let count=0;const r=await rankWithRecovery({},[{id:'1'}],{key:'test',rankFn:async()=>{count++;throw Error('AI HTTP 401')},delay:async()=>{}});assert.equal(count,1);assert.equal(r.ranked.length,0);});
test('Model hallucinated job ID or score 101 is never accepted',async()=>{const r=await rankWithRecovery({},[{id:'1'}],{key:'test',rankFn:async()=>[{id:'not-in-list',score:90,reason:'ok'},{id:'1',score:101,reason:'ok'}],delay:async()=>{},maxCalls:2});assert.equal(r.ranked.length,0);});
const html=j=>'<html><script type="application/ld+json">'+JSON.stringify(j)+'</script></html>';
const base={ '@type':'JobPosting',title:'Értékesítő',datePosted:'2026-11-09',hiringOrganization:{name:'Minta Kft.'},description:'Területi értékesítési tevékenység, kapcsolattartás, B2B partnerhálózat fejlesztése, ügyfélkapcsolatok bővítése és új megrendelők felkutatása.',jobLocation:{address:{addressLocality:'Zalakaros',addressCountry:'HU'}}};
test('Verifier accepts town inside county despite missing addressRegion',()=>assert.equal(Boolean(parseJob(html(base),{source:'CVonline',profile:{locations:'Zala vármegye'}},'https://cvonline.hu/allas/11',now).job),true));
test('Verifier accepts regional town despite missing county field',()=>assert.equal(Boolean(parseJob(html({...base,jobLocation:{address:{addressLocality:'Sopron',addressCountry:'HU'}}}),{source:'Profession',profile:{locations:'Nyugat-Dunántúl'}},'https://profession.hu/allas/11',now).job),true));
test('Verifier joins same job across two domains once',async()=>{
 const urls=['https://profession.hu/a/abc','https://cvonline.hu/b/def'];
 const fetch=async u=>({ok:true,status:200,headers:{get:()=> 'text/html'},text:async()=>html(base)});
 const res=await verifyLinks(urls.map((url,i)=>({url,title:'Értékesítő',source:'Portál'+i})),{locations:'Zala vármegye'},{request:fetch,now});
 assert.equal(res.jobs.length,1);assert.equal(res.checked,2);assert.equal(res.jobs[0].alternateUrls.length,2);
});
test('JobPosting with multiple cities displays the accepted city, not an excluded one',()=>{
 const listing={...base,jobLocation:[{address:{addressLocality:'Szeged',addressCountry:'HU'}},{address:{addressLocality:'Nagykanizsa',addressCountry:'HU'}}]};
 const r=parseJob(html(listing),{source:'CVonline',profile:{locations:'Zala vármegye'}},'https://cvonline.hu/allas/77',now);
 assert.equal(r.job?.city,'Nagykanizsa');
});
test('Every Hungarian NUTS2 region expands to its counties (no omission)',()=>{
 const expected=['Budapest','Pest','Közép-Dunántúl','Nyugat-Dunántúl','Dél-Dunántúl','Észak-Magyarország','Észak-Alföld','Dél-Alföld'];
 assert.equal(expected.flatMap(n=>GEO.NUTS2[n]).length,20);
 assert.equal(new Set(expected.flatMap(n=>GEO.NUTS2[n])).size,20);
});
