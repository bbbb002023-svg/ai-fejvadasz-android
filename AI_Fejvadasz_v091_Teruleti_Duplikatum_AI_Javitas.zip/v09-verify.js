'use strict';
/**
 * AI Fejvadász 0.9 – conservative, source-backed verification for Brave links.
 * A 200 response proves page reachability, not that an employer accepts applications.
 * Only JobPosting metadata with a verifiable publication date can pass.
 * Never converts search-index discovery age into a publication date.
 */
const crypto = require('node:crypto');
const {regionGate,dateGate}=require('./region-policy');
const {dedupeJobs}=require('./dedup');
const MAX_HTML=1_200_000, FRESH_DAYS=20;
const safeText=(x,n=4000)=>String(x??'').replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,' ').replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,' ').replace(/<[^>]+>/g,' ').replace(/&(?:nbsp|#160);/gi,' ').replace(/&amp;/gi,'&').replace(/&(?:quot|#34);/gi,'"').replace(/&#39;|&apos;/gi,"'").replace(/\s+/g,' ').trim().slice(0,n);
const ascii=x=>String(x??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
function isoDay(value){
 if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}(?:$|T|\s)/.test(value.trim()))return null;
 const date=value.trim().slice(0,10),obj=new Date(date+'T00:00:00Z');
 return Number.isFinite(obj.getTime())&&obj.toISOString().slice(0,10)===date?date:null;
}
function extractJsonLD(html){
 const list=[];const re=/<script\b(?=[^>]*\btype\s*=\s*["']application\/ld\+json["'])[^>]*>([\s\S]*?)<\/script\s*>/gi;
 let match;while((match=re.exec(html))&&list.length<40){try{list.push(JSON.parse(match[1].replace(/&quot;/g,'"').replace(/&amp;/g,'&').trim()));}catch{}}
 const nodes=[];function walk(node,depth=0){if(depth>8||!node||typeof node!=='object')return;if(Array.isArray(node)){node.forEach(x=>walk(x,depth+1));return;}if(String(node['@type']||'').split(/[,\s]+/).some(x=>x.toLowerCase()==='jobposting'))nodes.push(node);if(node['@graph'])walk(node['@graph'],depth+1);if(node.mainEntity)walk(node.mainEntity,depth+1);}
 list.forEach(x=>walk(x));return nodes;
}
function locationOf(job){
 const loc=Array.isArray(job.jobLocation)?job.jobLocation[0]:job.jobLocation;
 const address=loc?.address||loc||{};
 return {city:safeText(address.addressLocality||'',110),county:safeText(address.addressRegion||'',110),country:safeText(address.addressCountry?.name||address.addressCountry||'',70)};
}
function fullyRemote(job){const text=ascii(JSON.stringify(job.jobLocationType||''));return /telecommute|remote/.test(text);}
function allowedURL(s){try{const u=new URL(s);if(u.protocol!=='https:'||u.username||u.password||u.port)return false;const host=u.hostname.toLowerCase();if(host==='localhost'||host.endsWith('.local')||host.endsWith('.internal')||/^(?:\d{1,3}\.){3}\d{1,3}$/.test(host)||host.includes(':'))return false;return /^[a-z0-9.-]+\.[a-z]{2,}$/.test(host);}catch{return false;}}
async function getPage(url,request=globalThis.fetch){
 if(!allowedURL(url))return null;
 const origin=new URL(url).hostname.toLowerCase();
 let current=url;
 for(let redirects=0;redirects<=2;redirects++){
  const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),8500);
  try{
   const res=await request(current,{method:'GET',redirect:'manual',headers:{Accept:'text/html,application/xhtml+xml','User-Agent':'AI-Fejvadasz/0.9 (public job verification)'},signal:ctrl.signal});
   if([301,302,303,307,308].includes(res.status)){
    const next=new URL(res.headers?.get?.('location')||'',current).toString();
    const nHost=new URL(next).hostname.toLowerCase();
    if(!allowedURL(next)||!(nHost===origin||nHost.endsWith('.'+origin)||origin.endsWith('.'+nHost)))return null;
    current=next;continue;
   }
   if(!res.ok)return null;
   const type=String(res.headers?.get?.('content-type')||'');if(type&&!/html|xhtml/i.test(type))return null;
   const text=await res.text();if(text.length>MAX_HTML)return null;
   return {html:text,url:current};
  }catch{return null;}finally{clearTimeout(timer);}
 }
 return null;
}
function parseJob(html,link,url,now=new Date()){
 const candidates=extractJsonLD(html);if(!candidates.length)return {reason:'Nincs hiteles JobPosting-adat a hirdetés oldalán.'};
 const slug=ascii(safeText(html,7000));
 if(/(?:az allasajanlat mar nem elerheto|a hirdetes lejart|az allas betoltesre kerult|allas mar nem elerheto|job is no longer available|position has been filled|this job has expired)/.test(slug))return {reason:'A hirdetés lezártnak vagy töröltnek látszik.'};
 for(const j of candidates){
  const date=isoDay(j.datePosted),title=safeText(j.title||j.name,180),company=safeText(j.hiringOrganization?.name||'',120),loc=locationOf(j);
  const locs=(Array.isArray(j.jobLocation)?j.jobLocation:[j.jobLocation]).filter(Boolean).map(x=>locationOf({jobLocation:x}));
  if(!date||!title||!company||company.length<2){continue;}
  const validThrough=isoDay(j.validThrough);if(validThrough&&validThrough<now.toISOString().slice(0,10))continue;
  const dayAge=Math.floor((Date.UTC(now.getUTCFullYear(),now.getUTCMonth(),now.getUTCDate())-Date.parse(date+'T00:00:00Z'))/86_400_000);
  if(dayAge<0||dayAge>FRESH_DAYS)continue;
  if(j.jobLocationType&&fullyRemote(j)&&!loc.city){loc.city='';loc.county='';}
  let region={pass:false,reason:'Nem megállapítható terület'};
  if(!loc.city&&!loc.county&&!fullyRemote(j))continue;
  const applicationValue=ascii(JSON.stringify(j.applicationContact||j.directApply||j.url||''));
  // JobPosting + date + reachable source is evidence, not a live-application guarantee.
  const desc=safeText(j.description||link.snippet||'',4500);
  if(desc.length<70)continue;
  const obj={id:'v09_'+crypto.createHash('sha256').update(url).digest('hex').slice(0,25),title,company,city:loc.city,county:loc.county,locations:locs,description:desc,source:String(link.source||new URL(url).hostname).slice(0,110),url,workMode:fullyRemote(j)?'remote':String(j.employmentType||'').slice(0,80),remote:fullyRemote(j),remoteIsFullyRemote:fullyRemote(j),remoteAvailableInHungary:/HU|Hungary|Magyarorsz/i.test(JSON.stringify(j.applicantLocationRequirements||j.jobLocation||'')),publishedAt:date,publicationDateSource:'jobposting_jsonld',activityStatus:'active',activityCheckedAt:now.toISOString(),verified:true,verificationMethod:'Az eredeti oldalon elérhető JobPosting-adat és érvényes közzétételi dátum',applicationConfirmed:false,publicationAgeDays:dayAge};
  region=regionGate(obj,link.profile);
  if(!region.pass)continue;
  // Select the matching location for display, not necessarily the first listed city.
  if(locs.length>1){const match=locs.find(loc=>regionGate({city:loc.city,county:loc.county},link.profile).pass);if(match){obj.city=match.city;obj.county=match.county;}}
  if(!dateGate(obj,now).pass)continue;
  return {job:{...obj,regionReason:region.reason}};
 }
 return {reason:'A dátum, munkáltató, leírás vagy régió nem igazolható a megadott feltételekkel.'};
}
function normalizeHostLink(l){return l&&typeof l==='object'&&allowedURL(l.url)&&typeof l.title==='string';}
async function verifyLinks(links,profile,{request=globalThis.fetch,now=new Date(),parallel=5,onProgress=()=>{}}={}){
 const unique=[...new Map((Array.isArray(links)?links:[]).filter(normalizeHostLink).map(x=>[x.url,x])).values()].slice(0,160);
 let next=0,done=0;const valid=[],rejected=[];
 // A régiók/vármegyék kibontása a GEO-regiszterrel történik – nem szövegösszehasonlítással.
 const prefs=profile||{};
 const tokens=[String(prefs.locations||'').trim(),...(prefs.allowedRegions||[]),...(prefs.allowedCounties||[]),...(prefs.allowedCities||[])].filter(Boolean);
 if(!tokens.length)return {jobs:[],rejected:[{reason:'Először meg kell adni a keresési régiót.'}],checked:0};
 const worker=async()=>{while(next<unique.length){const idx=next++,l=unique[idx];try{
   const page=await getPage(l.url,request);if(!page){rejected.push({url:l.url,reason:'Az eredeti oldal nem érhető el vagy nem vizsgálható.'});continue;}
   const parsed=parseJob(page.html,{...l,profile:prefs},page.url,now);
   if(parsed.job)valid.push(parsed.job);else rejected.push({url:l.url,reason:parsed.reason});
  }catch{rejected.push({url:l.url,reason:'Ellenőrzési hiba.'});}
  finally{done++;onProgress(done,unique.length);}
 }};
 await Promise.all(Array.from({length:Math.min(Math.max(1,parallel),unique.length||1)},worker));
 valid.sort((a,b)=>b.publishedAt.localeCompare(a.publishedAt));
 return {jobs:dedupeJobs(valid),rejected,checked:done};
}
module.exports={getPage,parseJob,verifyLinks,extractJsonLD,isoDay,allowedURL};
