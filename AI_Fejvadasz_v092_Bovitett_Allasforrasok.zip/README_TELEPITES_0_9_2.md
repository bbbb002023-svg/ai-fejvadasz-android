# AI Fejvadász 0.9.2 – Bővített állásforrások

Ez a frissítő ZIP a már működő 0.9.1-es **Render szerverhez** készült. Nem Android APK; a telefonon nem kell újratelepíteni semmit, mert a módosítás teljes egészében szerveroldali.

## Mit javít?

- Megtartja a 4 korábbi indexforrást: Profession.hu, CVonline.hu, WHC, HSA.
- További 36, csoportos Brave-kereséssel vizsgált domain: további állásportálok, fejvadászok, munkaerő-közvetítők és közvetlen vállalati karrieroldalak.
- Hozzáadja az UNIX Autó, Inter Cars, Bárdi Autó, SPAR, Lidl, PENNY vállalati karrieroldalait. A Tesco, Humán Centrum, Hays és más források szintén a 36 között vannak.
- 3 domain/lekérdezés: 12 új csoport + a 4 korábbi forrás = **legfeljebb 16 Brave-kérés minden teljes új keresésnél**. A valódi ár a saját aktív Brave-szerződéstől függ; például $5/1000 kérésnél ez körülbelül $0.08/keresés a havi ingyenes kredit figyelembevétele előtt.
- Az új találatok **ugyanazon szigorú 0.9.1-es ellenőrzésen** mennek át: régió, legfeljebb 20 napos igazolható megjelenés, eredeti állásoldal, duplikációk, AI-illeszkedés. A keresőlink nem számít igazolt állásnak.
- Nem változtat az OpenAI, Brave vagy a telefonon tárolt titkok kezelésén.

**Keresési keret:** opcionális Render Environment Variable: `JOB_EXPANDED_GROUP_LIMIT=6` (0–12 közötti egész), például 6 extra csoport + 4 korábbi = legfeljebb 10 Brave-kérés/keresés. Az alapérték 12 extra csoport. A 0 kikapcsolja az új csoportokat, megtartva a régieket.

**Fontos különbség:** ez a csomag ellenőrzött, *előre kiválasztott* új doméneket ad a kereséshez. Nem telepít folyamatosan író adatbázist vagy 24 órás háttérmunkást. A ChatGPT-ben külön ütemezett webes forrásfelderítés beszámolhat a később talált oldalakról, de **nem módosítja automatikusan** a Render szervert. Ehhez perzisztens adatbázis, független feladatütemező és biztonságos forrás-jóváhagyás szükséges.

## 1. GitHub

Töltsd fel a `AI_Fejvadasz_v092_Bovitett_Allasforrasok.zip` fájlt a meglévő `bbbb002023-svg/ai-fejvadasz-android` repository gyökerébe. **Ne csomagold ki.** GitHub Actions- és Android APK-építés-módosítás nem szükséges: ez tisztán szerverfrissítés.

## 2. Render

Nyisd meg a `https://dashboard.render.com/` oldalt → `ai-fejvadasz-android` → Settings → Build Command.

A mező teljes tartalma (megtartja a 0.9.1-es Budapest/főváros adatforrás-javítást):

```bash
unzip -oq AI_Fejvadasz_AI_Szerver_v0821_Brave_Javitas.zip -d ai-server && unzip -oq AI_Fejvadasz_v090_Alkalmazas_Szerver_Frissites.zip -d ai-server && node ai-server/apply-v09-server.js && unzip -oq AI_Fejvadasz_v091_Teruleti_Duplikatum_AI_Javitas.zip -d ai-server && node ai-server/apply-v091-server.js && sed -i "s/trim();if(!city/trim().replace('főváros','Budapest');if(!city/" ai-server/prepare-hu-geo.js && node ai-server/prepare-hu-geo.js && unzip -oq AI_Fejvadasz_v092_Bovitett_Allasforrasok.zip -d ai-server && node ai-server/apply-v092-server.js && cd ai-server && npm install --omit=dev
```

Start Command: **változatlan**, `cd ai-server && npm start`.

Az összes meglévő környezeti változó megőrzendő. Opcionálisan állítsd be a `JOB_EXPANDED_GROUP_LIMIT=6` változót, ha csökkenteni akarod a Brave-költséget. Mentsd és Deploy.

## 3. Ellenőrzés

`https://ai-fejvadasz-android.onrender.com/health` → `"version":"0.9.2"`. Indíts a telefonon egy új keresést az Állások menüben. Több oldal ellenőrzése miatt a keresés tovább tarthat; a 20 napos korlát és a teljes hirdetésvizsgálat miatt a találatlista továbbra is lehet kevés.

## Teszt / korlát

A forráscsoportosító kód 10 automatikus teszten átment, az éles Brave/Render telepítés a csomag készítésekor még nem történt meg. Minden egyes forrásból származó hirdetést külön ellenőriz a régi megbízhatósági szűrő; a tartalmak megjelenését külső webhelyek és változó keresőindexek befolyásolják. A 0.9.1 korábbi nyers találatfeldolgozási és szerverfunkciói megmaradnak.
