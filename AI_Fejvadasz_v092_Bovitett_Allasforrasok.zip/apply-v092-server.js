'use strict';
// Apply after 0.8.2.1 -> 0.9.0 -> 0.9.1 overlays; idempotent, fail closed.
const fs=require('node:fs'),path=require('node:path');
const file=path.join(__dirname,'job-search.js');
let js=fs.readFileSync(file,'utf8');
if(js.includes("require('./expanded-sources')")){console.log('0.9.2 forrásbővítés már beépítve');process.exit(0);}
if(!js.includes("require('./rank-repair')"))throw Error('A 0.9.1-es AI Fejvadász szerver szükséges a forrásbővítéshez.');
function once(before,after,label){if(!js.includes(before))throw Error('Nem illeszkedik az új forrásmodul ('+label+'). A korábbi működő verzió maradjon éles.');js=js.replace(before,after);}
once("const E = require('./engine');", "const E = require('./engine');\nconst EXPANDED = require('./expanded-sources');",'új források importja');
once('sources.push(...INDEX_SOURCES);','sources.push(...INDEX_SOURCES,...EXPANDED.GROUPS.slice(0,EXPANDED.groupLimit(env)));','több álláskereső oldal');
once('const q=indexQuery(profile,src.domain),u=new URL(\'https://api.search.brave.com/res/v1/web/search\');',
`const q=src.type==='index-group'?EXPANDED.groupQuery(profile,src,indexQuery):indexQuery(profile,src.domain),u=new URL('https://api.search.brave.com/res/v1/web/search');`,'domaincsoport lekérdezés');
once('return list.map((r,i)=>standardizeIndexed(r,src,i)).filter(Boolean).slice(0,20);',
`const discovered=list.map((r,i)=>{\n    if(src.type!=='index-group')return standardizeIndexed(r,src,i);\n    const site=EXPANDED.matchSite(r?.url,src.sites);\n    return site?standardizeIndexed(r,{name:site.name+' – ellenőrzésre váró link',domain:site.domain},i):null;\n   }).filter(Boolean);\n  return discovered.slice(0,20);`,'tényleges webhely azonosítása');
once("src.type==='index'?await fetchIndexedLinks(env.BRAVE_SEARCH_API_KEY,src,p,fetchImpl)",
 "(src.type==='index'||src.type==='index-group')?await fetchIndexedLinks(env.BRAVE_SEARCH_API_KEY,src,p,fetchImpl)",'csoportos keresés meghívása');
once("if(src.type==='index')s.links.push(...arr)","if(src.type==='index'||src.type==='index-group')s.links.push(...arr)",'találatok összegyűjtése');
once("s.links=[...new Map(s.links.map(x=>[x.url,x])).values()].slice(0,150);",
 "s.links=EXPANDED.balancedLinks(s.links,220);",'arányos mintavétel az összes keresési forrásból');
// Main result gate remains unchanged: all candidates go through V09.verifyLinks
// with region, original date <= 20 days and JobPosting. No link-only results.
const verifyFile=path.join(__dirname,'v09-verify.js');let verify=fs.readFileSync(verifyFile,'utf8');
const original='filter(normalizeHostLink).map(x=>[x.url,x])).values()].slice(0,160);';
if(!verify.includes(original)&&!verify.includes('values()].slice(0,220);'))throw Error('Az ellenőrzési modul verziója eltér a várttól.');
if(verify.includes(original))verify=verify.replace(original,'filter(normalizeHostLink).map(x=>[x.url,x])).values()].slice(0,220);');
const serverFile=path.join(__dirname,'server.js');let server=fs.readFileSync(serverFile,'utf8');
if(!server.includes("VERSION='0.9.1';")&&!server.includes("VERSION='0.9.2';"))throw Error('0.9.1-es futó szerver szükséges.');
server=server.replace("VERSION='0.9.1';","VERSION='0.9.2';");
// Source schema checks are before all writes so failures don't leave a partial patch.
const src=require('./expanded-sources');if(src.GROUPS.length!==12||src.allSites.length!==36)throw Error('Forráslista integritási hiba');
fs.writeFileSync(file,js,'utf8');fs.writeFileSync(verifyFile,verify,'utf8');fs.writeFileSync(serverFile,server,'utf8');
console.log(`AI Fejvadász 0.9.2 aktív: ${src.GROUPS.length} bővített keresési csoport, ${src.allSites.length} új domain, a korábbi négy forrás megtartva.`);
