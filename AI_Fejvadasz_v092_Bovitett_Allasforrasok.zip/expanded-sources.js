'use strict';
/**
 * AI Fejvadász 0.9.2 – curated, multi-domain Brave discovery.
 * Discovery is not job verification. Only the existing V09 JobPosting/date/region gate
 * may turn a discovered URL into a displayed job.
 * Brave supports OR with site: operators; 3 curated domains per charged query.
 */
const RAW_GROUPS = [
  {category:'allasportal',name:'További magyar állásportálok',sites:[
    ['DreamJobs','dreamjobs.hu'], ['Jobinfo','jobinfo.hu'], ['Workline','workline.hu']]},
  {category:'kozvetito',name:'Nemzetközi munkaerő-közvetítők',sites:[
    ['Randstad','randstad.hu'], ['Trenkwalder','trenkwalder.com'], ['Manpower','manpower.hu']]},
  {category:'kozvetito',name:'Országos magyar közvetítők A',sites:[
    ['Prohuman','prohuman.hu'], ['Viapan','viapan.hu'], ['PannonJob','pannonjob.hu']]},
  {category:'kozvetito',name:'Országos magyar közvetítők B',sites:[
    ['Pannon-Work','pannonwork.hu'], ['Man at Work','manatwork.hu'], ['Work-Force','work-force.hu']]},
  {category:'fejvadasz',name:'Fejvadász és szakértői állások A',sites:[
    ['Karrier Hungária','karrierhungaria.hu'], ['Hays','hays.hu'], ['Grafton','grafton.hu']]},
  {category:'fejvadasz',name:'Fejvadász és szakértői állások B',sites:[
    ['Humán Centrum','humancentrum.hu'], ['Jobtain','jobtain.hu'], ['Enloyd','enloyd.hu']]},
  {category:'karrier',name:'Vállalati karrieroldalak – ipar',sites:[
    ['MOL Karrier','mol.hu'], ['Rába Karrier','raba.hu'], ['Bosch Karrier','bosch.hu']]},
  {category:'karrier',name:'Vállalati karrieroldalak – kereskedelem',sites:[
    ['ALDI Karrier','aldi.hu'], ['Magyar Posta Karrier','posta.hu'], ['Auchan Karrier','auchan.hu']]},
  {category:'karrier',name:'Vállalati karrieroldalak – műszaki',sites:[
    ['ZF Karrier','zf.com'], ['Magyar Telekom Karrier','magyar-telekom.onlyfy.jobs'], ['Continental Karrier','continental.com']]},
  {category:'karrier',name:'Vállalati karrieroldalak – további cégek',sites:[
    ['Schaeffler Karrier','schaeffler.com'], ['Flex Karrier','flex.com'], ['Tesco Karrier','karrier.tesco.hu']]},
  {category:'karrier',name:'Autóalkatrész-kereskedelem karrier',sites:[
    ['UNIX Autó','unixauto.hu'], ['Inter Cars','intercars.hu'], ['Bárdi Autó','bardiauto.karrierportal.hu']]},
  {category:'karrier',name:'Kiskereskedelem további karrieroldalak',sites:[
    ['SPAR','spar.karrierportal.hu'], ['Lidl','jobs.lidl.hu'], ['PENNY','karrier.penny.hu']]}
];
const domainPattern=/^(?:[a-z0-9-]+\.)+[a-z]{2,20}$/;
const groups=Object.freeze(RAW_GROUPS.map((g,i)=>Object.freeze({
 type:'index-group',category:g.category,name:g.name,queryIndex:i,
 sites:Object.freeze(g.sites.map(([name,domain])=>Object.freeze({name,domain})))
})));
const allSites=groups.flatMap(g=>g.sites);
if(allSites.some(s=>!domainPattern.test(s.domain))||new Set(allSites.map(s=>s.domain)).size!==allSites.length||groups.some(g=>g.sites.length!==3))throw Error('Hibás vagy duplikált 0.9.2-es forráslista');
function matchSite(url,sites){
 if(typeof url!=='string'||!Array.isArray(sites))return null;
 let u;try{u=new URL(url)}catch{return null}
 if(u.protocol!=='https:'||u.username||u.password||u.port)return null;
 const host=u.hostname.toLowerCase();
 return sites.find(s=>host===s.domain||host.endsWith('.'+s.domain))||null;
}
function groupQuery(profile,group,indexQuery){
 if(!group||!Array.isArray(group.sites)||!group.sites.length||typeof indexQuery!=='function')throw Error('Hiányzó index keresés');
 const raw=String(profile?.targetRoles||profile?.pastRoles||'');
 const roles=raw.split(/[,;\n]+/).map(x=>x.trim()).filter(Boolean).slice(0,6);
 const idx=Number.isSafeInteger(group.queryIndex)?group.queryIndex:0;
 const searchProfile=roles.length?{...profile,targetRoles:roles[idx%roles.length]}:profile;
 const seed=group.sites[0].domain;
 const original=indexQuery(searchProfile,seed);
 const operator='('+group.sites.map(x=>'site:'+x.domain).join(' OR ')+')';
 if(!original.startsWith('site:'+seed+' '))throw Error('Megváltozott alap keresési paraméter');
 return operator+original.slice(('site:'+seed).length);
}
/** Round-robin from domain sources: avoid dropping later career sites when cap is hit. */
function balancedLinks(items,limit=200){
 if(!Array.isArray(items)||!Number.isSafeInteger(limit)||limit<1)return [];
 const buckets=new Map(),seen=new Set();
 for(const item of items){if(!item||typeof item.url!=='string'||!item.url||seen.has(item.url))continue;
  seen.add(item.url);const source=String(item.source||'ismeretlen');if(!buckets.has(source))buckets.set(source,[]);buckets.get(source).push(item);
 }
 const keys=[...buckets.keys()],result=[];let more=true;
 while(more&&result.length<limit){more=false;for(const key of keys){const next=buckets.get(key).shift();if(next){result.push(next);more=true;}if(result.length===limit)break;}}
 return result;
}
function groupLimit(env={}){
 const raw=String(env.JOB_EXPANDED_GROUP_LIMIT??'12').trim();
 if(!/^(?:[0-9]|1[0-2])$/.test(raw))return 12;
 return Number(raw);
}
module.exports={GROUPS:groups,allSites,matchSite,groupQuery,balancedLinks,groupLimit};
