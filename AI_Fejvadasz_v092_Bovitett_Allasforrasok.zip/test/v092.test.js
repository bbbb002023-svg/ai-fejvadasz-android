'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),{spawnSync}=require('node:child_process');
const E=require('../server/expanded-sources');
test('12 source groups and 36 distinct domain sources',()=>{
 assert.equal(E.GROUPS.length,12);assert.equal(E.allSites.length,36);
 assert.equal(new Set(E.allSites.map(s=>s.domain)).size,36);
});
test('all grouped sources have exactly 3 HTTPS-compatible domains',()=>{
 for(const g of E.GROUPS){assert.equal(g.sites.length,3);for(const s of g.sites)assert.match(s.domain,/^(?:[a-z0-9-]+\.)+[a-z]{2,20}$/)}
});
test('only explicitly whitelisted hostname can be returned',()=>{
 const sites=E.GROUPS[0].sites;
 assert.equal(E.matchSite('https://www.dreamjobs.hu/allas/123',sites)?.name,'DreamJobs');
 assert.equal(E.matchSite('https://dreamjobs.hu.evil.example/job/1',sites),null);
 assert.equal(E.matchSite('https://evil.example/redirect?u=https://dreamjobs.hu',sites),null);
 assert.equal(E.matchSite('http://dreamjobs.hu/allas/1',sites),null);
 assert.equal(E.matchSite('https://dreamjobs.hu:8443/job',sites),null);
 assert.equal(E.matchSite('https://user:password@dreamjobs.hu/job',sites),null);
 assert.equal(E.matchSite('/redirect',sites),null);
});
test('Brave query uses OR and site restrictions for all three domains',()=>{
 const fakeIndex=(p,d)=>`site:${d} ${p.targetRoles} (Győr OR Sopron) állás`;
 const q=E.groupQuery({targetRoles:'területi képviselő, értékesítési vezető'},E.GROUPS[2],fakeIndex);
 assert.match(q,/^\(site:prohuman.hu OR site:viapan.hu OR site:pannonjob.hu\)/);
 assert.ok(q.includes('területi képviselő')||q.includes('értékesítési vezető'));
 assert.ok(q.includes('Győr OR Sopron'));
});
test('varied target roles across source groups',()=>{
 const fakeIndex=(p,d)=>`site:${d} ${p.targetRoles} Zala állás`;
 const profile={targetRoles:'értékesítő; üzletfejlesztő; telephelyvezető'};
 const q=E.GROUPS.slice(0,3).map(g=>E.groupQuery(profile,g,fakeIndex));
 assert.match(q[0],/értékesítő/);assert.match(q[1],/üzletfejlesztő/);assert.match(q[2],/telephelyvezető/);
});
test('requested car parts and retail chains included',()=>{
 const d=new Set(E.allSites.map(x=>x.domain));
 for(const x of ['unixauto.hu','intercars.hu','bardiauto.karrierportal.hu','spar.karrierportal.hu','jobs.lidl.hu','karrier.penny.hu','karrier.tesco.hu','humancentrum.hu'])assert.ok(d.has(x),x);
});
test('balanced results from early and late website sources',()=>{
 const results=[...Array.from({length:25},(_,i)=>({url:'https://s1.hu/'+i,source:'s1'})),...Array.from({length:10},(_,i)=>({url:'https://s2.hu/'+i,source:'s2'})),...Array.from({length:10},(_,i)=>({url:'https://s3.hu/'+i,source:'s3'}))];
 const chosen=E.balancedLinks(results,12);
 assert.deepEqual(chosen.map(x=>x.source),['s1','s2','s3','s1','s2','s3','s1','s2','s3','s1','s2','s3']);
});
test('duplicate URL included only once regardless of portals',()=>{
 const out=E.balancedLinks([{source:'a',url:'https://a.hu/1'},{source:'b',url:'https://a.hu/1'},{source:'b',url:'https://b.hu/2'}]);
 assert.equal(out.length,2);
});
test('optional strict group count to control query spending',()=>{
 for(const [s,n] of [['0',0],['1',1],['12',12],['99',12],['x',12],['-1',12]])assert.equal(E.groupLimit({JOB_EXPANDED_GROUP_LIMIT:s}),n);
});
test('server overlay integrates without touching existing validation and can apply twice',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'fejvadasz-v092-'));
 try{
  const mock=`'use strict';\nconst E = require('./engine');\nconst REPAIR = require('./rank-repair');\nfunction publicSources(env){const sources=[];sources.push(...INDEX_SOURCES);return sources;}\nconst q=indexQuery(profile,src.domain),u=new URL('https://api.search.brave.com/res/v1/web/search');\nreturn list.map((r,i)=>standardizeIndexed(r,src,i)).filter(Boolean).slice(0,20);\nconst arr=src.type==='index'?await fetchIndexedLinks(env.BRAVE_SEARCH_API_KEY,src,p,fetchImpl):src.type==='jooble'?null:null;\nif(src.type==='index')s.links.push(...arr);\ns.links=[...new Map(s.links.map(x=>[x.url,x])).values()].slice(0,150);\n// Only verified JobPosting and recent date can be displayed.\n`;
  fs.writeFileSync(path.join(dir,'job-search.js'),mock);fs.writeFileSync(path.join(dir,'v09-verify.js'),"const unique=[...new Map((Array.isArray(links)?links:[]).filter(normalizeHostLink).map(x=>[x.url,x])).values()].slice(0,160);\n");
  fs.writeFileSync(path.join(dir,'server.js'),"const VERSION='0.9.1';\n");
  for(const x of ['expanded-sources.js','apply-v092-server.js'])fs.copyFileSync(path.join(__dirname,'../server',x),path.join(dir,x));
  const a=spawnSync(process.execPath,[path.join(dir,'apply-v092-server.js')],{encoding:'utf8'});
  assert.equal(a.status,0,a.stderr);assert.match(a.stdout,/36 új domain/);
  const updated=fs.readFileSync(path.join(dir,'job-search.js'),'utf8');
  assert.match(updated,/EXPANDED\.GROUPS/);assert.match(updated,/EXPANDED\.matchSite/);assert.match(updated,/EXPANDED\.balancedLinks/);assert.match(updated,/EXPANDED\.groupQuery/);
  assert.match(fs.readFileSync(path.join(dir,'v09-verify.js'),'utf8'),/slice\(0,220\)/);
  assert.match(fs.readFileSync(path.join(dir,'server.js'),'utf8'),/0\.9\.2/);
  const b=spawnSync(process.execPath,[path.join(dir,'apply-v092-server.js')],{encoding:'utf8'});
  assert.equal(b.status,0,b.stderr);assert.match(b.stdout,/már beépítve/);
 } finally{fs.rmSync(dir,{recursive:true,force:true})}
});
