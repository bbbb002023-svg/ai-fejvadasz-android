# AI Fejvadász 0.9.4 – több állás Zalaegerszegen és más kiválasztott területeken

## Mit javít?

A 0.9.2-es kereső forrásonként egyetlen túl szűk Brave-lekérdezést készített, amelyben egyszerre szerepelt a CV-ből kiválasztott **első** munkakör és a város. A 12 bővített forráscsoportban három webhely osztozott legfeljebb 20 találaton, a rendszer pedig csak az első 220 jelöltet ellenőrizte. A szabálymotor egyes rokon szakmacsaládokat (pl. értékesítés versus üzletvezetés) a valódi AI-elemzés előtt kizárhatott.

A frissítés:

- forrásonként két külön Brave-keresést használ: **széles települési** és **szakmai** keresést (alapbeállítás, `JOB_SMART_QUERIES_PER_SOURCE=2`), URL-duplikációk nélkül;
- megőrzi a 40 korábbi forrást, és régió/vármegye esetén különböző városneveket forgat a lekérdezésekben (a **végső területi szűrés** továbbra is a KSH-alapú vármegye–település-adatbázist használja);
- maximum 360 URL-t enged a forrásarányos mintavételbe és legfeljebb 360 URL-t ellenőriz közvetlenül a hirdető webhelyén, 8 párhuzamos letöltővel;
- akár 120 ellenőrzött szakmai jelöltet ad az AI-rangsorolónak az eddigi 80 helyett; a kifejezetten kizárt vagy kötelező képesítés nélküli állások továbbra is kiesnek;
- csak ellenőrzött, legfeljebb 20 napos, megfelelő területű állások kerülhetnek a főlistába; a 80% feletti AI-értékeltek az ajánlottak közé;
- a Render naplóban **csak aggregált** ellenőrzési számokat közöl (CV, személyes adat, API-kulcs vagy teljes álláslink nélkül), így látható, mennyi jelölt esett ki hiányzó hiteles dátum vagy elérhetetlen oldal miatt;
- több településes JobPosting-hirdetésnél megtartja a 0.9.1-es helyszínkezelést és kezeli, ha az első helyszín adata hiányos.

**Korlátok:** A modul javítja a felfedezés lefedettségét, de az éles eredményszámhoz valós portál- és Brave API-teszt kell. Egyes portálok nem adnak kinyerhető strukturált JobPosting-adatot: ezeket a szigorú ellenőrzés továbbra sem engedi a főlistába. A vármegyéhez tartozó valamennyi településre vonatkozó végső szűrés működik, de a Brave-lekérdezések nem keresnek végig külön-külön minden településen. Ehhez később dedikált portál-adapterek és tartós keresési index szükséges.

**API-használat:** A 0.9.2 alap 16 Brave-lekérdezése helyett alapbeállításként legfeljebb 32 Brave-lekérdezés történhet egy teljes új keresésnél; további `JOB_INDEX_DOMAINS` beállítások ezt növelhetik. Az AI-értékelés is több tokent fogyaszthat. Kisebb kerethez Renderben opcionálisan `JOB_SMART_QUERIES_PER_SOURCE=1` állítható, így csak a széles keresés fut le. Az API-költség a szolgáltatói díjaktól függ. A telefonos appot nem kell újratelepíteni.

## Telepítés, 0.9.2 után közvetlenül

1. GitHub repository: `https://github.com/bbbb002023-svg/ai-fejvadasz-android/upload/main`
2. Töltsd fel a **`AI_Fejvadasz_v094_Szelesebb_Kereso_Javitas.zip`** fájlt a főkönyvtárba, kibontás nélkül.
3. Render: `https://dashboard.render.com/` → `ai-fejvadasz-android` → Settings → **Build Command**. Cseréld a teljes parancsot erre:

```bash
unzip -oq AI_Fejvadasz_AI_Szerver_v0821_Brave_Javitas.zip -d ai-server && unzip -oq AI_Fejvadasz_v090_Alkalmazas_Szerver_Frissites.zip -d ai-server && node ai-server/apply-v09-server.js && unzip -oq AI_Fejvadasz_v091_Teruleti_Duplikatum_AI_Javitas.zip -d ai-server && node ai-server/apply-v091-server.js && sed -i "s/trim();if(!city/trim().replace('főváros','Budapest');if(!city/" ai-server/prepare-hu-geo.js && node ai-server/prepare-hu-geo.js && unzip -oq AI_Fejvadasz_v092_Bovitett_Allasforrasok.zip -d ai-server && node ai-server/apply-v092-server.js && unzip -oq AI_Fejvadasz_v094_Szelesebb_Kereso_Javitas.zip -d ai-server && node ai-server/apply-v094-server.js && cd ai-server && npm install --omit=dev
```

4. **Start Command változatlan:** `cd ai-server && npm start`.
5. Mentés/Deploy után `https://ai-fejvadasz-android.onrender.com/health` várható verziója: `0.9.4`.
6. A telefonon **Állások → Zalaegerszeg → Új keresés**. Render Logs: `AI Fejvadasz verified job counts:` kezdetű aggregált naplóbejegyzés ellenőrizhető.

A 0.9.3 Facebook-modul külön engedélyköteles integráció; ez a csomag közvetlenül a már éles 0.9.2-re épül, és nem igényel Meta-kulcsot.

## Fejlesztői ellenőrzés

`node --test test/v094.test.js` – 10 független automatizált teszt az alapkeresésre, keresési költségkeretre, vármegye/régió kezelésére, AI előtti hard kizárásokra, duplikációkra, idempotens frissítésre, eredeti hirdetés dátum- és régióellenőrzésére. Ezek **nem** helyettesítik az éles Brave/portál-futtatást.
