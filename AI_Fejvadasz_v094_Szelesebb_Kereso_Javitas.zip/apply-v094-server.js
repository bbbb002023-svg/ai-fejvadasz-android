'use strict';
/** 0.9.4 server patch, apply AFTER v0.9.2 source expansion, no Facebook permission needed. */
const fs=require('node:fs'),path=require('node:path');
const serverPath=path.join(__dirname,'server.js');
const jobPath=path.join(__dirname,'job-search.js');
const verifyPath=path.join(__dirname,'v09-verify.js');
let js=fs.readFileSync(jobPath,'utf8');
if(js.includes("require('./smart-discovery')")){console.log('0.9.4 már telepítve');process.exit(0);}
if(!js.includes("require('./expanded-sources')")||!js.includes("require('./rank-repair')"))throw Error('Az AI Fejvadász 0.9.2-es szervere szükséges');
function patch(from,to,label){if(!js.includes(from))throw Error('Nem alkalmazható biztonságosan az új keresőjavítás: '+label);js=js.replace(from,to);}
patch("const E = require('./engine');","const E = require('./engine');\nconst SMART = require('./smart-discovery');",'új motor');
// Existing v0.9.1 indexQuery aggressively couples first target role and a short list of cities.
const qPattern=/function indexQuery\(profile,domain\)\{[\s\S]*?\n\}\nfunction validIndexedUrl/;
if(!qPattern.test(js))throw Error('A keresőindex lekérdezője megváltozott');
js=js.replace(qPattern,"function indexQuery(profile,domain){return SMART.indexQuery(profile,domain);}\nfunction validIndexedUrl");
patch("(src.type==='index'||src.type==='index-group')?await fetchIndexedLinks(env.BRAVE_SEARCH_API_KEY,src,p,fetchImpl)",
 "(src.type==='index'||src.type==='index-group')?await SMART.fetchExpandedLinks({key:env.BRAVE_SEARCH_API_KEY,src,profile:p,fetchIndexedLinks,request:fetchImpl,queryCount:SMART.queryCount(env)})",'széles és szakmai keresés');
patch('s.links=EXPANDED.balancedLinks(s.links,220);', 's.links=EXPANDED.balancedLinks(s.links,360);','forrásarányos mintavétel');
patch('const checkedJobs=await V09.verifyLinks(candidates,p,{request:fetchImpl,onProgress:',
      'const checkedJobs=await V09.verifyLinks(candidates,p,{request:fetchImpl,parallel:8,onProgress:','ellenőrzési párhuzamosítás');
patch('s.rejectedCount=checkedJobs.rejected.length;',
      "s.rejectedCount=checkedJobs.rejected.length;\n     s.rejectionReasons=SMART.rejectionSummary(checkedJobs.rejected);\n     console.info('AI Fejvadasz verified job counts:',JSON.stringify({checked:checkedJobs.checked,verified:checkedJobs.jobs.length,rejected:s.rejectionReasons}));",
      'nem személyes hibadiagnosztika');
patch('const unique=E.uniqueJobs(DEDUP.dedupeJobs(collected)).slice(0,150);',
      'const unique=E.uniqueJobs(DEDUP.dedupeJobs(collected)).slice(0,240);', 'több ellenőrzött jelölt');
patch('.filter(j=>j.fit.eligible).sort((a,b)=>b.fit.score-a.fit.score).slice(0,80);',
      '.filter(j=>SMART.notHardExcluded(j)).sort((a,b)=>b.fit.score-a.fit.score).slice(0,120);','AI előtti túlzott szakmai kizárás');
patch('if(!j.fit.eligible||excluded)score=0;', 'if(excluded)score=0;','rokon szakmák AI-értékelése');
const snap='rejectedCount:s.rejectedCount||0,aiPendingCount:';
if(js.includes(snap))js=js.replace(snap,'rejectedCount:s.rejectedCount||0,rejectionReasons:s.rejectionReasons||null,aiPendingCount:');
let verify=fs.readFileSync(verifyPath,'utf8');
if(!verify.includes('values()].slice(0,220);'))throw Error('Nem ismert JobPosting ellenőrzési korlát');
// 0.9.1 already checks every JobPosting location. The first one may be blank.
if(!verify.includes('const locs=(Array.isArray(j.jobLocation)?j.jobLocation:[j.jobLocation])'))throw Error('A 0.9.1-es többhelyszínes ellenőrzés hiányzik');
if(!verify.includes('if(!loc.city&&!loc.county&&!fullyRemote(j))continue;'))throw Error('JobPosting helyszínminimum eltér');
verify=verify.replace('if(!loc.city&&!loc.county&&!fullyRemote(j))continue;', 'if(!loc.city&&!loc.county&&!locs.length&&!fullyRemote(j))continue;');
let server=fs.readFileSync(serverPath,'utf8');
if(!server.includes("VERSION='0.9.2';"))throw Error('A futó szervernek 0.9.2-esnek kell lennie');
server=server.replace("VERSION='0.9.2';","VERSION='0.9.4';");
require('./smart-discovery');
// Atomically replace staged files; validation above ensures no partial incompatible patch.
for(const [file,data] of [[jobPath,js],[verifyPath,verify],[serverPath,server]])fs.writeFileSync(file,data,'utf8');
console.log('AI Fejvadász 0.9.4: dupla keresés, 360 ellenőrzendő jelölt, AI előtti szakmacsalád-szűrés javítva.');
