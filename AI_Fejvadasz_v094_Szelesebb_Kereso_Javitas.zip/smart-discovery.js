'use strict';
/** AI Fejvadász 0.9.4: greater verified-job recall without fabricated listings.
 * 1) A broad location-only pass prevents a single target-role keyword from hiding jobs.
 * 2) A complementary professional pass catches jobs missed by broad search.
 * 3) Only hard qualification/exclusion blockers apply before semantic AI ranking.
 * This code discovers candidates; V09 original-page validation remains authoritative.
 */
const GEO = require('./hu-geo');
const CITY_BY_COUNTY = Object.freeze({
  'Budapest':['Budapest'], 'Pest':['Érd','Vác','Gödöllő','Szentendre','Cegléd','Dunakeszi','Budaörs'],
  'Fejér':['Székesfehérvár','Dunaújváros','Mór','Bicske'],
  'Komárom-Esztergom':['Tatabánya','Esztergom','Komárom','Tata','Oroszlány'],
  'Veszprém':['Veszprém','Pápa','Ajka','Várpalota','Balatonfüred'],
  'Győr-Moson-Sopron':['Győr','Sopron','Mosonmagyaróvár','Kapuvár','Csorna'],
  'Vas':['Szombathely','Sárvár','Körmend','Kőszeg','Celldömölk'],
  'Zala':['Zalaegerszeg','Nagykanizsa','Keszthely','Lenti','Zalaszentgrót','Hévíz','Letenye'],
  'Baranya':['Pécs','Mohács','Komló','Szigetvár'],
  'Somogy':['Kaposvár','Siófok','Marcali','Nagyatád'],
  'Tolna':['Szekszárd','Paks','Dombóvár','Bonyhád'],
  'Borsod-Abaúj-Zemplén':['Miskolc','Kazincbarcika','Ózd','Tiszaújváros','Sátoraljaújhely'],
  'Heves':['Eger','Gyöngyös','Hatvan','Heves'],
  'Nógrád':['Salgótarján','Balassagyarmat','Pásztó'],
  'Hajdú-Bihar':['Debrecen','Hajdúszoboszló','Hajdúböszörmény','Berettyóújfalu'],
  'Jász-Nagykun-Szolnok':['Szolnok','Jászberény','Karcag','Törökszentmiklós'],
  'Szabolcs-Szatmár-Bereg':['Nyíregyháza','Kisvárda','Mátészalka','Nyírbátor'],
  'Bács-Kiskun':['Kecskemét','Baja','Kiskunfélegyháza','Kiskunhalas'],
  'Békés':['Békéscsaba','Gyula','Orosháza','Szarvas'],
  'Csongrád-Csanád':['Szeged','Hódmezővásárhely','Makó','Szentes']
});
const clean=x=>String(x??'').replace(/[\r\n\t"'`<>]/g,' ').replace(/[(){}\[\]|\\]/g,' ').replace(/\s+/g,' ').trim();
function hash(s){let n=0;for(const c of String(s))n=(n*31+c.charCodeAt(0))>>>0;return n;}
function unique(xs){const seen=new Set();return xs.filter(x=>{const k=GEO.norm(x);if(!k||seen.has(k))return false;seen.add(k);return true;});}
function localities(p,domain){
 const prefs=GEO.parsePreferences(p||{});
 const explicit=String(p?.locations||p?.city||'').split(/[,;\n]+/).map(x=>x.trim()).filter(x=>prefs.cities.has(GEO.norm(x)));
 const counties=[...prefs.counties];
 let pool=unique([...explicit,...counties.flatMap(c=>CITY_BY_COUNTY[c]||[])]);
 if(!pool.length&&prefs.cities.size)pool=[...prefs.cities];
 if(!pool.length)return ['Magyarország'];
 // Explicit city comes first; county cities rotate across source groups to improve coverage.
 const selected=unique(explicit).slice(0,2),rest=pool.filter(x=>!selected.some(y=>GEO.norm(x)===GEO.norm(y)));
 if(rest.length){const offset=hash(domain)%rest.length,remaining=Math.min(3-selected.length,rest.length);for(let i=0;i<remaining;i++)selected.push(rest[(offset+i)%rest.length]);}
 return selected.length?selected.slice(0,3):pool.slice(0,3);
}
function roles(p){const all=[p?.targetRoles,p?.pastRoles].flatMap(x=>String(x||'').split(/[,;\n]+/)).map(clean).filter(x=>x.length>=3);
 return unique(all).slice(0,3).map(x=>x.slice(0,55));}
function indexQuery(p,domain){
 const source=String(domain||'').toLowerCase();if(!/^(?:[a-z0-9-]+\.)+[a-z]{2,20}$/.test(source))throw Error('Nem biztonságos forrásdomain');
 const cities=localities(p,source).map(x=>clean(x).slice(0,48)).filter(Boolean);
 const location=cities.length===1?`"${cities[0]}"`:'('+cities.map(x=>`"${x}"`).join(' OR ')+')';
 const mode=p?.__smartMode==='role'?'role':'broad';
 const r=roles(p);
 const terms=(mode==='role'&&r.length)?'('+r.map(x=>`"${x}"`).join(' OR ')+')':'állás';
 // Brave's maximum query length is 400 chars. Never include untrusted URL or full CV.
 return (`site:${source} ${location} ${terms}`).slice(0,390);
}
function queryCount(env={}){const n=Number(String(env.JOB_SMART_QUERIES_PER_SOURCE??'2').trim());return Number.isInteger(n)&&n>=1&&n<=2?n:2;}
async function fetchExpandedLinks({key,src,profile,fetchIndexedLinks,request,queryCount:count=2}){
 if(typeof fetchIndexedLinks!=='function')throw Error('Indexkereső nem elérhető');
 const modes=count<=1?['broad']:['broad','role'];
 const all=[],seen=new Set();let succeeded=0,lastError;
 for(const mode of modes){
  try{
   const list=await fetchIndexedLinks(key,src,{...profile,__smartMode:mode},request);
   succeeded++;
   for(const item of Array.isArray(list)?list:[]){if(!item?.url||seen.has(item.url))continue;seen.add(item.url);all.push(item);}
  }catch(e){lastError=e;
   if(/\b(?:401|403|402|429)\b/.test(String(e?.message||'')))break;
  }
 }
 if(!succeeded&&lastError)throw lastError;
 return all;
}
function notHardExcluded(job){
 const blockers=job?.fit?.blockers||[];
 const hard=/kifejezetten kizartad|hianyzo kotelezo igazolas|kotelezo jogositvany|nem igazolt a megkovetelt vegzettseg|vegzettseg nem eri el/;
 return !blockers.some(x=>hard.test(GEO.norm(x)));
}
function locationsOf(job,parseOne){
 if(typeof parseOne!=='function')throw Error('Hiányzó JobPosting helyszínolvasó');
 const list=Array.isArray(job?.jobLocation)?job.jobLocation:[job?.jobLocation];
 return list.filter(Boolean).map(location=>parseOne({...job,jobLocation:location})).filter(x=>x.city||x.county);
}
function rejectionSummary(list){const summary={unavailable:0,missingEvidence:0,regionOrDate:0,other:0};
 for(const item of Array.isArray(list)?list:[]){const t=GEO.norm(item?.reason||'');
 if(/nem erheto el|nem vizsgalhato/.test(t))summary.unavailable++;
 else if(/nincs hiteles jobposting/.test(t))summary.missingEvidence++;
 else if(/datum|regio|munkaltato|leiras/.test(t))summary.regionOrDate++;
 else summary.other++;
 }return summary;
}
module.exports={CITY_BY_COUNTY,localities,roles,indexQuery,queryCount,fetchExpandedLinks,notHardExcluded,locationsOf,rejectionSummary};
