'use strict';
const test=require('node:test'), assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),{spawnSync}=require('node:child_process');
const SOURCE=fs.existsSync(path.join(__dirname,'../smart-discovery.js'))?path.join(__dirname,'..'):path.join(__dirname,'../server');
const PRIOR=fs.existsSync(path.join(SOURCE,'v09-verify.js'))?SOURCE:path.join(__dirname,'../../fejv091work/server');
const S=require(path.join(SOURCE,'smart-discovery.js'));
const G=require(path.join(PRIOR,'hu-geo.js'));
const p={targetRoles:'értékesítési vezető; üzletfejlesztési vezető',pastRoles:'területi képviselő',locations:'Zalaegerszeg'};
test('broad location query does not filter out adjacent professional families',()=>{
 const q=S.indexQuery({...p,__smartMode:'broad'},'profession.hu');
 assert.match(q,/^site:profession\.hu/);assert.match(q,/Zalaegerszeg/);
 assert.doesNotMatch(q,/értékesítési vezető/);
});
test('complementary query includes relevant roles as an alternative, not rigid intersection',()=>{
 const q=S.indexQuery({...p,__smartMode:'role'},'cvonline.hu');
 assert.match(q,/Zalaegerszeg/);assert.match(q,/értékesítési vezető/);assert.match(q,/ OR /);
});
test('county and NUTS regional discovery uses multiple cities but unchanged strict county verification',()=>{
 const cs=S.localities({locations:'Zala vármegye'},'profession.hu');
 assert.equal(cs.length,3);assert.ok(cs.every(c=>S.CITY_BY_COUNTY.Zala.includes(c)));
 const cs2=S.localities({locations:'Nyugat-Dunántúl'},'hsa.hu');
 assert.equal(cs2.length,3);assert.ok(cs2.some(c=>['Győr','Sopron','Szombathely','Zalaegerszeg','Keszthely'].includes(c)||c.length>2));
 assert.equal(G.regionMatches({city:'Keszthely',county:'Zala'},{locations:'Nyugat-Dunántúl'}).pass,true);
 assert.equal(G.regionMatches({city:'Szeged',county:'Csongrád-Csanád'},{locations:'Nyugat-Dunántúl'}).pass,false);
});
test('two modes are queried and URLs deduplicated',async()=>{
 const modes=[],src={domain:'cvonline.hu'};
 const got=await S.fetchExpandedLinks({key:'dummy',src,profile:p,request:null,fetchIndexedLinks:async(_,__,profile)=>{modes.push(profile.__smartMode);return [{url:'https://cvonline.hu/a',source:'a'},{url:'https://cvonline.hu/'+profile.__smartMode,source:'a'}];}});
 assert.deepEqual(modes,['broad','role']);assert.equal(got.length,3);
});
test('single broad call and transient second call failure retain verified candidates',async()=>{
 const got=await S.fetchExpandedLinks({key:'x',src:{},profile:p,queryCount:2,fetchIndexedLinks:async(_,__,profile)=>{if(profile.__smartMode==='role')throw Error('timeout');return [{url:'https://example.hu/job'}];}});
 assert.equal(got.length,1);
 let n=0;await S.fetchExpandedLinks({key:'x',src:{},profile:p,queryCount:1,fetchIndexedLinks:async()=>{n++;return [];}});assert.equal(n,1);
});
test('hard exclusions remain, family mismatch may be evaluated by semantic AI',()=>{
 assert.equal(S.notHardExcluded({fit:{blockers:['Eltérő szakmacsalád: értékesítés és kereskedelem']}}),true);
 for(const b of ['A munkakört kifejezetten kizártad.','Hiányzó kötelező igazolás: diploma.','Kötelező jogosítvány/engedély hiányzik: B.','Nem igazolt a megkövetelt végzettség: egyetem.'])assert.equal(S.notHardExcluded({fit:{blockers:[b]}}),false,b);
});
test('multi-location JobPosting recognizes alternate sites',()=>{
 const l=S.locationsOf({jobLocation:[{address:{addressLocality:'Budapest'}},{address:{addressLocality:'Zalaegerszeg',addressRegion:'Zala'}}]},x=>({city:x.jobLocation.address.addressLocality,county:x.jobLocation.address.addressRegion||''}));
 assert.deepEqual(l,[{city:'Budapest',county:''},{city:'Zalaegerszeg',county:'Zala'}]);
});
test('per-source budget is configurable and bounded',()=>{
 for(const [val,expected] of [['1',1],['2',2],['10',2],['0',2],['wat',2]])assert.equal(S.queryCount({JOB_SMART_QUERIES_PER_SOURCE:val}),expected);
});
test('rejection reasons summarize without disclosing personal job links',()=>{
 assert.deepEqual(S.rejectionSummary([{reason:'Az eredeti oldal nem érhető el vagy nem vizsgálható.'},{reason:'Nincs hiteles JobPosting-adat.'},{reason:'A dátum, régió nem igazolható.'},{reason:'Egyéb'}]),{unavailable:1,missingEvidence:1,regionOrDate:1,other:1});
});
test('0.9.4 server overlay applies and remains idempotent; multi-location original HTML gate still works',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'fejvadasz-v094-'));
 try{
  const MOCK=`'use strict';
const E = require('./engine');
const REPAIR = require('./rank-repair');
const EXPANDED = require('./expanded-sources');
function indexQuery(profile,domain){
 const role=String(profile.targetRoles||'állás');
 const city=String(profile.locations||'Magyarország');
 return \`site:\${domain} \${role} \${city} állás\`;
}
function validIndexedUrl(url,domain){return Boolean(url&&domain);}
async function jobProcess(){
 const env={BRAVE_SEARCH_API_KEY:'x'},src={type:'index',domain:'cvonline.hu'},p={targetRoles:'sales',locations:'Zalaegerszeg'},fetchImpl=async()=>null;
 const sources=[]; const INDEX_SOURCES=[];sources.push(...INDEX_SOURCES,...EXPANDED.GROUPS.slice(0,EXPANDED.groupLimit(env)));
 const q=src.type==='index-group'?EXPANDED.groupQuery(p,src,indexQuery):indexQuery(p,src.domain),u=new URL('https://api.search.brave.com/res/v1/web/search');
 const list=[];
 const discovered=list.map((r,i)=>{
    if(src.type!=='index-group')return standardizeIndexed(r,src,i);
    const site=EXPANDED.matchSite(r?.url,src.sites);
    return site?standardizeIndexed(r,{name:site.name+' – ellenőrzésre váró link',domain:site.domain},i):null;
   }).filter(Boolean);
 return discovered.slice(0,20);
 const arr=(src.type==='index'||src.type==='index-group')?await fetchIndexedLinks(env.BRAVE_SEARCH_API_KEY,src,p,fetchImpl):src.type==='jooble'?null:null;
 const s={links:[],rejectedCount:0,rejectionReasons:null};
 if(src.type==='index'||src.type==='index-group')s.links.push(...arr);
 s.links=EXPANDED.balancedLinks(s.links,220);
 const candidates=[],V09={verifyLinks:async()=>({rejected:[],jobs:[],checked:0})};
 const checkedJobs=await V09.verifyLinks(candidates,p,{request:fetchImpl,onProgress:(done,total)=>{}});
 s.rejectedCount=checkedJobs.rejected.length;
 const DEDUP={dedupeJobs:x=>x};const collected=[];
 const unique=E.uniqueJobs(DEDUP.dedupeJobs(collected)).slice(0,150);
 const scored=unique.map(j=>({...j,fit:E.fitJob(p,j)})).filter(j=>j.fit.eligible).sort((a,b)=>b.fit.score-a.fit.score).slice(0,80);
 const ranked=[],byId=new Map(), trim=x=>x;
 const jobs=scored.map(j=>{const a=byId.get(j.id),excluded=!!a?.excluded;let score=0;
 if(!j.fit.eligible||excluded)score=0;
 return {score,eligible:!excluded};});
 return {jobs,q,u,s};
}
function standardizeIndexed(){} async function fetchIndexedLinks(){}
`;
  fs.writeFileSync(path.join(dir,'job-search.js'),MOCK);
  fs.writeFileSync(path.join(dir,'server.js'),"const VERSION='0.9.2';\n");
  let v09=fs.readFileSync(path.join(PRIOR,'v09-verify.js'),'utf8');
  v09=v09.replace(/values\(\)\]\.slice\(0,(?:160|220|360)\);/,'values()].slice(0,220);');
  fs.writeFileSync(path.join(dir,'v09-verify.js'),v09);
  for(const f of ['apply-v094-server.js','smart-discovery.js'])fs.copyFileSync(path.join(SOURCE,f),path.join(dir,f));
  for(const f of ['hu-geo.js','region-policy.js','dedup.js'])fs.copyFileSync(path.join(PRIOR,f),path.join(dir,f));
  const r=spawnSync(process.execPath,[path.join(dir,'apply-v094-server.js')],{encoding:'utf8'});
  assert.equal(r.status,0,r.stderr||r.stdout);
  for(const f of ['job-search.js','v09-verify.js']){
   const check=spawnSync(process.execPath,['--check',path.join(dir,f)],{encoding:'utf8'});
   assert.equal(check.status,0,check.stderr);
  }
  const j=fs.readFileSync(path.join(dir,'job-search.js'),'utf8');
  assert.match(j,/SMART\.fetchExpandedLinks/);assert.match(j,/SMART\.notHardExcluded/);assert.match(j,/slice\(0,120\)/);assert.match(j,/balancedLinks\(s\.links,360\)/);
  assert.match(fs.readFileSync(path.join(dir,'v09-verify.js'),'utf8'),/const match=locs\.find/);
  assert.match(fs.readFileSync(path.join(dir,'server.js'),'utf8'),/0\.9\.4/);
  const r2=spawnSync(process.execPath,[path.join(dir,'apply-v094-server.js')],{encoding:'utf8'});
  assert.equal(r2.status,0,r2.stderr);assert.match(r2.stdout,/már telepítve/);
  const V=require(path.join(dir,'v09-verify.js'));
  const job={ '@type':'JobPosting',title:'Kirendeltség vezető',hiringOrganization:{name:'Teszt Kft.'},datePosted:'2026-11-08',jobLocation:[{address:{addressLocality:'Budapest',addressRegion:'Budapest'}},{address:{addressLocality:'Zalaegerszeg',addressRegion:'Zala'}}],description:'Kereskedelmi telephely vezetése, értékesítési stratégia, csapat irányítása és ügyfelekkel való napi kapcsolattartás Magyarországon.'};
  const html='<html><script type="application/ld+json">'+JSON.stringify(job)+'</script></html>';
  const parsed=V.parseJob(html,{source:'Teszt',profile:{allowedCities:['Zalaegerszeg']}},'https://www.example.hu/allas/abc',new Date('2026-11-10T12:00:00Z'));
  assert.ok(parsed.job,JSON.stringify(parsed));assert.equal(parsed.job.city,'Zalaegerszeg');
  assert.equal(V.parseJob(html,{source:'Teszt',profile:{allowedCities:['Szeged']}},'https://www.example.hu/allas/abc',new Date('2026-11-10T12:00:00Z')).job,undefined);
  const old={...job,datePosted:'2026-09-12'};
  assert.equal(V.parseJob('<script type="application/ld+json">'+JSON.stringify(old)+'</script>',{source:'Teszt',profile:{allowedCities:['Zalaegerszeg']}},'https://www.example.hu/allas/abc',new Date('2026-11-10T12:00:00Z')).job,undefined);
 }finally{fs.rmSync(dir,{force:true,recursive:true})}
});
