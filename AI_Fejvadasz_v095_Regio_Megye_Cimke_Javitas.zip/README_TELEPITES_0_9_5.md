# AI Fejvadász 0.9.5 – régió-, megye-/vármegye-címkék és keresési számláló

## Módosítások

- **Mind a 19 vármegye** a hagyományos `megye` és az új `vármegye` címkével is kiválasztható az Android Állások képernyőjén (pl. `Zala megye` és `Zala vármegye`). A régi eltárolt `megye` formátumot nem kell átírni.
- A szerver azonos területnek tekinti a két kifejezést; a `Csongrád megye` régi név továbbra is `Csongrád-Csanád`-ra térképeződik.
- A **régiókat** továbbra is az összes hozzátartozó vármegye alapján szűri, és a helyszín ellenőrzése a KSH-alapú település–vármegye adatbázist használja. A félrevezető, ellentmondásos címkéket nem fogadja el.
- A **Brave keresésben** a `megye` **és** a `vármegye` kifejezés is szerepel a kiválasztott területekre. Ez több releváns oldalt találhat, de nem helyettesíti a több ezer település külön portálon történő lekérését. A 275 karakteres egyedi lekérdezési korlát a 3-domain keresést is 400 karakter alatt tartja.
- A keresés végén a felfedezett (de nem feltétlenül elfogadott) linkek számlálója nem nullázódik. **A felfedezett link nem azonos a hitelesített állással.**
- A 20 napos dátum- és aktivitásellenőrzés, a duplikációszűrés és az AI-rangsorolás változatlanul megmarad.

## 1. GitHub feltöltés

Töltsd fel a `AI_Fejvadasz_v095_Regio_Megye_Cimke_Javitas.zip` fájlt a korábbi ZIP-ek mellé a repository gyökerébe: https://github.com/bbbb002023-svg/ai-fejvadasz-android/upload/main . **Ne bontsd ki** a GitHubon.

## 2. Render telepítés (már éles 0.9.4 után)

Render → `ai-fejvadasz-android` → Settings → Build Command. A teljes parancs, az eddigi javítások és API-kulcsok megtartásával:

```bash
unzip -oq AI_Fejvadasz_AI_Szerver_v0821_Brave_Javitas.zip -d ai-server && unzip -oq AI_Fejvadasz_v090_Alkalmazas_Szerver_Frissites.zip -d ai-server && node ai-server/apply-v09-server.js && unzip -oq AI_Fejvadasz_v091_Teruleti_Duplikatum_AI_Javitas.zip -d ai-server && node ai-server/apply-v091-server.js && sed -i "s/trim();if(!city/trim().replace('főváros','Budapest');if(!city/" ai-server/prepare-hu-geo.js && node ai-server/prepare-hu-geo.js && unzip -oq AI_Fejvadasz_v092_Bovitett_Allasforrasok.zip -d ai-server && node ai-server/apply-v092-server.js && unzip -oq AI_Fejvadasz_v094_Szelesebb_Kereso_Javitas.zip -d ai-server && node ai-server/apply-v094-server.js && sed -i 's/values()].slice(0,220);/values()].slice(0,360);/' ai-server/v09-verify.js && unzip -oq AI_Fejvadasz_v095_Regio_Megye_Cimke_Javitas.zip -d ai-server && node ai-server/apply-v095-server.js && cd ai-server && npm install --omit=dev
```

Start Command változatlan: `cd ai-server && npm start`. Környezeti kulcsok változatlanul maradnak. A sikeres egészségellenőrzés a `https://ai-fejvadasz-android.onrender.com/health` oldalon: `"version":"0.9.5"`.

**Fontos:** a 0.9.5-ös javítás új keresőszó-alternatívákat használ, de nem lazítja fel az eredeti `JobPosting`- és közzétételidátum-ellenőrzést. Ha korábban 39 felfedezett link és 0 elfogadott állás volt, a számlálójavítás önmagában nem teszi a 39 linket elfogadott állássá; a Render Logs `AI Fejvadasz verified job counts` bejegyzését kell megnézni.

## 3. Android – az új választólista telepítése

A 0.9.1-es Android ZIP overlay **után** újabb sort kell hozzáadni a `.github/workflows/build-apk.yml` `ZIP kibontasa` részéhez:

```bash
unzip -oq AI_Fejvadasz_v095_Regio_Megye_Cimke_Javitas.zip -d project
```

Az 0.9.2-es és 0.9.4-es csomag szerveroldali; nem kötelező az Android buildbe felvenni. A szerver frissítése nem igényel telefonos telepítést, de a megye **választólista** új felirataihoz új APK szükséges. A debug aláírás eltérhet; telepítési ütközés esetén **ne töröld a meglévő alkalmazást mentés nélkül**.

## Tesztek

`node --test test/v095.test.js` (a kibontott szerverkönyvtárban) – szinonimák, régiók, kizárások, keresőlekérdezések, idempotens szerverfrissítő, Android menü feliratai. Az éles álláshirdetések száma a tényleges forrásoktól és a strukturált adatok elérhetőségétől függ.
