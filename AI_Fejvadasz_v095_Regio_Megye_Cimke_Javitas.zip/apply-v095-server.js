'use strict';
/** AI Fejvadász 0.9.5: diagnostics + county/region terminology aliases. */
const fs=require('node:fs'),path=require('node:path');
const jobPath=path.join(__dirname,'job-search.js');
const serverPath=path.join(__dirname,'server.js');
const G=require('./hu-geo'),SMART=require('./smart-discovery');
if(G.cleanCounty('Zala megye')!=='Zala'||G.cleanCounty('Zala vármegye')!=='Zala'||
   !SMART.indexQuery({locations:'Zala megye'},'profession.hu').includes('"Zala vármegye"')){
 throw Error('A 0.9.5 területi és megyei szinonima-modul hibás, telepítés leállítva.');
}
let job=fs.readFileSync(jobPath,'utf8'),server=fs.readFileSync(serverPath,'utf8');
if(job.includes('s.linkCountCollected=s.links.length;')&&server.includes("VERSION='0.9.5';")){
 console.log('A 0.9.5-ös frissítés már be van építve.');process.exit(0);
}
if(!job.includes("require('./smart-discovery')")||!server.includes("VERSION='0.9.4';"))throw Error('Előbb a 0.9.4-es szerver szükséges.');
const old='s.links=[]; // No unchecked Brave links in the main results or a separate misleading listing.';
if(!job.includes(old))throw Error('A találatszámláló kódja váratlanul eltér.');
if(!job.includes('linkCount:s.links.length,links:'))throw Error('Nem ismert állapotlekérdezési mező; a telepítést leállítottuk.');
job=job.replace(old,`s.linkCountCollected=s.links.length; // Keep discovery count as a diagnostic, not as a verified-job count.\n     s.links=[]; // Unverified external URLs must NOT enter the verified jobs list.`);
job=job.replace('linkCount:s.links.length,links:','linkCount:(s.linkCountCollected??s.links.length),links:');
server=server.replace("VERSION='0.9.4';","VERSION='0.9.5';");
// Fail before overwriting files if the replacements cannot be checked safely.
if(!job.includes('linkCount:(s.linkCountCollected??s.links.length),links:')||!server.includes("VERSION='0.9.5';"))throw Error('A frissítési ellenőrzés sikertelen');
fs.writeFileSync(jobPath,job,'utf8');fs.writeFileSync(serverPath,server,'utf8');
console.log('0.9.5: megye/vármegye egyezés, régiók, felfedezett linkek számlálója javítva.');
