'use strict';
// KSH Helységnévtár (2025) settlement->county registry, processed from 2026-02-09 IrszHnk.csv.
// The complete indexed snapshot is generated at build time by prepare-hu-geo.js.
const fs=require('node:fs');
const path=require('node:path');
function norm(s){return String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim().replace(/\s+/g,' ');}
const COUNTIES=['Budapest','Pest','Fejér','Komárom-Esztergom','Veszprém','Győr-Moson-Sopron','Vas','Zala','Baranya','Somogy','Tolna','Borsod-Abaúj-Zemplén','Heves','Nógrád','Hajdú-Bihar','Jász-Nagykun-Szolnok','Szabolcs-Szatmár-Bereg','Bács-Kiskun','Békés','Csongrád-Csanád'];
const NUTS2=Object.freeze({
 'Budapest':['Budapest'], 'Pest':['Pest'],
 'Közép-Dunántúl':['Fejér','Komárom-Esztergom','Veszprém'],
 'Nyugat-Dunántúl':['Győr-Moson-Sopron','Vas','Zala'],
 'Dél-Dunántúl':['Baranya','Somogy','Tolna'],
 'Észak-Magyarország':['Borsod-Abaúj-Zemplén','Heves','Nógrád'],
 'Észak-Alföld':['Hajdú-Bihar','Jász-Nagykun-Szolnok','Szabolcs-Szatmár-Bereg'],
 'Dél-Alföld':['Bács-Kiskun','Békés','Csongrád-Csanád'],
 'Közép-Magyarország':['Budapest','Pest'], // NUTS1 historical/umbrella alias
 'Dunántúl':['Fejér','Komárom-Esztergom','Veszprém','Győr-Moson-Sopron','Vas','Zala','Baranya','Somogy','Tolna']
});
const countyMap=new Map(COUNTIES.map(c=>[norm(c),c]));
countyMap.set('csongrad','Csongrád-Csanád');
const regionMap=new Map(Object.entries(NUTS2).map(([n,counties])=>[norm(n),counties]));
const settlementFile=path.join(__dirname,'hu-settlements.json');
let geoData=null;
function loadGeo(){if(!geoData){try{geoData=JSON.parse(fs.readFileSync(settlementFile,'utf8'));}catch{geoData={};}}return geoData;}
function injectGeoForTest(map){geoData=map;}
// Both pre-2023 'megye' and current 'vármegye' are identical county labels.
function cleanCounty(s){const key=norm(s).replace(/\s+(?:varmegye|megye|county)$/,'').trim();return countyMap.get(key)||null;}
function countyLabelInLocality(s){const v=norm(s);return /\s+(?:megye|varmegye)$/.test(v)?cleanCounty(v):null;}
function expandToken(t){const v=norm(t).replace(/\s+(?:regio|tervezesi statisztikai regio)$/,'').trim();
 // Explicit 'régió' beats the Pest county alias; both expand identically in this case.
 if(regionMap.has(v))return {type:'region',name:t,counties:regionMap.get(v)};
 const c=cleanCounty(t);if(c)return {type:'county',name:c,counties:[c]};
 return {type:'city',name:cleanCity(t)};
}
function cleanCity(s){return norm(s).replace(/^\d{4}\s+/,'').replace(/\s+(?:varmegye|megye)$/,'').trim();}
function cityCounty(city){const key=cleanCity(city);if(!key)return null;
 if(/^budapest(?:\s+(?:\d{1,2}\s+ker(?:ulet)?|[ivx]+\s+ker(?:ulet)?))?$/.test(key))return 'Budapest';
 const data=loadGeo();const result=data[key];
 if(Array.isArray(result))return result.length===1?result[0]:null; // ambiguous: do not guess
 return typeof result==='string'&&countyMap.has(norm(result))?countyMap.get(norm(result)):null;
}
function parsePreferences(p){const values=[];
 for(const v of [].concat(p.allowedCities||[],p.allowedCounties||[],p.allowedRegions||[]))if(v)values.push(v);
 values.push(...String(p.locations||'').split(/[,;\n]+/).map(s=>s.trim()).filter(Boolean));
 const cities=new Set(),counties=new Set(),regions=new Set();
 for(const token of values){const x=expandToken(token);if(x.type==='city'){if(x.name)cities.add(x.name);}else{for(const c of x.counties)counties.add(c);if(x.type==='region')regions.add(norm(token));}}
 return {cities,counties,regions,allowFullyRemote:!!p.allowFullyRemote||/tavmunka|remote/i.test(String(p.workMode||'')),maxDistanceKm:Number(p.maxDistanceKm)||null,homeCoordinates:p.homeCoordinates||null};
}
function resolvedCounties(city,county){const explicit=cleanCounty(county),localityLabel=countyLabelInLocality(city);
 if(explicit&&localityLabel&&explicit!==localityLabel)return {county:null,conflict:true};
 const declared=explicit||localityLabel,derived=cityCounty(city);
 // Conflicting city and explicit region: no ungrounded positive match.
 if(declared&&derived&&declared!==derived)return {county:null,conflict:true};
 return {county:derived||declared||null,conflict:false};
}
function regionMatches(job,p){const pref=parsePreferences(p);
 if(!pref.cities.size&&!pref.counties.size&&!pref.allowFullyRemote)return {pass:false,reason:'Nincs beállított keresési régió.'};
 if(job.workMode==='remote'&&job.remoteIsFullyRemote===true&&job.remoteAvailableInHungary===true&&pref.allowFullyRemote)return {pass:true,reason:'Magyarországról végezhető távmunka'};
 const places=[{city:job.city,county:job.county},...(Array.isArray(job.locations)?job.locations.map(x=>typeof x==='string'?{city:x}:{city:x.city,county:x.county}):[])];
 for(const place of places){const city=cleanCity(place.city),{county,conflict}=resolvedCounties(place.city,place.county);if(conflict)continue;
   if(city&&pref.cities.has(city))return {pass:true,reason:'Engedélyezett település: '+city};
   if(county&&pref.counties.has(county))return {pass:true,reason:'Engedélyezett vármegye: '+county,county};
 }
 return {pass:false,reason:'Nem egyezik az engedélyezett vármegyékkel, régiókkal vagy településekkel.'};
}
module.exports={norm,COUNTIES,NUTS2,parsePreferences,cityCounty,cleanCounty,countyLabelInLocality,regionMatches,injectGeoForTest};
