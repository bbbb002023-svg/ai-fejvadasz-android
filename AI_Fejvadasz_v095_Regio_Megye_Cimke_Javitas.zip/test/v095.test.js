'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),{spawnSync}=require('node:child_process');
const SRC=fs.existsSync(path.join(__dirname,'../hu-geo.js'))?path.join(__dirname,'..'):path.join(__dirname,'../server');
const G=require(path.join(SRC,'hu-geo.js'));
const S=require(path.join(SRC,'smart-discovery.js'));
const norm=G.norm;
test('old and new county labels canonicalize to one identical Zala county',()=>{
 for(const value of ['Zala megye','Zala vármegye','ZALA MEGYE','Zala']){
  assert.equal(G.cleanCounty(value),'Zala');
  assert.deepEqual([...G.parsePreferences({locations:value}).counties],['Zala']);
 }
 assert.deepEqual([...G.parsePreferences({locations:'Zala vármegye, Zala megye'}).counties],['Zala']);
});
test('all 19 county labels work with both suffixes',()=>{
 const list=G.COUNTIES.filter(c=>c!=='Budapest');assert.equal(list.length,19);
 for(const c of list){assert.equal(G.cleanCounty(c+' megye'),c);assert.equal(G.cleanCounty(c+' vármegye'),c);}
 assert.equal(G.cleanCounty('Csongrád megye'),'Csongrád-Csanád');
});
test('region unfolds all counties and handles historic or new names',()=>{
 G.injectGeoForTest({zalaegerszeg:'Zala',nagykanizsa:'Zala',keszthely:'Zala',szombathely:'Vas',szeged:'Csongrád-Csanád'});
 const west=G.parsePreferences({locations:'Nyugat-Dunántúl régió'});
 assert.deepEqual([...west.counties],['Győr-Moson-Sopron','Vas','Zala']);
 const modern=G.parsePreferences({locations:'Zala vármegye'}),old=G.parsePreferences({locations:'Zala megye'});
 for(const job of [{city:'Zalaegerszeg',county:'Zala megye'},{city:'Keszthely',county:'Zala vármegye'},{city:'Zala megye',county:''},{city:'Nagykanizsa',county:'Zala'}]){
  assert.equal(G.regionMatches(job,{locations:'Zala megye'}).pass,true,JSON.stringify(job));
  assert.equal(G.regionMatches(job,{locations:'Zala vármegye'}).pass,true,JSON.stringify(job));
  assert.equal(G.regionMatches(job,{locations:'Nyugat-Dunántúl régió'}).pass,true,JSON.stringify(job));
 }
 for(const job of [{city:'Szeged',county:'Csongrád-Csanád'},{city:'Szombathely',county:'Vas'}])assert.equal(G.regionMatches(job,{locations:'Zala megye'}).pass,false);
 assert.equal(G.regionMatches({city:'Szeged',county:'Zala megye'},{locations:'Zala megye'}).pass,false,'Contradictory explicit county must not override city');
});
test('Brave broad/role index queries carry both county naming conventions',()=>{
 for(const label of ['Zala megye','Zala vármegye'])for(const mode of ['broad','role']){
  const q=S.indexQuery({locations:label,targetRoles:'Értékesítési vezető',__smartMode:mode},'profession.hu');
  assert.match(q,/"Zala megye"/);assert.match(q,/"Zala vármegye"/);
  assert.ok(q.length<=275);assert.equal((q.match(/\(/g)||[]).length,(q.match(/\)/g)||[]).length);
 }
 const q=S.indexQuery({locations:'Nyugat-Dunántúl régió'},'cvonline.hu');
 for(const c of ['Zala','Vas','Győr-Moson-Sopron']){assert.ok(q.includes(c+' megye'));assert.ok(q.includes(c+' vármegye'));}
});
test('server overlay upgrade runs and preserves discovered count in result snapshots',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'fejvadasz095-'));
 try{
  for(const f of ['apply-v095-server.js','hu-geo.js','smart-discovery.js'])fs.copyFileSync(path.join(SRC,f),path.join(dir,f));
  const job=`'use strict';\nconst SMART = require('./smart-discovery');\nfunction f(s){return {linkCount:s.links.length,links:s.links};}\nfunction g(s){s.links=[]; // No unchecked Brave links in the main results or a separate misleading listing.;}\n`;
  fs.writeFileSync(path.join(dir,'job-search.js'),job);fs.writeFileSync(path.join(dir,'server.js'),"const VERSION='0.9.4';\n");
  const run=()=>spawnSync(process.execPath,[path.join(dir,'apply-v095-server.js')],{encoding:'utf8'});
  const first=run();assert.equal(first.status,0,first.stderr||first.stdout);
  const patch=fs.readFileSync(path.join(dir,'job-search.js'),'utf8');
  assert.match(patch,/s\.linkCountCollected=s\.links\.length/);
  assert.match(patch,/linkCount:\(s\.linkCountCollected\?\?s\.links\.length\)/);
  assert.match(fs.readFileSync(path.join(dir,'server.js'),'utf8'),/0\.9\.5/);
  const second=run();assert.equal(second.status,0,second.stderr||second.stdout);
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
test('Android dropdown includes old and new label for all 19 counties',()=>{
 const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/index.html'),'utf8');
 for(const county of G.COUNTIES.filter(c=>c!=='Budapest')){
  assert.ok(html.includes(`value="${county} megye"`),county+' old');
  assert.ok(html.includes(`value="${county} vármegye"`),county+' new');
 }
});
