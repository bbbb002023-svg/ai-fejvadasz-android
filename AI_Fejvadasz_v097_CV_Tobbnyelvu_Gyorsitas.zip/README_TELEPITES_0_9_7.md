# AI Fejvadász 0.9.7 – CV-alapú készségfeltárás, többnyelvű álláskeresés, gyorsabb AI

**Ez ZIP-frissítőcsomag, nem Android APK.** A 0.9.6-os forrásra épül. Nem törli a korábbi profiladatokat. A meglevő, már jóváhagyott PDF/CV fájlt nem írja felül automatikusan; az újonnan generált CV-tervezetbe a bizonyítható készségek bekerülnek, a keresőprofilba azonnal.

## 0. Miben változik?

- A teljes, kiolvasható CV-ből **tényleges feladatok alapján** készségeket emel ki, és **azonnal beírja a felhasználó álláskeresési profiljába**. A javasolt rokon munkaköröket csak célmunkakörként kezeli, nem állítja, hogy a felhasználó már betöltötte azokat.
- A kinyert képességek megjelennek az újonnan generált CV-tervezetben; a korábban jóváhagyott PDF/CV változatlan marad.
- A magyar kereső mellé **angol és német** munkakörcím-variációkat ad: `Sales Representative`, `Area Sales Manager`, `Regional Sales Manager`, `Außendienstmitarbeiter`, `Gebietsleiter`, stb. Ez a keresőhirdetés felderítési részét bővíti; a tényleges illeszkedést a hirdetés szövegének értelmezése adja.
- A felhasználó által kiválasztott magyar település/vármegye továbbra is kötelező. A hirdetés idegen nyelve **nem bizonyítja**, hogy a munkaadó kötelező idegennyelv-tudást kér; a kifejezett nyelvi elvárásokat viszont külön ellenőrizni kell a CV-ben megadott nyelvtudással.
- A lassú AI-elemzés legfeljebb két párhuzamos, legfeljebb hat állást tartalmazó kéréscsoporttal halad, 25 másodperces kérésenkénti időkorláttal és korlátozott újrapróbálkozással. Az AI-választ nem kapó állások nem kapnak kitalált %-os értékelést.
- A korábbi aktívhirdetés-ellenőrzést nem kerüli meg. A 136 felfedezett linkből kevés hirdetés problémáját a strukturált JobPosting-adatok hiánya továbbra is korlátozhatja. Ez a csomag nem ígéri, hogy minden linket aktivált hirdetésként lehet megjeleníteni.

## 1. GitHub – ZIP feltöltése

1. Töltsd le a `AI_Fejvadasz_v097_CV_Tobbnyelvu_Gyorsitas.zip` fájlt.
2. Nyisd meg: https://github.com/bbbb002023-svg/ai-fejvadasz-android
3. **Add file → Upload files**. A ZIP-et a repository **gyökerébe** töltsd fel, **kibontás nélkül**.
4. **Commit changes**. A régi ZIP-eket ne töröld.

## 2. GitHub – Android APK-építés

Nyisd meg: https://github.com/bbbb002023-svg/ai-fejvadasz-android/blob/main/.github/workflows/build-apk.yml

A **ZIP kibontasa** szakaszban a 0.9.6-os Android-frissítő után adj hozzá pontosan még ezt a két sort:

```bash
          unzip -oq AI_Fejvadasz_v097_CV_Tobbnyelvu_Gyorsitas.zip -d project
          node project/apply-v097-android.js
```

A szakasz utolsó négy sora így nézzen ki (a 0.9.6-nál a felhasználó által feltöltött rövid fájlnév használatos):

```bash
          unzip -oq AI_Fejvadasz_096_Javitas.zip -d project
          node project/apply-v096-android.js
          unzip -oq AI_Fejvadasz_v097_CV_Tobbnyelvu_Gyorsitas.zip -d project
          node project/apply-v097-android.js
```

**Commit changes**, majd **Actions → AI Fejvadasz APK → legújabb futás**. Ha sikeres, az **Artifacts → AI-Fejvadasz-APK** csomagból töltsd le és bontsd ki az `app-debug.apk` fájlt. Az APK-futtatást a GitHub végzi, jelen csomag nem kész APK.

## 3. Render – szerver Build Command

Render: https://dashboard.render.com/ → `ai-fejvadasz-android` → **Settings → Build & Deploy → Build Command**.

A Build Command teljes tartalmát cseréld erre **egyben** (ez minden korábbi frissítést tartalmaz):

```bash
unzip -oq AI_Fejvadasz_AI_Szerver_v0821_Brave_Javitas.zip -d ai-server && unzip -oq AI_Fejvadasz_v090_Alkalmazas_Szerver_Frissites.zip -d ai-server && node ai-server/apply-v09-server.js && unzip -oq AI_Fejvadasz_v091_Teruleti_Duplikatum_AI_Javitas.zip -d ai-server && node ai-server/apply-v091-server.js && sed -i "s/trim();if(!city/trim().replace('főváros','Budapest');if(!city/" ai-server/prepare-hu-geo.js && node ai-server/prepare-hu-geo.js && unzip -oq AI_Fejvadasz_v092_Bovitett_Allasforrasok.zip -d ai-server && node ai-server/apply-v092-server.js && unzip -oq AI_Fejvadasz_v094_Szelesebb_Kereso_Javitas.zip -d ai-server && node ai-server/apply-v094-server.js && sed -i 's/values()].slice(0,220);/values()].slice(0,360);/' ai-server/v09-verify.js && unzip -oq AI_Fejvadasz_v095_Regio_Megye_Cimke_Javitas.zip -d ai-server && node ai-server/apply-v095-server.js && unzip -oq AI_Fejvadasz_096_Javitas.zip -d ai-server && node ai-server/apply-v096-server.js && unzip -oq AI_Fejvadasz_v097_CV_Tobbnyelvu_Gyorsitas.zip -d ai-server && node ai-server/apply-v097-server.js && cd ai-server && npm install --omit=dev
```

**Save Changes** → **Manual Deploy → Deploy latest commit** (ha nem indul automatikusan). A **Start Command** marad: `cd ai-server && npm start`. Az `OPENAI_API_KEY`, `BRAVE_SEARCH_API_KEY` és `AI_APP_ACCESS_TOKEN` kulcsokhoz ne nyúlj.

Ellenőrzés: https://ai-fejvadasz-android.onrender.com/health → `"version":"0.9.7"`.

## 4. Tesztek

A csomagban `test/v097.test.js` és izolált teszt-fixture-ök vannak. A kibontott projekt gyökerében:

```bash
node --test test/v097.test.js
```

**12/12 automatizált teszt sikeres** a fejlesztői környezetben: fiktív értékesítési/vezetői CV, ügyfélszolgálati és pénztárosi CV, tagadások/jogosítvány-hamisítás kiszűrése, rokon munkakörök, kétszeri azonos elemzés, CV-tervezet, Android és szerver-overlay, AI-részeredmény, angol/német keresőtervek.

A tesztek **nem élő OpenAI/Brave/Profession-integrációs tesztek**. Éles ellenőrzéskor fontos: felismerhető-e a CV valamennyi érdemi munkafeladata, megmarad-e a magyarországi helyszínszűrés, és hány **ellenőrzött** hirdetés jut át az eredeti oldal ellenőrzésén. A 0.9.7 nem garantál önmagában adott számú találatot vagy konkrét futási időt.

**Biztonság:** A hirdetési és CV-szöveg adat, nem feldolgozandó utasítás; kitalált végzettség, jogosítvány, munkáltató vagy munkakör nem kerülhet a szakmai múltba. A változtatások nem küldenek álláspályázatot automatikusan.
