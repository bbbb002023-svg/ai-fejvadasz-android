/* AI Fejvadász 0.9.7 – evidence-based transferable skills, local browser module.
 * It infers only occupational capabilities grounded in concrete tasks described by the CV.
 * Suggested roles are SEARCH TARGETS, never claims that the applicant held those jobs.
 */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;if(root)root.CVIntelligence=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').replace(/\s+/g,' ').trim();
const unique=a=>{const seen=new Set();return a.filter(v=>{const k=norm(v);if(!k||seen.has(k))return false;seen.add(k);return true;});};
// Patterns describe PERFORMANCE of a job-related task, not a degree/title/credential.
const RULES=[
 ['értékesítés',/(?:értékesít\w*|eladásokat? (?:végez|kezel|bonyolít)|termékeket? (?:adtam|adtunk) el|sales tevékenység)/iu],
 ['ügyfélkapcsolat-kezelés',/(?:ügyfelekkel? (?:dolgoz|tart|egyeztet|kommunik|foglalkoz)|ügyfélkapcsolat|vevőkkel? (?:foglalkoz|tart|egyeztet)|ügyféligényeket? (?:kezel|felmér)|partnerekkel? (?:kapcsolat|tart|dolgoz|egyeztet|tárgyal))/iu],
 ['tárgyalástechnika',/(?:tárgyal\w*|áralku|megállapodások? (?:kötés|előkészít)|szerződéses? feltételekről egyeztet)/iu],
 ['csapatvezetés',/(?:\d+\s*fős csapat\w* (?:irányít|vezet|szervez)|csapat\w* (?:irányít|vezet|koordinál)|munkatársak (?:irányítás|beosztás)|beosztottak (?:irányítás|vezetés))/iu],
 ['értékesítési terület kezelése',/(?:területi (?:értékesít|képviselő)|értékesítési terület\w* (?:felel|kezel|irányít)|régiós? (?:ügyfele|partnere)k(?:et)? (?:látogat|kezel))/iu],
 ['partnerhálózat-kezelés',/(?:partnerhálózat|új partnerek (?:felkutat|szerz|akvirál)|partnerek (?:gondoz|fejleszt))/iu],
 ['üzletfejlesztés',/(?:üzletfejleszt|új (?:ügyfelek|piacok|partnerek) (?:felkutat|megszerz)|piacbővít)/iu],
 ['készletgazdálkodás',/(?:készlet\w* (?:kezel|nyilvántart|ellenőrz|gazdálkod)|leltár\w* (?:készít|vezet|ellenőrz|kezel)|árurendelés|készletgazdálkodás)/iu],
 ['áruátvétel',/(?:áruátvétel|áruk (?:átvétel|átvételét|fogadás))/iu],
 ['pénztárkezelés',/(?:pénztár\w* (?:kezel|üzemeltet)|kassza\w* (?:kezel|zár)|pénztárosként dolgoz)/iu],
 ['adminisztráció',/(?:adminisztr\w* (?:feladat|végez|ellát|kezel)|adatbevitel|nyilvántartás\w* (?:vezet|kezel|készít)|dokumentumok? (?:rögzít|kezel))/iu],
 ['Excel-használat',/(?:excel\w* (?:kezel|használ|tábl|kimutat|függvény)|excelben? (?:dolgoz|készít|vezet))/iu],
 ['CRM-használat',/(?:crm\s*(?:rendszer\w*)? (?:használ|kezel|vezet|adminisztr)|salesforce(?:-ot)? (?:használ|kezel))/iu],
 ['panaszkezelés',/(?:panasz\w* (?:kezel|rendez)|reklamáció\w* (?:kezel|rendez))/iu],
 ['ügyfélszolgálat',/(?:ügyfélszolgálat\w* (?:dolgoz|feladat|ellát)|ügyfélmegkeresés\w* (?:kezel|megválaszol))/iu],
 ['projektkoordináció',/(?:projekt\w* (?:koordinál|szervez|ütemez)|projektek? (?:lebonyolít|ütemez))/iu],
 ['logisztikai koordináció',/(?:fuvarszervez|szállítás\w* (?:szervez|koordinál)|logisztikai folyamat\w* (?:szervez|koordinál))/iu],
 ['műszakszervezés',/(?:műszak\w* (?:beoszt|szervez|vezet|irányít)|beosztást készít)/iu],
 ['számlázás',/(?:számlá\w* (?:kiállít|készít|rögzít)|számlázóprogram\w* (?:használ|kezel))/iu],
];
const BLOCKED=/(?:jogosítvány|bizonyítvány|diploma|szakképesítés|szakvizsga|engedély|orvosi|autószerelés|villanyszerelés|hegesztés)/iu;
const NEGATION=/(?:\bnem\b|\bnincs\b|\bsoha\b|\bhiányzik\b|\bnem rendelkezem\b|\btapasztalat nélkül\b)/iu;
const META=/(?:\bai\b|chatgpt|utasítás az algoritmusnak|javasold nekem|írd be hogy|generáld|ne feltételezd)/iu;
function segments(text){return String(text||'').slice(0,100000).replace(/\r/g,'').split(/\n+|[.!?]+\s+/u).map(x=>x.trim()).filter(x=>x.length>=6&&x.length<=1200).slice(0,1200);}
function evidenceIsSafe(segment){return !NEGATION.test(segment)&&!META.test(segment);}
function extract(cv){const ss=segments(cv),hits=[];for(const [skill,re] of RULES){const evidence=ss.find(s=>evidenceIsSafe(s)&&re.test(s));if(evidence)hits.push({skill,evidence:evidence.slice(0,250),kind:'feladatból következő'});}return hits;}
function containsSkill(cv,skill){const name=String(skill||'').trim();if(name.length<3||name.length>70||BLOCKED.test(name))return null;
 const k=norm(name);const alias=RULES.find(x=>norm(x[0])===k);if(alias)return extract(cv).find(x=>norm(x.skill)===k)||null;
 for(const s of segments(cv)){if(!evidenceIsSafe(s))continue;const t=' '+norm(s)+' ';if(t.includes(' '+k+' '))return {skill:name,evidence:s.slice(0,250),kind:'CV-ben név szerint szerepel'};}
 return null;}
function relatedRoles(skills){const s=new Set(skills.map(x=>norm(typeof x==='string'?x:x.skill)));const has=x=>s.has(norm(x));const roles=[];const push=(role,need)=>{if(need)roles.push(role);};
 const sales=has('értékesítés'), clients=has('ügyfélkapcsolat-kezelés'), lead=has('csapatvezetés'),partner=has('partnerhálózat-kezelés'),negotiation=has('tárgyalástechnika'),region=has('értékesítési terület kezelése');
 push('Területi képviselő',sales&&clients);
 push('Értékesítési képviselő',sales&&clients);
 push('Területi értékesítési vezető',sales&&lead&&(clients||region));
 push('Területvezető',sales&&lead&&(clients||region));
 push('Értékesítési vezető',sales&&lead);
 push('Key account manager',sales&&clients&&(partner||negotiation));
 push('Üzletfejlesztési munkatárs',sales&&partner);
 push('Ügyfélkapcsolati munkatárs',clients);
 push('Üzletvezető-helyettes',lead&&has('készletgazdálkodás'));
 push('Készletgazdálkodási munkatárs',has('készletgazdálkodás'));
 push('Irodai adminisztrátor',has('adminisztráció'));
 push('Logisztikai koordinátor',has('logisztikai koordináció'));
 push('Ügyfélszolgálati munkatárs',has('ügyfélszolgálat')||has('panaszkezelés'));
 return unique(roles);}
function enrich(profile,cv,{aiSkills=[],aiRoles=[]}={}){const p={...(profile||{}),skills:Array.isArray(profile?.skills)?[...profile.skills]:[]};const derived=extract(cv),seen=new Set(derived.map(x=>norm(x.skill)));
 for(const raw of Array.isArray(aiSkills)?aiSkills:[]){const v=containsSkill(cv,raw);if(v&&!seen.has(norm(v.skill))){derived.push(v);seen.add(norm(v.skill));}}
 const oldSkills=new Set(p.skills.map(norm)),addedSkills=[];for(const item of derived){if(!oldSkills.has(norm(item.skill))&&p.skills.length<60){p.skills.push(item.skill);addedSkills.push(item);oldSkills.add(norm(item.skill));}}
 const actual=relatedRoles([...p.skills]);const possible=new Set(actual.map(norm));for(const role of Array.isArray(aiRoles)?aiRoles:[])if(possible.has(norm(role))&&!actual.some(x=>norm(x)===norm(role)))actual.push(role);
 const targets=String(p.targetRoles||'').split(/[,;\n]+/).map(x=>x.trim()).filter(Boolean),exclude=String(p.excludedRoles||'').split(/[,;\n]+/).map(norm).filter(Boolean),names=new Set(targets.map(norm)),addedRoles=[];
 for(const role of actual){if(targets.length>=10||addedRoles.length>=6)break;const key=norm(role);if(names.has(key)||exclude.some(x=>key===x||key.includes(x)||x.includes(key)))continue;targets.push(role);names.add(key);addedRoles.push(role);}
 p.targetRoles=targets.join(', ');
 return {profile:p,addedSkills,addedRoles,identifiedSkills:derived,availableRoles:actual};}
return {extract,containsSkill,relatedRoles,enrich,norm};
});
