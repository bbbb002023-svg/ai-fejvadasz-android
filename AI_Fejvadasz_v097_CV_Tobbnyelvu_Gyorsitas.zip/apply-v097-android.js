'use strict';
/** 0.9.7: automatically add CV-supported transferable skills & SEARCH-ONLY related roles.
 * Run from the extracted Android project root after all older overlays.
 * Re-runnable; never touches local user data or an approved CV/PDF.
 */
const fs=require('node:fs'),path=require('node:path');
for(const dir of ['app/src/main/assets','pwa']){
 const htmlPath=path.join(__dirname,dir,'index.html');let html=fs.readFileSync(htmlPath,'utf8');
 if(!html.includes('src="cv-intelligence.js"')){
  if(!html.includes('<script src="app.js"></script>'))throw Error(dir+': nem az ismert Android HTML');
  html=html.replace('<script src="app.js"></script>','<script src="cv-intelligence.js"></script><script src="app.js"></script>');
 }
 if(!html.includes('id="aiResumeAutoSummary"')){
  if(!html.includes('<div id="aiResumeReview"'))throw Error(dir+': CV-panel nem található');
  html=html.replace('<div id="aiResumeReview"','<div id="aiResumeAutoSummary" class="tiny muted" style="margin:10px 0" aria-live="polite"></div><div id="aiResumeReview"');
 }
 fs.writeFileSync(htmlPath,html);
 const appPath=path.join(__dirname,dir,'app.js');let app=fs.readFileSync(appPath,'utf8');
 if(!app.includes('AI_FV_CV_AUTO_V097')){
  const anchor=" $('oldCV').value=text.slice(0,42000);";
  if(!app.includes(anchor))throw Error(dir+': a CV-importálás helye eltér');
  app=app.replace(anchor,anchor+"\n // AI_FV_CV_AUTO_V097: local, source-backed skills enter the matching profile immediately.\n aiCvAutoEnrich();");
  const method=`// AI_FV_CV_AUTO_V097: complements OpenAI with verified, task-grounded local analysis.
function aiCvAutoEnrich(hints={}){
 const text=String($('oldCV')?.value||'');
 if(text.length<35||!window.CVIntelligence)return {addedSkills:[],addedRoles:[]};
 const result=window.CVIntelligence.enrich(state.profile,text,hints);
 state.profile=result.profile;
 if(state.resumeMeta){
  const prev=state.resumeMeta.cvAuto||{skills:[],roles:[],evidence:[]};
  state.resumeMeta.cvAuto={
   skills:[...new Set([...prev.skills,...result.addedSkills.map(x=>x.skill)])].slice(0,60),
   roles:[...new Set([...prev.roles,...result.addedRoles])].slice(0,20),
   evidence:[...prev.evidence,...result.addedSkills].slice(-60)
  };
 }
 // The user's approved/exported CV is NEVER replaced or silently re-signed.
 // A fresh CV draft uses the new profile; existing manually edited drafts stay untouched.
 if(!state.cvApproved&&(!state.cvDraft||state.cvDraft===state.resumeMeta?.cvAutoDraft)){state.cvDraft=buildCVText();if(state.resumeMeta)state.resumeMeta.cvAutoDraft=state.cvDraft;}
 fillProfile();persist();renderAll();
 const el=$('aiResumeAutoSummary');if(el&&state.resumeMeta?.cvAuto){
  const data=state.resumeMeta.cvAuto;
  el.textContent='✓ Automatikusan felismert, CV-vel alátámasztott készségek: '+data.skills.join(', ')+(data.roles.length?' | Kapcsolódó keresési munkakörök: '+data.roles.join(', '):'')+'. Az eredeti CV és a korábban jóváhagyott PDF változatlan; a következő CV-generálás felhasználja ezeket. A profilban bármikor módosíthatod.';
 }
 return result;
}
window.aiCvAutoEnrich=aiCvAutoEnrich;
`;
  const expose='window.previewExtractedResume=previewExtractedResume;';
  if(!app.includes(expose))throw Error(dir+': az app.js függvény-exportjai eltérnek');
  app=app.replace(expose,method+'\n'+expose);
 }
 fs.writeFileSync(appPath,app);
 const aiPath=path.join(__dirname,dir,'ai-live.js');let ai=fs.readFileSync(aiPath,'utf8');
 if(!ai.includes('AI_FV_CV_AUTO_V097')){
  const anchor=" if(lastAction==='analyze_resume'){\n latest=r.profile_patch||{};";
  if(!ai.includes(anchor))throw Error(dir+': CV AI-válaszfeldolgozója eltér');
  ai=ai.replace(anchor," if(lastAction==='analyze_resume'){\n // AI_FV_CV_AUTO_V097: auto-import only CV-supported skills/related search roles, not licenses/degrees.\n const auto=window.aiCvAutoEnrich?.({aiSkills:r.profile_patch?.skills||[],aiRoles:r.suggested_roles||[]})||{addedSkills:[],addedRoles:[]};\n html+='<div class=\"banner green\">✓ Ellenőrzött készségek és rokon keresési munkakörök automatikusan mentve a profilba. A képesítések és egyéb személyes adatok továbbra is ellenőrizhetők.</div>';\n latest=r.profile_patch||{};");
  const pattern="LABELS[key]&&(Array.isArray(value)?value.length>0:String(value||'').trim().length>0)";
  if((ai.split(pattern).length-1)!==2)throw Error(dir+': a két jóváhagyási mezőszűrő eltér');
  ai=ai.replaceAll(pattern,"key!=='skills'&&LABELS[key]&&(Array.isArray(value)?value.length>0:String(value||'').trim().length>0)");
  const old="fields.length?'review':'error',fields.length?'✓ Az AI-elemzés elkészült. '+fields.length+' profiladatot találtam. A jóváhagyás után az elemzési panel eltűnik.':'Az AI válaszolt, de nem talált ellenőrizhető mezőt. Ellenőrizd a CV szövegét, vagy próbáld újra.'";
  const newer="fields.length?'review':'approved',fields.length?'✓ Az AI-elemzés elkészült. A készségek és keresési alternatívák automatikusan bekerültek. '+fields.length+' további mezőt ellenőrizhetsz.':'✓ Az AI-elemzés elkészült. A CV-ben alátámasztott készségek és kapcsolódó keresési munkakörök automatikusan bekerültek.'";
  if(!ai.includes(old))throw Error(dir+': CV-státusz szöveg eltér');
  ai=ai.replace(old,newer);
  ai=ai.replace("out.skills=[...document.querySelectorAll('#skills .chip.selected')].map(el=>el.dataset.skill).slice(0,30);","out.skills=[...document.querySelectorAll('#skills .chip.selected')].map(el=>el.dataset.skill).slice(0,60);");
 }
 fs.writeFileSync(aiPath,ai);
}
console.log('0.9.7 Android: automatikus, bizonyíték-alapú CV-készségfeltárás és keresőprofil-bővítés.');
