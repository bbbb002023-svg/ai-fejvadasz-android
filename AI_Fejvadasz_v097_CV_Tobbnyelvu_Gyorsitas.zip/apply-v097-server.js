'use strict';
/** Run after v0.9.6. Only update known server signatures; fail before writing. */
const fs=require('node:fs'),path=require('node:path');
const serverPath=path.join(__dirname,'server.js'),jobPath=path.join(__dirname,'job-search.js');
let server=fs.readFileSync(serverPath,'utf8'),job=fs.readFileSync(jobPath,'utf8');
if(server.includes("VERSION='0.9.7';")&&job.includes('AI_FV_SKILL_PROFILE_V097')&&job.includes('AI_FV_MULTILINGUAL_V097')){console.log('0.9.7 már telepítve');process.exit(0);}
if(!server.includes("VERSION='0.9.6';")||!job.includes('AI_FV_SEMANTIC_V096'))throw Error('A 0.9.6-os szerver szükséges.');
const marker='A CV egészét elemezd jelentés és összefüggés szerint, ne csak kulcsszavak mentén.';
if(!server.includes(marker))throw Error('CV elemző utasításai megváltoztak');
server=server.replace(marker,`A CV teljes szövegéből az összes tényszerű, munkával alátámasztott és átvihető készséget próbáld feltárni. A ténylegesen végzett feladatokból következhet például csapatvezetés, ügyfélkapcsolat-kezelés, tárgyalás, készletgazdálkodás vagy adminisztráció. A profile_patch.skills listába ezek mindegyikét felveheted, ha a CV valamely pontos részlete alátámasztja. A suggested_roles tartalmazzon életszerű rokon munkaköröket is (pl. területi képviselő, területi értékesítési vezető), akár angolul vagy németül közölt munkaköri megnevezések esetén is, de ezeket SOHA NE tekintsd betöltött munkakörnek, csak álláskeresési céloknak. Ne keverj bele képesítést, jogosítványt, hiányzó végzettséget vagy bizonyítatlan vezetői gyakorlatot. A végső alkalmazás minden javasolt készséget a CV tényleges tartalmával is ellenőriz.\n${marker}`);
const first='parsed.profile_patch.skills.slice(0,25)';
if(!server.includes(first))throw Error('Szerver készség-lista korlátja eltér');
server=server.replace(first,'parsed.profile_patch.skills.slice(0,60)');
const roles='parsed.suggested_roles:[]).slice(0,8)';if(!server.includes(roles))throw Error('Rokon munkakör limit eltér');
server=server.replace(roles,'parsed.suggested_roles:[]).slice(0,12)');
server=server.replace("VERSION='0.9.6';","VERSION='0.9.7';");
if(!job.includes('AI_FV_SKILL_PROFILE_V097')){
 const hit='p[k].slice(0,35)';if(!job.includes(hit))throw Error('Kereső profil-skill korlát eltér');
 job=job.replace(hit,'p[k].slice(0,60) /* AI_FV_SKILL_PROFILE_V097 */');
 const retry='maxCalls:48});';if(!job.includes(retry))throw Error('AI feldolgozásának korlátja eltér');
 job=job.replace(retry,`maxCalls:12,onProgress:(done,total)=>{s.progress=81+Math.floor(17*done/Math.max(1,total));s.stage='AI-szövegértelmezés: '+done+'/'+total+' csoport';}});`);
 const timeout='setTimeout(()=>controller.abort(),40000)';if(!job.includes(timeout))throw Error('AI kérés időkorlátja eltér');
 job=job.replace(timeout,'setTimeout(()=>controller.abort(),25000)');
 const lang="u.searchParams.set('search_lang','hu');";
 if(!job.includes(lang))throw Error('A Brave nyelvi szűrője eltér, nem módosítjuk vakon.');
 job=job.replace(lang,"u.searchParams.set('search_lang',typeof profile!=='undefined'&&['en','de'].includes(profile?.__smartPlan?.language)?profile.__smartPlan.language:'hu'); /* AI_FV_MULTILINGUAL_V097 */");
 const marker='// AI_FV_SEMANTIC_V096';
 if(!job.includes(marker))throw Error('A 0.9.6 szemantikus értékelő hiányzik.');
 job=job.replace(marker,`// AI_FV_MULTILINGUAL_V097: Ads may be in Hungarian, English or German. Interpret translated job functions and requirements, not just literal job titles. The language of the posting does NOT prove a mandatory language requirement. Evaluate expressly required language skills against the verified CV profile; never invent proficiency. Hungarian job location remains mandatory.\n ${marker}`);
 const clause="'Az AI Fejvadász álláshirdetés-elemzője vagy. A teljes felhasználói profilt és a hirdetés TÉNYLEGES feladatait értékeld, magyarul.',";
 if(!job.includes(clause))throw Error('Szemantikus AI promptja nem felismerhető');
 job=job.replace(clause,clause+"\n 'Magyar, angol, német és vegyes nyelvű hirdetést egyformán értelmezz; fordítsd le fejben a feladatokat és az elvárásokat. Sales Representative / Außendienstmitarbeiter = területi képviselő jellegű; Area Sales Manager / Gebietsleiter = területi értékesítési vezető jellegű, de mindig a FELADAT döntsön. A hirdetés nyelve önmagában nem kötelező nyelvtudás. Ha az állás kifejezetten nyelvtudást követel, azt a profil tényeihez vesd; ismeretlen nyelvtudást ne feltételezz.',");
}
// No secrets are written to code. Current credentials remain solely in Render ENV.
fs.writeFileSync(serverPath,server,'utf8');fs.writeFileSync(jobPath,job,'utf8');
console.log('AI Fejvadász 0.9.7: CV-készségek, rokon keresési munkakörök, AI időkorlát és feloldás.');
