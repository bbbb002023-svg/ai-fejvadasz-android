'use strict';
/** 0.9.7: parallel bounded AI batches; no artificial scores if the model fails.
 * Underlying single-request timeout is enforced by job-search.js.
 */
const validResult=(batch,result)=>{const ids=new Set(batch.map(j=>String(j.id))),seen=new Set();return (Array.isArray(result)?result:[]).filter(x=>{const id=String(x?.id||'');if(!ids.has(id)||seen.has(id)||!Number.isFinite(x?.score)||x.score<0||x.score>100||typeof x?.reason!=='string'||!x.reason.trim())return false;seen.add(id);return true;});};
async function rankWithRecovery(profile,jobs,{rankFn,key,model,request,onProgress=()=>{},maxCalls=12}={}){
 if(!key||!Array.isArray(jobs)||!jobs.length)return {ranked:[],unranked:jobs?.length||0,calls:0};
 const batches=[];for(let i=0;i<jobs.length;i+=6)batches.push(jobs.slice(i,i+6));
 const results=new Map(),limit=Math.min(maxCalls,12),deadline=Date.now()+85000;
 let next=0,calls=0,completed=0;
 const worker=async()=>{while(next<batches.length&&calls<limit&&Date.now()<deadline){const batch=batches[next++];let returned=[];
   for(let attempt=0;attempt<2&&calls<limit&&Date.now()<deadline;attempt++){
    calls++;
    try{const sub=batch.filter(x=>!results.has(String(x.id)));if(!sub.length)break;
     returned=validResult(sub,await rankFn(profile,sub,{key,model,request}));
     for(const r of returned)results.set(String(r.id),r);
     if(sub.every(x=>results.has(String(x.id))))break;
    }catch(err){if(/\b(?:400|401|402|403)\b/.test(String(err?.message||'')))break;}
   }
   completed++;try{onProgress(completed,batches.length);}catch{}
 }};
 await Promise.all(Array.from({length:Math.min(2,batches.length)},worker));
 return {ranked:[...results.values()],unranked:jobs.length-results.size,calls};
}
module.exports={rankWithRecovery,validResult};
