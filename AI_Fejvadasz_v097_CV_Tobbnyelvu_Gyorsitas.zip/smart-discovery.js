'use strict';
/** 0.9.6: city-first county search, then county fallback; semantic ranking remains downstream.
 * Discovery terms find documents; they DO NOT decide whether a candidate is qualified.
 */
const GEO=require('./hu-geo');
const CITY_BY_COUNTY=Object.freeze({
 'Budapest':['Budapest'],
 'Pest':['Érd','Dunakeszi','Gödöllő','Vác','Szentendre','Cegléd','Budaörs'],
 'Fejér':['Székesfehérvár','Dunaújváros','Mór','Bicske'],
 'Komárom-Esztergom':['Tatabánya','Esztergom','Tata','Komárom','Oroszlány'],
 'Veszprém':['Veszprém','Pápa','Ajka','Várpalota','Balatonfüred'],
 'Győr-Moson-Sopron':['Győr','Sopron','Mosonmagyaróvár','Kapuvár','Csorna'],
 'Vas':['Szombathely','Sárvár','Körmend','Kőszeg','Celldömölk'],
 'Zala':['Zalaegerszeg','Nagykanizsa','Keszthely','Hévíz','Lenti','Zalaszentgrót','Letenye'],
 'Baranya':['Pécs','Komló','Mohács','Szigetvár'],
 'Somogy':['Kaposvár','Siófok','Nagyatád','Marcali'],
 'Tolna':['Szekszárd','Paks','Dombóvár','Bonyhád'],
 'Borsod-Abaúj-Zemplén':['Miskolc','Kazincbarcika','Tiszaújváros','Ózd','Sátoraljaújhely'],
 'Heves':['Eger','Gyöngyös','Hatvan','Heves'],
 'Nógrád':['Salgótarján','Balassagyarmat','Pásztó'],
 'Hajdú-Bihar':['Debrecen','Hajdúböszörmény','Hajdúszoboszló','Berettyóújfalu'],
 'Jász-Nagykun-Szolnok':['Szolnok','Jászberény','Karcag','Törökszentmiklós'],
 'Szabolcs-Szatmár-Bereg':['Nyíregyháza','Kisvárda','Mátészalka','Nyírbátor'],
 'Bács-Kiskun':['Kecskemét','Baja','Kiskunfélegyháza','Kiskunhalas'],
 'Békés':['Békéscsaba','Gyula','Orosháza','Szarvas'],
 'Csongrád-Csanád':['Szeged','Hódmezővásárhely','Szentes','Makó']
});
const clean=x=>String(x??'').replace(/[\r\n\t"'`<>]/g,' ').replace(/[(){}\[\]|\\]/g,' ').replace(/\s+/g,' ').trim();
// Foreign-language titles are used ONLY to discover ads; qualifications and location
// are checked from the original posting, then interpreted by the AI regardless of language.
const MULTILINGUAL_ROLE_FAMILIES=Object.freeze({
 sales_rep: Object.freeze({
  hu:['Területi képviselő','Értékesítési képviselő'],
  en:['Sales Representative','Field Sales Representative','Area Sales Representative','Account Executive'],
  de:['Außendienstmitarbeiter','Vertriebsmitarbeiter Außendienst','Gebietsverkaufsleiter']
 }),
 sales_manager: Object.freeze({
  hu:['Területvezető','Területi értékesítési vezető'],
  en:['Area Sales Manager','Regional Sales Manager','Territory Manager','Regional Manager'],
  de:['Gebietsleiter','Regionalverkaufsleiter','Vertriebsleiter']
 }),
 customer: Object.freeze({
  hu:['Ügyfélkapcsolati munkatárs'],
  en:['Customer Success Specialist','Account Manager'],
  de:['Kundenbetreuer','Account Manager']
 })
});
function roleFamilies(profile){
 const text=GEO.norm([profile?.targetRoles,profile?.pastRoles,(Array.isArray(profile?.skills)?profile.skills:[]).join(' ')].join(' '));
 const found=[];
 // Explicit responsibilities and skill evidence influence retrieval, not suitability.
 if(/ertekesit|sales|teruleti kepvisel|uzletfejleszt|targyal|crm|partnerhalozat|vertrieb|aussendienst/.test(text))found.push('sales_rep');
 if(/vezet|iranyit|manager|management|teamlead|gebietsleiter|regionalverkaufsleiter/.test(text)&&/ertekesit|sales|terulet|csapat|vertrieb|vezet/.test(text))found.push('sales_manager');
 if(/ugyfelkapcsolat|ugyfelszolgalat|account|customer|kundenbetreu/.test(text))found.push('customer');
 return found;
}
function foreignRolePlans(profile){
 const families=roleFamilies(profile);if(!families.length)return [];
 return ['en','de'].map(language=>({kind:'foreign',language,
  roles:unique(families.flatMap(f=>MULTILINGUAL_ROLE_FAMILIES[f][language].slice(0,2))).slice(0,4)}));
}
function titleEquivalents(title){
 const normalized=GEO.norm(title),matching=[];
 for(const [family,langs] of Object.entries(MULTILINGUAL_ROLE_FAMILIES)){
  if(Object.values(langs).flat().some(word=>normalized.includes(GEO.norm(word))))matching.push(family);
 }
 return matching;
}

const unique=xs=>{const seen=new Set();return xs.filter(x=>{const key=GEO.norm(x);if(!key||seen.has(key))return false;seen.add(key);return true;});};
function roles(p){return unique([p?.targetRoles,p?.pastRoles].flatMap(v=>String(v||'').split(/[,;\n]+/)).map(clean).filter(x=>x.length>=3)).slice(0,3).map(x=>x.slice(0,55));}
function localities(p){
 const pref=GEO.parsePreferences(p||{}),explicit=[...pref.cities],counties=[...pref.counties];
 const cities=[...explicit];
 // Round-robin: a multi-county region doesn't silently give all places to its first county.
 for(let i=0;i<7;i++)for(const county of counties){const city=CITY_BY_COUNTY[county]?.[i];if(city)cities.push(city);}
 return unique(cities).slice(0,40);
}
function countyTerms(county){return county==='Budapest'?['Budapest']:[county+' vármegye',county+' megye'];}
function placesQuery(places){return places.length===1?'"'+places[0]+'"':'('+places.map(x=>'"'+x+'"').join(' OR ')+')';}
function queryForPlan(plan,domain){
 const src=String(domain||'').toLowerCase();if(!/^(?:[a-z0-9-]+\.)+[a-z]{2,20}$/.test(src))throw Error('Nem biztonságos forrásdomain');
 const terms=unique(plan.places.map(x=>clean(x).slice(0,65))).filter(Boolean);
 if(!terms.length)terms.push('Magyarország');
 const loc=placesQuery(terms);
 const role=(plan.kind==='role'||plan.kind==='foreign')&&plan.roles?.length?placesQuery(plan.roles.slice(0,plan.kind==='foreign'?4:2).map(x=>clean(x).slice(0,50))):'állás';
 return ('site:'+src+' '+loc+' '+role).slice(0,385);
}
function buildSearchPlans(profile,{limit=8}={}){
 const p=profile||{},prefs=GEO.parsePreferences(p),counties=[...prefs.counties],cities=localities(p),r=roles(p);
 const cap=Math.max(1,Math.min(12,Math.floor(Number(limit)||8)));
 const foreign=foreignRolePlans(p);
 const countyGroups=[];
 // One grouped fallback query per one/two counties: both megye/vármegye spellings.
 for(let i=0;i<counties.length;i+=2){countyGroups.push({kind:'county',places:counties.slice(i,i+2).flatMap(countyTerms)});}
 const reserveCounties=Math.min(cap,countyGroups.length),reserveForeign=Math.min(foreign.length,Math.max(0,cap-reserveCounties-2)),reserveRole=r.length&&cap>reserveCounties+reserveForeign+1?1:0;
 const cityBudget=Math.max(0,cap-reserveCounties-reserveRole-reserveForeign);
 const cityPlans=[];for(let i=0;i<cities.length&&cityPlans.length<cityBudget;i+=2)cityPlans.push({kind:'city',places:cities.slice(i,i+2)});
 const plans=[...cityPlans,...countyGroups.slice(0,cap-cityPlans.length)];
 if(r.length&&plans.length<cap-reserveForeign){plans.push({kind:'role',places:cities.slice(0,2).length?cities.slice(0,2):counties.slice(0,1).flatMap(countyTerms),roles:r});}
 for(const variant of foreign.slice(0,reserveForeign))if(plans.length<cap)plans.push({...variant,places:cities.slice(0,2).length?cities.slice(0,2):counties.slice(0,1).flatMap(countyTerms)});
 if(!plans.length)plans.push({kind:'city',places:['Magyarország']});
 return plans.slice(0,cap);
}
// Backward-compatible query API. Multi-pass searches use __smartPlan instead.
function indexQuery(p,domain){
 if(p?.__smartPlan)return queryForPlan(p.__smartPlan,domain);
 const county=[...GEO.parsePreferences(p||{}).counties].flatMap(countyTerms),cities=localities(p).slice(0,3);
 const terms=[];for(const v of unique([...county,...cities])){
  if(queryForPlan({kind:'city',places:[...terms,v]},domain).length<=275)terms.push(v);
 }
 const r=roles(p),roleMode=p?.__smartMode==='role';
 return queryForPlan({kind:roleMode?'role':'city',places:terms.length?terms:['Magyarország'],roles:r},domain);
}
function queryCount(env={}){const n=Number(String(env.JOB_SMART_QUERIES_PER_SOURCE??'8').trim());return Number.isInteger(n)&&n>=1&&n<=12?n:8;}
async function fetchExpandedLinks({key,src,profile,fetchIndexedLinks,request,queryCount:count=8}){
 if(typeof fetchIndexedLinks!=='function')throw Error('Indexkereső nem elérhető');
 const all=[],seen=new Set();let succeeded=0,lastError;
 for(const plan of buildSearchPlans(profile,{limit:count})){
  try{
   const batch=await fetchIndexedLinks(key,src,{...profile,__smartPlan:plan},request);
   succeeded++;
   for(const link of Array.isArray(batch)?batch:[]){if(!link?.url||seen.has(link.url))continue;seen.add(link.url);all.push(link);}
  }catch(err){lastError=err;if(/\b(?:401|403|402|429)\b/.test(String(err?.message||'')))break;}
 }
 if(!succeeded&&lastError)throw lastError;
 return all;
}
function notHardExcluded(job){
 const hard=/kifejezetten kizartad|hianyzo kotelezo igazolas|kotelezo jogositvany|nem igazolt a megkovetelt vegzettseg|vegzettseg nem eri el/;
 return !(job?.fit?.blockers||[]).some(x=>hard.test(GEO.norm(x)));
}
function locationsOf(job,parseOne){
 if(typeof parseOne!=='function')throw Error('Hiányzó JobPosting helyszínolvasó');
 const list=Array.isArray(job?.jobLocation)?job.jobLocation:[job?.jobLocation];
 return list.filter(Boolean).map(location=>parseOne({...job,jobLocation:location})).filter(x=>x.city||x.county);
}
function rejectionSummary(list){const summary={unavailable:0,missingEvidence:0,regionOrDate:0,other:0};
 for(const item of Array.isArray(list)?list:[]){const t=GEO.norm(item?.reason||'');
  if(/nem erheto el|nem vizsgalhato/.test(t))summary.unavailable++;
  else if(/nincs hiteles jobposting/.test(t))summary.missingEvidence++;
  else if(/datum|regio|munkaltato|leiras/.test(t))summary.regionOrDate++;
  else summary.other++;
 }return summary;
}
module.exports={CITY_BY_COUNTY,MULTILINGUAL_ROLE_FAMILIES,roleFamilies,foreignRolePlans,titleEquivalents,localities,roles,indexQuery,queryForPlan,buildSearchPlans,queryCount,fetchExpandedLinks,notHardExcluded,locationsOf,rejectionSummary};
