# AI Fejvadász 1.0.1 – Android / országos kereső összekötése

**Ez forráskód-frissítő ZIP, nem telepíthető APK.** A GitHub Actions állítja elő az APK-t az eredeti Android-projektből. Az 1.0.1-es app csak a régi AI-szerver 1.0.1-es hídjával együtt tudja az új országos adatokat lekérni.

## Működés

- A 0.9.7-es Android-app az ismert AI-szerverén (`ai-fejvadasz-android.onrender.com`) keresztül keres tovább, és megtartja a meglévő Android Keystore kapcsolatot.
- A régi AI-szerver új `national-bridge.js` modullal, szerveroldali Bearer tokennel kér ajánlásokat a külön nemzeti API-tól (`ai-fejvadasz-national-api.onrender.com`). Token nem kerül az APK-ba, webes JS-be vagy URL-be.
- A két külön CV-portálkereső kizárólag a Brave Search indexén keresztül keresi a Profession és a CVonline eredményeit; csak kifejezett hozzájárulással. A teljes CV-t, nevet és elérhetőséget nem továbbítja.
- A portálos indexeredményeket és a saját nemzeti index linkjeit **NEM ellenőrzött előtalálatként**, elkülönített, összecsukható listában mutatja. Soha nem emeli át automatikusan az ellenőrzött, friss állások közé.
- A Profession és a CVonline felé közvetlen automatizált scrapinget nem végez; a felhasználó a portál eredeti linkjét is megnyithatja.
- Az országos index jelenlegi adatai és az eredeti álláshirdetések aktivitása továbbra is külön ellenőrzést igényel. A 4 önálló AI modell közül az optimizer aktív; három modellel még nincs kész az ellenőrzött tanítás.

## A) GitHub – APK újraépítése

1. Töltsd fel ezt a ZIP-et a GitHub-repo gyökerébe, **kibontás nélkül**.
2. A `.github/workflows/build-apk.yml` `ZIP kibontasa` blokkjába, **a v097 patch után** tedd be:

   ```bash
   unzip -oq AI_Fejvadasz_v101_Android_National_Bridge.zip -d project
   node project/apply-v101-android.js
   ```

3. GitHub **Actions → AI Fejvadasz APK → legújabb sikeres futás → Artifacts → AI-Fejvadasz-APK** → csomagban `app-debug.apk`.
4. Eredeti Android app package ID és aláírás maradjon változatlan; különben Android nem frissíti a telepített verziót adatvesztés nélkül. A debug APK csak a már meglévő debug APK-val azonos kulcs esetén frissíthet adatvesztés nélkül. Ne távolítsd el a meglévő appot biztonsági mentés nélkül.

## B) Régi Android AI-szerver – szerveroldali híd

Render szolgáltatás: `ai-fejvadasz-android` (`srv-dbov950u01pc738gpfrg`).

A jelenlegi Build Command **végére** illeszd a következő kiegészítést:

```bash
&& cd .. && unzip -oq AI_Fejvadasz_v101_Android_National_Bridge.zip -d ai-server && node ai-server/apply-v101-legacy-server.js
```

A `Start Command` marad `cd ai-server && npm start`.

A régi Android szerver Environment menüjében adj hozzá `NATIONAL_API_TOKEN` nevű változót a **nemzeti API azonos nevű változójával azonos értékkel**. Más meglévő környezeti változót nem szabad törölni vagy felülírni. A titkos kulcsot ne küldd chaten és ne fotózd le.

A nemzeti API-n `BRAVE_SEARCH_API_KEY` szükséges a két külső CV-portál indexkereséséhez. A meglévő API-kulcsot **nem** kell az Android appba beírni. A Brave kérések kvótába és esetleg díjba számítanak.

## C) Tesztelés

A kicsomagolt ZIP gyökeréből: `node --test test/v101.test.js`.
A tesztek szimulált API-válaszokkal ellenőrzik, hogy nincs CV-adatszivárgás, nincs kliensoldali API token, van portál-engedélyezés, a linkek ellenőrizetlenként jelennek meg és az Android patch ismételt futtatása biztonságos.

A teljes lánc éles ellenőrzéséhez: a nemzeti API rendelkezésre áll, a régi AI-szerver sikeresen bejelentkezik hozzá, a két Brave-portálkereső válaszol, és az Android-app a három, elkülönített előtalálati csoportot megjeleníti. **Ez az éles végponttól telefonig tartó teszt még nincs elvégezve.**

## Biztonsági korlát

A Google portálon belüli webes keresés megnyitása a felhasználó saját gombnyomására történik. A felhasználó által korábban mentett CV/profil nem cserélődik le és nem kerül bele a letöltött ZIP-be. Csak forráskódot és tesztfixture-öket tartalmaz. A végső álláshirdetés aktualitásáért a külső portál felel; az indexelőtalálatok nem jelentkezési garanciák.
