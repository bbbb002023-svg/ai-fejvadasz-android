/* AI_FV_APP_NATIONAL_V101: explicit, profile-only portal search controls.
 * This JS never holds a server API key, CV document or contact details.
 */
(function(){'use strict';
 const KEY='ai_fv_external_portals_consent_v101';
 const BOARDS={profession:{domain:'profession.hu',name:'Profession.hu'},cvonline:{domain:'cvonline.hu',name:'CVonline.hu'}};
 function consent(){try{return localStorage.getItem(KEY)==='yes'}catch{return false}}
 function setConsent(yes){try{if(yes)localStorage.setItem(KEY,'yes');else localStorage.removeItem(KEY)}catch{}}
 function split(x,max=3){const a=Array.isArray(x)?x:String(x||'').split(/[,;\n]+/);return a.map(y=>String(y||'').trim().slice(0,60)).filter(y=>y.length>=2&&!/@|\d{6,}/.test(y)).slice(0,max)}
 function query(board,profile){const b=BOARDS[board];if(!b)return null;
  const titles=split(profile?.targetRoles||profile?.pastRoles,2);const skills=split(profile?.skills,2),places=split(profile?.locations||profile?.city,2);
  if(!titles.length&&!skills.length)return null;
  const q=['site:'+b.domain,...titles,...skills,...places,'állás'].join(' ');
  return 'https://www.google.com/search?q='+encodeURIComponent(q)+'&hl=hu';
 }
 function search(board){const p=window.getSearchProfile?.()||{},url=query(board,p);
  if(!url){window.alert('Először állíts be keresett munkakört vagy készséget a profilodban.');return;}
  const a=document.createElement('a');a.href=url;a.target='_blank';a.rel='noopener noreferrer';a.style.display='none';document.body.appendChild(a);a.click();a.remove();
 }
 function sync(){const box=document.getElementById('aiExternalPortalConsent');if(box)box.checked=consent()}
 window.aiPortalConsent=consent;window.aiPortalConsentChanged=flag=>{setConsent(Boolean(flag));sync()};
 window.aiPortalOpen=search;window.aiPortalBuildQuery=query;
 window.addEventListener('DOMContentLoaded',sync);
})();
