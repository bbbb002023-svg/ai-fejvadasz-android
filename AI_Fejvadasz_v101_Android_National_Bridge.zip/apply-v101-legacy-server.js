'use strict';
/** Non-destructive overlay for the legacy v0.9.7 search service. Separate
 * protected national API requests happen at the server; no token in APK.
 * All new links are placed in the NOT-VERIFIED research list, never in the
 * verified job-card array. Fail closed if original code signatures changed.
 */
const fs=require('node:fs'),path=require('node:path');
const root=__dirname,sp=path.join(root,'server.js'),jp=path.join(root,'job-search.js'),bridge=path.join(root,'national-bridge.js');
if(!fs.existsSync(sp)||!fs.existsSync(jp)||!fs.existsSync(bridge))throw Error('Hiányzik a 0.9.7-es szerverkód vagy a national-bridge.js');
let s=fs.readFileSync(sp,'utf8'),j=fs.readFileSync(jp,'utf8');
if(j.includes('AI_FV_NATIONAL_BRIDGE_V101')){console.log('v1.0.1 szerverhíd már telepítve');process.exit(0)}
if(!s.includes("VERSION='0.9.7';")||!j.includes('AI_FV_MULTILINGUAL_V097'))throw Error('Előbb a régi Android szerveren v0.9.7 szükséges.');
function exactly(text,needle,label){const n=text.split(needle).length-1;if(n!==1)throw Error('A forráskód megváltozott ('+label+'): '+n)}
const anchor="const E = require('./engine');";
exactly(j,anchor,'motor import');j=j.replace(anchor,anchor+"\nconst NATIONAL = require('./national-bridge'); // AI_FV_NATIONAL_BRIDGE_V101");
const searchPoint='s.rejectedCount=checkedJobs.rejected.length;';
exactly(j,searchPoint,'ellenőrzési pont');
// A failure of the new bridge may NOT bring down legacy search.
const include=`// AI_FV_NATIONAL_BRIDGE_V101: read-only search links; never elevate to verified jobs.
     try{
       const extra=await NATIONAL.expand(p,{env,request:fetchImpl});
       if(extra.links.length&&Array.isArray(s.links)){
         const already=new Set(s.links.map(j=>String(j.url||'')));
         for(const item of extra.links){if(!already.has(item.url)){s.links.push(item);already.add(item.url)}}
         s.linkCount=s.links.length;
       }
       if(extra.nationalStatus==='ok'){
         s.indexConnected=true;
         if(Array.isArray(s.sourceNames))s.sourceNames.push('Saját országos AI-állásindex');
       }
       if(extra.portalsStatus==='searched'||extra.portalsStatus==='partial'){
         if(Array.isArray(s.sourceNames))s.sourceNames.push('Két CV-portál indexkereső');
       }
       s.nationalBridge={nationalStatus:extra.nationalStatus,cvPortalsStatus:extra.portalsStatus,unverifiedOnly:true};
     }catch(err){
       s.nationalBridge={status:'failed',unverifiedOnly:true};
       console.warn('national-bridge unavailable:',String(err?.message||err).slice(0,110));
     }
`;
j=j.replace(searchPoint,searchPoint+'\n     '+include);
s=s.replace("VERSION='0.9.7';","VERSION='1.0.1';");
// Syntax-test ALL mutations before touching disk.
new Function('require','module','exports',s);new Function('require','module','exports',j);
fs.writeFileSync(sp,s,'utf8');fs.writeFileSync(jp,j,'utf8');
console.log('v1.0.1 old-server bridge installed: protected national index + optional opt-in CV portal links.');
