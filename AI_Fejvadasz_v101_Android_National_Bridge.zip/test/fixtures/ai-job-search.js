/* AI Fejvadász 0.7.1 – szerveroldali saját álláskeresés mobilos vezérlője.
 * Az API titkos hozzáférési kódja NEM érhető el JS-ből; csak az Android Keystore-ban él.
 */
(function(){'use strict';
const IDKEY='ai_fejvadasz_job_search_id_v07';
const $=id=>document.getElementById(id);
let current='',pollTimer=null,awaiting=false,lastLinks=[];
function status(message,percentage,details){
 const s=$('aiJobSearchText'),p=$('aiJobSearchPercent'),bar=$('aiJobProgress'),fill=$('aiJobProgressFill'),info=$('aiJobSearchDetails');
 if(s)s.textContent=message;if(p)p.textContent=Math.max(0,Math.min(100,percentage||0))+'%';
 if(fill)fill.style.width=Math.max(0,Math.min(100,percentage||0))+'%';
 if(bar)bar.setAttribute('aria-valuenow',String(percentage||0));if(info&&details)info.textContent=details;
}
function showDiscovered(links){
 const root=$('aiJobLinkResults');if(!root)return;
 root.replaceChildren();root.classList.add('hide');
 // Brave discovery links may be expired. Only the server-verified, dated listings
 // may enter the primary job view. No more unverified direct links.
}

function configured(){try{return Boolean(JSON.parse(window.AndroidApp?.getAiConnection?.()||'{}').configured);}catch{return false;}}
function schedule(){clearTimeout(pollTimer);if(current)pollTimer=setTimeout(poll,2600);}
function poll(){if(!current||awaiting)return;awaiting=true;window.AndroidApp?.pollJobSearch?.(JSON.stringify({requestId:'poll_'+Date.now(),searchId:current}));}
function start(automatic){
 if(!window.AndroidApp?.startJobSearch){if(!automatic)status('Az automatikus élő keresés az Android 0.7-es verziójában érhető el.',0);return;}
 if(!configured()){status('Először állítsd be a külön AI-szerver hozzáférést.',0,'A keresés a CV véglegesítése után automatikus; nincs minden keresés előtt új jóváhagyás.');return;}
 const profile=window.getSearchProfile?.();if(!String(profile?.locations||'').trim()){status('Először add meg a keresési régiódat a Profil oldalon.',0,'Az elfogadott települések vagy vármegyék kötelezőek, a lakcím önmagában nem elegendő.');return;}if(!profile?.targetRoles&&!profile?.pastRoles&&!profile?.skills?.length){status('Még nincs elegendő szakmai adat a kereséshez.',0);return;}
 current='';clearTimeout(pollTimer);awaiting=true;
 status('A saját AI keresőmotor elindítása…',1,'Először a régiót, majd a hirdetések dátumát és az eredeti oldalt ellenőrizzük.');
 window.AndroidApp.startJobSearch(JSON.stringify({requestId:'start_'+Date.now(),profile}));
}
function refresh(){showDiscovered(lastLinks);if(!current){try{current=localStorage.getItem(IDKEY)||'';}catch{}}
 if(current&&window.AndroidApp?.pollJobSearch&&!awaiting)poll();}
function receive(x){awaiting=false;
 if(!x||!x.ok){
   const msg=String(x?.error||'Nem sikerült lekérni a keresés állapotát.');
   status('Keresési hiba: '+msg,0,'A következő próbálkozás előtt ellenőrizd a Render-szerver elérhetőségét.');
   if(/nem található|újraindulhatott/.test(msg)){current='';try{localStorage.removeItem(IDKEY);}catch{}}return;
 }
 const s=x.search||{};if(!s.id)return;
 current=s.id;try{localStorage.setItem(IDKEY,current);}catch{}
 const progress=Number(s.progress)||0,errors=Array.isArray(s.errors)?s.errors:[];
 const portal=[s.portalConnected?'Jooble.hu adatkapcsolat bekötve':null,s.indexConnected?'Webes linkfelderítés bekötve':null].filter(Boolean).join(' + ')||'⚠ Nincs bekötött adatforrás';
 const sources=Array.isArray(s.sourceNames)?s.sourceNames.join(', '):'';
 const details=`${portal} · ${s.checked||0}/${s.sourceCount||0} forrás · ${s.found||0} strukturált hirdetés · ${s.linkCount||0} felfedezett link · ${sources||'nincs adatforrás'}${errors.length?' · '+errors.join(' / ').slice(0,280):''}`;
 if(s.status==='running'){
   status('✦ '+(s.stage||'Az AI a hirdetéseket elemzi'),progress,details);schedule();
 }else if(s.status==='done'){
   const jobs=Array.isArray(s.jobs)?s.jobs:[];
   const links=Array.isArray(s.links)?s.links:[];lastLinks=links.slice(0,35);showDiscovered(lastLinks);
   window.ingestLiveJobSearch?.(jobs);
   const jobList=$('jobList'),page=$('jobs');
   if(jobList&&page){const head=page.querySelector('.pagehead'),section=jobList.previousElementSibling;if(head){if(section?.classList?.contains('sectionline'))head.after(section,jobList);else head.after(jobList);}}
   if(jobList&&jobs.length&&document.getElementById('jobs')?.classList.contains('active'))jobList.scrollIntoView({behavior:'smooth',block:'start'});
   const ai=jobs.some(j=>j.aiAnalyzed);
   status(s.sourceCount===0?'⚠ Nincs bekötött keresési forrás.':jobs.length?`✓ Ellenőrzés kész: ${jobs.length} friss, dátumozott állás. Az ajánlottak felül.`:'Nincs igazolhatóan friss állás a kiválasztott régióban. Ellenőrizetlen linkeket nem mutatunk.',100,
     details+(ai?' · AI-szövegértelmezés elkészült.':' · A modell nem volt elérhető minden találatnál; szabályalapú pontozás.'));
   // Ne navigáljunk újra: a go('jobs') ablakgörgetést nulláz, így használhatatlan volt az állásmonitor.
   current='';try{localStorage.removeItem(IDKEY);}catch{}
 }else{
   status('A keresés megszakadt vagy hibára futott.',progress,errors.join(' · ')||'Ellenőrizd a keresési forrásokat.');
   current='';try{localStorage.removeItem(IDKEY);}catch{}
 }
}
window.aiJobSearchStart=start;window.aiJobSearchRefresh=refresh;window.receiveJobSearch=receive;
window.addEventListener('DOMContentLoaded',()=>{setTimeout(refresh,600);});
})();
