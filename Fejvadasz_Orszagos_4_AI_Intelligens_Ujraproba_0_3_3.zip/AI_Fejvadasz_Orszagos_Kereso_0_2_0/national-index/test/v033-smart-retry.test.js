'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const D=require('../src/db'),C=require('../src/collector');
const source={source_key:'lever:tsmg',engine:'lever',enabled:true,approved:true,board:'tsmg',location_filters:['Budapest'],company:'TSMG',country_scope:'mixed',consecutive_failures:0};
const content=jobs=>({ok:true,status:200,headers:{get:()=>null},text:async()=>JSON.stringify(jobs)});
function fakePool({selected=source,manualAllowed=true,fetchFailure=false}={}){
 const queries=[],connection={query:async sql=>{queries.push(sql);if(sql.includes('pg_try_advisory_lock'))return {rows:[{acquired:true}]};return {rows:[],rowCount:1}},release(){queries.push('RELEASE')}};
 const pool={queries,connect:async()=>connection,query:async(sql,values)=>{queries.push([sql,values]);
  if(sql.includes('INSERT INTO national_runs DEFAULT'))return {rows:[{run_id:42}]};
  if(sql.includes('UPDATE national_sources SET last_manual_retry_at'))return {rows:manualAllowed?[selected]:[]};
  if(sql.includes('SELECT * FROM national_sources'))return {rows:[selected]};
  return {rows:[],rowCount:1};}};
 const fetchImpl=async url=>fetchFailure?Promise.reject(new Error('This operation was aborted')):content([{id:'test-budapest',text:'Driver',hostedUrl:'https://jobs.lever.co/tsmg/test-budapest',categories:{location:'Budapest'},descriptionPlain:'Budapest'}]);
 return {pool,fetchImpl};
}
test('schema v7 safely adds retry state without erasing any previous jobs',async()=>{
 const seen=[];await D.migrate({query:async sql=>seen.push(sql)});
 assert.equal(seen.length,7);assert.match(seen[6],/IF NOT EXISTS consecutive_failures/);
 assert.match(seen[6],/IF NOT EXISTS last_manual_retry_at/);
 assert.doesNotMatch(seen[6],/DELETE FROM|DROP TABLE|TRUNCATE/i);
});
test('timeout retry delay starts at 5 minutes and grows, capped at 60',()=>{
 assert.deepEqual([0,1,2,3,4,10].map(i=>D.retryDelayMinutes(new Error('This operation was aborted'),i)),[5,10,20,40,60,60]);
});
test('general errors back off 10..120 minutes; HTTP denial/rate-limit are never expedited',()=>{
 assert.deepEqual([0,1,3,9].map(i=>D.retryDelayMinutes('HTTP 500 unexpected',i)),[10,20,80,120]);
 assert.equal(D.retryDelayMinutes('Source HTTP 429',0),120);
 assert.equal(D.retryDelayMinutes('Source HTTP 403',0),240);
 assert.equal(D.retryDelayMinutes('Source HTTP 401',0),240);
 assert.equal(D.retryDelayMinutes('Source HTTP 429',8),120);
});
test('failure stores computed new due, increments consecutive counter, and does not claim success',async()=>{
 const calls=[];const pool={query:async(...x)=>calls.push(x)};
 const x=await D.sourceFailure(pool,source,new Error('This operation was aborted'));
 assert.equal(x.cooldownMinutes,5);assert.equal(calls[0][1][2],5);
 assert.match(calls[0][0],/consecutive_failures=consecutive_failures\+1/);
 assert.match(calls[0][0],/next_due_at=NOW\(\)/);
});
test('after successful snapshot consecutive failure count is reset',async()=>{
 const sql=[];const pool={connect:async()=>({query:async(q)=>{sql.push(q);return {rows:[],rowCount:1}},release(){}})};
 await D.upsertSnapshot(pool,source,[],{complete:false});
 assert.ok(sql.some(s=>s.includes('consecutive_failures=0')));
});
test('legacy 60-minute failure gets bounded one-time exception; not authorization or rate limit',async()=>{
 const calls=[];await D.dueSources({query:async(q)=>{calls.push(q);return {rows:[]}}});
 assert.match(calls[0],/consecutive_failures=0 AND last_error IS NOT NULL/);
 assert.match(calls[0],/last_checked_at<=NOW\(\)-INTERVAL '5 minutes'/);
 assert.match(calls[0],/401\|403\|429/);
 assert.match(calls[0],/enabled=true AND approved=true AND engine<>'registry'/);
});
test('manual retry validates source key, does not accept arbitrary SQL fragments',async()=>{
 const pool={query:async()=>{throw Error('DB must not be hit')}};
 for(const key of ['','lever:tsmg OR 1=1','https://example.org','registry:foo;DELETE','lever:x\n'])
  await assert.rejects(()=>D.selectManualRetrySource(pool,key),/Invalid source key/);
});
test('manual retry is a parameterized, atomic update with a 2-minute burst guard',async()=>{
 const calls=[];const pool={query:async(...args)=>{calls.push(args);return {rows:[source]}}};
 const r=await D.selectManualRetrySource(pool,'lever:tsmg');assert.equal(r.source_key,'lever:tsmg');
 assert.deepEqual(calls[0][1],['lever:tsmg']);
 assert.match(calls[0][0],/last_manual_retry_at<=NOW\(\)-INTERVAL '2 minutes'/);
 assert.match(calls[0][0],/last_checked_at<=NOW\(\)-INTERVAL '60 seconds'/);
 assert.match(calls[0][0],/enabled=true AND approved=true AND engine<>'registry'/);
 assert.match(calls[0][0],/401\|403\|429/);
});
test('manual retry only reads one selected source, keeping normal due queue untouched',async()=>{
 const {pool,fetchImpl}=fakePool();const result=await C.runOnce(pool,{manualSourceKey:'lever:tsmg',fetchImpl});
 assert.equal(result.mode,'manual_single_source');assert.equal(result.sources,1);
 assert.equal(result.succeeded,1);assert.equal(result.hungaryJobs,1);
 assert.ok(pool.queries.some(x=>Array.isArray(x)&&x[0].includes('last_manual_retry_at')));
 assert.ok(!pool.queries.some(x=>Array.isArray(x)&&x[0].includes('SELECT * FROM national_sources')));
});
test('manual retry rejection does not create empty run or contact ATS',async()=>{
 const {pool}=fakePool({manualAllowed:false});let calls=0;
 const result=await C.runOnce(pool,{manualSourceKey:'lever:tsmg',fetchImpl:async()=>{calls++;throw Error('network')}});
 assert.equal(result.skipped,true);assert.equal(calls,0);
 assert.ok(!pool.queries.some(x=>Array.isArray(x)&&x[0].includes('INSERT INTO national_runs')));
});
test('manual timeout records failed source and short retry window, does not lose advisory lock',async()=>{
 const {pool,fetchImpl}=fakePool({fetchFailure:true});const result=await C.runOnce(pool,{manualSourceKey:'lever:tsmg',fetchImpl});
 assert.equal(result.failed,1);assert.equal(result.errors[0].retryAfterMinutes,5);
 assert.ok(pool.queries.includes('RELEASE'));
});
test('normal scheduler still uses due queue, not the forced-source lookup',async()=>{
 const {pool,fetchImpl}=fakePool();const result=await C.runOnce(pool,{fetchImpl});
 assert.equal(result.mode,'scheduled');assert.equal(result.sources,1);
 assert.ok(!pool.queries.some(x=>Array.isArray(x)&&x[0].includes('last_manual_retry_at')));
});
test('package includes real CLI retry command and cannot change normal cron script',()=>{
 const pkg=require('../package.json');assert.match(pkg.scripts['collect:retry'],/collect-retry/);
 assert.match(pkg.scripts.collect, /node src\/cli.js collect$/);
 assert.equal(pkg.version,'0.3.3');
});
