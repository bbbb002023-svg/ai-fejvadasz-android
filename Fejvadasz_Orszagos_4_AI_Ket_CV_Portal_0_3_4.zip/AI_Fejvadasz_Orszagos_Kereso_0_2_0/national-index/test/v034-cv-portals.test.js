'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const CV=require('../src/cv-portals'),{createApi}=require('../src/api');
const profile={targetRoles:'Területi képviselő, Értékesítési képviselő',skills:['CRM','B2B','Excel'],locations:'Zalaegerszeg',excludedRoles:'Értékesítési vezető',name:'TESZT KERESZTNÉV',email:'personal@example.com',phone:'+361000000'};
const consent={externalSearchConsent:true,profile};
const records={
 profession:[
  {title:'Területi képviselő – Zalaegerszeg CRM B2B',description:'Területi képviselő, CRM és B2B',url:'https://www.profession.hu/allas/teruleti-kepviselo-5678'},
  {title:'Értékesítési vezető CRM',description:'Területi képviselő Zalaegerszeg',url:'https://www.profession.hu/allas/ertekesitesi-vezeto'},
  {title:'Hamis külső link',description:'Területi képviselő CRM Zalaegerszeg',url:'https://evil.example/allas/teruleti'},
  {title:'Kérlek jelentkezz be',description:'Területi képviselő CRM Zalaegerszeg',url:'https://www.profession.hu/login'},
 ],
 cvonline:[{title:'Területi képviselő - B2B',description:'CRM, Excel. Zalaegerszeg',url:'https://www.cvonline.hu/hu/allasok/teruleti-kepviselo-123'}]
};
const requests=[];
async function mockSearch(url,options){
 requests.push({url,options});const u=new URL(url),domain=u.searchParams.get('q')?.includes('site:profession.hu')?'profession':'cvonline';
 return {ok:true,json:async()=>({web:{results:records[domain]}})};
}
test('exactly two portal CV search robots with exclusive, different targets',()=>{
 assert.deepEqual(CV.BOARDS.map(x=>x.id),['profession_cv','cvonline_cv']);
 assert.deepEqual(CV.BOARDS.map(x=>x.domain),['profession.hu','cvonline.hu']);
 assert.equal(CV.BOARDS[0].focus,'target_roles');assert.equal(CV.BOARDS[1].focus,'skills_and_roles');
});
test('sanitized CV uses roles, skills, places and exclusion but does not send raw CV/contact fields',()=>{
 const p=CV.sanitizedProfile(profile);assert.equal(p.roles.length,2);assert.equal(p.skills.length,3);
 const q=CV.buildQuery(CV.BOARDS[0],p);assert.match(q,/site:profession.hu/);
 assert.match(q,/Zalaegerszeg/);assert.doesNotMatch(q,/personal@example.com|TESZT KERESZTNÉV|361000000/);
});
test('cannot start external job searching without explicit consent',async()=>{
 await assert.rejects(()=>CV.searchCVPortals({profile},{key:'k',request:mockSearch}),/hozzájárulás/);
});
test('missing key reports not_configured instead of fabricated job matches or external requests',async()=>{
 const before=requests.length;const r=await CV.searchCVPortals(consent,{key:'',request:mockSearch});
 assert.equal(r.ok,false);assert.equal(r.status,'not_configured');assert.equal(r.boards.length,2);
 assert.equal(requests.length,before);assert.equal(r.boards.every(x=>x.jobs.length===0),true);
});
test('user must supply meaningful target role or skills',()=>{
 assert.throws(()=>CV.sanitizedProfile({targetRoles:'',skills:[],email:'a@b.com'}),/keresett/);
});
test('search links allow only exact trusted portal domains, reject lookalike and unsecure URLs',()=>{
 const b=CV.BOARDS[0];assert.ok(CV.safePortalUrl('https://www.profession.hu/allas/foo',b));
 for(const val of ['http://profession.hu/allas/foo','https://profession.hu.evil.example/allas/foo','https://evil.example/allas/foo', 'https://profession.hu/login','https://profession.hu@evil.example/allas/foo','https://profession.hu:8443/allas/foo'])
  assert.equal(CV.safePortalUrl(val,b),null,val);
});
test('excluded jobs receive a large matching penalty',()=>{
 const p=CV.sanitizedProfile(profile);
 let a=CV.scoreSnippet({title:'Területi képviselő CRM Zalaegerszeg',description:'B2B'},p);
 let b=CV.scoreSnippet({title:'Értékesítési vezető CRM',description:'Területi képviselő Zalaegerszeg'},p);
 assert.ok(a.score>b.score);assert.ok(a.reasons.includes('célmunkakör'));
});
test('each robot searches ONLY its portal in a permitted index, never scrapes source HTML',async()=>{
 requests.length=0;
 const result=await CV.searchCVPortals(consent,{key:'fake-brave-key',request:mockSearch});
 assert.equal(result.ok,true);assert.equal(result.status,'searched');assert.equal(requests.length,2);
 const qs=requests.map(x=>new URL(x.url).searchParams.get('q'));
 assert.match(qs[0],/^site:profession\.hu /);assert.match(qs[1],/^site:cvonline\.hu /);
 assert.equal(requests.every(x=>x.url.startsWith('https://api.search.brave.com/res/v1/web/search')),true);
 assert.equal(result.boards[0].jobs.length,1);assert.equal(result.boards[1].jobs.length,1);
 assert.ok(result.boards.every(x=>x.jobs.every(y=>y.verified===false)));
 assert.ok(result.boards.every(x=>x.jobs.every(y=>y.url.includes(x.id==='profession_cv'?'profession.hu':'cvonline.hu'))));
 assert.equal(result.meta.rawCvSent,false);assert.equal(result.meta.jobDetailsVerified,false);
 assert.doesNotMatch(JSON.stringify(requests),/personal@example.com|TESZT KERESZTNÉV|361000000/);
});
test('partial provider failure does not hide successful board search',async()=>{
 const r=await CV.searchCVPortals(consent,{key:'key',request:async url=>{
  if(new URL(url).searchParams.get('q').includes('site:profession.hu'))throw Error('Search down');
  return {ok:true,json:async()=>({web:{results:records.cvonline}})};
 }});
 assert.equal(r.status,'partial');assert.equal(r.boards[0].status,'failed');assert.equal(r.boards[1].jobs.length,1);
});
test('server endpoint enforces auth, consent and does not touch DB during portal search',async()=>{
 const reads=[];const pool={query:async sql=>{reads.push(sql);return {rows:[]}}};
 const server=createApi(pool,{token:'local-token',embeddingKey:'',braveKey:'mock-key',request:mockSearch});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 const origin='http://127.0.0.1:'+server.address().port;
 try{
  const headers={'Content-Type':'application/json',Authorization:'Bearer local-token'};
  const unauth=await fetch(origin+'/api/v3/cv-portal-search',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(consent)});
  assert.equal(unauth.status,401);
  const denied=await fetch(origin+'/api/v3/cv-portal-search',{method:'POST',headers,body:JSON.stringify({profile})});assert.equal(denied.status,400);
  const yes=await fetch(origin+'/api/v3/cv-portal-search',{method:'POST',headers,body:JSON.stringify(consent)});
  assert.equal(yes.status,200);const data=await yes.json();assert.equal(data.boards.length,2);
  assert.equal(reads.length,0);
 }finally{await new Promise(resolve=>server.close(resolve))}
});
test('missing Brave key gives 503 at HTTP level, not a misleading successful job list',async()=>{
 const server=createApi({query:async()=>({rows:[]})},{token:'local-token',braveKey:'',embeddingKey:'',request:mockSearch});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 try{const r=await fetch('http://127.0.0.1:'+server.address().port+'/api/v3/cv-portal-search',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer local-token'},body:JSON.stringify(consent)});assert.equal(r.status,503);assert.equal((await r.json()).status,'not_configured')}
 finally{await new Promise(resolve=>server.close(resolve))}
});
test('version has upgraded to 0.3.4 without changing old collector commands',()=>{
 const pkg=require('../package.json');assert.equal(pkg.version,'0.3.4');assert.equal(pkg.scripts.collect,'node src/cli.js collect');assert.equal(pkg.scripts['ai:cycle'],'node src/cli.js ai-cycle');
});
