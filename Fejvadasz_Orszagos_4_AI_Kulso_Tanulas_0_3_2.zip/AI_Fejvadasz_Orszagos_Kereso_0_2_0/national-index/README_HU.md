# ÚJ: 0.3.0 – négy saját AI-modell

A négy saját tanítható AI-modell, a biztonságos verziózás, a review queue és az éles motoradatokból tanuló optimalizáló leírása: **`docs/NEGY_SAJAT_AI_MODELL_0_3_0_HU.md`**. A 0.2.2 országos állásgyűjtő és GeoNames működése megmaradt. A három felügyelt modell **tanítóadatokra vár**; szintetikus demó alapján nem aktiválódik.

---

# AI Fejvadász országos frissítés 0.2.2 – egy ZIP-feltöltés (tesztelt forráskód)

## Teljesítménycél, nem hamis ígéret

- Minden **gyűjtőmotortípusnál 1000 különálló, az elmúlt 14 napban megfigyelt magyar hirdetés** a cél. Az első körben várhatóan nem teljesül; ha nem teljesül, `needs_development` jelzés és további forrásfejlesztési feladat következik. A `registry` nem gyűjtőmotor. Hirdetések elérhetősége jelentkezés előtt ellenőrizendő.
- A számláló a `national_observations` és a `national_jobs` alapján **egyedi** magyar állásrekordokat számol motoronként. Duplikált állásazonosítókat nem fúj fel 1000-re.
- A teljesítményjelentés: `npm run engine-targets` vagy Bearer-tokenes `GET /api/v1/engine-targets`. **A gyenge motort fejleszteni kell, de a gyűjtés nem áll le miatta.**

## Országos koordinátatár

- Forrás: **GeoNames HU.zip**, GeoNames CC BY 4.0, https://www.geonames.org/ (forrásmegjelölés kötelező). A Render-szerver a GeoNames hivatalos országfájlját HTTPS-sel letöltheti a migráció során.
- `npm run import:geonames` letölti, ellenőrzi a vármegye rekordokat, csak magyar lakott helyeket importál, a koordinátákat WGS84-ben tartja, és csak validált helyeket enged be. Külső `unzip` szükséges.
- Kézi/offline ellenőrzés: `npm run import:geonames -- /path/to/HU.zip`; újraimport: `npm run import:geonames -- /path/to/HU.zip --force`. 1000 már betöltött hely felett automatikusan kihagyja a napi újrafeltöltést (frissítéshez `--force`).
- A művelet tranzakcióban fut. Hibás vagy hiányos állomány esetén visszagörget, nem talál ki koordinátát, és a rendszer nem jelzi működőnek a km-keresést.
- A GeoNames településnév + vármegye kapcsolatát használja; az azonos nevű, több vármegyében előforduló helységeket csak egyértelmű helyszínnél kapcsolja. Nem GPS-mérés: a helypont jellemzően településközpont.

## Javítások, források, kapcsolódás

- A v0.2.2-es adatbázis-migráció **idempotens**; a Workable és SmartRecruiters források engedélyezettek, egyéb, csak névleg regisztrált portálok nem kerülnek hamisan bekapcsolásra.
- A nagy globális SmartRecruiters állásportálokat országkóddal szűrjük (`country=hu`), és a lapozás szabályait ellenőrizzük. A Lever oldalankénti, kontrollált lekérést végez.
- A korábbi 0.9.7-es Android klienshez való keresési integráció **még nem készült el**; ezt külön kell tesztelni, ne állítsunk éles összekötést engedély nélkül.
- A `POST /api/v2/recommend` a profilt kérésenként dolgozza fel, a nyers CV nem kerül a nemzeti állás-adatbázisba. A szemantikus AI-funkció `OPENAI_API_KEY` nélkül nem aktív.

## Render (a meglévő két szolgáltatás, nincs új havi szolgáltatás)

1. A **ZIP-et kibontás nélkül** töltsd fel a GitHub tároló főkönyvtárába.
2. A `national-api` Web Service és a `national-collector` Cron Job Build Commandban mindkettőnél **a ZIP-fájlnevet** cseréld a 0.2.2-esre; a belső `AI_Fejvadasz_Orszagos_Kereso_0_2_0/national-index` mappanév változatlan.
3. A `national-api` Pre-Deploy Command végleges javaslat:

```
cd AI_Fejvadasz_Orszagos_Kereso_0_2_0/national-index && npm run migrate && npm run seed && npm run import:geonames
```

4. A Cron Job Command változatlan: `cd AI_Fejvadasz_Orszagos_Kereso_0_2_0/national-index && npm run collect && npm run geocode && npm run embed`. Időzítés `0 */4 * * *`.
5. Ha a GeoNames letöltése hálózati hiba miatt nem sikerül, az API új telepítése **nem lép élesre**. A korábbi élő verzió megmarad. A hiba naplóját kell ellenőrizni; ne kapcsold ki némán az importot.
6. Éles ellenőrzés: Render deploy `live`, `npm run engine-targets`, a PostGIS `national_places` és `national_job_places` táblák növekedése, álláskeresés Budapest/Zala körzetében. A helyi tesztek önmagukban nem igazolják a valódi internetes források napi teljesítményét.

## Egyéb

A rendszer nem kerüli meg az állásoldalak tiltásait, nem dolgozik bejelentkezést igénylő tartalmakkal. Forrásmegjelölés: GeoNames – https://www.geonames.org/ – CC BY 4.0. Harmadik fél API-ja bármikor változhat; a motorokat újra kell tesztelni élesben.

---

# Keresőmotor-bővítés 0.2.1 (2026-11-10)

- 5 új elsődleges, nyilvános munkáltatói ATS-forrás (4 Workable + Anton Paar SmartRecruiters); összesen 75 regisztrált, 14 engedélyezett. A források működése az első éles lekérdezéskor igazolható; az eredmény nem garantált.
- Javított Lever motor: lapozott, kis méretű lekérdezések a korábbi `Oversized source response` hibák ellen; ha a lapozási limit miatt csonkolódik az adat, az előző állásokat **nem** minősíti lejártnak.
- A meglévő régi Android szerver nem módosul. Az országos Web Service és Cron Job ZIP-fájlneve cserélendő külön-külön a Render Build Commandban. A nem hitelesített RSS/karrieroldalak továbbra is kikapcsolva maradnak, amíg nincs megfelelő csatlakozó/engedély.
- Nem tartalmaz Brave-hívást, a személyes CV-ket nem tárolja.
- A régi 61 regisztrált magyar forrás továbbra sem gyűjt aktívan. Az országos lefedettség további forrásonkénti adaptereket és ellenőrzéseket igényel.

## Frissítés

1. Töltsd fel a `Fejvadasz_Orszagos_Szerver_0_2_1.zip` ZIP-et a GitHub projekt főkönyvtárába, kibontás nélkül.
2. A **national-api** Web Service Render Settings > Build & Deploy > Build Command mezőjében a régi `Fejvadasz_Orszagos_Szerver.zip` nevet cseréld `Fejvadasz_Orszagos_Szerver_0_2_1.zip`-re. A ZIP-ben az `AI_Fejvadasz_Orszagos_Kereso_0_2_0/national-index` mappanév szándékosan változatlan, ezért a Start Command és a Pre-Deploy Command nem módosul.
3. A **national-collector** Cron Job Build Command mezőjében ugyanezt az egy fájlnevet cseréld. A Command és az időzítés nem módosul.
4. Az API pre-deploy seed lépése hozzáadja az új forrásokat a PostgreSQL-hez. Az első Cron futás után ellenőrizd a Render Logs és az adatbázis `national_runs` számait. A `sources_failed` és `errors` megmutatja, ha egy külső API elérhetetlen.

Ez lokálisan tesztelt kódváltozat; nem állítjuk, hogy a 75 forrás mind aktív, vagy hogy már lefutott élesben.

---

# AI Fejvadász országos szerver és keresőmotorok 0.2.0

**Állapot:** telepíthető forráscsomag, 38 helyi teszttel ellenőrzött prototípus. **NEM éles Render-telepítés.** Nem csatlakozott valós PostgreSQL-adatbázishoz ebben a munkamenetben; éles API- és indexelési teszt még szükséges. A meglévő 0.9.7-es Android alkalmazás és `ai-fejvadasz-android` Render szolgáltatás változatlan.

## Architektúra – két egymástól független réteg

```
                         ORSZÁGOS ÁLLÁSGYŰJTÉS
        Greenhouse | Lever | Ashby | SmartRecruiters | RSS | Sitemap
                                 |
             PostgreSQL (national_jobs, observations, sources)
                                 |
               +-----------------+-----------------+
               |                 |                 |
     Szöveges kereső      Szemantikus AI       Földrajzi motor
     (pg_trgm, aliasok)   (pgvector + embed)    (PostGIS, helyadatok)
               +-----------------+-----------------+
                                 |
                           Ajánlómotor
                          (összefésülés)
                                 |
                       Szerveroldali API
                      (védett, CV-t nem tárol)
                                 |
                    Későbbi Android integráció
```

A motorok **külön kódfájlban** vannak: `src/search/text.js`, `semantic.js`, `geo.js`, `ranking.js`. Nem egymás munkáját ismétlik. A rangsorolás a szöveges és szemantikus találatokat fésüli össze; a geolokáció precíz helyszínszűrés. A szemantikus motor valódi OpenAI-embeddinget kér, és a PostgreSQL pgvector adatain keres. A gyűjtő nem használ Brave-ot, és nem kap személyes CV-t.

## Biztonságos Render-telepítési sorrend

**Ne** cseréld le a korábbi `ai-fejvadasz-android` Build Commandját, és **ne** másold a database-jelszót a GitHubra vagy a chatbe. Külön országos szolgáltatást telepítünk.

1. Bontsd ki az archívum `national-index/` mappáját, és ezt a mappát töltsd fel a GitHub-tárolód főkönyvtárába (`/national-index` néven). A ZIP-fájl puszta feltöltése nem elég ehhez a külön Node projekthez.
2. A Render Dashboardban válaszd a **New → Postgres** opciót. Hozz létre **tartós** adatbázist, például `ai-fejvadasz-orszagos-db` néven. A meglévő Render szolgáltatással **azonos régióban** legyen. A Render adatbázis konstrukciója díjköteles lehet; az erőforrás létrehozása előtt ellenőrizd a díjszabást. Ingyenes, 30 napra korlátozott DB hosszú távú országos indexhez nem megfelelő.
3. Új **Web Service**: `ai-fejvadasz-national-api` a GitHub repository-ból, **Root Directory**: `national-index`; **Build Command**: `npm install --omit=dev`; **Start Command**: `npm run api`. Állíts be két környezeti változót: `DATABASE_URL` = az új Postgres **Internal Database URL**-je (a Render DB `Connect` oldaláról) és `NATIONAL_API_TOKEN` = véletlen, hosszú titok. A titkot soha ne tedd az Android APK-ba. A tényleges szemantikus motorhoz: `OPENAI_API_KEY`, külön költséget jelenthet.
4. Az új szolgáltatás első indítása előtt az adatbázison **egyszer** futtasd: `npm run migrate` majd `npm run seed`. Fizetős Render Web Service esetén ez automatizálható a **Pre-deploy Command** mezőben: `npm run migrate && npm run seed`. Ha nincs Pre-deploy Command lehetőség, használj külön Render **Job/Cron** szolgáltatást egyszeri futtatással vagy megbízható helyi számítógépről (`DATABASE_URL` külső URL-je + TLS), de jelszót ne ossz meg. Az alkalmazás nem talál ki adatbázist a semmiből.
5. A Renderen a `/health` a DB elérhetőségét, a `/ready` a szükséges táblák meglétét ellenőrzi. Siker esetén HTTP **200**, DB-kapcsolat hiányában **503**. Az API a titkot `Authorization: Bearer <NATIONAL_API_TOKEN>` fejlécben várja.
6. Külön **Cron Job** vagy Background Worker: Root `national-index`, Build `npm install --omit=dev`, óránkénti parancs: `npm run collect && npm run geocode && npm run embed`. Ugyanazt a DB-t használja. `OPENAI_API_KEY` nélkül az embedding-feltöltés `disabled` státusszal lép tovább, a szöveges keresés ettől működik. A Cron és a Web Service külön számítható költség.
7. Importálj ellenőrzött magyar településjegyzéket `name,county,latitude,longitude,source_note` CSV-formában: `npm run import:places -- ./telepulesek.csv`, utána `npm run geocode`. A mellékelt `config/places-template.csv` csak FEJLÉC, nem állít valótlan koordinátákat. A pontos km-alapú geolokáció addig korlátozott.

A `render.yaml.example` egy választható, **fizetős** Render Blueprint példát tartalmaz, nem indít automatikus szolgáltatást. Létrehozása előtt jóvá kell hagyni az erőforrások költségeit. A `DATABASE_URL` a Render belső hálózatán legyen elérhető a szolgáltatásoknak ugyanabban a régióban.

## API tesztelés

```
GET  /health
GET  /ready
GET  /api/v1/stats                  (Bearer token)
GET  /api/v1/jobs?q=...           (Bearer token, régi API)
GET  /api/v2/search?q=területi%20képviselő&region=Zala&mode=hybrid&limit=50
GET  /api/v2/search?q=Area%20Sales%20Manager&lat=46.85&lon=16.85&radius_km=30
POST /api/v2/recommend            (JSON {"targetRoles":"területi képviselő","skills":["B2B"]}, Bearer token)
```

A `hybrid` mód akkor is működik szöveges eredményekkel, ha a szemantikus motor nem elérhető, de ezt egyértelműen jelzi a válasz `meta.semanticStatus` mezője. A `semantic` mód kulcs vagy embeddingadat nélkül nem ad hamis AI-eredményt. Az ajánlómotor rangsorolást készít, de **nem állít felvételi valószínűséget**, és nem helyettesíti a külön CV-alapú AI-értékelést.

**Technikai ellenőrzés** (Node.js 20+):

```bash
npm install --omit=dev
npm test
npm run check-db       # DATABASE_URL kell; a valódi kapcsolatot ellenőrzi
npm run migrate        # PostgreSQL + bővítmények + táblák
npm run seed           # forrásjegyzék
npm run collect        # tényleges országos ATS/feed lekérések
npm run embed          # opcionális OpenAI embeddings, költségplafon max per run
npm run api            # HTTP REST API a PORT változón
```

## Jelenlegi korlátok – ne tekintsük kész országos lefedettségnek

- A 70 jegyzékelt forrásból jelenleg 9 próbakapcsolat aktív, a többi nem automatikus crawler. Ezek egy részénél még ellenőrizni kell az élő ATS-válaszokat. Ez nem több százezer hirdetés. További forrásokat és engedélyezett adaptereket kell építeni.
- A `pgvector`, `postgis` és `pg_trgm` migrációját élő PostgreSQL-en kell ellenőrizni. A helyi tesztek SQL- és HTTP-útvonalakat szimulálnak; **nem valós Postgres adatbázist** használnak.
- A földrajzi vármegye- és km-keresés csak feltöltött, igazolt helyadatok és összekötött állások mellett teljes. A találatot nem teszi magyarországinak pusztán az, hogy egy várost megemlítettek a szövegben.
- Az embeddingek külön feldolgozási feladatban készülnek. Első indexeléskor üres lehet a szemantikus eredménylista. Az OpenAI API fizetős használatot jelenthet; a megadott `NATIONAL_EMBED_MAX_PER_RUN` egyetlen futás hívásmennyiségét korlátozza, nem havi pénzügyi költségplafon.
- A korábbi Android APK-t **nem** kapcsoltam át erre az API-ra. Az országos rendszer külön Render szolgáltatásként indítandó, éles hozzáférések után.
- Az automatikus optimalizálás jelenleg a források korábbi sikeressége alapján rendezi a gyűjtést. A keresőmotorok nem írják át autonóm módon a saját kódjukat.

A végcél: több száz / ezer megbízható forrás, tartós országos állásadatbázis, saját szerveroldali keresés és megbízható CV-alapú kiválasztás külön rétegben.


## 0.3.1 – Külső tanulási kör és kapacitásfigyelés

Lásd `RELEASE_NOTES_0_3_1_HU.md`. A kutatás engedély nélkül nem indul, a külső bizonyítékok nem automatikus tanítóadatok. A négy modell változatlanul önálló, tesztkapus fejlesztési ciklussal használható.
