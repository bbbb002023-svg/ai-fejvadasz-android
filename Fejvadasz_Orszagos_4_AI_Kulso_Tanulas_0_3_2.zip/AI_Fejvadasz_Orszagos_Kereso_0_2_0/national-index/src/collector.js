'use strict';
const {collectSource}=require('./engines');const db=require('./db');
const LOCK_ID=8181026;
async function runOnce(pool,{fetchImpl=globalThis.fetch,maxSources=160,parallel=3}={}){
 // Advisory lock is held on one dedicated connection to prevent concurrent cron/worker runs.
 const lock=await pool.connect(),grant=await lock.query('SELECT pg_try_advisory_lock($1) AS acquired',[LOCK_ID]);
 if(!grant.rows[0]?.acquired){lock.release();return {skipped:true,reason:'Another collector is running'}};
 let runId,errors=[],succeeded=0,failed=0,found=0,hu=0;
 try{
  const run=await pool.query('INSERT INTO national_runs DEFAULT VALUES RETURNING run_id');runId=run.rows[0].run_id;
  const sources=await db.dueSources(pool,Math.min(maxSources,500));let index=0;
  parallel=Math.max(1,Math.min(8,Number(parallel)||3));
  await Promise.all(Array.from({length:Math.min(parallel,sources.length)},async()=>{
   while(index<sources.length){const src=sources[index++];
    try{
     const result=await collectSource(src,{request:fetchImpl,maxItems:1800,maxPages:60});
     const info=await db.upsertSnapshot(pool,src,result.jobs,{complete:result.complete});
     succeeded++;found+=info.total;hu+=info.hu;
    }catch(e){failed++;const msg=String(e?.message||e).slice(0,220);errors.push({source:src.source_key,error:msg});await db.sourceFailure(pool,src,e)}
   }
  }));
  await pool.query(`UPDATE national_runs SET finished_at=NOW(),sources_attempted=$2,sources_succeeded=$3,
    sources_failed=$4,jobs_seen=$5,jobs_hu=$6,errors=$7::jsonb WHERE run_id=$1`,
   [runId,sources.length,succeeded,failed,found,hu,JSON.stringify(errors.slice(0,50))]);
  return {runId,sources:sources.length,succeeded,failed,jobsSeen:found,hungaryJobs:hu,errors};
 }finally{try{await lock.query('SELECT pg_advisory_unlock($1)',[LOCK_ID])}finally{lock.release()}}
}
module.exports={runOnce};
