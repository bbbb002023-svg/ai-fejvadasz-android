'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const E=require('../src/engines'),D=require('../src/db'),C=require('../src/collector');
const N=require('../src/normalize'),S=require('../src/search/service');
const GEO=require('../src/search/geo'),P=require('../src/places');
const config=require('../config/sources.json');
const source=(engine='smartrecruiters',board='BoschGroup',scope='hu_only')=>({source_key:`${engine}:${board}`,engine,board,enabled:true,approved:true,country_scope:scope,name:board,company:board});
const response=(body,status=200,contentLength=null)=>({ok:status>=200&&status<300,status,headers:{get:k=>k==='content-length'?contentLength:null},text:async()=>JSON.stringify(body)});
const item=(id=1,country='hu')=>({id:String(id),name:'Területi képviselő',location:{city:'Zalaszentgrót',country},releasedDate:'2026-11-01'});

test('v0.2.2 schema migration explicitly and idempotently allows Workable',async()=>{
 const seen=[];await D.migrate({query:async text=>seen.push(text)});
 assert.equal(seen.length,6);assert.match(seen[5],/ADD COLUMN IF NOT EXISTS location_filters/);assert.match(seen[3],/CREATE TABLE IF NOT EXISTS national_ai_examples/);assert.match(seen[4],/CREATE TABLE IF NOT EXISTS national_ai_external_evidence/);assert.match(seen[2],/DROP CONSTRAINT IF EXISTS national_sources_engine_check/);
 assert.match(seen[2],/\bworkable\b/);assert.match(seen[2],/BEGIN;/);
 assert.ok(!/DROP TABLE|TRUNCATE|DELETE FROM national_jobs/i.test(seen[2]));
});
test('idempotent migration includes conservative HU-code legacy backfill and no personal data',()=>{
 const s=fs.readFileSync(path.join(__dirname,'../src/schema-v3.sql'),'utf8');
 assert.match(s,/country_status='unknown'/);assert.match(s,/location_text ~\*/);
 assert.ok(!/profile|curriculum|cv_text|resum[eé]/i.test(s));
});
test('source catalog has 78 unique entries, 17 active, and no enabled registry placeholders',()=>{
 assert.equal(config.length,78);assert.equal(config.filter(s=>s.enabled).length,17);
 assert.equal(new Set(config.map(s=>s.source_key)).size,78);
 assert.ok(config.every(s=>s.engine!=='registry'||!s.enabled));
 for(const key of ['smartrecruiters:boschgroup','smartrecruiters:wise','smartrecruiters:deutschetelekomitsolutions']){
  const e=config.find(x=>x.source_key===key);assert.equal(e.enabled,true);assert.equal(e.country_scope,'hu_only');
 }
});
test('seed preserves existing toggles when upgrading source metadata',async()=>{
 const sql=[];const pool={query:async(q,v)=>{sql.push(q);assert.equal(v[0],'smartrecruiters:BoschGroup')}};
 await D.seed(pool,[source()]);assert.match(sql[0],/ON CONFLICT/);
 assert.ok(!/enabled\s*=\s*EXCLUDED.enabled/.test(sql[0]));
});
test('explicit HU, hun and unfamiliar Hungarian towns are Hungarian',()=>{
 for(const loc of ['Fiktívfalu, hu','Gyál, HUN','Budapest, Hungary','Hévíz','Zalaszentgrót','Kiskunhalas','Budaörs','Baja'])
  assert.equal(N.countryStatus(loc),'hu',loc);
});
test('foreign explicit location takes precedence over similarly named town',()=>{
 for(const loc of ['Eger, Germany','Budapest, Romania','Bonn, DE','Vienna, Austria'])
  assert.equal(N.countryStatus(loc),'foreign',loc);
});
test('ambiguous remote and arbitrary foreign geographies do not become Hungarian',()=>{
 for(const loc of ['remote','worldwide','work from anywhere','home office','', 'church', 'budapestmore'])
  assert.equal(N.countryStatus(loc),'unknown',loc);
});
test('hu_only marking must not override a foreign explicit country',()=>{
 const src=source();assert.equal(N.countryStatus('Germany',src),'foreign');
 assert.equal(N.countryStatus('UnknownTown',src),'hu');
});
test('SmartRecruiters country-filtered query includes hu and restricts foreign replies',async()=>{
 const urls=[];const request=async u=>{urls.push(u);return response({content:[item(1),item(2,'de')],totalFound:2})};
 const r=await E.smartrecruiters(source(),{request,detailLimit:0});
 assert.match(urls[0],/country=hu/);assert.equal(r.jobs.length,1);
 assert.equal(r.jobs[0].location,'Zalaszentgrót, hu');assert.equal(r.complete,true);
 assert.equal(N.countryStatus(r.jobs[0].location),'hu');
});
test('SmartRecruiters emits browser-facing public posting URLs rather than API JSON links',async()=>{
 const r=await E.smartrecruiters(source(),{request:async u=>response({content:[item(12345)],totalFound:1}),detailLimit:0});
 assert.equal(r.jobs[0].url,'https://jobs.smartrecruiters.com/BoschGroup/12345');
 assert.ok(N.normalizeJob(r.jobs[0],source()).url.startsWith('https://jobs.smartrecruiters.com/'));
});
test('SmartRecruiters gets an optional full description for up to a configured cap',async()=>{
 let details=0;const request=async u=>{
  if(u.includes('postings?'))return response({content:[item(1),item(2)],totalFound:2});
  details++;return response({jobAd:{sections:{jobDescription:{text:'<p>Értékesítési feladatok</p>'},qualifications:{text:'B kategóriás jogosítvány'}}}});
 };
 const r=await E.smartrecruiters(source(),{request,detailLimit:1});
 assert.equal(details,1);assert.equal(r.jobs[0].description,'Értékesítési feladatok B kategóriás jogosítvány');
 assert.equal(r.jobs[1].description,'');
});
test('SmartRecruiters missing detail endpoint preserves public listing',async()=>{
 const request=async u=>u.includes('postings?')?response({content:[item(1)],totalFound:1}):response({error:'rate limit'},429);
 const r=await E.smartrecruiters(source(),{request});assert.equal(r.jobs.length,1);assert.equal(r.complete,true);
});
test('SmartRecruiters respects 100-item pagination and marks hard caps incomplete',async()=>{
 const request=async u=>{const url=new URL(u),offset=Number(url.searchParams.get('offset'));return response({content:Array.from({length:100},(_,i)=>item(offset+i)),totalFound:1000})};
 const r=await E.smartrecruiters(source(),{request,maxItems:200,maxPages:2,detailLimit:0});
 assert.equal(r.jobs.length,200);assert.equal(r.complete,false);
});
test('SmartRecruiters detects empty but non-finished pages instead of falsely closing jobs',async()=>{
 await assert.rejects(()=>E.smartrecruiters(source(),{request:async()=>response({content:[],totalFound:50}),detailLimit:0}),/pagination stalled/);
});
test('SmartRecruiters rejects oversized or malformed source replies',async()=>{
 await assert.rejects(()=>E.smartrecruiters(source(),{request:async()=>response({content:Array(101).fill(item()),totalFound:101}),detailLimit:0}),/page limit/);
});
test('Lever retries down to one item and safely skips an oversized individual record',async()=>{
 const seen=[];const request=async u=>{const {searchParams:q}=new URL(u),skip=Number(q.get('skip')),size=Number(q.get('limit'));seen.push([skip,size]);
  if(skip===0)return {ok:true,status:200,headers:{get:()=>7000000},text:async()=>''};
  return response([{id:String(skip),text:'Technikus',hostedUrl:`https://jobs.lever.co/ion/${skip}`,categories:{location:'Zalaegerszeg'}}]);};
 const r=await E.lever(source('lever','ion','mixed'),{request,maxPages:12,maxItems:60,delayMs:0});
 assert.ok(seen.some(x=>x[1]===1));assert.equal(r.skippedOversized,1);assert.equal(r.complete,false);
 assert.ok(r.jobs.length>0);
});
test('partial Lever source results are never advertised as complete',async()=>{
 const request=async u=>{const {searchParams:q}=new URL(u),sz=Number(q.get('limit'));return response(Array.from({length:sz},(_,i)=>({id:'a'+i,text:'Mérnök',hostedUrl:'https://jobs.lever.co/ion/'+i}))) };
 const r=await E.lever(source('lever','ion','mixed'),{request,maxPages:2,maxItems:500,delayMs:0});
 assert.equal(r.complete,false);
});
test('region=Zala matches named settlements even before gazetteer is populated',()=>{
 const x=GEO.predicates(GEO.parseGeo({region:'Zala vármegye'}));
 assert.ok(x.params.includes('Nagykanizsa'));assert.ok(x.params.includes('Keszthely'));assert.ok(x.params.includes('Lenti'));
 assert.ok(x.sql.includes('national_job_places'));assert.ok(!x.sql.includes('Nagykanizsa'));
});
test('region aliases cannot be SQL-injected',()=>{
 const injection="Zala' OR true --",x=GEO.predicates(GEO.parseGeo({region:injection}));
 assert.ok(!x.sql.includes(injection));assert.deepEqual(x.params,[injection]);
});
test('valid radius query clearly fails without trusted coordinates rather than returning false zero',async()=>{
 const pool={query:async()=>({rows:[{available:false}]})};
 await assert.rejects(()=>S.search(pool,{q:'raktáros',lat:47.5,lon:19,radius_km:20,key:''}),/még nincs betöltve/);
});
test('geo radius with a seeded gazetteer can proceed to normal text search',async()=>{
 const pool={query:async()=>({rows:[{available:true}]})};
 const r=await S.search(pool,{q:'területi vezető',lat:47.5,lon:19,radius_km:20,mode:'text'});
 assert.equal(r.meta.geoFiltered,true);
});
test('ambiguously named towns in multiple counties are not assigned two different locations',()=>{
 const places=[{place_key:'a',name:'Próba',county:'Zala'},{place_key:'b',name:'Próba',county:'Vas'}];
 assert.deepEqual(P.distinctPlaceMatches('Próba, Hungary',places),[]);
 assert.deepEqual(P.distinctPlaceMatches('Próba, Zala, Hungary',places).map(x=>x.place_key),['a']);
});
test('geocode refresh clears stale town links even when a job moved',async()=>{
 const queries=[];const pool={query:async(sql,params)=>{queries.push(sql);
  if(sql.startsWith('SELECT place_key'))return {rows:[{place_key:'z',name:'Zalaegerszeg',county:'Zala'}]};
  if(sql.startsWith('SELECT j.job_key'))return {rows:[{job_key:'1',location_text:'Budapest, Hungary'}]};
  return {rows:[],rowCount:1};}};
 const r=await P.assignJobPlaces(pool);
 assert.equal(r.updated,0);assert.ok(queries.some(x=>x.startsWith('DELETE FROM national_job_places')));
});
test('a canonical URL change closes the former orphan job only if no live source still references it',async()=>{
 const calls=[];const pool={connect:async()=>({query:async(sql,params)=>{calls.push([sql,params]);
  if(sql.startsWith('SELECT job_key FROM national_observations'))return {rows:[{job_key:'old-key'}]};return {rows:[],rowCount:1};},release(){}})};
 await D.upsertSnapshot(pool,source('lever','ion','mixed'),[{external_id:'x',title:'Current',url:'https://jobs.lever.co/ion/new',location:'Budapest',company:'ION'}],{complete:true});
 assert.ok(calls.some(([s])=>s.includes("SET state='closed'")));
 assert.ok(calls.some(([s])=>s.includes('NOT EXISTS(SELECT 1 FROM national_observations o')));
});
test('database transaction rolls back on failed insert rather than partially saving',async()=>{
 const calls=[];const pool={connect:async()=>({query:async sql=>{calls.push(sql);if(sql.includes('INSERT INTO national_jobs'))throw Error('SQL broken');return {rows:[]}},release(){}})};
 await assert.rejects(()=>D.upsertSnapshot(pool,source(),[{external_id:'j',title:'Menedzser',url:'https://example.com/jobs/1',company:'Teszt'}]),/SQL broken/);
 assert.ok(calls.includes('BEGIN'));assert.ok(calls.includes('ROLLBACK'));assert.ok(!calls.includes('COMMIT'));
});
test('no sources due means no fake jobs; collector still tracks an empty run',async()=>{
 const calls=[];const connection={query:async()=>({rows:[{acquired:true}]}),release(){}};
 const pool={connect:async()=>connection,query:async sql=>{calls.push(sql);return sql.includes('INSERT INTO national_runs')?{rows:[{run_id:'123'}]}:{rows:[]}}};
 const r=await C.runOnce(pool);assert.equal(r.jobsSeen,0);assert.equal(r.sources,0);assert.equal(r.failed,0);
});
test('large-scale normalization 5000 jobs stays deterministic without sharing CV data',()=>{
 const src=source();const set=new Set();for(let i=0;i<5000;i++){
  const j=N.normalizeJob({title:'Raktáros',url:`https://jobs.example.com/${i}?utm_source=external`,company:'Példa Kft.',location:'Szeged'},src);
  assert.ok(j);set.add(j.job_key);assert.equal(j.country_status,'hu');
 }
 assert.equal(set.size,5000);
});
test('end-to-end pipeline: official HU source -> collector -> normalized SQL write -> reported HU count',async()=>{
 const statements=[],s=source('smartrecruiters','BoschGroup','hu_only');
 const connection={query:async(sql,params)=>{statements.push([sql,params]);
   if(sql.includes('pg_try_advisory_lock'))return {rows:[{acquired:true}]};
   return {rows:[],rowCount:1};},release(){}};
 const pool={connect:async()=>connection,query:async(sql,params)=>{statements.push([sql,params]);
  if(sql.includes('INSERT INTO national_runs DEFAULT'))return {rows:[{run_id:'26'}]};
  if(sql.includes('SELECT * FROM national_sources'))return {rows:[s]};
  return {rows:[]};}};
 const fetchImpl=async url=>url.includes('postings?')?response({content:[item(123,'hu')],totalFound:1}):response({jobAd:{sections:{jobDescription:{text:'<p>Gyártási munka Zalaegerszegen</p>'}}}});
 const out=await C.runOnce(pool,{fetchImpl,parallel:1});
 assert.equal(out.sources,1);assert.equal(out.succeeded,1);assert.equal(out.failed,0);
 assert.equal(out.hungaryJobs,1);
 const ins=statements.find(([s])=>s.includes('INSERT INTO national_jobs'));
 assert.ok(ins);assert.equal(ins[1][5],'hu');assert.equal(ins[1][2],'BoschGroup');
 assert.ok(statements.some(([s])=>s.includes('UPDATE national_runs SET finished_at')));
});
test('failed-source pipeline reports a failed source rather than misreporting a successful collection',async()=>{
 const statements=[],s=source('smartrecruiters','BoschGroup','hu_only');
 const connection={query:async(sql)=>sql.includes('pg_try_advisory_lock')?{rows:[{acquired:true}]}:{rows:[]},release(){}};
 const pool={connect:async()=>connection,query:async(sql,params)=>{statements.push(sql);
  if(sql.includes('INSERT INTO national_runs DEFAULT'))return {rows:[{run_id:'123'}]};
  if(sql.includes('SELECT * FROM national_sources'))return {rows:[s]};
  return {rows:[]};}};
 const out=await C.runOnce(pool,{fetchImpl:async()=>response({error:'bad'},503),parallel:1});
 assert.equal(out.failed,1);assert.equal(out.succeeded,0);assert.equal(out.jobsSeen,0);
 assert.ok(out.errors[0].error.includes('HTTP 503'));
 assert.ok(statements.some(sql=>sql.includes('fail_count=fail_count+1')));
});
test('API health endpoint reports the new release version, without exposing tokens',async()=>{
 const {createApi}=require('../src/api'),pool={query:async()=>({rows:[{jobs:'national_jobs',places:'national_places'}]})};
 const server=createApi(pool,{token:'sample-test-secret'});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 try{const {port}=server.address();const response=await fetch(`http://127.0.0.1:${port}/health`),payload=await response.json();
  assert.equal(response.status,200);assert.equal(payload.version,require('../package.json').version);
  assert.ok(!JSON.stringify(payload).includes('sample-test-secret'));
 }finally{await new Promise(resolve=>server.close(resolve))}
});
test('legacy v1 job API uses county alias fallback and safe parameterized SQL',async()=>{
 const calls=[];const pool={query:async(sql,params)=>{calls.push({sql,params});return {rows:[]}}};
 await D.search(pool,{q:'raktáros',region:'Zala',limit:15});
 assert.ok(calls[0].params.includes('Keszthely'));
 assert.ok(calls[0].params.includes('Nagykanizsa'));
 assert.equal(calls[0].params.at(-2),15);
 assert.ok(!calls[0].sql.includes('Nagykanizsa'));
});
test('SimpleMaps city importer accepts documented HU coordinates with source attribution and rejects non-HU rows',async()=>{
 const os=require('node:os'),file=path.join(os.tmpdir(),'simplemaps-'+process.pid+'.csv');
 fs.writeFileSync(file,'city,lat,lng,country,iso2,admin_name\nZalaegerszeg,46.8417,16.8416,Hungary,HU,Zala\nVienna,48.2,16.3,Austria,AT,Vienna\n');
 const out=[];const pool={query:async(sql,args)=>{out.push(args);return {rowCount:1}}};
 try{const result=await P.importSimplemaps(pool,file);assert.equal(result.imported,1);assert.equal(result.ignored,1);
  assert.equal(out[0][1],'Zalaegerszeg');assert.equal(out[0][2],'Zala');assert.match(out[0][5],/SimpleMaps/);
 }finally{fs.unlinkSync(file)}
});
test('SimpleMaps importer refuses malformed / unverifiable coordinates rather than inventing places',async()=>{
 const os=require('node:os'),file=path.join(os.tmpdir(),'bad-simplemaps-'+process.pid+'.csv');
 fs.writeFileSync(file,'city,lat,lng,iso2,admin_name\nBajor,100.00,80.00,HU,Zala\n');
 try{await assert.rejects(()=>P.importSimplemaps({query:async()=>{}},file),/Invalid or undocumented/)}finally{fs.unlinkSync(file)}
});
test('operational audit fails closed on incomplete national coverage instead of claiming success',async()=>{
 const pool={query:async sql=>{
  if(sql.includes('AS sources'))return {rows:[{sources:78,enabled_sources:17,all_jobs:674,active_hu_jobs:108,country_unknown:447,places_available:0,jobs_with_embeddings:0}]};
  if(sql.includes('FROM national_runs'))return {rows:[{run_id:1,sources_failed:0}]};
  return {rows:[]};}};
 const audit=await D.audit(pool);assert.equal(audit.readyForNationalCoverage,false);assert.ok(audit.issues.length>=3);
 assert.ok(audit.issues.some(x=>x.includes('koordinátatár')));
});
test('legacy API escapes SQL LIKE wildcards in keyword searches without literal SQL interpolation',async()=>{
 const sql=[];const pool={query:async(q,params)=>{sql.push([q,params]);return {rows:[]}}};
 await D.search(pool,{q:'dev%_!'});
 assert.ok(sql[0][0].includes("ESCAPE '!'"));assert.equal(sql[0][1][0],'dev%_!');
 assert.ok(!sql[0][0].includes('dev%_!'));
});
