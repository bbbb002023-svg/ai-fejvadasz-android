'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const E=require('../src/engines'),D=require('../src/db');
const config=require('../config/sources.json');
const response=(list)=>({ok:true,status:200,headers:{get:()=>null},text:async()=>JSON.stringify(list)});
const src={source_key:'lever:tsmg',board:'tsmg',engine:'lever',enabled:true,approved:true,location_filters:['Budapest'],country_scope:'mixed',company:'TSMG'};
test('TSMG Lever uses the official exact Budapest location query rather than the huge worldwide board',async()=>{
 const seen=[];
 const r=await E.lever(src,{request:async url=>{
  const u=new URL(url);seen.push(u);
  return response([{id:'bd1',text:'Driver / Data Collector',hostedUrl:'https://jobs.lever.co/tsmg/bd1',categories:{location:'Budapest'}}]);
 },maxItems:100,delayMs:0});
 assert.equal(seen.length,1);assert.equal(seen[0].searchParams.get('location'),'Budapest');
 assert.equal(seen[0].searchParams.get('limit'),'30');
 assert.equal(r.jobs.length,1);assert.equal(r.complete,true);
});
test('Lever locations use URL encoding, are OR-combined, and do not leak to other sources',async()=>{
 const urls=[];
 const r=await E.lever({...src,location_filters:['Győr','Budapest','Győr']},{request:async u=>{urls.push(new URL(u));return response([])},delayMs:0});
 assert.equal(r.complete,true);
 assert.deepEqual(urls[0].searchParams.getAll('location'),['Győr','Budapest']);
 const urls2=[];
 await E.lever({...src,location_filters:[]},{request:async u=>{urls2.push(new URL(u));return response([])},delayMs:0});
 assert.equal(urls2[0].searchParams.has('location'),false);
});
test('Lever rejects malicious or malformed stored filter before sending any network request',async()=>{
 let requests=0;
 for(const location_filters of [['Budapest\nX:evil'],Array(13).fill('Budapest'),'Budapest', ['']]){
  await assert.rejects(()=>E.lever({...src,location_filters},{request:async()=>{requests++;return response([])}}),/Invalid Lever location filter/);
 }
 assert.equal(requests,0);
});
test('TSMG catalog opts in to a reviewed Hungarian location, while other Lever boards are unaffected',()=>{
 const t=config.find(x=>x.source_key==='lever:tsmg');
 assert.deepEqual(t.location_filters,['Budapest']);
 assert.ok(config.filter(x=>x.engine==='lever'&&x.source_key!=='lever:tsmg').every(x=>!x.location_filters));
});
test('migrate preserves all old tables and adds an idempotent source filter field',async()=>{
 const scripts=[];await D.migrate({query:async sql=>{scripts.push(sql)}});
 assert.equal(scripts.length,6);
 assert.match(scripts[5],/ADD COLUMN IF NOT EXISTS location_filters jsonb/);
 assert.ok(!scripts[5].includes('DELETE FROM'));
});
test('seed persists exact allowlisted location strings, preserves existing enable and approved states',async()=>{
 const sql=[];const vals=[];
 await D.seed({query:async(s,v)=>{sql.push(s);vals.push(v)}},[{...src,name:'TSMG',category:'employer'}]);
 assert.ok(sql[0].includes('location_filters=EXCLUDED.location_filters'));
 assert.deepEqual(JSON.parse(vals[0][10]),['Budapest']);
 assert.ok(!/approved\s*=\s*EXCLUDED.approved/.test(sql[0]));
});
