# AI Fejvadász – országos szerver 0.2.2 – tesztkiadás

**Minősítés: kiadási jelölt / éles beüzemelési teszt szükséges. NEM végleges országos lefedettség.**

## Tartalom

1. Önálló állásgyűjtő forrásmotorok és javított lapozás: Lever, Ashby, Greenhouse, SmartRecruiters, Workable, RSS és Sitemap (csak engedélyezett/ellenőrzött oldalak). A `registry` sorai nem aktív gyűjtők.
2. Magyar ország- és vármegye-felismerés javítva, országszűrő ATS API-lekérdezések.
3. Idempotens, korábbi állásrekordokat megtartó PostgreSQL-migráció (v3); Workable engedélyezése a CHECK constraintban.
4. **GeoNames Magyarország-koordinátaimport** CC BY 4.0; automatizált `npm run import:geonames` futtatással. A ZIP **a letöltő- és importkódot tartalmazza**, a teljes hivatalos GeoNames HU.zip adatállományt nem. A tényleges koordinátaimport éles Render hálózati hozzáférést igényel.
5. Motoronként **1000 egyedi, magyarországi, az utóbbi 14 napban megfigyelt állásrekord** mint *fejlesztési cél*, nem alapértelmezett garancia: `npm run engine-targets`, Bearer API `/api/v1/engine-targets`. A cél alatt `needs_development` vagy `no_active_sources`.
6. Védett `/api/v1/audit` és `/api/v1/engine-targets` diagnosztika, azonosító- és URL-duplikáció kerülése, hibás források elkülönítése.

## Tesztelés

- `npm test`: **92/92 helyi automatizált teszt sikeres** (2026-11-10). Syntax, egységtesztek, szimulált teljes gyűjtési lánc, HTTP API autorizáció, ZIP/GeoNames import, hiányos adatok, tranzakció-visszagörgetés, forráshibák, 5000 településes terhelés, 5000 állás-normalizálás.
- Telepítés előtti szintaktikai ellenőrzés: `node --check` minden JS fájlon, archívum szerkezet és ZIP kibontás ellenőrzése.
- **NEM igazolt**: az új konkrét Bosch/Wise/DT IT HU források élő elérhetősége, a valós GeoNames országfájl Render-hálózati elérhetősége, a jelenlegi 108 magyar rekord növekedése, az 1000/motor cél teljesülése, az Android 0.9.7 integráció.

## Adatforrás / licenc

GeoNames https://www.geonames.org/ , CC BY 4.0, https://creativecommons.org/licenses/by/4.0/ , letöltési specifikáció: https://download.geonames.org/export/dump/readme.txt . A felhasznált adatok nem GPS-pontosságú munkavégzési címek, hanem településközéppontok.

**Szerveroldali változtatásokat mindig egyesével, naplóellenőrzéssel végezd.**
