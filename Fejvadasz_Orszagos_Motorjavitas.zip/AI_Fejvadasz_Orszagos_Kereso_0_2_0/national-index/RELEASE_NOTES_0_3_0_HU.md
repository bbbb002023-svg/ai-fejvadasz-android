# 0.3.0 – Négy saját AI-modell, fejlesztői tesztkiadás

## Új komponensek

- `src/ai/features.js`: numerikus, átlátható jellemzők három specializált modellhez.
- `src/ai/logistic.js`: saját tanítható, CPU-n futó bináris osztályozó; elkülönített teszttel.
- `src/ai/bandit.js`: források kimeneteleiből tanuló, kockázatkorlátos keresési prioritás.
- `src/ai/learning.js`: verziózás, visszajelzés-betöltés, tanítás, holdout teszt, automatikus aktiválási kapuk és áttekintési sor.
- `src/ai/schema-v4.sql`: kizárólag új PostgreSQL táblákat hoz létre. Az állásadatokat nem törli.
- `src/ai/cli.js`: külön AI parancsok, demonstráció, állapot, naprakész tanulási ciklus és explicit visszaállítás.
- `src/api.js`: új, azonos tokennel védett AI API végpontok; a hagyományos keresés változatlan.
- `src/db.js`: csak jóváhagyott adatforrások lekérdezése, saját optimizer szerinti ütemezés, automatikus v4 migráció.

## Védelmek

- A felügyelt modellek **nem aktiválódnak csak szintetikus példákból**.
- A magas megbízhatóságú címkék és elkülönített holdout minőségi küszöbök kötelezők.
- A források `approved=true` és `enabled=true` állapotát egy AI nem írhatja felül.
- Nincs CV- vagy személyesadat-mentés a modell-tanítótáblákba.
- A meglévő PostgreSQL és koordináta-adatok változatlanul megmaradnak.
- Nem tartalmaz automatikus, ellenőrizetlen kódátírást vagy önálló portálengedély-megkerülést.

## Fokozatosság

Az első kiadás a valódi önfejlesztő *tanítási infrastruktúra*, nem kész betanított négy nyelvi modell. Az eredményekről az `npm run ai:status` számol be, ahol a mérőszámok nem kozmetikázhatók.
