# AI Fejvadász 0.3.1 – külső kutatás és tanulási ciklus (fejlesztői kiadás)

Ez a csomag a 0.3.0 összes funkcióját megtartja. A négy könnyű saját modell rendszere mellé egy engedélyezett internetes kutató, tartósan mentett forrásforgó és egy kapacitásfigyelő komponens került. **Az éles Render még nincs átállítva** erre a verzióra.

## Funkciók

- `npm run ai:research-check -- ./config/approved-research-seeds.json`: a seed engedélyeinek és URL-jeinek offline ellenőrzése.
- `npm run ai:research`: csak `AI_EXTERNAL_RESEARCH_ENABLED=true` és előzetesen jóváhagyott seed-fájl mellett kér le korlátozott mennyiségű nyilvános oldalt. Az egyes domainekhez külön engedély és ellenőrzött robots szabályok kellenek.
- `npm run ai:research-status`: ellenőrzésre váró webes bizonyítékok mennyisége.
- `npm run ai:review-queue -- 25`: listázza az új állás- és forrásbizonyítékokat eredeti hivatkozással.
- `npm run ai:review-external -- ./reviewed-external-labels.json`: külön ember által ellenőrzött címkéket vesz át a tanításba, forrásazonosító és értékelő azonosító alapján.
- `npm run ai:market-terms`: ellenőrzött, véges szakmai kifejezés-szótár statisztikája a megengedett karrieroldalakon. Ez nem állásadatbázis-másolás és nem automatikus modellcímke.
- `npm run ai:capacity`: PostgreSQL és memória kihasználtság, időbeni bővítési riasztás. Az erőforráskereteket az üzemeltető adja meg.
- `npm run ai:cycle`: kapacitásellenőrzés → engedélyezett kutatás → tanítás előkészítése és független tesztelése.
- A felderítő és állásellenőrző számszerű megfigyeléseket kap a weboldalakról, **nem** ellenőrizetlen automatikus címkéket. A CV-illesztő csak megfelelő hozzájárulással és független értékeléssel tanulhat, nincs internetes önéletrajz-gyűjtés. Az optimalizáló a tényleges forrás-sikerességből fejlődik.

## Kötelező védelmek

- Nincs tiltott portál-scraping, bejelentkezés, CAPTCHA-megkerülés, tiltott forráshoz hozzáférés. A robots szabályok nem jelentenek felhasználási engedélyt.
- Nincs nyers HTML, személyes CV, API-kulcs vagy önkényesen generált pozitív tanítócímke tárolás. A hivatkozások, forrás- és bizonyítékadatok tárolhatók külön ellenőrzésig.
- Nem engedélyez automatikus fizetős Render-csomag váltást; a 65/80/90%-os kihasználtság alapján bővítési jelzést ad.
- A feltöltés önmagában nem indítja a kutatást. A tanítási próbák és verziófrissítés továbbra is független holdout minőségkapuhoz kötöttek.

## Telepítés – lépésenként, csak külön engedéllyel

1. Töltsd fel a ZIP-et GitHubra.
2. A Render API és Cron Build Commandját egyenként állítsd át a 0.3.1 ZIP-re; a mappa neve továbbra is `AI_Fejvadasz_Orszagos_Kereso_0_2_0/national-index`.
3. Az API Pre-Deploy Command tartalmazza `npm run migrate && npm run seed && npm run import:geonames` parancsot. Az idempotens v5 adatbázisséma előáll.
4. Csak az engedélyezett forrásmagok jóváhagyása, kapacitáskorlátok és költségkeret ellenőrzése után szabad az `ai:research` / `ai:cycle` folyamatot a Cronba kapcsolni.
5. Előbb élő ellenőrzés: kutatási státusz, manuális ellenőrzési sor, modellmetrikák, és a korábbi országos gyűjtés regressziója.

**Fontos:** a 0.3.1 csomag tesztelhető mechanizmust ad, nem négy automatikusan intelligensre betanult modellt. Az AI nem módosíthat felügyelet nélkül programkódot, hozzáférési engedélyt vagy fizetős Render erőforrást.

## Tartós forrásforgó

A kutató nem mindig a lista első N elemét dolgozza fel. Az új `national_ai_research_seed_state` táblában nyilvántartja a következő megengedett felkeresés idejét, a sikertelen források korábbi újrapróbálását és a gyűjtés eredményét. A robots Crawl-delay-t is figyelembe veszi; a Render erőforrás bővítése nem jelenti egy külső webhely lekérdezési keretének átlépését.

## Opcionális bővítési figyelmeztetés

Ha be van állítva a `AI_CAPACITY_ALERT_WEBHOOK_URL` (szigorúan HTTPS), a `ai:capacity` az újonnan elért figyelmeztetési küszöbről vagy várható 7 napos kapacitáshiányról korlátozott JSON-riasztást küld. Nem továbbít CV-t, jelszót vagy nyers állásadatokat. A webhelynek saját, az üzemeltető által engedélyezett végpontnak kell lennie. A Render fizetős csomagját nem módosítja; ehhez a tulajdonosnak költségkerettel előzetesen jóvá kell hagynia a váltást. A memóriaérték a Node folyamat RSS-memóriája, nem a teljes gép memóriahasználata.
