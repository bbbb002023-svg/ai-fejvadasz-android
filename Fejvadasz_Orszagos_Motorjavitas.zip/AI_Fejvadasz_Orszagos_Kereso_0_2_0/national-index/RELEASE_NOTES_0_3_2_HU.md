# AI Fejvadász 0.3.2 – célzott Lever-helyszínszűrés

Az éles 0.3.1-es ellenőrzés feltárta, hogy a TSMG nemzetközi Lever-álláslistája időtúllépést okoz. A hivatalos Lever Postings API támogatja az ismételhető, pontos helyszín szerinti `location` szűrést. A TSMG forrás első célzott szűrője `Budapest`, a nyilvános TSMG karrieroldal alapján.

- Új `location_filters` mező a forrásjegyzékben és az idempotens `schema-v6.sql` migrációban.
- Az adatgyűjtő csak a forráshoz explicit módon rögzített helyszínneveket teszi az API-kérésbe. A szűrők hosszát, típusát és darabszámát ellenőrzi.
- Nem módosul a felhasználó CV-adatainak kezelése. A meglévő állás- és AI-adatbázis megmarad; az API-, koordináta- és tanulási rendszer a 0.3.1-ből változatlan.
- A patch a teljes nemzetközi TSMG-forráslistát Budapest helyszínre szűkíti. Egyéb magyar városok felvétele csak a karrieroldal valós helyszínlistájának ellenőrzése után történjen; a szűkítés önmagában nem igazolja a teljes országos lefedettséget.
- Teszt: `npm test` és a ZIP-ből kibontott változat újratesztelése.

**Telepítés:** teljes ZIP GitHubra; API és Cron Build Command átállítása erre a ZIP-re. Az API `migrate && seed && import:geonames` pre-deploy parancsa automatikusan telepíti a helyszínszűrőt, a korábbi forrás-engedélyezési állapotokat megtartva. Külön éles futással ellenőrizni kell a Lever válaszidejét és a magyarországi eredményeket.

**Hivatalos API-dokumentáció:** https://github.com/lever/postings-api
**TSMG nyilvános budapesti állásoldal:** https://jobs.lever.co/tsmg?location=Budapest
