# AI Fejvadász 0.3.3 – intelligens újrapróbálás és célzott kézi teszt

**Hibajavítás:** a 0.3.2-es gyűjtő hibánál mindig 60 perc várakozást írt elő, és a Render Trigger Run ugyanúgy kihagyta a nem esedékes forrásokat. Ezért a fejlesztői tesztek 0 forrással futottak.

## Új működés

- **Normál automatikus gyűjtés:** sikeres forrásnál marad az eddigi frissítési időzítés. Átmeneti időtúllépésnél az újrapróbálás 5, 10, 20, 40, majd legfeljebb 60 perc, az egymást követő hibáktól függően; egyéb hiba 10-120 perc. Siker esetén az egymást követő hibák számlálója nullázódik.
- **Tiltás / sebességkorlát:** HTTP 401/403-nál 240 perc, HTTP 429-nél 120 perc, a célzott kézi teszt sem írja felül ezt a várakozást. A webhelyek használati szabályait továbbra is tiszteletben kell tartani.
- **Régi 60 perces várakozások:** a 0.3.2-es verzióban már hibás forrásokra egyetlen korábbi próbát engedünk legalább 5 perc múltán; csak akkor, ha nem 401/403/429 hiba volt. Új hibánál már az új exponenciális szabály él.
- **Célzott kézi próba:** `npm run collect:retry -- lever:tsmg` csak az engedélyezett `lever:tsmg` forrást ellenőrzi, a normál `next_due_at` várakozástól függetlenül. Nincs szükség 1 óra várakozásra. Ugyanazon forrás két kézi tesztje között legalább 2 percnek, az előző tetszőleges gyűjtéstől legalább 60 másodpercnek el kell telnie. A célzott teszt is ugyanazokat a naplókat és adatellenőrzéseket használja.
- **Biztonság:** a rendszer kizárólag engedélyezett és bekapcsolt forrásokat kezel; nem tesztelhető ismeretlen vagy `registry` forrás. Közös PostgreSQL advisory lock védi az időzített és kézi gyűjtések ütközését. Csak egy kiválasztott forrás lekérése történik. Az esetleges forrásoldali 429-et, 401-et vagy 403-at tiszteletben tartjuk.
- **Idempotens migráció:** `schema-v7.sql` hozzáadja a `consecutive_failures`, `last_manual_retry_at` oszlopokat, adatvesztés nélkül. Először az **országos API** Build Commandját frissítsd erre a ZIP-re (a meglévő `migrate && seed && import:geonames` Pre-deploy parancs létrehozza az oszlopokat), majd az **országos Cron** Build Commandját. Az AI-ciklus, a 17 engedélyezett forrás, a saját állásadatbázis és a GeoNames helyadatok változatlanok.

## Használat és teszt

- `npm test` – valamennyi lokális teszt (köztük új időzítési és jogosultsági tesztek).
- `npm run collect` – normál esedékességi gyűjtés.
- `npm run collect:retry -- lever:tsmg` – egyetlen forrás célzott tesztje Node-parancssorból vagy olyan Render egyszeri jobban, ahol a start command kiválasztható. A meglévő Cron Job **Trigger Run** gombja továbbra is a Cronban beállított parancsot indítja, nem egy tetszőleges célzott tesztet.

**Fontos:** a ZIP-beli automatikus tesztek nem bizonyítják, hogy a külső TSMG jelenleg ténylegesen elérhető. Ezt külön éles futással ellenőrizni kell. A Render Cron eredeti `0 */4 * * *` időzítése 4 óránként indul; a rövidebb hibavárakozás nem gyorsítja meg automatikusan az egész Cron ütemezését. Gyakoribb ellenőrzéshez az ütemezést később külön kell átállítani és költségét ellenőrizni.
