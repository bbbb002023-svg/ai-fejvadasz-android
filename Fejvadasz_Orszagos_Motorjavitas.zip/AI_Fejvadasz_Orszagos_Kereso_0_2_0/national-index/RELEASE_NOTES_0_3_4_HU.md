# AI Fejvadász 0.3.4 – két külön CV-portál kereső

**Új API:** `POST /api/v3/cv-portal-search` a meglévő `Authorization: Bearer NATIONAL_API_TOKEN` mellett.

Ez a két különálló, párhuzamos, nagy portálra korlátozott CV-kereső:

1. `profession_cv` – kizárólag Profession.hu találatok, célmunkakör elsőbbséggel.
2. `cvonline_cv` – kizárólag CVonline.hu találatok, szakmai készségekkel súlyozva.

Az általános országos ATS-gyűjtő változatlanul működik, a CV-keresők nem egészítik ki annak nyilvános álláskatalógusát. A négy célfeladatra épített AI tanítását ez a kiadás nem állítja, hogy befejezte volna.

## Adatvédelem és jogtisztaság

- Egy keresés kizárólag `externalSearchConsent: true` esetén indul.
- Kizárólag strukturált, a CV-ből jóváhagyott `targetRoles`, `skills`, `locations` kerülnek a Brave Search API lekérdezésébe. Teljes önéletrajz, név, e-mail, telefonszám nem.
- Nincs közvetlen Profession/CVonline HTML-letöltés vagy tömeges adatmentés, és portáladatból történő AI-tanítás.
- A találatok csak keresőindex-cím és rövid leírás alapján előszűrtek, nem ellenőrzött aktív hirdetések; nem szerepel mellettük koholt százalék.
- A rendszer memóriában limitálja a kereséseket és nem menti a profilokat az adatbázisba.

## Előfeltétel

A nemzeti API-szolgáltatáson `BRAVE_SEARCH_API_KEY` (vagy `BRAVE_API_KEY`) kell. Ha nincs kulcs, a végpont világos `not_configured` állapotot ad, nem hazudik találatokat. A Brave Search API önálló, külső szolgáltatás, esetleges díjazását ellenőrizni kell. A `NATIONAL_API_TOKEN` továbbra is szükséges.

## Telefonos app

Ez szerveroldali funkció: **a jelenlegi 0.9.7-es APK még a régi szervert használja**. Az új végpontot a következő Android-integrációs kiadásba be kell kötni (profilhozzájárulással és a visszaküldött linkek megjelenítésével). Addig nem állítjuk, hogy az appból használható.

## Teszt

`npm test` – egységtesztek, mock Brave-válaszok, API-védelem, domain-tisztaság, profil-adatvédelem. Éles portál-API teszt csak tényleges, engedélyezett Brave kulccsal.
