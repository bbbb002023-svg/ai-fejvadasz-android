import json
from urllib.parse import urlparse
from pathlib import Path
p=Path(__file__).parent/'sources.json'
s=[]
def ats(engine,board,name,company):
 s.append({'source_key':f'{engine}:{board.lower()}','name':name,'category':'employer','engine':engine,'board':board,'company':company,'enabled':True,'approved':True,'country_scope':'mixed','notes':'Nyilvános ATS-karrieroldal alapján felvett kezdőforrás, éles API-t még ellenőrizni kell.'})
for e,b,n in [('lever','Civitta','Civitta'),('lever','aleph','Aleph'),('lever','ion','ION Group'),('lever','tsmg','TSMG'),('lever','qualysoft','Qualysoft'),('ashby','instructure','Instructure'),('ashby','freetrade','Freetrade'),('ashby','hawkeyeinnovations','Hawk-Eye Innovations'),('smartrecruiters','Hiflylabs','Hiflylabs')]:ats(e,b,n,n)

def reg(name,url,cat):
 host=urlparse(url).hostname
 s.append({'source_key':f'registry:{host.lower()}','name':name,'category':cat,'engine':'registry','url':url,'company':name if cat=='employer' else None,'enabled':False,'approved':False,'country_scope':'mixed','notes':'Kutatott forrásjelölt. Nem gyűjt aktívan, amíg nincs ellenőrzött API/feed/sitemap csatlakozó és hozzáférési jogosultság.'})
for n,u in [
 ('Profession.hu','https://www.profession.hu'),('CVonline','https://www.cvonline.hu'),('Indeed HU','https://hu.indeed.com'),('Jooble HU','https://hu.jooble.org'),('Careerjet HU','https://www.careerjet.hu'),('Mumi.hu','https://mumi.hu'),('Allasklikk','https://www.allasklikk.hu'),('Jófogás Állás','https://allas.jofogas.hu'),('Workania','https://www.workania.hu'),('Közszolgállás','https://kozszolgallas.ksz.gov.hu'),('EURES','https://eures.europa.eu'),('DreamJobs','https://dreamjobs.hu'),('Zyntern','https://zyntern.com'),('Meló-Diák','https://www.melodiak.hu'),('Mind-Diák','https://www.minddiak.hu')]:reg(n,u,'portal')
for n,u in [
 ('Hays Hungary','https://www.hays.hu'),('Randstad Hungary','https://www.randstad.hu'),('Adecco Hungary','https://www.adecco.hu'),('Trenkwalder Hungary','https://hu.trenkwalder.com'),('WHC','https://whc.hu'),('HSA','https://www.hsa.hu'),('Manpower Hungary','https://www.manpower.hu'),('Gi Group Hungary','https://hu.gigroup.com'),('Grafton Recruitment','https://www.grafton.hu'),('Bluebird','https://bluebird.hu'),('Enloyd','https://enloyd.hu'),('Prohuman','https://prohuman.hu'),('Pannon-Work','https://pannonwork.hu'),('Delego','https://www.delego.hu'),('Jobtain','https://jobtain.hu'),('Humanfield','https://humanfield.hu')]:reg(n,u,'recruiter')
for n,u in [
 ('OTP Bank','https://karrier.otpbank.hu'),('MOL','https://karrier.mol.hu'),('ALDI','https://karrier.aldi.hu'),('Lidl','https://jobs.lidl.hu'),('Tesco','https://karrier.tesco.hu'),('SPAR','https://spar.karrierportal.hu'),('Auchan','https://karrier.auchan.hu'),('Rossmann','https://www.rossmann.hu'),('DM','https://www.dm.hu'),('Bosch','https://www.bosch.hu'),('Magyar Telekom','https://www.telekom.hu'),('Yettel','https://www.yettel.hu'),('One Hungary','https://www.one.hu'),('MVM','https://mvm.karrierportal.hu'),('Richter Gedeon','https://careers.gedeonrichter.com'),('Egis','https://www.egis.hu'),('Magyar Posta','https://karrier.posta.hu'),('Wizz Air','https://careers.wizzair.com'),('MÁV','https://karrier.mavcsoport.hu'),('Audi Hungaria','https://www.audi.hu'),('Mercedes-Benz','https://group.mercedes-benz.com'),('Knorr-Bremse','https://www.knorr-bremse.hu'),('Continental','https://www.continental.com'),('Suzuki','https://www.suzuki.hu'),('E.ON Hungária','https://www.eon.hu'),('UniCredit Bank','https://www.unicreditbank.hu'),('K&H Bank','https://www.kh.hu'),('Erste Bank','https://www.erstebank.hu'),('MBH Bank','https://www.mbhbank.hu'),('Penny','https://www.penny.hu')]:reg(n,u,'employer')
p.write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(s),'sources,',sum(x['enabled'] for x in s),'enabled ATS seeds,',sum(x['engine']=='registry' for x in s),'registry-only')
