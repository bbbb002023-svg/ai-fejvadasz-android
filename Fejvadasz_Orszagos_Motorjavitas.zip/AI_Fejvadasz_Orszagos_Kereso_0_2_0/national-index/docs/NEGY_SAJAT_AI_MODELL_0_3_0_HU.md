# AI Fejvadász – négy saját, fokozatosan önfejlesztő AI (0.3.0)

**Státusz:** fejlesztői/tesztkiadás. A 0.2.2 országos indexszel kompatibilis. A cél az, hogy később az alacsony költségű, saját modelljeink oldják meg a rutinmunkát. **Ez a csomag négy modell algoritmusát és a hozzájuk tartozó tanítási infrastruktúrát tartalmazza; három modell még nem tekinthető betanítottnak az éles rendszeren.**

## A négy modell

1. **SourceScout (forrásfelmérő):** tanítható logisztikus osztályozó. A nyilvános feed, robots-jelzések, dokumentált engedély, ATS-hivatkozás, korábbi sikeresség és magyar állásszám alapján ad tanácsadó pontszámot. Nem végez automatikus, tiltást megkerülő webkaparást; nem tudja felülírni a jóváhagyási státuszt.
2. **JobVerifier (állásellenőrző):** külön tanítható osztályozó. URL-, cím-, vállalat-, helyszín-, leírás- és időbeli jegyekből ad **becsült** érvényességi pontszámot. A pontszám önmagában *nem* bizonyítja, hogy az állás a webhelyen ma is nyitott; ezt a forrásellenőrzésnek kell igazolnia.
3. **CV Match (illesztő):** külön tanítható osztályozó. A CV-ből kinyert kompetenciák és a hirdetés **ideiglenes, numerikus jellemzőit** hasonlítja össze. A CV-t, nevet, e-mailt, telefonszámot és szabad szövegű profilt az AI-tanítótáblákba nem menti. A valódi tanításhoz függetlenül címkézett vagy megfelelően hozzájárult, felülvizsgált visszajelzés kell.
4. **SearchOptimizer (keresőmotor-optimalizáló):** UCB-szerű kontextuális pontozó; a jóváhagyott források siker- és hibaszámaiból, valamint magyar állásszámaiból **minden futásban** új prioritást számít. Külön GPU-t nem igényel. Nem módosít automatikusan a forrásengedélyeken.

A négy modell egy közös, verziózott PostgreSQL tanító- és kiértékelő rendszert használ. A tanítást a `national_ai_examples` táblában tárolt, **ellenőrzött** 0/1 címkék vezérlik. A nyilvános állások és források numerikus jellegzetességeit az `ai:improve` automatikusan felveszi az `national_ai_review_queue` listába; a címkéket nem találja ki.

## Önálló fejlesztési ciklus

```
Éles gyűjtés és forrásmérés
    → numerikus tanítójelölt-gyűjtés (nem bizalmas adatok)
    → független címkézés és jóváhagyás
    → jelölt modell tanítása
    → elkülönített holdout kiértékelés
    → csak bizonyítható javulás esetén automatikus modellváltás
    → verziózott mentés / kézi visszaállítás
```

Az `ai:improve` hívás **nem generál ál-valós címkéket**. Azért fontos ez, mert valótlan tanítócímkékből a modell hibás magabiztosságot tanulna. A felügyelt modellek megkezdett tanulásához legalább 32–40 függetlenül címkézett tanítópélda és 12–16 független tesztpélda szükséges modellenként, mindkét osztályban megfelelő mintaszámmal. Mindezek önmagukban még nem jelentenek jó minőséget. Az automatikus aktiválás küszöbei: legalább **82% holdout pontosság**, legalább **75% visszahívás**, legalább **80% precizitás**, a JobVerifier esetén **90% precizitás**; korábbi aktív modellhez képest romlás sem engedett meg a beállított tolerancián túl. A tesztpéldák nem szerepelhetnek a tanítóadatok között.

**Az új felügyelt modellek addig NEM AKTÍVAK**, amíg nincsenek valóban ellenőrzött címkék. Az API `409 awaiting_verified_training` státusszal jelzi ezt. A hagyományos álláskeresés és az országos adatbázis tovább működik.

## Helyi ellenőrzés (Node.js 20+)

```sh
cd AI_Fejvadasz_Orszagos_Kereso_0_2_0/national-index
npm install --omit=dev
npm test
npm run ai:demo
```

**Figyelem:** az `ai:demo` mesterséges, túl könnyű, elkülönített tesztadaton mutatja meg, hogy a tanuló algoritmus képes változtatni a súlyain. A demo 100%-os eredménye **nem éles modellpontosság**, és nem aktivál modellt.

## Render telepítés (egyelőre ne változtass automatikusan az éles rendszeren)

A korábban létrehozott két Render-szolgáltatás és PostgreSQL marad. Az új ZIP-et a GitHub gyökérbe kell feltölteni, majd a **Build Command** ZIP-nevét **mindkét szolgáltatásban** az új fájlra cserélni.

```sh
unzip -oq Fejvadasz_Orszagos_4_Sajat_AI_Modell_0_3_0.zip -d . && cd AI_Fejvadasz_Orszagos_Kereso_0_2_0/national-index && npm install --omit=dev
```

API Pre-deploy (a `schema-v4.sql` migrációja automatikusan a `migrate` része, a GeoNames-adatbázis megmarad):

```sh
cd AI_Fejvadasz_Orszagos_Kereso_0_2_0/national-index && npm run migrate && npm run seed && npm run import:geonames
```

Cron Command, **csak az API sikeres frissítése után**:

```sh
cd AI_Fejvadasz_Orszagos_Kereso_0_2_0/national-index && npm run collect && npm run geocode && npm run ai:improve && npm run embed
```

A korábbi `DATABASE_URL`, `NATIONAL_API_TOKEN`, cron időzítés és a keresőmotorok beállításai nem változnak. **Többlet GPU / Render-előfizetés nem kell az első verzióhoz.** A cron futásának időtartama és a PostgreSQL-tárhely minimálisan nőhet.

## Tanítási parancsok

```sh
npm run ai:status             # modellek valódi állapota
npm run ai:optimizer          # saját motorok aktuális prioritása
npm run ai:review-queue       # várakozó, nyilvános forrás-/állásjelöltek
npm run ai:ingest -- ./ellenorzott-cimkek.json
npm run ai:improve            # tanítás + kiértékelés + minőségkapu
```

**Címkézett JSON-formátum:** egy tömb, amelynek minden eleme tartalmazza a `model_key` (`scout`/`verifier`/`matcher`), `features` (a megfelelő 8 darab 0–1 közötti jellemző), `label` (0 vagy 1), `split` (`train` vagy `holdout`), `reviewed:true`, `origin` (`manual_review`, `licensed_dataset` vagy `opt_in_feedback`) mezőket; opt-in visszajelzés esetén `consent:true` kötelező. A modellnyers szöveg és személyes adatok **nem** megengedettek a jellemzőkben. A tényleges független felülvizsgálatot a rendszer nem tudja önállóan bizonyítani: az importálónak kell felelősen biztosítania.

**Kézi visszaállítás:** `AI_ALLOW_MANUAL_ROLLBACK=YES npm run ai:rollback -- matcher 123` (a 123 a korábbi verzió azonosítója). A modellkódot az AI nem írja át.

## Belső API-végpontok

* `GET /health` — meglévő egészségellenőrzés.
* `GET /api/v3/ai/status` — a négy modell állapota, tanítócímkék száma, várakozó ellenőrzések.
* `GET /api/v3/ai/optimizer` — motoronkénti, operatív adatokból számolt ajánlott prioritás.
* `POST /api/v3/ai/score` — csak **már élesített** osztályozó tanácsadó pontszáma; kizárólag numerikus `features` objektummal.
* `POST /api/v3/ai/recommend` — a meglévő országos keresés; az aktív saját Match AI-val rangsorol, ha van biztonságosan bevezetett változat. A CV-adatot nem tárolja a tanítóadatbázisban.

Az AI API-khoz továbbra is kell a `Authorization: Bearer <NATIONAL_API_TOKEN>` fejléc. A titkos tokeneket sem GitHub-fájlba, sem képernyőképre nem szabad tenni.

## Az OpenAI mint kezdeti segéd és későbbi tartalék

Az OpenAI használható futás közbeni bonyolult értelmezésre, de a válaszait nem csatornázzuk be automatikusan e saját, helyettesítésre tervezett modellek tanítóadataiba. A tanítóanyag alapja jogszerű nyilvános állásadat, önállóan ellenőrzött címkék és hozzájárulással gyűjtött, felülvizsgált visszajelzés. Ezzel a saját modellek fokozatosan átvehetik a rutinmunkát, a külső API pedig később tartalék lehet.

## Amit ez még NEM jelent

* A 4 algoritmus megvalósítása nem 4 nagy, általános nyelvi modell betanítása.
* A 3 felügyelt modell tesztadatai szintetikusak; éles készségük még nem igazolt.
* A SourceScout jelenleg **forrásértékelő modell**, nem önállóan böngésző robot; a valódi forrás-feltérképező szolgáltatást külön kell bekötni.
* Az állásellenőrző valós hirdetésigazolásához élő URL-ellenőrzés és jóváhagyott forrásadat szükséges.
* Az 1000 magyar állás / gyűjtőmotor **teljesítménycél**, nem a modellkiadás ígérete.
* A jelenlegi régi Android/HTML alkalmazás 0.9.7-es keresésének bekötése az új API-ba ettől még külön feladat.
