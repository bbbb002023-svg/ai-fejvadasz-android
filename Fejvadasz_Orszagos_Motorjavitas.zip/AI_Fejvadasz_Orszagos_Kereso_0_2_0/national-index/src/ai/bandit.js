'use strict';
/** Deterministic, bounded upper-confidence bandit for scheduling approved sources. */
const {bounded}=require('./features');
function snapshot(source={}){
 const successes=Math.max(0,Number(source.success_count)||0),failures=Math.max(0,Number(source.fail_count)||0),attempts=successes+failures;
 const hu=Math.max(0,Number(source.verified_hu_count)||0);
 const expected=(successes+1)/(attempts+2),yieldScore=bounded(Math.log1p(hu)/Math.log1p(1000));
 const confidence=attempts?Math.min(1,Math.sqrt(2*Math.log(2+attempts)/(2+attempts))):1;
 const value=bounded(0.65*expected+0.35*yieldScore+0.25*confidence,0,1);
 return {source_key:source.source_key,engine:source.engine,attempts,successes,failures,hu_seen:hu,success_estimate:expected,exploration_bonus:confidence,priority:value};
}
function prioritize(sources){return [...sources].sort((a,b)=>snapshot(b).priority-snapshot(a).priority||String(a.source_key).localeCompare(String(b.source_key)))}
function report(sources){const grouped=new Map();for(const x of sources){if(!x.approved||!x.enabled)continue;const k=x.engine,r=grouped.get(k)||{engine:k,active_sources:0,attempts:0,successes:0,hu_seen:0,errors:0};r.active_sources++;r.attempts+=(Number(x.success_count)||0)+(Number(x.fail_count)||0);r.successes+=Number(x.success_count)||0;r.hu_seen+=Number(x.verified_hu_count)||0;r.errors+=Number(x.fail_count)||0;grouped.set(k,r)}return {algorithm:'ucb-verified-outcomes-v1',ranked:prioritize(sources.filter(s=>s.approved&&s.enabled)).map(snapshot),engines:[...grouped.values()].sort((a,b)=>b.hu_seen-a.hu_seen),note:'Csak a jóváhagyott, aktív forrásokat rangsorolja; tiltást vagy új forrásengedélyt nem kerül meg.'}}
module.exports={snapshot,prioritize,report};
