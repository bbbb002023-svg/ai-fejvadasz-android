'use strict';
/** Pre-emptive capacity planning. Never authorizes paid scaling or touches Render credentials. */
const {canonicalUrl}=require('../normalize');
function number(x,fallback=null){const n=Number(x);return Number.isFinite(n)&&n>0?n:fallback;}
function percent(used,limit){return limit&&limit>0?Math.round(10000*used/limit)/100:null;}
function evaluate({dbBytes,dbLimitGb,memoryUsedBytes,memoryLimitMb,growthBytesPerDay=0,alertsAt=[65,80,90]}={}){
 const gb=1024**3,mb=1024**2,usedDb=Number(dbBytes)||0,usedMemory=Number(memoryUsedBytes)||0;
 const dbLimit=number(dbLimitGb)?Number(dbLimitGb)*gb:null,memoryLimit=number(memoryLimitMb)?Number(memoryLimitMb)*mb:null;
 const dbPercent=percent(usedDb,dbLimit),ramPercent=percent(usedMemory,memoryLimit);
 const peak=Math.max(dbPercent??0,ramPercent??0);const [warn,expand,critical]=alertsAt;
 const state=(!dbLimit&&!memoryLimit)?'unconfigured':peak>=critical?'critical':peak>=expand?'expansion_recommended':peak>=warn?'capacity_watch':'normal';
 const projectedDays=dbLimit&&Number(growthBytesPerDay)>0?Math.max(0,(dbLimit*expand/100-usedDb)/growthBytesPerDay):null;
 const action=state==='unconfigured'?'configure_limits':projectedDays!==null&&projectedDays<=7?'plan_expansion_within_7_days':state==='normal'?'monitor':state==='capacity_watch'?'review_growth_trend':'review_and_approve_capacity_upgrade';
 return {state,action,db:{bytes:usedDb,limitBytes:dbLimit,usedPercent:dbPercent},memory:{bytes:usedMemory,limitBytes:memoryLimit,usedPercent:ramPercent},daysUntilExpansionThreshold:projectedDays!==null?Math.round(projectedDays*10)/10:null,thresholds:{watch:warn,expand,critical},paidScaling:'never_automatic_without_explicit_approval'};
}
async function check(pool,{env=process.env,memoryUsage=process.memoryUsage(),persist=true,now=new Date(),request=globalThis.fetch}={}){
 const r=await pool.query('SELECT pg_database_size(current_database())::bigint AS db_bytes');const dbBytes=Number(r.rows[0]?.db_bytes||0);
 let trend=0,prior=null;
 try{
  const prev=(await pool.query('SELECT db_bytes,recorded_at,alert_status FROM national_ai_capacity_snapshots ORDER BY recorded_at DESC LIMIT 1')).rows[0];
  prior=prev;const days=prev?(now-new Date(prev.recorded_at))/86400000:0;
  if(days>=1/24)trend=Math.max(0,(dbBytes-Number(prev.db_bytes))/days);
 }catch(e){if(!/does not exist/i.test(e.message))throw e;}
 const report=evaluate({dbBytes,dbLimitGb:env.AI_CAPACITY_DB_LIMIT_GB,memoryUsedBytes:memoryUsage.rss,memoryLimitMb:env.AI_CAPACITY_RAM_LIMIT_MB,growthBytesPerDay:trend});
 if(persist)await pool.query('INSERT INTO national_ai_capacity_snapshots(db_bytes,memory_bytes,db_utilization_pct,memory_utilization_pct,alert_status) VALUES($1,$2,$3,$4,$5)',[dbBytes,memoryUsage.rss,report.db.usedPercent,report.memory.usedPercent,report.action]);
 let alertDelivery='not_configured';
 const url=env.AI_CAPACITY_ALERT_WEBHOOK_URL;
 if(url && report.action!=='monitor' && report.action!==prior?.alert_status){
  const safe=canonicalUrl(url);
  if(!safe)alertDelivery='invalid_webhook_url';
  else{
   try{
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),5000);
    let response;try{response=await request(safe,{method:'POST',redirect:'manual',signal:controller.signal,headers:{'Content-Type':'application/json'},
      body:JSON.stringify({application:'ai-fejvadasz',event:'capacity_warning',state:report.state,action:report.action,
       dbUsedPercent:report.db.usedPercent,memoryUsedPercent:report.memory.usedPercent,daysUntilExpansionThreshold:report.daysUntilExpansionThreshold,
       requiresHumanCostApproval:true})});}finally{clearTimeout(timer)}
    alertDelivery=response?.ok?'delivered':'http_failed';
   }catch{alertDelivery='failed';}
  }
 }else if(url)alertDelivery='not_needed';
 return {...report,alertDelivery,configurationNote:!env.AI_CAPACITY_DB_LIMIT_GB||!env.AI_CAPACITY_RAM_LIMIT_MB?'Set AI_CAPACITY_DB_LIMIT_GB and AI_CAPACITY_RAM_LIMIT_MB to get reliable early warnings.':'Capacity limits are operator-configured; not read from Render billing API.'};
}
module.exports={evaluate,check,percent};
