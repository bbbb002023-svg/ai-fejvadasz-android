'use strict';
const fs=require('node:fs');
const db=require('../db');const learning=require('./learning');const bandit=require('./bandit');const logistic=require('./logistic');const {SPECS}=require('./features');const external=require('./external');const capacity=require('./capacity');
async function run(mode,args=[]){
 if(mode==='ai-research-check'){
  const file=args[0]||process.env.AI_RESEARCH_SEEDS_FILE;
  if(!file)throw Error('Usage: ai-research-check ./approved-research-seeds.json');
  const seeds=external.readSeeds(file);
  console.log(JSON.stringify({valid:true,reviewed_seeds:seeds.length,hosts:seeds.map(x=>x.host),note:'Config validation only; zero network requests.'},null,2));return;
 }
 if(mode==='ai-demo'){
  const result={note:'Synthetic test data only; NOT a production trained model',models:[]};
  for(const key of ['scout','verifier','matcher']){
   const f=SPECS[key].features;
   const examples=Array.from({length:160},(_,i)=>{const positive=i%2===0;const features=Object.fromEntries(f.map((name,j)=>[name,positive?(j%3?0.75:0.95):(j%3?0.20:0.05)]));return {features,label:+positive}});
   const m=logistic.train(key,examples.slice(0,120));result.models.push({key,metrics:logistic.evaluate(m,examples.slice(120))});
  }
  result.models.push({key:'optimizer',algorithm:'ucb-verified-outcomes-v1',status:'trained_from_real_source_counters_after_ai-improve'});
  console.log(JSON.stringify(result,null,2));return;
 }
 const pool=db.newPool();try{
  if(mode==='ai-research')console.log(JSON.stringify(await external.research(pool,{seedsFile:args[0]||process.env.AI_RESEARCH_SEEDS_FILE}),null,2));
  else if(mode==='ai-capacity')console.log(JSON.stringify(await capacity.check(pool),null,2));
  else if(mode==='ai-cycle'){
   const capacityBefore=await capacity.check(pool),research=await external.research(pool,{seedsFile:args[0]||process.env.AI_RESEARCH_SEEDS_FILE});
   // Limits are warnings: research is bounded per-run, and promotion is gated by independent holdouts.
   const learningResult=await learning.improve(pool);
   console.log(JSON.stringify({capacity:capacityBefore,research,learning:learningResult,policy:'new web evidence always pending review; no automatic paid scaling'},null,2));
  }
  else if(mode==='ai-market-terms'){
   const r=await pool.query(`SELECT m.term,COUNT(*)::int AS observed_count,COUNT(*) FILTER (WHERE e.review_status='reviewed')::int AS independently_reviewed_count
      FROM national_ai_market_terms m JOIN national_ai_external_evidence e ON e.observation_key=m.observation_key
      GROUP BY m.term ORDER BY observed_count DESC, m.term LIMIT 100`);
   console.log(JSON.stringify({terms:r.rows,note:'Public-job vocabulary only; observation is not a training label. Independently review before trusting.'},null,2));
  }
  else if(mode==='ai-review-external'){
   if(!args[0])throw Error('Usage: npm run ai:review-external -- ./verified-external-labels.json');
   console.log(JSON.stringify(await external.ingestReviewed(pool,args[0]),null,2));
  }
  else if(mode==='ai-research-status'){
   const res=await pool.query('SELECT model_key,review_status,COUNT(*)::int AS total FROM national_ai_external_evidence GROUP BY model_key,review_status');
   console.log(JSON.stringify({evidence:res.rows,policy:'External research is not labeled training data'},null,2));
  }
  else if(mode==='ai-improve')console.log(JSON.stringify(await learning.improve(pool),null,2));
  else if(mode==='ai-status')console.log(JSON.stringify(await learning.status(pool),null,2));
  else if(mode==='ai-ingest'){
   if(!args[0])throw Error('Usage: npm run ai:ingest -- ./reviewed-labels.json');console.log(JSON.stringify(await learning.ingest(pool,args[0]),null,2));
  }else if(mode==='ai-optimizer'){
   const r=await pool.query("SELECT source_key,engine,approved,enabled,success_count,fail_count,verified_hu_count FROM national_sources WHERE enabled AND approved");console.log(JSON.stringify(bandit.report(r.rows),null,2));
  }else if(mode==='ai-review-queue'){
   const n=Math.min(100,Math.max(1,Number(args[0])||25));
   const r=await pool.query(`SELECT q.review_id,q.model_key,q.sample_ref,q.features,q.created_at,
      COALESCE(j.title,e.title) AS title, COALESCE(j.company,e.company) AS company,
      COALESCE(j.canonical_url,e.public_url) AS canonical_url,
      COALESCE(j.location_text,e.location_text) AS location_text,
      COALESCE(s.name,e.company) AS source_name, e.permission_basis AS external_permission_basis
    FROM national_ai_review_queue q
    LEFT JOIN national_jobs j ON q.model_key='verifier' AND q.sample_ref=j.job_key
    LEFT JOIN national_sources s ON q.model_key='scout' AND q.sample_ref=s.source_key
    LEFT JOIN national_ai_external_evidence e ON q.sample_ref=e.observation_key
    WHERE q.status='pending' ORDER BY q.created_at LIMIT $1`,[n]);
   console.log(JSON.stringify({count:r.rows.length,rows:r.rows,note:'Manual review needed. An AI guess is not an independently verified label.'},null,2));
  }else if(mode==='ai-rollback'){
   if(process.env.AI_ALLOW_MANUAL_ROLLBACK!=='YES')throw Error('Set AI_ALLOW_MANUAL_ROLLBACK=YES for explicit audited rollback');
   const [key,id]=args;if(!['scout','verifier','matcher','optimizer'].includes(key)||!/^\d+$/.test(String(id)))throw Error('Usage: ai-rollback MODEL_KEY VERSION_ID');
   const client=await pool.connect();try{await client.query('BEGIN');const older=await client.query('SELECT version_id FROM national_ai_model_versions WHERE version_id=$1 AND model_key=$2',[id,key]);if(!older.rows.length)throw Error('Version not found');await client.query("UPDATE national_ai_model_versions SET status='rejected' WHERE model_key=$1 AND status='active'",[key]);await client.query("UPDATE national_ai_model_versions SET status='active',activated_at=NOW() WHERE version_id=$1 AND model_key=$2",[id,key]);await client.query('COMMIT');console.log(JSON.stringify({rolled_back:true,model:key,version:id}));}catch(e){await client.query('ROLLBACK');throw e}finally{client.release()}
  }else throw Error('Unknown AI mode: '+mode);
 }finally{await pool.end()}
}
module.exports={run};
