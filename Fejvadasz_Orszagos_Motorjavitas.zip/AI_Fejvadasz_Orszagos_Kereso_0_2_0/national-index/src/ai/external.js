'use strict';
/**
 * Bounded, permission-gated public career-site research for four specialist AI modules.
 * Robots is a technical crawl restriction, NOT a substitute for legal permission.
 * Nothing observed on the open web is automatically a reviewed training label.
 */
const fs=require('node:fs');
const crypto=require('node:crypto');
const {parseJobPosting}=require('../engines');
const {canonicalUrl}=require('../normalize');
const {jobFeatures,scoutFeatures,featuresFor}=require('./features');
const {SPECS}=require('./features');const {termsFromJob}=require('./terms');
const AGENT='AI-Fejvadasz-Research/0.3.1 (+public career research; contact site owner)';
const sha=x=>crypto.createHash('sha256').update(String(x)).digest('hex');
const int=(x,def,low,high)=>{const n=Number(x);return Number.isInteger(n)&&n>=low&&n<=high?n:def};
const capBytes=(x,def,low,high)=>int(x,def,low,high);
const clean=x=>String(x||'').replace(/[\u0000-\u001f\u007f]/g,' ').replace(/\s+/g,' ').trim();
const safeUrl=(s,origin=null)=>{
 let u;try{u=new URL(s,origin||undefined)}catch{return null}
 const canonical=canonicalUrl(u.href);if(!canonical)return null;
 // DNS must not be chosen from unknown URLs: only the explicitly whitelisted seed host.
 if(origin && new URL(canonical).origin!==new URL(origin).origin)return null;
 return canonical;
};
function validateSeed(input){
 if(!input||typeof input!=='object'||Array.isArray(input))throw Error('Research seed object required');
 const url=safeUrl(input.url);
 if(!url)throw Error('Unsafe research seed URL');
 if(input.approved_for_research!==true||input.permission_reviewed!==true)throw Error('Research seed requires explicit reviewed permission');
 const owner=clean(input.owner||'').slice(0,120);
 const license=clean(input.permission_basis||'').slice(0,180);
 if(!owner||!license||/^(unknown|none|robots|public)$/i.test(license))throw Error('Research seed needs named owner and explicit permission basis');
 return {url,origin:new URL(url).origin,host:new URL(url).hostname,owner,permission_basis:license,approved_for_research:true,permission_reviewed:true,
  max_pages:int(input.max_pages,4,1,8),country_scope:input.country_scope==='hu_only'?'hu_only':'mixed'};
}
function readSeeds(file){
 const rows=JSON.parse(fs.readFileSync(file,'utf8'));
 if(!Array.isArray(rows)||rows.length>80)throw Error('Expected at most 80 reviewed research seeds');
 const seen=new Set();return rows.map(validateSeed).filter(x=>{if(seen.has(x.url))return false;seen.add(x.url);return true});
}
function robotsGroups(txt){
 const groups=[];let current=null,seenRules=false;
 for(const raw of String(txt).split(/\r?\n/)){
  const line=raw.replace(/\s*#.*$/,'').trim();if(!line)continue;
  const pos=line.indexOf(':');if(pos<0)continue;
  const key=line.slice(0,pos).trim().toLowerCase(),v=line.slice(pos+1).trim();
  if(key==='user-agent'){
   if(!current||seenRules){current={agents:[],rules:[],crawlDelay:0};groups.push(current);seenRules=false}
   current.agents.push(v.toLowerCase());continue;
  }
  if(!current)continue;
  if(key==='allow'||key==='disallow'){
   seenRules=true;if(v.startsWith('/'))current.rules.push({path:v,type:key});
  }else if(key==='crawl-delay'){
   seenRules=true;const n=Number(v);if(Number.isFinite(n)&&n>=0)current.crawlDelay=Math.min(30,n);
  }
 }
 return groups;
}
function robotsPolicy(txt,agent='ai-fejvadasz-research'){
 const groups=robotsGroups(txt),named=groups.filter(g=>g.agents.some(a=>a!=='*'&&agent.includes(a)));
 const selected=named.length?named:groups.filter(g=>g.agents.includes('*'));
 const rules=selected.flatMap(g=>g.rules),delayMs=Math.max(0,...selected.map(g=>g.crawlDelay))*1000;
 return {delayMs,allows(pathname){
  const path=String(pathname||'/');const matching=rules.filter(r=>path.startsWith(r.path.replace(/\*.*$/,'')));
  if(!matching.length)return true;
  matching.sort((a,b)=>b.path.length-a.path.length||(a.type==='allow'?-1:1));
  return matching[0].type==='allow';
 }};
}
async function fetchBounded(url,{request=globalThis.fetch,maxBytes=700000,timeoutMs=9000}={}){
 const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),timeoutMs);
 try{
  const res=await request(url,{method:'GET',redirect:'manual',signal:ctrl.signal,headers:{Accept:'text/html,text/plain;q=0.9', 'User-Agent':AGENT}});
  if(!res||!res.ok)throw Error('HTTP '+(res?.status??'unavailable'));
  const ct=String(res.headers?.get?.('content-type')||'').toLowerCase();
  if(ct && !/(text\/|application\/xml|application\/xhtml)/.test(ct))throw Error('Unexpected content type');
  const length=Number(res.headers?.get?.('content-length')||0);
  if(length>maxBytes)throw Error('Page size limit exceeded');
  if(res.body&&typeof res.body.getReader==='function'){
   const r=res.body.getReader(),chunks=[];let n=0;
   try{
    while(true){const x=await r.read();if(x.done)break;n+=x.value.byteLength;if(n>maxBytes)throw Error('Page size limit exceeded');chunks.push(Buffer.from(x.value));}
   }finally{try{await r.cancel()}catch{}}
   return {text:Buffer.concat(chunks,n).toString('utf8'),bytes:n};
  }
  const text=await res.text(),bytes=Buffer.byteLength(text);
  if(bytes>maxBytes)throw Error('Page size limit exceeded');
  return {text,bytes};
 }finally{clearTimeout(timer)}
}
function candidateLinks(html,url){
 const results=[];const candidates=[...String(html).matchAll(/<a\b[^>]*\bhref\s*=\s*["']([^"']{1,600})["'][^>]*>/gi)];
 for(const m of candidates){
  const raw=m[1].replace(/&amp;/g,'&'),next=safeUrl(raw,url);
  if(!next||next===url||!/(?:\/|[-_])(jobs?|careers?|karrier|allas|allashirdetes|positions?|opportunities|stellen)(?:\/|[-_.?]|$)/i.test(new URL(next).pathname))continue;
  if(!results.includes(next))results.push(next);
 }
 return results;
}
function observedJob(j,seed,page){
 const url=safeUrl(j.url||page);if(!url||!j.title||!j.company)return null;
 // Source URLs to external applications are preserved as links, not crawled or submitted.
 const features=featuresFor('verifier',jobFeatures({canonical_url:url,title:j.title,company:j.company,location_text:j.location,description:j.description,published_at:j.published_at,last_seen_at:new Date().toISOString()}));
 return {observation_key:sha(seed.url+'\n'+url),seed_url:seed.url,public_url:url,model_key:'verifier',features,
  title:clean(j.title).slice(0,220),company:clean(j.company).slice(0,180),location_text:clean(j.location).slice(0,180),
  permission_basis:seed.permission_basis,evidence_type:'jobposting_jsonld',terms:termsFromJob(j)};
}
async function researchSeed(seed,{request=globalThis.fetch,sleep=ms=>new Promise(r=>setTimeout(r,ms)),maxPages=4,maxBytes=700000,maxTotalBytes=3500000}={}){
 seed=validateSeed(seed);
 const robotsUrl=new URL('/robots.txt',seed.url).href;
 const robots=await fetchBounded(robotsUrl,{request,maxBytes:100000});const policy=robotsPolicy(robots.text);
 if(!policy.allows(new URL(seed.url).pathname))return {seed:seed.url,status:'disallowed_by_robots',pages:0,bytes:robots.bytes,jobs:[],scout:null};
 const pages=[seed.url],visited=new Set(),jobs=[],jobRefs=new Set(),limit=Math.min(maxPages,seed.max_pages),maxAllowedBytes=Math.max(robots.bytes,maxTotalBytes);
 let partial=false;
 let bytes=robots.bytes;
 while(pages.length&&visited.size<limit){
  const u=pages.shift();if(visited.has(u))continue;
  if(!policy.allows(new URL(u).pathname))continue;
  const remaining=maxAllowedBytes-bytes;
  if(remaining<200){partial=true;break;}
  if(visited.size&&policy.delayMs)await sleep(Math.min(30000,policy.delayMs));
  let page;try{page=await fetchBounded(u,{request,maxBytes:Math.min(maxBytes,remaining)})}
  catch(e){if(visited.size && /Page size limit exceeded/.test(e.message)){partial=true;break}throw e}
  visited.add(u);bytes+=page.bytes;
  for(const j of parseJobPosting(page.text,u,{name:seed.owner,company:seed.owner})){
   const item=observedJob(j,seed,u);if(item&&!jobRefs.has(item.observation_key)){jobs.push(item);jobRefs.add(item.observation_key)}
  }
  for(const link of candidateLinks(page.text,u))if(visited.size+pages.length<limit&&!visited.has(link)&&!pages.includes(link))pages.push(link);
 }
 const scout=featuresFor('scout',scoutFeatures({engine:'sitemap',approved:true,robots_allowed:true,jobposting_schema:jobs.length>0,
  success_count:1,verified_hu_count:jobs.filter(x=>x.location_text.match(/\b(?:hu|hungary|magyarorsz[aá]g)\b/i)).length}));
 return {seed:seed.url,status:'researched_pending_review',pages:visited.size,partial:partial||pages.length>0,bytes,jobs,scout};
}
async function saveResearch(pool,seed,result){
 if(result.status!=='researched_pending_review')return {saved:0};
 const client=await pool.connect();let saved=0;
 try{
  await client.query('BEGIN');
  const scoutKey=sha('scout\n'+seed.url);
  await client.query(`INSERT INTO national_ai_external_evidence(observation_key,seed_url,public_url,model_key,features,title,company,location_text,permission_basis,evidence_type)
    VALUES($1,$2,$3,'scout',$4::jsonb,$5,$6,'',$7,'site_metadata') ON CONFLICT(observation_key) DO UPDATE SET features=EXCLUDED.features,updated_at=NOW()`,
  [scoutKey,seed.url,seed.url,JSON.stringify(result.scout),seed.owner,seed.owner,seed.permission_basis]);saved++;
  await client.query(`INSERT INTO national_ai_review_queue(model_key,sample_ref,features) VALUES('scout',$1,$2::jsonb) ON CONFLICT(model_key,sample_ref) DO NOTHING`,[scoutKey,JSON.stringify(result.scout)]);
  for(const job of result.jobs){
   await client.query(`INSERT INTO national_ai_external_evidence(observation_key,seed_url,public_url,model_key,features,title,company,location_text,permission_basis,evidence_type)
    VALUES($1,$2,$3,$4,$5::jsonb,$6,$7,$8,$9,$10) ON CONFLICT(observation_key) DO UPDATE SET features=EXCLUDED.features,updated_at=NOW()`,
   [job.observation_key,job.seed_url,job.public_url,job.model_key,JSON.stringify(job.features),job.title,job.company,job.location_text,job.permission_basis,job.evidence_type]);saved++;
   await client.query(`INSERT INTO national_ai_review_queue(model_key,sample_ref,features) VALUES('verifier',$1,$2::jsonb) ON CONFLICT(model_key,sample_ref) DO NOTHING`,[job.observation_key,JSON.stringify(job.features)]);
   for(const term of (job.terms||[]))await client.query(`INSERT INTO national_ai_market_terms(observation_key,term) VALUES($1,$2) ON CONFLICT(observation_key,term) DO NOTHING`,[job.observation_key,term]);
  }
  await client.query('COMMIT');return {saved};
 }catch(e){await client.query('ROLLBACK');throw e}finally{client.release()}
}
async function research(pool,{
 seedsFile=process.env.AI_RESEARCH_SEEDS_FILE,request=globalThis.fetch,
 enabled=process.env.AI_EXTERNAL_RESEARCH_ENABLED==='true',sleep,
 maxSeeds=int(process.env.AI_RESEARCH_MAX_SEEDS_PER_RUN,6,1,10),
 maxPages=int(process.env.AI_RESEARCH_MAX_PAGES_PER_SEED,4,1,8),
 maxTotalBytes=int(process.env.AI_RESEARCH_MAX_BYTES_PER_SEED,3500000,100000,9000000),
 cooldownHours=int(process.env.AI_RESEARCH_COOLDOWN_HOURS,24,1,168),
 errorRetryHours=int(process.env.AI_RESEARCH_RETRY_HOURS,4,1,48),
 now=new Date()
}={}){
 if(!enabled)return {status:'disabled',reason:'Set AI_EXTERNAL_RESEARCH_ENABLED=true after authorizing seeds',requests:0};
 if(!seedsFile)return {status:'no_approved_seeds',requests:0};
 const all=readSeeds(seedsFile);if(!all.length)return {status:'no_approved_seeds',requests:0};
 const existing=(await pool.query('SELECT seed_url,last_run_at,next_due_at FROM national_ai_research_seed_state WHERE seed_url = ANY($1::text[])',[all.map(s=>s.url)])).rows;
 const states=new Map(existing.map(r=>[r.seed_url,r]));
 const due=all.filter(s=>{const item=states.get(s.url);return !item||new Date(item.next_due_at)<=now})
   .sort((a,b)=>new Date(states.get(a.url)?.last_run_at||0)-new Date(states.get(b.url)?.last_run_at||0)||a.url.localeCompare(b.url));
 const seeds=due.slice(0,int(maxSeeds,6,1,10));
 if(!seeds.length)return {status:'all_seeds_on_cooldown',totalSeeds:all.length,requests:0};
 const results=[];
 for(const seed of seeds){
  let result;
  try{
   const r=await researchSeed(seed,{request,sleep,maxPages,maxTotalBytes});
   const saved=await saveResearch(pool,seed,r);
   result={seed:seed.url,status:r.status,pages:r.pages,partial:r.partial||false,bytes:r.bytes,observed:r.jobs.length,saved:saved.saved};
  }catch(e){result={seed:seed.url,status:'error',error:clean(e.message).slice(0,170)}}
  const retry=result.status==='error'?errorRetryHours:cooldownHours;
  await pool.query(`INSERT INTO national_ai_research_seed_state(seed_url,last_run_at,next_due_at,last_status,observed)
    VALUES($1,$2::timestamptz,$2::timestamptz + ($3::integer || ' hours')::interval,$4,$5)
    ON CONFLICT(seed_url) DO UPDATE SET last_run_at=EXCLUDED.last_run_at,next_due_at=EXCLUDED.next_due_at,
    last_status=EXCLUDED.last_status,observed=EXCLUDED.observed`,[seed.url,now.toISOString(),retry,result.status,result.observed||0]);
  results.push(result);
 }
 return {status:'research_complete',seeds:seeds.length,totalSeeds:all.length,remainingDue:due.length-seeds.length,results,
  policy:'permission-gated, robots-aware, rate-limited, raw pages not stored, unreviewed evidence only; never modifies allowed source registry or model labels'};
}
/** Human-reviewed, source-traceable labels. No model-generated pseudo-labels accepted. */
async function ingestReviewed(pool,filename){
 const data=JSON.parse(fs.readFileSync(filename,'utf8'));
 if(!Array.isArray(data)||!data.length||data.length>500)throw Error('Expected 1-500 independently reviewed external labels');
 for(const row of data){
  if(!row||typeof row.observation_key!=='string'||!/^[a-f0-9]{64}$/.test(row.observation_key)||
   !['scout','verifier'].includes(row.model_key)||![0,1].includes(row.label)||
   !['train','holdout'].includes(row.split)||row.reviewed!==true||
   !/^[a-zA-Z0-9_-]{3,80}$/.test(row.reviewer_id||''))throw Error('Invalid independent human review declaration');
 }
 const keys=new Set(data.map(x=>x.observation_key));if(keys.size!==data.length)throw Error('Duplicate external review in batch');
 const client=await pool.connect();let count=0;
 try{
  await client.query('BEGIN');
  for(const row of data){
   const found=await client.query(`SELECT features FROM national_ai_external_evidence WHERE observation_key=$1 AND model_key=$2 AND review_status='pending' FOR UPDATE`,[row.observation_key,row.model_key]);
   if(found.rows.length!==1)throw Error('Review item absent or already reviewed');
   const feature=featuresFor(row.model_key,found.rows[0].features);
   await client.query(`INSERT INTO national_ai_examples(model_key,features,label,split,reviewed,consent,origin)
     VALUES($1,$2::jsonb,$3,$4,true,false,'manual_review')`,[row.model_key,JSON.stringify(feature),row.label,row.split]);
   await client.query(`UPDATE national_ai_external_evidence SET review_status='reviewed',updated_at=NOW() WHERE observation_key=$1`,[row.observation_key]);
   await client.query(`UPDATE national_ai_review_queue SET status='reviewed' WHERE model_key=$1 AND sample_ref=$2`,[row.model_key,row.observation_key]);
   count++;
  }
  await client.query('COMMIT');return {reviewed:count,note:'Human reviewed external evidence; independent holdout gating still required before model promotion'};
 }catch(e){await client.query('ROLLBACK');throw e}finally{client.release()}
}
module.exports={safeUrl,validateSeed,readSeeds,robotsGroups,robotsPolicy,fetchBounded,candidateLinks,observedJob,researchSeed,saveResearch,research,ingestReviewed};
