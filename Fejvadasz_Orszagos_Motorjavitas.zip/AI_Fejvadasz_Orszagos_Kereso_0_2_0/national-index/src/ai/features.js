'use strict';
/** Four small transparent task models; no raw CVs or applicant text are persisted. */
const SPECS=Object.freeze({
 scout:{label:'Karrieroldal-felmérő AI',features:['public_feed','robots_allowed','permission_confirmed','jobposting_schema','known_ats','recent_success','hu_yield','error_rate'],minTrain:32,minHoldout:12},
 verifier:{label:'Állásellenőrző AI',features:['https_link','real_title','real_company','location_known','country_hu','description_quality','recently_seen','valid_published_date'],minTrain:40,minHoldout:16},
 matcher:{label:'CV-illesztő AI',features:['skill_overlap','role_match','distance_fit','language_match','employment_match','experience_fit','salary_fit','recency'],minTrain:40,minHoldout:16},
 optimizer:{label:'Keresőmotor-optimalizáló AI',features:[],minTrain:0,minHoldout:0}
});
function finite01(v){const n=Number(v);if(!Number.isFinite(n))throw Error('Feature must be a finite number');if(n<0||n>1)throw Error('Feature must be in [0,1]');return n}
function featuresFor(key,record){const s=SPECS[key];if(!s||key==='optimizer')throw Error('Invalid supervised model key');if(!record||typeof record!=='object'||Array.isArray(record))throw Error('Feature object required');const o={};for(const f of s.features){if(!Object.hasOwn(record,f))throw Error('Missing feature: '+f);o[f]=finite01(record[f]);}return o}
function vector(key,record){const o=featuresFor(key,record);return SPECS[key].features.map(f=>o[f])}
function bounded(v,min=0,max=1){return Math.max(min,Math.min(max,Number.isFinite(Number(v))?Number(v):0))}
function ageScore(date,now=Date.now()){if(!date)return 0.4;const t=Date.parse(date);if(!Number.isFinite(t))return 0;return bounded(1-(now-t)/(90*86400000))}
const hasCountryHu=loc=>/(^|[,;\s])(?:hu|hungary|magyarorsz[aá]g)(?=$|[,;\s])/i.test(String(loc||''));
function jobFeatures(j={},now=Date.now()){
 const url=String(j.canonical_url||j.url||'');let isHttps=false;try{const u=new URL(url);isHttps=u.protocol==='https:'&&!u.username&&!u.password}catch{}
 const title=String(j.title||'').trim(),desc=String(j.description||'').trim(),loc=String(j.location_text||j.location||'').trim();
 return {https_link:+isHttps,real_title:+(title.length>=5&&title.length<=260),real_company:+(String(j.company||'').trim().length>=2),location_known:+(loc.length>=3),country_hu:+(j.country_status==='hu'||hasCountryHu(loc)),description_quality:bounded(desc.length/600),recently_seen:ageScore(j.last_seen_at||j.updated_at||j.published_at,now),valid_published_date:!j.published_at?0.5:+(Number.isFinite(Date.parse(j.published_at))&&Date.parse(j.published_at)<=now+86400000)};
}
function terms(x){return new Set(String(x||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().split(/[^\p{L}\p{N}#+]+/u).filter(w=>w.length>=3).slice(0,100))}
function overlap(a,b){const A=terms(a),B=terms(b);if(!A.size||!B.size)return 0;let hit=0;for(const w of A)if(B.has(w))hit++;return bounded(hit/A.size)}
function categoryOverlap(a,b){
 const {termsFromJob}=require('./terms');
 const left=new Set(termsFromJob({title:String(a||'')})),right=new Set(termsFromJob({title:String(b||'')}));
 if(!left.size||!right.size)return 0;
 let hit=0;for(const key of left)if(right.has(key))hit++;
 return bounded(hit/left.size);
}
function matchFeatures(profile={},job={}){
 const skills=Array.isArray(profile.skills)?profile.skills.join(' '):String(profile.skills||'');const role=profile.targetRoles||profile.targetRole||'';
 const text=[job.title,job.description].filter(Boolean).join(' ');const loc=String(job.location_text||job.location||'');
 const region=String(profile.region||profile.locations||'');const location=region?overlap(region,loc):0.5;
 return {skill_overlap:Math.max(overlap(skills,text),categoryOverlap(skills,text)),role_match:Math.max(overlap(role,job.title),categoryOverlap(role,job.title)),distance_fit:location,language_match:0.5,employment_match:0.5,experience_fit:0.5,salary_fit:0.5,recency:ageScore(job.last_seen_at||job.published_at)};
}
function scoutFeatures(source={}){
 const checks=Number(source.success_count||0),fails=Number(source.fail_count||0),ok=checks+fails;
 return {public_feed:+['greenhouse','lever','ashby','smartrecruiters','workable','rss'].includes(source.engine),robots_allowed:+(source.robots_allowed===true),permission_confirmed:+(source.approved===true),jobposting_schema:+(source.jobposting_schema===true),known_ats:+['greenhouse','lever','ashby','smartrecruiters','workable'].includes(source.engine),recent_success:+Boolean(source.last_success_at),hu_yield:bounded(Math.log1p(Number(source.verified_hu_count)||0)/Math.log1p(1000)),error_rate:ok?bounded(fails/ok):0.5};
}
module.exports={SPECS,finite01,featuresFor,vector,bounded,jobFeatures,scoutFeatures,matchFeatures,overlap,categoryOverlap};
