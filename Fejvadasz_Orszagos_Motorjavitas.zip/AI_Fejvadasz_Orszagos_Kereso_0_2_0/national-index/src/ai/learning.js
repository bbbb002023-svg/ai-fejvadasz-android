'use strict';
const crypto=require('node:crypto');
const fs=require('node:fs');
const {SPECS,featuresFor}=require('./features');
const logistic=require('./logistic');
const {jobFeatures,scoutFeatures}=require('./features');
const bandit=require('./bandit');
const CLASSIFIERS=['scout','verifier','matcher'];
const sha=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
function validateExample(e){
 if(!CLASSIFIERS.includes(e.model_key))throw Error('Unknown model key');
 const features=featuresFor(e.model_key,e.features);
 if(e.label!==0&&e.label!==1)throw Error('Binary label required');
 if(!['train','holdout'].includes(e.split))throw Error('Invalid split');
 if(e.reviewed!==true)throw Error('Independent review is mandatory');
 if(!['manual_review','licensed_dataset','opt_in_feedback'].includes(e.origin))throw Error('Invalid origin');
 if(e.origin==='opt_in_feedback'&&e.consent!==true)throw Error('Explicit consent required for opt-in feedback');
 return {model_key:e.model_key,features,label:e.label,split:e.split,reviewed:true,consent:e.consent===true,origin:e.origin};
}
async function ingest(pool,filename){
 const data=JSON.parse(fs.readFileSync(filename,'utf8'));if(!Array.isArray(data)||!data.length||data.length>2000)throw Error('Expected 1-2000 labeled rows');
 const examples=data.map(validateExample),seen=new Set();for(const r of examples){const id=sha([r.model_key,r.features]);if(seen.has(id))throw Error('Duplicate feature vector in batch');seen.add(id)}
 const client=await pool.connect();try{await client.query('BEGIN');for(const r of examples){await client.query(`INSERT INTO national_ai_examples(model_key,features,label,split,reviewed,consent,origin) VALUES($1,$2::jsonb,$3,$4,$5,$6,$7)`,[r.model_key,JSON.stringify(r.features),r.label,r.split,r.reviewed,r.consent,r.origin]);}await client.query('COMMIT');return {ingested:examples.length,models:[...new Set(examples.map(x=>x.model_key))]}}catch(e){await client.query('ROLLBACK');throw e}finally{client.release()}
}
function groupLabels(rows){const c={positive:0,negative:0};for(const r of rows)if(r.label===1)c.positive++;else c.negative++;return c}
function independent(rows,holdout){const training=new Set(rows.map(x=>sha(x.features)));return !holdout.some(x=>training.has(sha(x.features)))}
async function supervised(pool,key){
 const spec=SPECS[key];const rows=(await pool.query(`SELECT model_key,features,label,split,reviewed,consent,origin FROM national_ai_examples WHERE model_key=$1 AND reviewed=true AND (origin <> 'opt_in_feedback' OR consent=true) ORDER BY example_id`,[key])).rows;
 const trainRows=rows.filter(x=>x.split==='train'),held=rows.filter(x=>x.split==='holdout');const cl=groupLabels(trainRows),ch=groupLabels(held);
 if(trainRows.length<spec.minTrain||held.length<spec.minHoldout||cl.positive<8||cl.negative<8||ch.positive<4||ch.negative<4)return {model:key,status:'awaiting_verified_labels',train:trainRows.length,holdout:held.length,need:{train:spec.minTrain,holdout:spec.minHoldout}};
 if(!independent(trainRows,held))return {model:key,status:'holdout_leakage_detected'};
 const last=(await pool.query(`SELECT version_id,training_count,artifact,metrics FROM national_ai_model_versions WHERE model_key=$1 AND status='active' ORDER BY version_id DESC LIMIT 1`,[key])).rows[0];
 if(last&&trainRows.length<Number(last.training_count)+10)return {model:key,status:'waiting_for_new_feedback',train:trainRows.length,active_version:last.version_id};
 const artifact=logistic.train(key,trainRows),metrics=logistic.evaluate(artifact,held);
 const baseline=last?logistic.evaluate(last.artifact,held):null;
 // The verifier MUST have unusually high precision to avoid misleading "verified" labels.
 const safePrecision=key==='verifier'?0.90:0.80;
 const passed=metrics.accuracy>=0.82&&metrics.precision>=safePrecision&&metrics.recall>=0.75&&(!baseline||(metrics.accuracy>=baseline.accuracy-0.005&&metrics.precision>=baseline.precision-0.005&&metrics.recall>=baseline.recall-0.005));
 const client=await pool.connect();try{
  await client.query('BEGIN');
  if(passed)await client.query("UPDATE national_ai_model_versions SET status='rejected' WHERE model_key=$1 AND status='active'",[key]);
  const created=await client.query(`INSERT INTO national_ai_model_versions(model_key,artifact,metrics,status,training_count,activated_at) VALUES($1,$2::jsonb,$3::jsonb,$4,$5,$6) RETURNING version_id`,[key,JSON.stringify(artifact),JSON.stringify({...metrics,baseline_accuracy:baseline?.accuracy??null,examples_train:trainRows.length,examples_holdout:held.length}),passed?'active':'candidate',trainRows.length,passed?new Date().toISOString():null]);
  await client.query('COMMIT');return {model:key,status:passed?'automatically_promoted':'candidate_needs_review',version:created.rows[0].version_id,metrics};
 }catch(e){await client.query('ROLLBACK');throw e}finally{client.release()}
}
async function optimize(pool){
 const sources=(await pool.query(`SELECT source_key,engine,enabled,approved,success_count,fail_count,verified_hu_count FROM national_sources WHERE enabled AND approved AND engine<>'registry' ORDER BY source_key`)).rows;
 const snapshot=bandit.report(sources),digest=sha(snapshot.ranked);
 const last=(await pool.query(`SELECT version_id,artifact FROM national_ai_model_versions WHERE model_key='optimizer' AND status='active' LIMIT 1`)).rows[0];
 if(last?.artifact?.digest===digest)return {model:'optimizer',status:'unchanged',active_version:last.version_id,source_count:sources.length};
 // Source success/failure counters are only trusted operational signals, not a legal permission source.
 const data={key:'optimizer',algorithm:'ucb-verified-outcomes-v1',digest,summary:snapshot.engines,updated:new Date().toISOString()};
 const client=await pool.connect();try{await client.query('BEGIN');await client.query("UPDATE national_ai_model_versions SET status='rejected' WHERE model_key='optimizer' AND status='active'");const r=await client.query(`INSERT INTO national_ai_model_versions(model_key,artifact,metrics,status,training_count,activated_at) VALUES('optimizer',$1::jsonb,$2::jsonb,'active',$3,NOW()) RETURNING version_id`,[JSON.stringify(data),JSON.stringify({engines:snapshot.engines.length,source_count:sources.length}),sources.length]);await client.query('COMMIT');return {model:'optimizer',status:'updated_from_source_outcomes',version:r.rows[0].version_id,source_count:sources.length}}catch(e){await client.query('ROLLBACK');throw e}finally{client.release()}
}
async function queueReviews(pool,{maxPerModel=36}={}){
 maxPerModel=Math.min(100,Math.max(1,Math.trunc(maxPerModel)||36));
 // Public records only; no CV text, applicant PII, or external model outputs.
 const jobs=(await pool.query(`SELECT job_key,canonical_url,title,company,location_text,country_status,description,published_at,last_seen_at FROM national_jobs WHERE state='observed' ORDER BY last_seen_at DESC LIMIT $1`,[maxPerModel])).rows;
 const sources=(await pool.query(`SELECT source_key,engine,approved,enabled,success_count,fail_count,verified_hu_count,last_success_at FROM national_sources WHERE engine<>'registry' ORDER BY last_checked_at DESC NULLS LAST LIMIT $1`,[maxPerModel])).rows;
 let added=0;
 for(const [key,items,extract,idKey] of [['verifier',jobs,jobFeatures,'job_key'],['scout',sources,scoutFeatures,'source_key']]){
  for(const x of items){const f=featuresFor(key,extract(x));const r=await pool.query(`INSERT INTO national_ai_review_queue(model_key,sample_ref,features) VALUES($1,$2,$3::jsonb) ON CONFLICT(model_key,sample_ref) DO NOTHING RETURNING review_id`,[key,x[idKey],JSON.stringify(f)]);added+=r.rows.length}
 }
 return {queued_new:added,job_candidates:jobs.length,source_candidates:sources.length,matcher:'Requires explicit consented outcome feedback; no CV is queued.'};
}
async function improve(pool){const queue=await queueReviews(pool);const results=[];for(const k of CLASSIFIERS){try{results.push(await supervised(pool,k))}catch(e){results.push({model:k,status:'error',error:String(e.message).slice(0,180)})}}try{results.push(await optimize(pool))}catch(e){results.push({model:'optimizer',status:'error',error:String(e.message).slice(0,180)})}return {policy:'reviewed-data-only; independent holdout; no OpenAI-generated training labels; no CV data stored',reviewQueue:queue,models:results}}
async function getActive(pool,key){if(!Object.hasOwn(SPECS,key))throw Error('Unknown AI model');if(key==='optimizer')return null;const r=await pool.query("SELECT version_id,artifact,metrics FROM national_ai_model_versions WHERE model_key=$1 AND status='active' LIMIT 1",[key]);return r.rows[0]||null;}
async function status(pool){
 const a=(await pool.query('SELECT model_key,status,version_id,training_count,metrics,created_at,activated_at FROM national_ai_model_versions ORDER BY version_id DESC LIMIT 100')).rows;
 const c=(await pool.query(`SELECT model_key,split,COUNT(*)::int AS n FROM national_ai_examples WHERE reviewed=true AND (origin <> 'opt_in_feedback' OR consent=true) GROUP BY model_key,split`)).rows;
 const q=(await pool.query("SELECT model_key,COUNT(*)::int AS n FROM national_ai_review_queue WHERE status='pending' GROUP BY model_key")).rows;
 return {review_queue_pending:Object.fromEntries(q.map(x=>[x.model_key,Number(x.n)])),models:Object.entries(SPECS).map(([key,s])=>({key,name:s.label,active:a.find(x=>x.model_key===key&&x.status==='active')||null,latest:a.find(x=>x.model_key===key)||null,verified_examples:Object.fromEntries(c.filter(x=>x.model_key===key).map(x=>[x.split,Number(x.n)])),readiness:key==='optimizer'?'operational_feedback':a.some(x=>x.model_key===key&&x.status==='active')?'validated':'awaiting_verified_data'})),privacy:'No raw CV data stored in national AI training tables',caution:'Model predictions never override robots, permission review or deterministic job validation.'};
}
module.exports={validateExample,ingest,groupLabels,independent,supervised,optimize,queueReviews,improve,getActive,status};
