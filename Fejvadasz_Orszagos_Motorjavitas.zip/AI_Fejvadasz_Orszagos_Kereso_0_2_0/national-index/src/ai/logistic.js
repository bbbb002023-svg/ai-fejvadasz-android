'use strict';
const {SPECS,vector,bounded}=require('./features');
function sigmoid(x){if(x<0){const z=Math.exp(x);return z/(1+z)}return 1/(1+Math.exp(-x))}
function score(model,features){if(!model||!SPECS[model.key]||model.key==='optimizer')throw Error('Invalid model');const x=vector(model.key,features);if(!Array.isArray(model.weights)||model.weights.length!==x.length)throw Error('Weight size mismatch');return sigmoid(x.reduce((s,v,i)=>s+v*model.weights[i],Number(model.bias)||0))}
function train(key,examples,{epochs=160,rate=0.24,l2=0.001}={}){
 if(!SPECS[key]||key==='optimizer')throw Error('Unknown classifier');
 const rows=examples.map(e=>({x:vector(key,e.features),y:e.label}));
 if(!rows.length||rows.some(x=>x.y!==0&&x.y!==1))throw Error('Binary labeled examples required');
 let w=Array(SPECS[key].features.length).fill(0),bias=0;
 for(let epoch=0;epoch<epochs;epoch++){
  const dw=w.map(()=>0);let db=0;
  for(const {x,y} of rows){const p=sigmoid(x.reduce((s,v,i)=>s+v*w[i],bias));const err=p-y;for(let j=0;j<w.length;j++)dw[j]+=err*x[j];db+=err;}
  const eta=rate/(1+epoch/75),n=rows.length;for(let j=0;j<w.length;j++)w[j]-=eta*(dw[j]/n+l2*w[j]);bias-=eta*db/n;
 }
 return {key,algorithm:'bounded-logistic-v1',weights:w.map(x=>+x.toFixed(8)),bias:+bias.toFixed(8),version:1};
}
function evaluate(model,examples){if(!examples.length)return {count:0};let correct=0,tp=0,tn=0,fp=0,fn=0,loss=0;for(const e of examples){const p=score(model,e.features),y=e.label;const pred=p>=0.5?1:0;if(pred===y)correct++;if(pred&&y)tp++;if(!pred&&!y)tn++;if(pred&&!y)fp++;if(!pred&&y)fn++;loss+=-(y*Math.log(Math.max(1e-9,p))+(1-y)*Math.log(Math.max(1e-9,1-p)));}
 const n=examples.length;return {count:n,accuracy:correct/n,precision:tp+fp?tp/(tp+fp):0,recall:tp+fn?tp/(tp+fn):0,loss:loss/n,confusion:{tp,tn,fp,fn}};
}
module.exports={sigmoid,score,train,evaluate};
