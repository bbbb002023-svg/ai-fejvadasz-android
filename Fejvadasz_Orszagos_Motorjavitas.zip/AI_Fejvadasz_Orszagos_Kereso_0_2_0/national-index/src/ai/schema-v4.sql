-- Versioned, opt-in training data. No CV text, name, contact or applicant record.
CREATE TABLE IF NOT EXISTS national_ai_examples (
 example_id bigserial PRIMARY KEY,
 model_key text NOT NULL CHECK (model_key IN ('scout','verifier','matcher')),
 features jsonb NOT NULL,
 label smallint NOT NULL CHECK (label IN (0,1)),
 split text NOT NULL CHECK (split IN ('train','holdout')),
 reviewed boolean NOT NULL DEFAULT false,
 consent boolean NOT NULL DEFAULT false,
 origin text NOT NULL CHECK (origin IN ('manual_review','licensed_dataset','opt_in_feedback')),
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS national_ai_examples_key_split_idx ON national_ai_examples(model_key,split,reviewed);
CREATE TABLE IF NOT EXISTS national_ai_model_versions (
 version_id bigserial PRIMARY KEY,
 model_key text NOT NULL CHECK (model_key IN ('scout','verifier','matcher','optimizer')),
 artifact jsonb NOT NULL,
 metrics jsonb NOT NULL DEFAULT '{}'::jsonb,
 status text NOT NULL CHECK (status IN ('candidate','active','rejected')),
 training_count integer NOT NULL DEFAULT 0,
 created_at timestamptz NOT NULL DEFAULT now(),
 activated_at timestamptz
);
CREATE UNIQUE INDEX IF NOT EXISTS national_ai_one_active_per_model ON national_ai_model_versions(model_key) WHERE status='active';
CREATE INDEX IF NOT EXISTS national_ai_models_lookup ON national_ai_model_versions(model_key,created_at DESC);
-- Active learning queue: public catalogue identifiers and numeric metadata only.
CREATE TABLE IF NOT EXISTS national_ai_review_queue (
 review_id bigserial PRIMARY KEY,
 model_key text NOT NULL CHECK (model_key IN ('scout','verifier')),
 sample_ref text NOT NULL,
 features jsonb NOT NULL,
 status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','reviewed','skipped')),
 created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(model_key,sample_ref)
);
CREATE INDEX IF NOT EXISTS national_ai_review_pending_idx ON national_ai_review_queue(model_key,created_at) WHERE status='pending';
