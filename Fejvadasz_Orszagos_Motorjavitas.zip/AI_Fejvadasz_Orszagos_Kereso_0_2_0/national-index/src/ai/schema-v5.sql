-- v0.3.1 external research: metadata only; no website HTML or applicant CV stored.
-- Permission and robots checks are enforced by the research worker, not database flags alone.
CREATE TABLE IF NOT EXISTS national_ai_external_evidence (
 observation_key text PRIMARY KEY,
 seed_url text NOT NULL,
 public_url text NOT NULL,
 model_key text NOT NULL CHECK(model_key IN ('scout','verifier')),
 features jsonb NOT NULL,
 title text NOT NULL DEFAULT '',
 company text NOT NULL DEFAULT '',
 location_text text NOT NULL DEFAULT '',
 permission_basis text NOT NULL,
 evidence_type text NOT NULL CHECK(evidence_type IN ('site_metadata','jobposting_jsonld')),
 review_status text NOT NULL DEFAULT 'pending' CHECK(review_status IN ('pending','reviewed','rejected')),
 created_at timestamptz NOT NULL DEFAULT NOW(),
 updated_at timestamptz NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS national_ai_external_evidence_review_idx ON national_ai_external_evidence(review_status,created_at DESC);
CREATE TABLE IF NOT EXISTS national_ai_capacity_snapshots (
 snapshot_id bigserial PRIMARY KEY,
 recorded_at timestamptz NOT NULL DEFAULT NOW(),
 db_bytes bigint NOT NULL CHECK(db_bytes>=0),
 memory_bytes bigint NOT NULL CHECK(memory_bytes>=0),
 db_utilization_pct numeric(7,2),
 memory_utilization_pct numeric(7,2),
 alert_status text NOT NULL
);
CREATE INDEX IF NOT EXISTS national_ai_capacity_snapshots_time_idx ON national_ai_capacity_snapshots(recorded_at DESC);

-- Market vocabulary is a set of controlled skill/category tags, not raw website text.
CREATE TABLE IF NOT EXISTS national_ai_market_terms (
 observation_key text NOT NULL REFERENCES national_ai_external_evidence(observation_key) ON DELETE CASCADE,
 term text NOT NULL CHECK(length(term) BETWEEN 2 AND 55),
 PRIMARY KEY(observation_key,term)
);
CREATE INDEX IF NOT EXISTS national_ai_market_terms_term_idx ON national_ai_market_terms(term);

-- Durable fair-rotation scheduler; no automatic expansion of crawl permissions.
CREATE TABLE IF NOT EXISTS national_ai_research_seed_state (
 seed_url text PRIMARY KEY,
 last_run_at timestamptz NOT NULL,
 next_due_at timestamptz NOT NULL,
 last_status text NOT NULL,
 observed integer NOT NULL DEFAULT 0 CHECK(observed>=0)
);
CREATE INDEX IF NOT EXISTS national_ai_research_due_idx ON national_ai_research_seed_state(next_due_at);
