'use strict';
/** Lightweight privacy-safe market vocabulary extraction from permitted public postings.
 * No raw job description or applicant data is retained; terms aren't training labels.
 */
const VOCAB=Object.freeze({
 cnc:['cnc','cnc gép','cnc machinist','cnc forgácsoló'],
 sql:['sql','postgresql','mysql','mssql'],
 excel:['excel','spreadsheet','táblázatkezelés'],
 python:['python'],
 java:['java'],
 javascript:['javascript','typescript','node.js','nodejs'],
 react:['react','react.js'],
 angular:['angular'],
 sap:['sap'],
 sales:['sales','értékesítő','értékesítés','kereskedelmi képviselő'],
 logistics:['logisztika','logistics','supply chain'],
 accounting:['könyvelő','könyvelés','accountant','accounting'],
 customer_support:['ügyfélszolgálat','customer support','customer service'],
 warehouse:['raktáros','warehouse','raktárkezelő'],
 driver:['sofőr','gépkocsivezető','driver'],
 quality_assurance:['minőségbiztosítás','quality assurance','quality inspector','minőségellenőr'],
 engineer:['mérnök','engineer','engineering'],
 healthcare:['ápoló','nurse','egészségügyi'],
 welding:['hegesztő','welder','welding'],
 forklift:['targonca','forklift'],
 electrician:['villanyszerelő','electrician'],
 production:['termelés','production','gyártás'],
 recruiter:['recruiter','toborzó','recruitment'],
 marketing:['marketing'],
 finance:['pénzügy','finance','financial'],
 german:['német nyelv','german speaking','german language'],
 english:['angol nyelv','english speaking','english language']
});
const normalize=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('hu').replace(/[^a-z0-9+#.]+/g,' ').replace(/\s+/g,' ').trim();
const boundaryMatch=(hay,needle)=>new RegExp('(?:^|\\s)'+needle.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'(?:$|\\s)').test(hay);
function termsFromJob(j={}){
 const text=normalize([j.title,j.description].filter(Boolean).join(' ').slice(0,14000));if(!text)return [];
 return Object.entries(VOCAB).filter(([,variants])=>variants.some(v=>boundaryMatch(text,normalize(v)))).map(([term])=>term).slice(0,22);
}
module.exports={VOCAB,normalize,termsFromJob,boundaryMatch};
