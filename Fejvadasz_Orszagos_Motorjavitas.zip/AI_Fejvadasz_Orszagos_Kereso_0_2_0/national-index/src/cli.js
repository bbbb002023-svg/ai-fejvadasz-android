'use strict';
const fs=require('node:fs'),path=require('node:path');const db=require('./db');const {runOnce}=require('./collector');const {createApi}=require('./api');const {runEmbeddingBatch}=require('./embedding-worker');const {importPlaces,importSimplemaps,assignJobPlaces}=require('./places');const {importGeoNames}=require('./geonames');const {engineTargets}=require('./quality');
async function main(){
 const mode=process.argv[2]||'help';if(mode.startsWith('ai-'))return require('./ai/cli').run(mode,process.argv.slice(3));if(!['migrate','seed','collect','collect-retry','worker','api','stats','audit','check-db','embed','import-places','import-simplemaps','import-geonames','engine-targets','geocode'].includes(mode)){
  console.log('Usage: node src/cli.js migrate|seed|collect|collect-retry|worker|api|stats|audit|check-db|embed|import-places|import-simplemaps|import-geonames|engine-targets|geocode');return;
 }
 const pool=db.newPool();
 async function stop(){await pool.end()}
 if(mode==='check-db'){const ping=await pool.query('SELECT version() AS postgres');console.log(JSON.stringify({connected:true,postgres:ping.rows[0].postgres.split(' ')[0]}));return stop()}
 if(mode==='embed'){console.log(JSON.stringify(await runEmbeddingBatch(pool)));return stop()}
 if(mode==='import-places'){if(!process.argv[3])throw Error('Usage: npm run import:places -- ./trusted-places.csv');console.log(JSON.stringify(await importPlaces(pool,process.argv[3])));return stop()}
 if(mode==='import-simplemaps'){if(!process.argv[3])throw Error('Usage: npm run import:simplemaps -- ./hu.csv');console.log(JSON.stringify(await importSimplemaps(pool,process.argv[3])));return stop()}
 if(mode==='import-geonames'){console.log(JSON.stringify(await importGeoNames(pool,{zipPath:process.argv[3]||undefined,force:process.argv.includes('--force')})));return stop()}
 if(mode==='engine-targets'){console.log(JSON.stringify(await engineTargets(pool,{target:Number(process.env.NATIONAL_HU_TARGET)||1000}),null,2));return stop()}
 if(mode==='geocode'){console.log(JSON.stringify(await assignJobPlaces(pool)));return stop()}
 if(mode==='migrate'){await db.migrate(pool);console.log('Schema installed');return stop()}
 if(mode==='seed'){
  const catalog=JSON.parse(fs.readFileSync(path.join(__dirname,'../config/sources.json'),'utf8'));
  const n=await db.seed(pool,catalog);console.log(`Imported source registry: ${n}; enabled flags preserved`);return stop();
 }
 if(mode==='collect'){console.log(JSON.stringify(await runOnce(pool,{parallel:Number(process.env.NATIONAL_PARALLEL)||3})));return stop()}
 if(mode==='collect-retry'){
  const sourceKey=process.argv[3];
  if(!sourceKey||process.argv.length!==4)throw Error('Usage: npm run collect:retry -- lever:tsmg');
  console.log(JSON.stringify(await runOnce(pool,{manualSourceKey:sourceKey,parallel:1})));
  return stop();
 }
 if(mode==='stats'){console.log(JSON.stringify(await db.stats(pool)));return stop()}
 if(mode==='audit'){console.log(JSON.stringify(await db.audit(pool),null,2));return stop()}
 if(mode==='api'){const server=createApi(pool);server.listen(Number(process.env.PORT)||10000,'0.0.0.0',()=>console.log('National API listening'));
  async function close(){server.close(async()=>{await stop();process.exit(0)})}process.once('SIGTERM',close);process.once('SIGINT',close);return}
 if(mode==='worker'){
  const mins=Math.min(1440,Math.max(15,Number(process.env.NATIONAL_WORKER_MINUTES)||60));
  let active=false;async function tick(){if(active)return;active=true;try{console.log(JSON.stringify(await runOnce(pool,{parallel:Number(process.env.NATIONAL_PARALLEL)||3})))}catch(e){console.error('National worker failure:',String(e?.message||e).slice(0,200))}finally{active=false}}
  await tick();const timer=setInterval(tick,mins*60000);async function quit(){clearInterval(timer);await stop();process.exit(0)}process.once('SIGTERM',quit);process.once('SIGINT',quit);
 }
}
main().catch(e=>{console.error(e?.message||e);process.exitCode=1});
