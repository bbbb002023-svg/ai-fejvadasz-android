'use strict';
/**
 * Two independently scoped CV-focused portal scouts. Only Brave's licensed index
 * is queried. Does not scrape Profession / CVonline, store a CV, train on portal
 * contents, or claim to verify the ad at the original website.
 */
const BOARDS=Object.freeze([
 Object.freeze({id:'profession_cv',name:'Profession.hu',domain:'profession.hu',openUrl:'https://www.profession.hu/kereses',focus:'target_roles'}),
 Object.freeze({id:'cvonline_cv',name:'CVonline.hu',domain:'cvonline.hu',openUrl:'https://www.cvonline.hu/hu/allashirdetesek',focus:'skills_and_roles'})
]);
const PERSONAL=/\b(?:e-?mail|telefon|telefonszám|lakcím|születési|társadalombiztosítás|útlevél|adóazonosító)\b/i;
const PAGE_LINK=/\/(?:login|register|bejelentkezes|regisztracio|kapcsolat|privacy|aszf|felhasznalasi|impresszum|kereses|search|tudastar|allaskereses)(?:\/|$)/i;
const clean=x=>String(x??'').replace(/[\r\n\t<>"'`{}[\]|]/g,' ').replace(/\s+/g,' ').trim();
const fold=x=>clean(x).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
function items(x,{max=4,length=60}={}){
 const raw=Array.isArray(x)?x:String(x||'').split(/[,;\n]+/);
 return [...new Set(raw.map(x=>clean(x).slice(0,length)).filter(x=>x.length>=2&&!PERSONAL.test(x)))].slice(0,max);
}
function sanitizedProfile(input){
 if(!input||typeof input!=='object'||Array.isArray(input))throw Object.assign(Error('Szakmai profil szükséges'),{status:400});
 // Explicit allowlist: names, emails, phone, CV paragraphs, photos, contact details, etc.
 // are never used in outbound requests.
 const roles=items(input.targetRoles||input.targetRole,{max:3});
 const skills=items(input.skills,{max:6,length:45});
 const locations=items(input.locations||input.region||input.city,{max:3,length:50});
 const excludedRoles=items(input.excludedRoles,{max:6});
 if(!roles.length&&!skills.length)throw Object.assign(Error('Adj meg keresett munkakört vagy készséget'),{status:400});
 return {roles,skills,locations,excludedRoles};
}
function buildQuery(board,profile){
 const roles=profile.roles.slice(0,2),skills=profile.skills.slice(0,2),loc=profile.locations.slice(0,2);
 const primary=board.focus==='target_roles'?[...roles,...skills.slice(0,1)]:[...roles.slice(0,1),...skills];
 const terms=[`site:${board.domain}`,...primary,...loc.length?loc:['Magyarország'],'állás'];
 return terms.map(clean).filter(Boolean).join(' ').slice(0,340);
}
function safePortalUrl(value,board){
 try{
  const u=new URL(String(value||''));const h=u.hostname.toLowerCase();
  if(u.protocol!=='https:'||u.username||u.password||u.port||!(h===board.domain||h.endsWith('.'+board.domain))||PAGE_LINK.test(u.pathname))return null;
  if(u.pathname==='/'||u.pathname.length<7)return null;
  u.hash='';
  for(const key of [...u.searchParams.keys()])if(/^(utm_|fbclid|gclid|ref$)/i.test(key))u.searchParams.delete(key);
  return u.toString();
 }catch{return null}
}
function scoreSnippet(hit,p){
 const title=fold(hit.title),description=fold(hit.description),whole=title+' '+description;
 let points=0;const reasons=[];
 for(const role of p.roles){const r=fold(role);if(title.includes(r)){points+=9;reasons.push('célmunkakör')}else if(description.includes(r)){points+=4;reasons.push('munkakör említése')}}
 for(const skill of p.skills){const s=fold(skill);if(whole.includes(s)){points+=3;if(reasons.length<4)reasons.push('készség: '+skill)}}
 if(!points)return {score:0,reasons:[]};
 if(p.locations.length){const loc=p.locations.some(x=>whole.includes(fold(x)));if(loc){points+=3;reasons.push('helyszín szerepel')}else points-=2;}
 for(const bad of p.excludedRoles)if(whole.includes(fold(bad))){points-=35;reasons.push('kizárt munkakör említése')}
 return {score:Math.max(0,points),reasons:[...new Set(reasons)].slice(0,5)};
}
async function searchOne(board,p,{request,key,timeoutMs=9000}={}){
 const query=buildQuery(board,p);
 const url=new URL('https://api.search.brave.com/res/v1/web/search');
 for(const [k,v] of Object.entries({q:query,country:'HU',search_lang:'hu',count:'20',safesearch:'strict'}))url.searchParams.set(k,v);
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),timeoutMs);
 try{
  const res=await request(url.toString(),{headers:{Accept:'application/json','X-Subscription-Token':key},signal:controller.signal});
  if(!res.ok)throw Error('Index API HTTP '+res.status);
  const json=await res.json(),found=Array.isArray(json.web?.results)?json.web.results:[];
  const seen=new Set(),jobs=[];
  for(const item of found){
   const link=safePortalUrl(item.url,board);
   if(!link||seen.has(link))continue;seen.add(link);
   const title=clean(item.title).replace(/<[^>]+>/g,'').slice(0,150),description=clean(item.description).replace(/<[^>]+>/g,'').slice(0,260);
   if(title.length<5)continue;
   const fit=scoreSnippet({title,description},p);
   if(!fit.score)continue;
   jobs.push({title,description,url:link,board:board.name,preliminaryRelevance:fit.score,signals:fit.reasons,verified:false});
  }
  jobs.sort((a,b)=>b.preliminaryRelevance-a.preliminaryRelevance);
  return {id:board.id,board:board.name,query,openSearch:board.openUrl,status:'searched',jobs:jobs.slice(0,12),checkedOnOriginalSite:false};
 }catch(e){return {id:board.id,board:board.name,query,openSearch:board.openUrl,status:'failed',jobs:[],reason:String(e?.name==='AbortError'?'Search timeout':e?.message||'Search failed').slice(0,80)};}
 finally{clearTimeout(timer)}
}
const minuteCounters={window:0,count:0};
function reserveSearch({now=Date.now(),limit=12}={}){
 // Constrains potentially paid external API requests, not a claim of global distributed rate limiting.
 const window=Math.floor(now/60000);
 if(minuteCounters.window!==window){minuteCounters.window=window;minuteCounters.count=0}
 if(minuteCounters.count>=limit)return false;
 minuteCounters.count++;return true;
}
async function searchCVPortals(input,{key=process.env.BRAVE_SEARCH_API_KEY||process.env.BRAVE_API_KEY,request=globalThis.fetch,rateLimit=12}={}){
 if(input?.externalSearchConsent!==true)throw Object.assign(Error('A külső kereséshez kifejezett hozzájárulás szükséges'),{status:400});
 const p=sanitizedProfile(input.profile||input);
 if(!key)return {ok:false,status:'not_configured',message:'BRAVE_SEARCH_API_KEY is required for actual portal searching',boards:BOARDS.map(b=>({id:b.id,name:b.name,openSearch:b.openUrl,status:'not_configured',jobs:[]})),personalDataStored:false};
 if(!reserveSearch({limit:rateLimit}))throw Object.assign(Error('Túl sok külső keresés, próbáld újra később'),{status:429});
 const boards=await Promise.all(BOARDS.map(board=>searchOne(board,p,{request,key})));
 return {ok:boards.some(b=>b.status==='searched'),status:boards.every(b=>b.status==='searched')?'searched':boards.some(b=>b.status==='searched')?'partial':'unavailable',boards,
  meta:{scouts:2,scope:'Profession.hu and CVonline.hu only',personalDataStored:false,rawCvSent:false,jobDetailsVerified:false,
  relevanceExplanation:'Heuristic match from search-index title and snippet, NOT verified fit percentage or hiring probability',
  notice:'Eredeti hirdetés megnyitása és ellenőrzése szükséges jelentkezés előtt; nincs közvetlen portál-scraping.'}};
}
module.exports={BOARDS,sanitizedProfile,buildQuery,safePortalUrl,scoreSnippet,searchOne,searchCVPortals,reserveSearch};
