'use strict';
/** All persistent data is public job catalogue data. Never stores CV or user profile. */
const {normalizeJob}=require('./normalize');
const fs=require('node:fs');const path=require('node:path');
function newPool(env=process.env){
 if(!env.DATABASE_URL)throw Error('DATABASE_URL (persistent PostgreSQL) is required');
 const {Pool}=require('pg');return new Pool({connectionString:env.DATABASE_URL,max:Math.min(8,Number(env.DB_POOL_SIZE)||5),connectionTimeoutMillis:7000,idleTimeoutMillis:15000,ssl:env.PGSSLMODE==='require'?{rejectUnauthorized:true}:undefined});
}
async function migrate(pool){await pool.query(fs.readFileSync(path.join(__dirname,'schema.sql'),'utf8'));await pool.query(fs.readFileSync(path.join(__dirname,'schema-v2.sql'),'utf8'));await pool.query(fs.readFileSync(path.join(__dirname,'schema-v3.sql'),'utf8'));await pool.query(fs.readFileSync(path.join(__dirname,'ai/schema-v4.sql'),'utf8'));await pool.query(fs.readFileSync(path.join(__dirname,'ai/schema-v5.sql'),'utf8'));await pool.query(fs.readFileSync(path.join(__dirname,'schema-v6.sql'),'utf8'));await pool.query(fs.readFileSync(path.join(__dirname,'schema-v7.sql'),'utf8'));}
async function seed(pool,sources){
 let count=0;
 for(const src of sources){
  const locations=Array.isArray(src.location_filters)?src.location_filters:[];
  if(locations.length>12||locations.some(x=>typeof x!=='string'||!x.trim()||x.length>100||/[\x00-\x1f\x7f]/.test(x)))
   throw Error('Invalid location_filters for source '+src.source_key);
  await pool.query(`INSERT INTO national_sources(source_key,name,category,engine,board,url,company,enabled,approved,country_scope,location_filters)
   VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11::jsonb)
   ON CONFLICT (source_key) DO UPDATE SET name=EXCLUDED.name,category=EXCLUDED.category,engine=EXCLUDED.engine,
    board=EXCLUDED.board,url=EXCLUDED.url,company=EXCLUDED.company,country_scope=EXCLUDED.country_scope,
    location_filters=EXCLUDED.location_filters,updated_at=NOW()
    -- Never overwrite enable/approval toggles from the database during re-seed
   `,[src.source_key,src.name,src.category,src.engine,src.board||null,src.url||null,src.company||null,!!src.enabled,!!src.approved,src.country_scope||'mixed',JSON.stringify([...new Set(locations.map(x=>x.trim()))])]);count++;
 }
 return count;
}
async function upsertSnapshot(pool,src,rawJobs,{complete=true}={}){
 const client=await pool.connect(),seen=[],externalSeen=new Set(),perJob=new Set();
 try{
  await client.query('BEGIN');
  for(const raw of rawJobs){
   const j=normalizeJob(raw,src);if(!j)continue;
   // Do not double-count a repeated source id in a single batch.
   if(externalSeen.has(j.external_id))continue;
   externalSeen.add(j.external_id);seen.push(j.external_id);perJob.add(j.job_key);
   await client.query(`INSERT INTO national_jobs(job_key,canonical_url,company,title,location_text,country_status,description,language,published_at,duplicate_group,content_fingerprint)
     VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
     ON CONFLICT(job_key) DO UPDATE SET company=EXCLUDED.company,title=EXCLUDED.title,
      location_text=EXCLUDED.location_text,country_status=EXCLUDED.country_status,
      description=CASE WHEN length(EXCLUDED.description)>0 THEN EXCLUDED.description ELSE national_jobs.description END,
      language=COALESCE(EXCLUDED.language,national_jobs.language),published_at=COALESCE(EXCLUDED.published_at,national_jobs.published_at),
      duplicate_group=EXCLUDED.duplicate_group,content_fingerprint=EXCLUDED.content_fingerprint,
      state='observed',last_seen_at=NOW(),updated_at=NOW()`,
    [j.job_key,j.url,j.company,j.title,j.location,j.country_status,j.description,j.language,j.published_at,j.duplicate_group,require('node:crypto').createHash('sha256').update([j.title,j.company,j.location,j.description].join('\n')).digest('hex')]);
   const previous=await client.query('SELECT job_key FROM national_observations WHERE source_key=$1 AND external_id=$2',[src.source_key,j.external_id]);
   await client.query(`INSERT INTO national_observations(source_key,external_id,job_key)
      VALUES($1,$2,$3)
      ON CONFLICT(source_key,external_id) DO UPDATE SET job_key=EXCLUDED.job_key,last_seen_at=NOW(),present=true`,
     [src.source_key,j.external_id,j.job_key]);
   const oldKey=previous.rows[0]?.job_key;
   if(oldKey&&oldKey!==j.job_key)await client.query(`UPDATE national_jobs j SET state='closed',updated_at=NOW()
    WHERE j.job_key=$1 AND NOT EXISTS(SELECT 1 FROM national_observations o WHERE o.job_key=j.job_key AND o.present=true)`,[oldKey]);
  }
  if(complete){
   await client.query(`UPDATE national_observations SET present=false WHERE source_key=$1 AND present=true
     AND NOT (external_id = ANY($2::text[]))`,[src.source_key,seen]);
   await client.query(`UPDATE national_jobs j SET state='closed',updated_at=NOW() WHERE j.state='observed'
     AND EXISTS(SELECT 1 FROM national_observations o WHERE o.job_key=j.job_key AND o.source_key=$1)
     AND NOT EXISTS(SELECT 1 FROM national_observations o WHERE o.job_key=j.job_key AND o.present=true)`,[src.source_key]);
  }
  await client.query(`UPDATE national_sources SET last_checked_at=NOW(),last_success_at=NOW(),last_error=NULL,
    success_count=success_count+1,verified_hu_count=$2,fail_count=GREATEST(0,fail_count-1),consecutive_failures=0,
    next_due_at=NOW()+($3||' minutes')::interval WHERE source_key=$1`,[src.source_key,rawJobs.filter(j=>normalizeJob(j,src)?.country_status==='hu').length,Math.max(30,Number(process.env.NATIONAL_REFRESH_MINUTES)||210)]);
  await client.query('COMMIT');
  return {total:seen.length,hu:rawJobs.filter(j=>normalizeJob(j,src)?.country_status==='hu').length,complete};
 }catch(e){await client.query('ROLLBACK');throw e}finally{client.release()}
}
/** Adaptive retry: short waits for transient timeouts, increasing only after repeated failures.
 * Authorization or rate-limit errors are NEVER expedited. All policy settings are bounded.
 */
function retryDelayMinutes(error,previousFailures=0){
 const message=String(error?.message||error||'');
 if(/Source HTTP (401|403)(?:\D|$)/.test(message))return 240;
 if(/Source HTTP 429(?:\D|$)/.test(message))return 120;
 const failures=Math.max(0,Math.min(5,Number(previousFailures)||0));
 if(/abort|timed?\s*out|timeout|ETIMEDOUT|ECONNRESET/i.test(message))return Math.min(60,5*2**failures);
 return Math.min(120,10*2**failures);
}
async function sourceFailure(pool,src,error){
 const message=String(error?.message||error).slice(0,300);
 const cooldownMinutes=retryDelayMinutes(error,src.consecutive_failures);
 await pool.query(`UPDATE national_sources SET last_checked_at=NOW(),fail_count=fail_count+1,
  consecutive_failures=consecutive_failures+1,last_error=$2,
  next_due_at=NOW()+($3::int * INTERVAL '1 minute') WHERE source_key=$1`,
  [src.source_key,message,cooldownMinutes]);
 return {cooldownMinutes};
}
async function dueSources(pool,max=150){
 const r=await pool.query(`SELECT * FROM national_sources WHERE enabled=true AND approved=true AND engine<>'registry'
 AND (next_due_at<=NOW() OR (
   -- One-time compatibility for old fixed 60-minute failures before v0.3.3:
   consecutive_failures=0 AND last_error IS NOT NULL AND last_checked_at<=NOW()-INTERVAL '5 minutes'
   AND last_error !~* '^Source HTTP (401|403|429)([^0-9]|$)'
 )) ORDER BY last_checked_at NULLS FIRST,source_key LIMIT $1`,[max]);
 return require('./ai/bandit').prioritize(r.rows);
}
/** Explicit one-source diagnostic: bypass due_at ONLY for an approved active source.
 * Atomic database throttling prevents repeated manual calls. No disabling safety rules.
 */
async function selectManualRetrySource(pool,sourceKey){
 if(typeof sourceKey!=='string'||!(/^[a-z0-9_-]+:[a-zA-Z0-9_-]+$/).test(sourceKey)||sourceKey.length>120)
  throw Error('Invalid source key');
 const r=await pool.query(`UPDATE national_sources SET last_manual_retry_at=NOW()
 WHERE source_key=$1 AND enabled=true AND approved=true AND engine<>'registry'
 AND (last_manual_retry_at IS NULL OR last_manual_retry_at<=NOW()-INTERVAL '2 minutes')
 AND (last_checked_at IS NULL OR last_checked_at<=NOW()-INTERVAL '60 seconds')
 -- A manual diagnostic must not evade the remote service's rate-limiting/denial.
 AND NOT (last_error ~* '^Source HTTP (401|403|429)([^0-9]|$)' AND next_due_at>NOW())
 RETURNING *`,[sourceKey]);
 return r.rows[0]||null;
}
async function stats(pool){const r=await pool.query(`SELECT (SELECT COUNT(*)::int FROM national_sources) AS sources,
 (SELECT COUNT(*)::int FROM national_sources WHERE enabled=true) AS enabled_sources,
 (SELECT COUNT(*)::int FROM national_jobs) AS all_jobs,
 (SELECT COUNT(*)::int FROM national_jobs WHERE country_status='hu' AND state='observed' AND last_seen_at>NOW()-INTERVAL '72 hours') AS active_hu_jobs,
 (SELECT COUNT(*)::int FROM national_jobs WHERE country_status='unknown') AS location_review,
 (SELECT COUNT(*)::int FROM national_places) AS places_available,
 (SELECT COUNT(*)::int FROM national_jobs WHERE country_status='unknown') AS country_unknown,
 (SELECT COUNT(*)::int FROM national_jobs WHERE embedding IS NOT NULL) AS jobs_with_embeddings,
 (SELECT MAX(finished_at) FROM national_runs) AS last_run`);return r.rows[0]}
async function search(pool,{q='',region='',limit=40,offset=0}={}){
 const {parseGeo,predicates}=require('./search/geo');
 limit=Math.min(100,Math.max(1,Number(limit)||40));offset=Math.min(20000,Math.max(0,Number(offset)||0));
 const query=String(q||'').trim().slice(0,150),place=String(region||'').trim().slice(0,100);
 const gp=predicates(parseGeo({region:place}),{jobAlias:'j',start:2});
 const params=[query,...gp.params,limit,offset];
 const r=await pool.query(`SELECT j.job_key,j.title,j.company,j.location_text,j.canonical_url,j.language,j.published_at,j.last_seen_at,
     j.description,j.country_status FROM national_jobs j WHERE j.country_status='hu' AND j.state='observed'
     AND j.last_seen_at>NOW()-INTERVAL '72 hours'
     AND ($1='' OR to_tsvector('simple',j.title||' '||j.company||' '||left(j.description,2500)) @@ plainto_tsquery('simple',$1)
      OR j.title ILIKE '%'||replace(replace(replace($1,'!','!!'),'%','!%'),'_','!_')||'%' ESCAPE '!')
     ${gp.sql}
     ORDER BY j.last_seen_at DESC,j.job_key ASC LIMIT $${params.length-1} OFFSET $${params.length}`,params);
 return r.rows;
}
async function audit(pool){
 const summary=await stats(pool);
 const last=(await pool.query('SELECT run_id,started_at,finished_at,sources_attempted,sources_succeeded,sources_failed,jobs_seen,jobs_hu,errors FROM national_runs ORDER BY run_id DESC LIMIT 1')).rows[0]||null;
 const failures=(await pool.query('SELECT source_key,last_error FROM national_sources WHERE enabled AND last_error IS NOT NULL ORDER BY last_checked_at DESC LIMIT 15')).rows;
 const issues=[];
 if(Number(summary.enabled_sources)<30)issues.push('Kevés ténylegesen bekötött forrás; a regisztrált források nem egyenlők az aktív gyűjtőkkel.');
 if(Number(summary.places_available)===0)issues.push('A km-alapú földrajzi kereséshez nincs betöltött hiteles koordinátatár.');
 if(Number(summary.jobs_with_embeddings)===0)issues.push('A szemantikus kereséshez nincs előállított állás-embedding.');
 if(Number(summary.country_unknown)>Number(summary.active_hu_jobs))issues.push('Sok állás országkódja bizonytalan; ezek nincsenek automatikusan magyarnak besorolva.');
 if(!last)issues.push('Még nincs befejezett adatgyűjtési futás.');
 else if(Number(last.sources_failed)>0)issues.push('A legutóbbi adatgyűjtésben hibás forrás is volt.');
 return {readyForNationalCoverage:issues.length===0,summary,lastRun:last,failedSources:failures,issues};
}
module.exports={newPool,migrate,seed,upsertSnapshot,sourceFailure,retryDelayMinutes,dueSources,selectManualRetrySource,stats,search,audit};
