'use strict';
const {embeddings,vectorLiteral}=require('./search/semantic');
const safePositive=(raw,def,max)=>Math.min(max,Math.max(1,Number(raw)||def));
async function runEmbeddingBatch(pool,{key=process.env.OPENAI_API_KEY,request=globalThis.fetch,batchSize=16,maxJobs=Number(process.env.NATIONAL_EMBED_MAX_PER_RUN)||40}={}){
 if(!key)return {status:'disabled',processed:0,reason:'No OPENAI_API_KEY'};
 maxJobs=safePositive(maxJobs,40,200);batchSize=safePositive(batchSize,16,32);
 const res=await pool.query(`SELECT job_key,title,company,location_text,left(description,2800) AS description,content_fingerprint FROM national_jobs
 WHERE country_status='hu' AND state='observed' AND last_seen_at>now()-interval '72 hours'
 AND (embedding IS NULL OR embedding_fingerprint IS DISTINCT FROM content_fingerprint)
 ORDER BY last_seen_at DESC LIMIT $1`,[maxJobs]);
 let processed=0,skipped=0;
 for(let i=0;i<res.rows.length;i+=batchSize){
  const items=res.rows.slice(i,i+batchSize),input=items.map(j=>[j.title,j.company,j.location_text,j.description].filter(Boolean).join('\n').slice(0,7000));
  const vectors=await embeddings(input,{key,request});
  for(let n=0;n<items.length;n++){
   const j=items[n],v=vectorLiteral(vectors[n]);
   const r=await pool.query(`UPDATE national_jobs SET embedding=$1::vector,embedding_fingerprint=$2,embedding_updated_at=now()
    WHERE job_key=$3 AND content_fingerprint=$2`,[v,j.content_fingerprint,j.job_key]);
   if(r.rowCount===1)processed++;else skipped++;
  }
 }
 return {status:'ok',processed,skipped,totalCandidates:res.rows.length};
}
module.exports={runEmbeddingBatch};
