"use strict";
/** Hungary GeoNames county/city importer (CC BY 4.0, https://www.geonames.org/).
 * Source ZIP: https://download.geonames.org/export/dump/HU.zip .
 * No geographic coordinates are invented or inferred from a CV.
 * `unzip -p` extracts only the fixed HU.txt entry (no filesystem path extraction).
 */
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto');
const {spawnSync}=require('node:child_process');
const {normalize}=require('./places');
const SOURCE='GeoNames Hungary, CC BY 4.0, https://www.geonames.org/';
const ARCHIVE='https://download.geonames.org/export/dump/HU.zip';
const ALLOWED=new Set(['PPL','PPLA','PPLA2','PPLA3','PPLA4','PPLC','PPLF','PPLG','PPLL']);
function validCoord(lat,lon){return Number.isFinite(lat)&&Number.isFinite(lon)&&lat>=45&&lat<=49&&lon>=16&&lon<=23;}
function parseHU(text){
 const counties=new Map(),candidate=[];let ignored=0;
 for(const line of String(text).split(/\r?\n/)){
  if(!line.trim())continue; const v=line.split('\t');
  if(v.length<18||v[8]!=='HU'){ignored++;continue;}
  const name=v[1]?.trim(),classCode=v[6],feature=v[7],code=v[10]?.trim(),lat=Number(v[4]),lon=Number(v[5]);
  if(!name||!validCoord(lat,lon)){ignored++;continue;}
  if(classCode==='A'&&feature==='ADM1'&&code){counties.set(code,name);continue;}
  if(classCode!=='P'||!ALLOWED.has(feature)){ignored++;continue;}
  candidate.push({name,code,lat,lon,priority:feature==='PPLC'?100:feature==='PPLA'?50:feature==='PPLA2'?20:10,population:Math.max(0,Number(v[14])||0)});
 }
 const map=new Map();let unresolved=0;
 for(const p of candidate){const county=counties.get(p.code);if(!county){unresolved++;continue;}
  const norm=normalize(p.name)+'|'+normalize(county),old=map.get(norm);
  if(!old||p.priority>old.priority||(p.priority===old.priority&&p.population>old.population))map.set(norm,{name:p.name,county,lat:p.lat,lon:p.lon,priority:p.priority,population:p.population});
 }
 return {places:[...map.values()].sort((a,b)=>a.county.localeCompare(b.county,'hu')||a.name.localeCompare(b.name,'hu')),counties:counties.size,unresolved,ignored};
}
async function fetchArchive({request=globalThis.fetch,url=ARCHIVE,timeoutMs=45000,maxBytes=14000000}={}){
 if(new URL(url).protocol!=='https:'||new URL(url).hostname!=='download.geonames.org')throw Error('Unexpected GeoNames download URL');
 const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),timeoutMs);
 try{const r=await request(url,{headers:{'User-Agent':'AI-Fejvadasz-NationalIndex/0.2.2 (+GeoNames CC-BY Attribution)'},signal:controller.signal,redirect:'follow'});
  if(!r.ok)throw Error('GeoNames download returned HTTP '+r.status);
  const l=Number(r.headers?.get?.('content-length')||0);if(l>maxBytes)throw Error('GeoNames ZIP too large');
  const chunks=[];let total=0;
  if(r.body&&Symbol.asyncIterator in r.body){for await(const c of r.body){total+=c.length;if(total>maxBytes)throw Error('GeoNames ZIP exceeded size limit');chunks.push(Buffer.from(c))}}
  else{const b=Buffer.from(await r.arrayBuffer());if(b.length>maxBytes)throw Error('GeoNames ZIP exceeded size limit');chunks.push(b)}
  const buf=Buffer.concat(chunks);if(buf[0]!==80||buf[1]!==75)throw Error('Not a GeoNames ZIP');return buf;
 }finally{clearTimeout(timer)}
}
function unzipHU(zip){const temp=fs.mkdtempSync(path.join(os.tmpdir(),'fejvadasz-hu-'));try{
 const file=path.join(temp,'HU.zip');fs.writeFileSync(file,zip);
 const x=spawnSync('unzip',['-p',file,'HU.txt'],{encoding:'utf8',maxBuffer:45000000,timeout:18000});
 if(x.status!==0||!x.stdout)throw Error('GeoNames ZIP extraction failed: '+String(x.stderr||'').slice(0,150));return x.stdout;
}finally{fs.rmSync(temp,{recursive:true,force:true})}}
async function importGeoNames(pool,{zipPath,request,minPlaces=1000,minCounties=15,force=false}={}){
 const existing=await pool.query('SELECT count(*)::int AS n FROM national_places');
 const existingCount=Number(existing.rows[0]?.n)||0;
 if(!force&&existingCount>=minPlaces)return {status:'already_present',places:existingCount,source:SOURCE};
 const zip=zipPath?fs.readFileSync(zipPath):await fetchArchive({request});
 if(zip.length>14000000)throw Error('GeoNames ZIP too large');
 const data=parseHU(unzipHU(zip));if(data.counties<minCounties||data.places.length<minPlaces)throw Error('GeoNames country file incomplete: '+data.counties+' counties, '+data.places.length+' valid places');
 const client=await pool.connect(),batchSize=100;let imported=0;
 try{await client.query('BEGIN');
  for(let i=0;i<data.places.length;i+=batchSize){const batch=data.places.slice(i,i+batchSize),values=[],parts=[];
   for(let j=0;j<batch.length;j++){
    const p=batch[j],offset=j*6,k=crypto.createHash('sha256').update(normalize(p.name)+'|'+normalize(p.county)).digest('hex').slice(0,40);
    values.push(k,p.name,p.county,p.lat,p.lon,SOURCE);
    parts.push(`($${offset+1},$${offset+2},$${offset+3},ST_SetSRID(ST_MakePoint($${offset+5},$${offset+4}),4326)::geography,$${offset+6})`);
   }
   await client.query(`INSERT INTO national_places(place_key,name,county,location,source_note) VALUES ${parts.join(',')}
    ON CONFLICT(place_key) DO UPDATE SET name=EXCLUDED.name,county=EXCLUDED.county,location=EXCLUDED.location,source_note=EXCLUDED.source_note,updated_at=now()`,values);
   imported+=batch.length;
  }
  await client.query('COMMIT');
 }catch(e){await client.query('ROLLBACK');throw e}finally{client.release()}
 return {status:'imported',places:imported,counties:data.counties,unresolved:data.unresolved,source:SOURCE,license:'CC BY 4.0'};
}
module.exports={ARCHIVE,SOURCE,parseHU,fetchArchive,unzipHU,importGeoNames};
