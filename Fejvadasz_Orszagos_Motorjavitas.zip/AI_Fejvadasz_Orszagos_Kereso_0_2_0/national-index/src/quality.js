"use strict";
const COLLECTABLE=['greenhouse','lever','ashby','smartrecruiters','workable','rss','sitemap'];
const DEFAULT_TARGET=1000;
function classifyEngine({engine,source_count,hu_jobs,errors,target=DEFAULT_TARGET}){
 const sources=Number(source_count)||0,hu=Number(hu_jobs)||0,failed=Number(errors)||0;
 return {engine,active_sources:sources,observed_hu_unique_jobs:hu,target,
  status:hu>=target?'target_met':sources===0?'no_active_sources':'needs_development',
  gap:Math.max(0,target-hu),failures:failed,
  actions:sources===0?['Új, ellenőrzött magyar forráscsatlakozó szükséges.']:[...(failed?['Forráshibák kivizsgálása és javítása.']:[]),...(hu<target?['További saját állásfeed/API források bekötése; ország- és duplikátumszűrés javítása.']:[])]};
}
async function engineTargets(pool,{target=DEFAULT_TARGET}={}){
 target=Math.min(100000,Math.max(1,Math.trunc(Number(target))||DEFAULT_TARGET));
 const q=await pool.query(`SELECT s.engine,
   COUNT(DISTINCT s.source_key)::int AS source_count,
   COUNT(DISTINCT j.job_key) FILTER (WHERE j.country_status='hu' AND j.state='observed' AND j.last_seen_at>=now()-interval '14 days')::int AS hu_jobs,
   COUNT(DISTINCT s.source_key) FILTER(WHERE s.last_error IS NOT NULL)::int AS errors
  FROM national_sources s
  LEFT JOIN national_observations o ON o.source_key=s.source_key AND o.present=true
  LEFT JOIN national_jobs j ON j.job_key=o.job_key
  WHERE s.enabled=true AND s.engine <> 'registry'
  GROUP BY s.engine`);
 const byName=new Map(q.rows.map(x=>[x.engine,x]));
 return {target_per_engine:target,unit:'egyedi magyarországi megfigyelt álláshirdetés / gyűjtőmotortípus (14 nap)',
  verification:'Nem jelent külön URL-elérhetőségi vagy jogi aktívhirdetés-ellenőrzést.',
  engines:COLLECTABLE.map(engine=>classifyEngine({engine,...(byName.get(engine)||{}),target})),
  all_targets_met:COLLECTABLE.every(engine=>Number(byName.get(engine)?.hu_jobs||0)>=target)};
}
module.exports={COLLECTABLE,DEFAULT_TARGET,classifyEngine,engineTargets};
