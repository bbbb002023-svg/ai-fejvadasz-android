-- AI Fejvadasz national index v0.2; add-ons to schema.sql; PostgreSQL >=14.
-- Render supports vector, postgis and pg_trgm; fail clearly if unavailable.
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pg_trgm;

ALTER TABLE national_jobs ADD COLUMN IF NOT EXISTS content_fingerprint text NOT NULL DEFAULT '';
ALTER TABLE national_jobs ADD COLUMN IF NOT EXISTS embedding vector(512);
ALTER TABLE national_jobs ADD COLUMN IF NOT EXISTS embedding_fingerprint text;
ALTER TABLE national_jobs ADD COLUMN IF NOT EXISTS embedding_updated_at timestamptz;
CREATE INDEX IF NOT EXISTS national_jobs_description_trgm ON national_jobs USING gin ((left(description,2500)) gin_trgm_ops);
CREATE INDEX IF NOT EXISTS national_jobs_title_trgm ON national_jobs USING gin (title gin_trgm_ops);
CREATE INDEX IF NOT EXISTS national_jobs_embedding_hnsw ON national_jobs USING hnsw (embedding vector_cosine_ops);

CREATE TABLE IF NOT EXISTS national_places (
  place_key text PRIMARY KEY,
  name text NOT NULL,
  county text NOT NULL,
  location geography(Point,4326) NOT NULL,
  source_note text NOT NULL DEFAULT '',
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(name,county)
);
CREATE INDEX IF NOT EXISTS national_places_location_gix ON national_places USING gist (location);
CREATE INDEX IF NOT EXISTS national_places_name_trgm ON national_places USING gin (name gin_trgm_ops);
CREATE INDEX IF NOT EXISTS national_places_county_idx ON national_places (lower(county));

CREATE TABLE IF NOT EXISTS national_job_places (
  job_key text NOT NULL REFERENCES national_jobs(job_key) ON DELETE CASCADE,
  place_key text NOT NULL REFERENCES national_places(place_key) ON DELETE CASCADE,
  linked_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (job_key,place_key)
);
CREATE INDEX IF NOT EXISTS national_job_places_place_idx ON national_job_places(place_key);

CREATE TABLE IF NOT EXISTS national_search_metrics (
  engine text PRIMARY KEY CHECK(engine IN ('text','semantic','geo','ranking')),
  searches bigint NOT NULL DEFAULT 0,
  results bigint NOT NULL DEFAULT 0,
  errors bigint NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO national_search_metrics(engine) VALUES ('text'),('semantic'),('geo'),('ranking') ON CONFLICT DO NOTHING;
