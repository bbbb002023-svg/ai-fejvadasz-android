-- v0.2.2: idempotent, data-preserving migration for the Workable adapter.
-- Older databases were created before Workable existed, and CREATE TABLE IF NOT EXISTS
-- does not change an already existing CHECK constraint.
BEGIN;
ALTER TABLE national_sources DROP CONSTRAINT IF EXISTS national_sources_engine_check;
ALTER TABLE national_sources ADD CONSTRAINT national_sources_engine_check
  CHECK (engine IN ('greenhouse','lever','ashby','smartrecruiters','workable','rss','sitemap','registry'));
-- Correct only explicitly supplied HU country codes in already collected locations.
-- Do not guess the country from titles, job descriptions, or CV information.
UPDATE national_jobs SET country_status='hu',updated_at=NOW()
 WHERE country_status='unknown' AND location_text ~* '(^|[,;[:space:]])hu([,;[:space:]]|$)';
COMMIT;
