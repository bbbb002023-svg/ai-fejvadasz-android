-- v0.3.2: optional, explicitly reviewed Lever locations; safe to rerun.
BEGIN;
ALTER TABLE national_sources ADD COLUMN IF NOT EXISTS location_filters jsonb NOT NULL DEFAULT '[]'::jsonb;
COMMIT;
