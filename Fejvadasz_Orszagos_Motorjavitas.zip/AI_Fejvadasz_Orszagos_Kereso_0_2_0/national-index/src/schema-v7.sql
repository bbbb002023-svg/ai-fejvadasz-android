-- v0.3.3 retry scheduling: retain existing jobs and previously approved sources.
ALTER TABLE national_sources ADD COLUMN IF NOT EXISTS consecutive_failures integer NOT NULL DEFAULT 0;
ALTER TABLE national_sources ADD COLUMN IF NOT EXISTS last_manual_retry_at timestamptz;
-- Existing v0.3.2 cooldowns stay recorded; the collector can give older transient
-- failures one early chance without ignoring HTTP 401/403/429 restrictions.
