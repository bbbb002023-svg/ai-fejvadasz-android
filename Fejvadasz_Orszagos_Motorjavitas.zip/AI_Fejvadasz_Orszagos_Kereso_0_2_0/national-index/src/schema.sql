-- Orszagos AI Fejvadasz index 0.1 (PostgreSQL 14+). No CVs or personal profiles.
CREATE TABLE IF NOT EXISTS national_sources (
  source_key text PRIMARY KEY,
  name text NOT NULL,
  category text NOT NULL CHECK (category IN ('employer','recruiter','portal')),
  engine text NOT NULL CHECK (engine IN ('greenhouse','lever','ashby','smartrecruiters','rss','sitemap','registry')),
  board text,
  url text,
  company text,
  enabled boolean NOT NULL DEFAULT false,
  approved boolean NOT NULL DEFAULT false,
  country_scope text NOT NULL DEFAULT 'mixed' CHECK (country_scope IN ('mixed','hu_only')),
  last_success_at timestamptz,
  last_error text,
  last_checked_at timestamptz,
  success_count integer NOT NULL DEFAULT 0,
  fail_count integer NOT NULL DEFAULT 0,
  verified_hu_count bigint NOT NULL DEFAULT 0,
  next_due_at timestamptz NOT NULL DEFAULT NOW(),
  created_at timestamptz NOT NULL DEFAULT NOW(),
  updated_at timestamptz NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS national_sources_due ON national_sources(enabled,next_due_at);
CREATE TABLE IF NOT EXISTS national_jobs (
  job_key text PRIMARY KEY,
  canonical_url text NOT NULL UNIQUE,
  company text NOT NULL,
  title text NOT NULL,
  location_text text NOT NULL DEFAULT '',
  country_status text NOT NULL DEFAULT 'unknown' CHECK (country_status IN ('hu','unknown','foreign')),
  description text NOT NULL DEFAULT '',
  language text,
  published_at timestamptz,
  last_seen_at timestamptz NOT NULL DEFAULT NOW(),
  first_seen_at timestamptz NOT NULL DEFAULT NOW(),
  state text NOT NULL DEFAULT 'observed' CHECK (state IN ('observed','closed')),
  duplicate_group text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS national_jobs_active ON national_jobs(country_status,state,last_seen_at DESC);
CREATE INDEX IF NOT EXISTS national_jobs_group ON national_jobs(duplicate_group);
CREATE INDEX IF NOT EXISTS national_jobs_search ON national_jobs USING gin (to_tsvector('simple',title||' '||company||' '||left(description,2500)));
CREATE TABLE IF NOT EXISTS national_observations (
  source_key text NOT NULL REFERENCES national_sources(source_key),
  external_id text NOT NULL,
  job_key text NOT NULL REFERENCES national_jobs(job_key),
  first_seen_at timestamptz NOT NULL DEFAULT NOW(),
  last_seen_at timestamptz NOT NULL DEFAULT NOW(),
  present boolean NOT NULL DEFAULT true,
  PRIMARY KEY (source_key,external_id)
);
CREATE INDEX IF NOT EXISTS national_obs_job ON national_observations(job_key,present);
CREATE TABLE IF NOT EXISTS national_runs (
  run_id bigserial PRIMARY KEY,
  started_at timestamptz NOT NULL DEFAULT NOW(),
  finished_at timestamptz,
  sources_attempted integer NOT NULL DEFAULT 0,
  sources_succeeded integer NOT NULL DEFAULT 0,
  sources_failed integer NOT NULL DEFAULT 0,
  jobs_seen integer NOT NULL DEFAULT 0,
  jobs_hu integer NOT NULL DEFAULT 0,
  errors jsonb NOT NULL DEFAULT '[]'::jsonb
);
