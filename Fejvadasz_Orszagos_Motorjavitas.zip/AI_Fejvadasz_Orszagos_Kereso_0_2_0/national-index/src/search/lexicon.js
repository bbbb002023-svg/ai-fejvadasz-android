'use strict';
// Role descriptions rather than CV fields; vocabulary can be reviewed and expanded.
const FAMILIES=[
 ['területi képviselő','teruleti kepviselo','területi értékesítő','üzletkötő','sales representative','field sales representative','territory sales representative','außendienstmitarbeiter','aussendienstmitarbeiter','gebietsvertreter'],
 ['területi vezető','teruletvezeto','területi értékesítési vezető','area sales manager','regional sales manager','territory manager','gebietsleiter','regionalverkaufsleiter'],
 ['értékesítési vezető','sales manager','kereskedelmi vezető','vertriebsleiter','head of sales'],
 ['ügyfélkapcsolati munkatárs','account manager','key account manager','ügyfélmenedzser','kundenbetreuer','partnerkapcsolati menedzser'],
 ['bolti eladó','üzleti értékesítő','store sales assistant','shop assistant','verkaufsmitarbeiter'],
 ['szoftverfejlesztő','programozó','developer','software engineer','softwareentwickler'],
 ['raktáros','warehouse operative','lagerist','logisztikai munkatárs'],
 ['projektvezető','project manager','projektmenedzser','projektleiter']
];
const fold=x=>String(x||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').replace(/\s+/g,' ').trim();
const groups=FAMILIES.map(f=>[...new Set(f)]);
function expand(query,{max=9}={}){
 const q=String(query||'').trim().slice(0,160);if(!q)return [];
 const canon=fold(q),matched=groups.filter(group=>group.some(s=>fold(s)===canon));
 // Broader terms only for a named role. Generic skill queries remain strict.
 const extra=matched.flatMap(group=>group);
 return [...new Set([q,...extra])].slice(0,Math.max(1,Math.min(20,max)));
}
module.exports={FAMILIES,fold,expand};
