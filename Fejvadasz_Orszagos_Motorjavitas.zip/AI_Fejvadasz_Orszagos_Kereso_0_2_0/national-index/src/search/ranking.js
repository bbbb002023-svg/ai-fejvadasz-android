'use strict';
const {fold}=require('./lexicon');
function mergeResults(textJobs=[],semanticJobs=[],limit=50){
 const byId=new Map();function add(items,channel){items.forEach((j,i)=>{let id=j.job_key;let o=byId.get(id);if(!o){o={...j,channels:[],fusionScore:0};byId.set(id,o)}o.fusionScore+=1/(60+i+1);o.channels.push(channel);});}
 add(textJobs,'text');add(semanticJobs,'semantic');
 return [...byId.values()].sort((a,b)=>b.fusionScore-a.fusionScore||String(a.job_key).localeCompare(String(b.job_key))).slice(0,Math.max(1,Math.min(200,Number(limit)||50))).map(({fusionScore,...job})=>job);
}
function personalize(jobs,{skills=[],targetRoles='',excludedRoles=''}={}){
 const terms=(Array.isArray(skills)?skills:[]).map(fold).filter(s=>s.length>2).slice(0,30),excluded=String(excludedRoles||'').split(/[,;\n]+/).map(fold).filter(Boolean);
 return jobs.map(job=>{
  const title=fold(job.title),all=fold([job.title,job.description].join(' '));
  if(excluded.some(t=>title.includes(t)))return null;
  const matched=terms.filter(t=>all.includes(t));
  return {...job,matchedSkills:matched,matchedSkillCount:matched.length};
 }).filter(Boolean).sort((a,b)=>b.matchedSkillCount-a.matchedSkillCount);
}
module.exports={mergeResults,personalize};
