'use strict';
const {parseGeo,predicates}=require('./geo');
const DIMENSIONS=512,MODEL='text-embedding-3-small';
function vectorLiteral(a){if(!Array.isArray(a)||a.length!==DIMENSIONS||a.some(n=>!Number.isFinite(n)))throw Error('Embedding format/dimension invalid');return '['+a.map(n=>Number(n).toFixed(8)).join(',')+']'}
async function embeddings(inputs,{key=process.env.OPENAI_API_KEY,request=globalThis.fetch,timeoutMs=20000}={}){
 if(!key)throw Object.assign(Error('OPENAI_API_KEY nincs beállítva'),{status:424});
 if(!Array.isArray(inputs)||inputs.length<1||inputs.length>32||inputs.some(x=>!String(x).trim()||String(x).length>8000))throw Error('Embedding input invalid');
 const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),timeoutMs);
 try{
  const response=await request('https://api.openai.com/v1/embeddings',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+key},body:JSON.stringify({model:MODEL,input:inputs,dimensions:DIMENSIONS,encoding_format:'float'}),signal:ctrl.signal});
  if(!response.ok)throw Error('Embedding API HTTP '+response.status);
  const body=await response.json();if(!Array.isArray(body.data)||body.data.length!==inputs.length)throw Error('Embedding API result incomplete');
  const indexed=[...body.data].sort((a,b)=>a.index-b.index).map(x=>x.embedding);indexed.forEach(vectorLiteral);return indexed;
 }finally{clearTimeout(timer)}
}
function semanticQuery({q,vector,region='',lat,lon,radius_km,limit=80}={}){
 if(!String(q||'').trim())throw Object.assign(Error('Szemantikus kereséshez szükséges a q'),{status:400});
 const geo=parseGeo({region,lat,lon,radius_km}),params=[vectorLiteral(vector)],gp=predicates(geo,{start:2});params.push(...gp.params);
 params.push(Math.max(1,Math.min(200,Number(limit)||80)));
 const sql=`SELECT j.job_key,j.title,j.company,j.location_text,j.canonical_url,j.description,j.language,j.published_at,j.last_seen_at,(1.0-(j.embedding <=> $1::vector))::float AS semantic_score FROM national_jobs j WHERE j.embedding IS NOT NULL AND j.country_status='hu' AND j.state='observed' AND j.last_seen_at>now()-interval '72 hours' ${gp.sql} ORDER BY j.embedding <=> $1::vector LIMIT $${params.length}`;
 return {sql,params};
}
async function searchSemantic(pool,{q,key,request,...filters}={}){
 if(!String(q||'').trim())return {jobs:[],status:'empty_query'};
 if(!key)return {jobs:[],status:'disabled'};
 try{const [vec]=await embeddings([q],{key,request});const x=semanticQuery({q,vector:vec,...filters});const r=await pool.query(x.sql,x.params);return {jobs:r.rows,status:'ok'};}
 catch(e){return {jobs:[],status:'unavailable',error:String(e.message).slice(0,130)}}
}
module.exports={DIMENSIONS,MODEL,vectorLiteral,embeddings,semanticQuery,searchSemantic};
