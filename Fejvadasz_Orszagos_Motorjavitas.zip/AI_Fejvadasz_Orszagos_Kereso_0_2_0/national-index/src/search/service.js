'use strict';
const {parseGeo}=require('./geo');const {searchText}=require('./text'),{searchSemantic}=require('./semantic'),{mergeResults,personalize}=require('./ranking');
function cleanMode(s){const x=String(s||'hybrid');if(!['hybrid','text','semantic'].includes(x))throw Object.assign(Error('Ismeretlen keresési mód'),{status:400});return x}
async function search(pool,{q='',mode='hybrid',limit=50,key=process.env.OPENAI_API_KEY,request=globalThis.fetch,...geo}={}){
 const checkedGeo=parseGeo(geo);
 if(checkedGeo.hasRadius){
  const ready=await pool.query('SELECT EXISTS(SELECT 1 FROM national_places LIMIT 1) AS available');
  if(!ready.rows[0]?.available)throw Object.assign(Error('A távolságalapú kereséshez még nincs betöltve település-koordináta adatbázis.'),{status:503});
 }
 const normalizedMode=cleanMode(mode),perEngine=Math.max(25,Math.min(200,Number(limit)*3||100));
 const common={q,limit:perEngine,...geo};let text={jobs:[],expanded:[]},semantic={jobs:[],status:'not_requested'};
 // Independent engines; failure in AI does not suppress PostgreSQL text results.
 const [t,s]=await Promise.all([
  normalizedMode==='semantic'?Promise.resolve(text):searchText(pool,common),
  normalizedMode==='text'?Promise.resolve(semantic):searchSemantic(pool,{...common,key,request})
 ]);
 text=t;semantic=s;
 if(normalizedMode==='semantic'&&semantic.status!=='ok')throw Object.assign(Error('A szemantikus motor nem elérhető: '+semantic.status),{status:503});
 return {jobs:mergeResults(text.jobs,semantic.jobs,limit),meta:{query:String(q).slice(0,160),mode:normalizedMode,textCount:text.jobs.length,semanticCount:semantic.jobs.length,semanticStatus:semantic.status,expandedQueries:text.expanded,geoFiltered:Boolean(geo.radius_km),note:'Az állások korábban megfigyelt állások; jelentkezés előtt ellenőrizd a hirdetést.'}};
}
async function recommend(pool,profile={},options={}){
 const target=String(profile.targetRoles||profile.targetRole||'').split(/[,;\n]+/)[0].trim();
 const q=target||String((profile.skills||[])[0]||'').slice(0,100);
 const r=await search(pool,{q,region:profile.region||profile.locations||'',mode:options.mode||'hybrid',limit:options.limit||40,key:options.key,request:options.request});
 return {...r,jobs:personalize(r.jobs,profile),meta:{...r.meta,personalization:'A felhasználói profilt nem mentjük az országos adatbázisba; szakmai illeszkedési százalékot ez az API nem állít.'}};
}
module.exports={search,recommend,cleanMode};
