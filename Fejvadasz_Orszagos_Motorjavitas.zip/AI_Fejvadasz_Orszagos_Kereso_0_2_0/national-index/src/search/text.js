'use strict';
const {expand}=require('./lexicon');const {parseGeo,predicates}=require('./geo');
const BASE=`j.job_key,j.title,j.company,j.location_text,j.canonical_url,j.description,j.language,j.published_at,j.last_seen_at`;
function textQuery({q='',region='',lat,lon,radius_km,limit=80}={}){
 const words=expand(q,{max:10}),geo=parseGeo({region,lat,lon,radius_km});
 const params=[];let conditions=`j.country_status='hu' AND j.state='observed' AND j.last_seen_at>now()-interval '72 hours'`;
 const where=[],titleScore=[];
 for(const phrase of words){params.push(phrase.replace(/[!%_]/g,m=>"!"+m));const k=params.length;
  where.push(`(j.title ILIKE '%'||$${k}||'%' ESCAPE '!' OR left(j.description,2500) ILIKE '%'||$${k}||'%' ESCAPE '!')`);
  titleScore.push(`CASE WHEN j.title ILIKE '%'||$${k}||'%' ESCAPE '!' THEN 1.0 ELSE 0 END`);
 }
 if(words.length)conditions+=` AND (${where.join(' OR ')})`;
 const gp=predicates(geo,{start:params.length+1});params.push(...gp.params);conditions+=gp.sql;
 params.push(Math.max(1,Math.min(200,Number(limit)||80)));
 const score=titleScore.length?`(${titleScore.join(' + ')})::float / ${titleScore.length}`:'0.0';
 const sql=`SELECT ${BASE},${score} AS text_score FROM national_jobs j WHERE ${conditions} ORDER BY text_score DESC,j.last_seen_at DESC,j.job_key LIMIT $${params.length}`;
 return {sql,params,expanded:words,geo};
}
async function searchText(pool,options){const query=textQuery(options);const res=await pool.query(query.sql,query.params);return {jobs:res.rows,expanded:query.expanded};}
module.exports={textQuery,searchText};
