 'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const E=require('../src/engines'),catalog=require('../config/sources.json');
const src=(engine,board)=>({engine,board,source_key:engine+':'+board,name:board,company:board,approved:true,enabled:true,country_scope:'mixed'});
const mock=fn=>async url=>{const x=fn(String(url));return {ok:true,status:200,headers:{get:()=>null},text:async()=>JSON.stringify(x)}};
test('Lever adapter paginates and never treats a truncated board as complete',async()=>{
 const seen=[];const fetch=mock(url=>{const q=new URL(url).searchParams,skip=Number(q.get('skip')),limit=Number(q.get('limit'));seen.push({skip,limit});return Array.from({length:limit},(_,i)=>({id:String(skip+i),text:'Sales Manager',hostedUrl:'https://jobs.lever.co/aleph/'+(skip+i),categories:{location:'Budapest, Hungary'}}))});
 const r=await E.collectSource(src('lever','aleph'),{request:fetch,maxItems:75,maxPages:2,delayMs:0});
 assert.equal(r.jobs.length,60);assert.equal(r.complete,false);assert.deepEqual(seen.map(x=>x.skip),[0,30]);
});
test('Lever adapter retries oversized pages by shrinking batch and resumes without duplicates',async()=>{
 let calls=0;const fetch=async url=>{calls++;const q=new URL(url).searchParams;const lim=Number(q.get('limit')),skip=Number(q.get('skip'));if(lim>10)return {ok:true,status:200,headers:{get:()=>2000000},text:async()=>''};return {ok:true,status:200,headers:{get:()=>null},text:async()=>JSON.stringify(Array.from({length:skip?2:lim},(_,i)=>({id:String(skip+i),text:'Role '+(skip+i),hostedUrl:'https://jobs.lever.co/ion/'+(skip+i),categories:{location:'Budapest, Hungary'}})))}};
 const r=await E.collectSource(src('lever','ion'),{request:fetch,maxItems:50,delayMs:0});
 assert.equal(r.jobs.length,9);assert.equal(r.complete,true);assert.ok(calls>=4);
});
test('Workable adapter reads verified public widget and Hungarian location without a CV',async()=>{
 const source=src('workable','tciscareers'),fetch=mock(url=>{assert.ok(url.startsWith('https://apply.workable.com/api/v1/widget/accounts/tciscareers?details=true'));return {name:'transcosmos',jobs:[{shortcode:'FABB',title:'Field Sales Representative',city:'Debrecen',state:'Hajdú-Bihar',country:'Hungary',shortlink:'https://apply.workable.com/tciscareers/j/FABB/',description:'<p>Területi értékesítés</p>',published_on:'2026-11-01'}]}});
 const r=await E.collectSource(source,{request:fetch});assert.equal(r.jobs.length,1);assert.equal(r.jobs[0].location,'Debrecen, Hajdú-Bihar, Hungary');assert.equal(r.jobs[0].description,'Területi értékesítés');assert.equal(r.complete,true);
});
test('Workable source cannot inject a malicious board slug into the API URL',async()=>{
 await assert.rejects(()=>E.collectSource(src('workable','../internal'),{request:mock(()=>({jobs:[]}))}),/Invalid board slug/);
});
test('Newly identified real career boards are enabled, national sources remain CV-independent',()=>{
 const workables=catalog.filter(x=>x.engine==='workable'&&x.enabled);assert.ok(workables.length>=4);
 assert.ok(catalog.every(x=>!('cv' in x)&&!('profile' in x)));assert.equal(new Set(catalog.map(x=>x.source_key)).size,catalog.length);
});
