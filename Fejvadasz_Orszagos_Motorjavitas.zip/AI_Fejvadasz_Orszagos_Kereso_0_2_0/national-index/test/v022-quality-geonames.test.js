'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const os=require('node:os'),fs=require('node:fs'),path=require('node:path'),{spawnSync}=require('node:child_process');
const G=require('../src/geonames'),Q=require('../src/quality');
const line=({id=1,name='Zalaegerszeg',lat='46.8400',lon='16.8410',featureClass='P',featureCode='PPLA',admin1='24',country='HU',population='50000'}={})=>[
 id,name,name,'',lat,lon,featureClass,featureCode,country,'',admin1,'','','',population,'','Europe/Budapest','2026-11-09'
].join('\t');
const huFixture=()=>[
 line({id:101,name:'Zala',featureClass:'A',featureCode:'ADM1'}),
 line({id:102,name:'Budapest',featureClass:'A',featureCode:'ADM1',admin1:'05',lat:'47.4983',lon:'19.0408'}),
 line(),
 line({id:2,name:'Budapest',lat:'47.4983',lon:'19.0408',featureCode:'PPLC',admin1:'05',population:'1685209'}),
 line({id:3,name:'Zalaegerszeg',lat:'46.839',lon:'16.839',featureCode:'PPL',admin1:'24',population:'50'}),
 line({id:4,name:'London',lat:'51.5',lon:'-0.1',admin1:'24',country:'GB'}),
 line({id:5,name:'Puszta',lat:'46.9',lon:'16.8',featureClass:'T',featureCode:'MT',admin1:'24'}),
 line({id:6,name:'Unmatched',lat:'46.4',lon:'17',admin1:'FF'}),
 line({id:7,name:'BadCoord',lat:'999',lon:'17',admin1:'24'}),
 line({id:8,name:'Zalaváros',lat:'46.88',lon:'16.8',admin1:'24'})
].join('\n');

test('GeoNames Hungarian settlement parse distinguishes ADM1 counties from populated places',()=>{
 const x=G.parseHU(huFixture());assert.equal(x.counties,2);assert.equal(x.places.length,3);
 assert.equal(x.unresolved,1);assert.equal(x.places.find(x=>x.name==='Zalaegerszeg').county,'Zala');
 assert.equal(x.places.find(x=>x.name==='Zalaegerszeg').lat,46.84);
 assert.ok(x.places.every(p=>p.lat>=45&&p.lon>=16));
});
test('GeoNames rejects wrong-country points and unreferenced counties, no fabricated HU places',()=>{
 const x=G.parseHU(huFixture());assert.ok(!x.places.some(p=>p.name==='London'||p.name==='Unmatched'||p.name==='Puszta'||p.name==='BadCoord'));
});
test('GeoNames importer ZIP parser can read only HU.txt from a local ZIP',()=>{
 const d=fs.mkdtempSync(path.join(os.tmpdir(),'fej-zip-test-'));try{
 fs.writeFileSync(path.join(d,'HU.txt'),huFixture());
 const z=spawnSync('zip',['-q','source.zip','HU.txt'],{cwd:d});assert.equal(z.status,0);
 const csv=G.unzipHU(fs.readFileSync(path.join(d,'source.zip')));assert.ok(csv.includes('Zalaegerszeg'));
 }finally{fs.rmSync(d,{force:true,recursive:true})}
});
test('GeoNames import validates county coverage and minimum settlements before DB writes',async()=>{
 const d=fs.mkdtempSync(path.join(os.tmpdir(),'fej-hu-test-'));try{
 fs.writeFileSync(path.join(d,'HU.txt'),huFixture());assert.equal(spawnSync('zip',['-q','source.zip','HU.txt'],{cwd:d}).status,0);
 let writes=0;const pool={query:async()=>({rows:[{n:0}]}),connect:async()=>{writes++;return{query:async()=>{},release(){}}}};
 await assert.rejects(()=>G.importGeoNames(pool,{zipPath:path.join(d,'source.zip'),minPlaces:2}),/incomplete/);
 assert.equal(writes,0);
 }finally{fs.rmSync(d,{force:true,recursive:true})}
});
test('GeoNames transaction stores sourced points without duplicate placeholders',async()=>{
 const d=fs.mkdtempSync(path.join(os.tmpdir(),'fej-hu-test2-'));try{
 fs.writeFileSync(path.join(d,'HU.txt'),huFixture());assert.equal(spawnSync('zip',['-q','source.zip','HU.txt'],{cwd:d}).status,0);
 const records=[];const pool={query:async()=>({rows:[{n:0}]}),connect:async()=>({query:async(q,vals)=>{records.push({q,vals});},release(){}})};
 const r=await G.importGeoNames(pool,{zipPath:path.join(d,'source.zip'),minPlaces:2,minCounties:2});assert.equal(r.places,3);
 assert.equal(records[0].q,'BEGIN');assert.equal(records.at(-1).q,'COMMIT');
 const ins=records.find(x=>x.q.startsWith('INSERT INTO national_places'));
 assert.equal(ins.vals.length,3*6);assert.match(ins.vals.join(' '),/GeoNames Hungary/);
 assert.ok(!records.some(x=>x.q.includes('DELETE FROM national_places')));
 }finally{fs.rmSync(d,{force:true,recursive:true})}
});
test('GeoNames importer safely skips daily re-download when database already has >=1000 places',async()=>{
 const pool={query:async()=>({rows:[{n:3155}]}),connect:async()=>{throw Error('must not be called')}};
 const x=await G.importGeoNames(pool);assert.equal(x.status,'already_present');assert.equal(x.places,3155);
});
test('GeoNames ZIP over size cap must be rejected',async()=>{
 await assert.rejects(()=>G.importGeoNames({query:async()=>({rows:[{n:0}]})},{zipPath:'/nonexistent/HU.zip'}),/ENOENT/);
});
test('GeoNames fixed HTTPS host cannot be replaced with untrusted hosts',async()=>{
 await assert.rejects(()=>G.fetchArchive({url:'https://evil.example.com/HU.zip',request:async()=>{throw Error('should not reach')}}),/Unexpected/);
});
test('Per-engine 1000 threshold is a development target, not invented job data',()=>{
 const x=Q.classifyEngine({engine:'workable',source_count:4,hu_jobs:108,target:1000});
 assert.equal(x.status,'needs_development');assert.equal(x.gap,892);assert.equal(x.observed_hu_unique_jobs,108);
 assert.equal(Q.classifyEngine({engine:'rss',source_count:0,hu_jobs:0}).status,'no_active_sources');
 assert.equal(Q.classifyEngine({engine:'lever',source_count:10,hu_jobs:1000}).status,'target_met');
});
test('Per-engine unique HU observation count uses distinct IDs and live seen-state filtering',async()=>{
 let seen;const pool={query:async q=>{seen=q;return {rows:[{engine:'workable',source_count:'4',hu_jobs:'987',errors:'1'}]}}};
 const r=await Q.engineTargets(pool,{target:1000});
 assert.equal(r.all_targets_met,false);assert.equal(r.engines.find(x=>x.engine==='workable').gap,13);
 assert.ok(r.engines.find(x=>x.engine==='workable').actions.some(x=>x.includes('hibák'))===false || r.engines.find(x=>x.engine==='workable').failures===1);
 assert.match(seen,/COUNT\(DISTINCT j.job_key\)/);assert.match(seen,/last_seen_at/);assert.match(seen,/o.present=true/);
});
test('Per-engine target never changes runtime if source is below target',async()=>{
 const p={query:async()=>({rows:[]})};const report=await Q.engineTargets(p);
 assert.equal(report.engines.length,Q.COLLECTABLE.length);assert.ok(report.engines.every(x=>x.status==='no_active_sources'));
 assert.equal(report.target_per_engine,1000);
});
test('engine target API requires bearer token and never reveals secrets',async()=>{
 const {createApi}=require('../src/api');
 const pool={query:async sql=>{if(sql.includes('FROM national_sources s'))return {rows:[{engine:'workable',source_count:'4',hu_jobs:'48',errors:'0'}]};return {rows:[{}]}}};
 const server=createApi(pool,{token:'dont-print-this-token'});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 try{const uri=`http://127.0.0.1:${server.address().port}/api/v1/engine-targets`;
  const noAuth=await fetch(uri);assert.equal(noAuth.status,401);
  const yes=await fetch(uri,{headers:{Authorization:'Bearer dont-print-this-token'}});assert.equal(yes.status,200);
  const o=await yes.json();assert.equal(o.engines.find(x=>x.engine==='workable').observed_hu_unique_jobs,48);
  assert.equal(o.all_targets_met,false);assert.ok(!JSON.stringify(o).includes('dont-print-this-token'));
 }finally{await new Promise(resolve=>server.close(resolve))}
});
test('large-scale GeoNames parser handles 5000 valid place records with only sourced coordinates',()=>{
 const header=[];for(let i=0;i<20;i++)header.push(line({id:100+i,name:'County'+i,featureClass:'A',featureCode:'ADM1',admin1:String(i),lat:47,lon:18}));
 const items=[];for(let i=0;i<5000;i++)items.push(line({id:1000+i,name:'Village'+i,lat:(45.7+(i%100)*.012).toFixed(5),lon:(16.3+(i%150)*.02).toFixed(5),admin1:String(i%20),population:'500'}));
 const o=G.parseHU([...header,...items].join('\n'));
 assert.equal(o.counties,20);assert.equal(o.places.length,5000);assert.equal(o.unresolved,0);
});
test('failed DB batch rolls back, without committing partial settlement import',async()=>{
 const d=fs.mkdtempSync(path.join(os.tmpdir(),'fej-hu-test3-'));
 try{fs.writeFileSync(path.join(d,'HU.txt'),huFixture());assert.equal(spawnSync('zip',['-q','source.zip','HU.txt'],{cwd:d}).status,0);
  const queries=[];const pool={query:async()=>({rows:[{n:0}]}),connect:async()=>({query:async q=>{queries.push(q);if(q.startsWith('INSERT INTO national_places'))throw Error('db connection reset')},release(){}})};
  await assert.rejects(()=>G.importGeoNames(pool,{zipPath:path.join(d,'source.zip'),minCounties:2,minPlaces:2}),/db connection reset/);
  assert.ok(queries.includes('BEGIN'));assert.ok(queries.includes('ROLLBACK'));assert.ok(!queries.includes('COMMIT'));
 }finally{fs.rmSync(d,{recursive:true,force:true})}
});
