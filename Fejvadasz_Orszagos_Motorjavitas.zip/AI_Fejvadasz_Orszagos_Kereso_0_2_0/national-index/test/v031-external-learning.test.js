'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const X=require('../src/ai/external'),C=require('../src/ai/capacity'),F=require('../src/ai/features'),DB=require('../src/db');
const seed=()=>({url:'https://example.org/careers/',owner:'Example Employer',approved_for_research:true,permission_reviewed:true,permission_basis:'Documented first-party permission (test only)',max_pages:4});
const job=`<html><script type="application/ld+json">{"@context":"https://schema.org","@type":"JobPosting","title":"Gépészmérnök","description":"Budapesti fejlesztőmérnök", "datePosted":"2026-11-09","hiringOrganization":{"name":"Example Employer"},"jobLocation":{"address":{"addressLocality":"Budapest","addressCountry":"HU"}}}</script></html>`;
function response(text,{status=200,ct='text/html',declared=null,stream=false}={}){
 const bytes=Buffer.from(text);
 return {ok:status>=200&&status<300,status,headers:{get:k=>k==='content-type'?ct:k==='content-length'?declared:null},text:async()=>text,
  body:stream?new ReadableStream({start(controller){controller.enqueue(bytes);controller.close()}}):null};
}
const routes={
 'https://example.org/robots.txt':`User-agent: *\nDisallow: /admin\nAllow: /careers\n`,
 'https://example.org/careers/':`<html><a href="/careers/engineer">Open role</a><a href="https://evil.net/jobs/secret">Evil link</a><a href="http://example.org/jobs/unsafe">Unsafe</a></html>`,
 'https://example.org/careers/engineer':job
};
function mockRequest(pages=routes,invocations=[]){return async(url,opts)=>{invocations.push([url,opts]);const v=pages[url];return v===undefined?response('not found',{status:404}):response(v)};}
function fakePool(){let writes=[],fail=null;const client={query:async(sql,args)=>{writes.push({sql,args});if(fail&&sql.includes(fail))throw Error('simulated write failure');return {rows:[]}},release:()=>{writes.push({sql:'RELEASE'})}};return {writes,client,connect:async()=>client,query:async()=>({rows:[]}),setFailure(s){fail=s}};}
test('seed rejects unauthorized or unreviewed source',()=>{assert.throws(()=>X.validateSeed({...seed(),approved_for_research:false}),/permission/);assert.throws(()=>X.validateSeed({...seed(),permission_reviewed:false}),/permission/);assert.throws(()=>X.validateSeed({...seed(),permission_basis:'robots'}),/permission basis/)});
test('seed rejects HTTP, local and IP hosts, and external credentials',()=>{for(const url of ['http://example.org/careers','https://127.0.0.1/jobs','https://localhost/jobs','https://me:pass@example.org/careers','https://example.org:8443/jobs'])assert.throws(()=>X.validateSeed({...seed(),url}),/Unsafe/)});
test('approved source is normalized with evidence and fixed origin',()=>{const s=X.validateSeed(seed());assert.equal(s.host,'example.org');assert.equal(s.permission_reviewed,true);assert.equal(s.origin,'https://example.org')});
test('seed file dedupes and rejects invalid rows prior to fetching',()=>{const dir=fs.mkdtempSync(path.join(os.tmpdir(),'fv031-'));try{const f=path.join(dir,'seeds.json');fs.writeFileSync(f,JSON.stringify([seed(),seed()]));assert.equal(X.readSeeds(f).length,1);fs.writeFileSync(f,JSON.stringify([seed(),{url:'http://localhost/private',approved_for_research:true,permission_reviewed:true,owner:'x',permission_basis:'license'}]));assert.throws(()=>X.readSeeds(f),/Unsafe/)}finally{fs.rmSync(dir,{recursive:true,force:true})}});
test('site crawler ignores cross-domain and HTTP links',()=>{const links=X.candidateLinks(routes['https://example.org/careers/'],'https://example.org/careers/');assert.deepEqual(links,['https://example.org/careers/engineer']);});
test('robots respects allow, disallow, and user agent specificity',()=>{const t=`User-agent: *\nDisallow: /\nAllow: /careers/\nUser-agent: ai-fejvadasz-research\nDisallow: /admin/\nCrawl-delay: 0.3`;
 const p=X.robotsPolicy(t);assert.equal(p.allows('/careers/engineer'),true);assert.equal(p.allows('/admin/secret'),false);assert.equal(p.delayMs,300);});
test('robots denies entire seed without visiting it',async()=>{const requests=[];const r=await X.researchSeed({...seed(),url:'https://example.org/private'},{request:mockRequest({'https://example.org/robots.txt':'User-agent: *\nDisallow: /\n'},requests)});assert.equal(r.status,'disallowed_by_robots');assert.deepEqual(requests.map(x=>x[0]),['https://example.org/robots.txt']);});
test('robots missing fails closed',async()=>{await assert.rejects(()=>X.researchSeed(seed(),{request:mockRequest({})}),/HTTP 404/)});
test('unbounded redirect refused and not followed',async()=>{const req=async(url,opts)=>{assert.equal(opts.redirect,'manual');return response('',{status:302})};await assert.rejects(()=>X.researchSeed(seed(),{request:req}),/HTTP 302/)});
test('declared page too large is rejected before body read',async()=>{const r=async()=>response('<html>secret</html>',{declared:800000});await assert.rejects(()=>X.fetchBounded('https://example.org/careers',{request:r,maxBytes:1000}),/Page size/)});
test('streaming page too large is rejected without buffering full response',async()=>{const r=async()=>response('x'.repeat(2000),{stream:true});await assert.rejects(()=>X.fetchBounded('https://example.org/careers',{request:r,maxBytes:256}),/Page size/)});
test('unexpected binary content cannot become training evidence',async()=>{const r=async()=>response('evil',{ct:'application/octet-stream'});await assert.rejects(()=>X.fetchBounded('https://example.org/careers',{request:r}),/content type/)});
test('extracts structured job from authorized website, not arbitrary links',async()=>{const request=mockRequest();const r=await X.researchSeed(seed(),{request,sleep:async()=>{}});assert.equal(r.pages,2);assert.equal(r.jobs.length,1);assert.equal(r.jobs[0].title,'Gépészmérnök');assert.equal(r.jobs[0].location_text,'Budapest, HU');assert.equal(r.jobs[0].evidence_type,'jobposting_jsonld');assert.equal(r.status,'researched_pending_review');assert.ok(Object.values(r.jobs[0].features).every(x=>typeof x==='number'));});
test('external evidence includes no copyrighted HTML or CV text',async()=>{const r=await X.researchSeed(seed(),{request:mockRequest()});const db=fakePool(),saved=await X.saveResearch(db,X.validateSeed(seed()),r);assert.equal(saved.saved,2);const raw=JSON.stringify(db.writes);assert.doesNotMatch(raw,/Budapesti fejlesztőmérnök/);assert.doesNotMatch(raw,/<html>/);assert.ok(raw.includes('national_ai_review_queue'));assert.doesNotMatch(raw,/INSERT INTO national_ai_examples/)});
test('saved observations and review queue are rolled back on failure',async()=>{const r=await X.researchSeed(seed(),{request:mockRequest()});const db=fakePool();db.setFailure('national_ai_review_queue');await assert.rejects(()=>X.saveResearch(db,X.validateSeed(seed()),r),/simulated/);assert.ok(db.writes.some(x=>x.sql==='ROLLBACK'));assert.ok(!db.writes.some(x=>x.sql==='COMMIT'));});
test('research disabled issues zero requests and no DB writes',async()=>{let requests=0;const r=await X.research(fakePool(),{enabled:false,request:async()=>{requests++}});assert.equal(r.status,'disabled');assert.equal(requests,0)});
test('research enabled but no seed list does not search random sites',async()=>{const r=await X.research(fakePool(),{enabled:true,seedsFile:''});assert.equal(r.status,'no_approved_seeds')});
test('research with explicit seeds records evidence but not labels',async()=>{const dir=fs.mkdtempSync(path.join(os.tmpdir(),'fv031-'));try{const f=path.join(dir,'seeds.json');fs.writeFileSync(f,JSON.stringify([seed()]));const db=fakePool(),r=await X.research(db,{enabled:true,seedsFile:f,request:mockRequest(),sleep:async()=>{}});assert.equal(r.results[0].observed,1);assert.equal(r.results[0].saved,2);assert.equal(r.policy.includes('unreviewed'),true);assert.ok(!db.writes.some(x=>x.sql.includes('national_ai_examples')))}finally{fs.rmSync(dir,{recursive:true,force:true})}});
test('external review requires human reviewer and fixed evidence references',async()=>{const dir=fs.mkdtempSync(path.join(os.tmpdir(),'fv031-'));try{const f=path.join(dir,'review.json');fs.writeFileSync(f,JSON.stringify([{observation_key:'0'.repeat(64),model_key:'verifier',label:1,split:'train',reviewed:true}]));await assert.rejects(()=>X.ingestReviewed(fakePool(),f),/Invalid independent/)}finally{fs.rmSync(dir,{recursive:true,force:true})}});
test('external labels only accepted after evidence exists, transaction rolls back',async()=>{const dir=fs.mkdtempSync(path.join(os.tmpdir(),'fv031-'));try{const f=path.join(dir,'review.json');fs.writeFileSync(f,JSON.stringify([{observation_key:'f'.repeat(64),model_key:'verifier',label:1,split:'holdout',reviewed:true,reviewer_id:'auditor-1'}]));const db=fakePool();await assert.rejects(()=>X.ingestReviewed(db,f),/absent/);assert.ok(db.writes.some(x=>x.sql==='ROLLBACK'))}finally{fs.rmSync(dir,{recursive:true,force:true})}});
test('valid externally reviewed evidence enters supervised training only by human action',async()=>{const dir=fs.mkdtempSync(path.join(os.tmpdir(),'fv031-'));try{const f=path.join(dir,'review.json');fs.writeFileSync(f,JSON.stringify([{observation_key:'f'.repeat(64),model_key:'verifier',label:1,split:'train',reviewed:true,reviewer_id:'auditor-1'}]));const db=fakePool();db.client.query=async(sql,args)=>{db.writes.push({sql,args});if(sql.includes('SELECT features FROM national_ai_external_evidence'))return {rows:[{features:Object.fromEntries(F.SPECS.verifier.features.map(x=>[x,0.7]))}]};return {rows:[]}};const r=await X.ingestReviewed(db,f);assert.equal(r.reviewed,1);assert.ok(db.writes.some(x=>x.sql.includes('INSERT INTO national_ai_examples')));assert.ok(db.writes.some(x=>x.sql==='COMMIT'))}finally{fs.rmSync(dir,{recursive:true,force:true})}});
test('capacity thresholds warn before exhaustion',()=>{for(const [used,expected] of [[50,'normal'],[68,'capacity_watch'],[82,'expansion_recommended'],[94,'critical']]){const r=C.evaluate({dbBytes:used*1024**2,dbLimitGb:0.1,memoryUsedBytes:used*1024**2,memoryLimitMb:100});assert.equal(r.state,expected)}});
test('capacity trend projects expansion threshold before it happens',()=>{const r=C.evaluate({dbBytes:50*1024**2,dbLimitGb:0.1,memoryUsedBytes:30*1024**2,memoryLimitMb:100,growthBytesPerDay:5*1024**2});assert.ok(r.daysUntilExpansionThreshold>0&&r.daysUntilExpansionThreshold<7);assert.equal(r.action,'plan_expansion_within_7_days')});
test('capacity missing physical limits is explicitly unconfigured',()=>{const r=C.evaluate({dbBytes:8000,memoryUsedBytes:3000});assert.equal(r.db.usedPercent,null);assert.equal(r.paidScaling,'never_automatic_without_explicit_approval')});
test('capacity snapshot uses real DB and configured limits; cannot change a paid plan',async()=>{let sqls=[];const pool={query:async(sql,args)=>{sqls.push(sql);if(sql.includes('pg_database_size'))return {rows:[{db_bytes:String(80*1024**2)}]};if(sql.includes('capacity_snapshots')&&sql.includes('SELECT'))return {rows:[]};return {rows:[]}}};const r=await C.check(pool,{env:{AI_CAPACITY_DB_LIMIT_GB:'0.1',AI_CAPACITY_RAM_LIMIT_MB:'200'},memoryUsage:{rss:50*1024**2}});assert.equal(r.state,'capacity_watch');assert.ok(sqls.some(x=>x.includes('INSERT INTO national_ai_capacity_snapshots')));assert.equal(sqls.some(x=>/render api|billing|upgrade|scale plan/i.test(x)),false)});
test('new schema is additive, idempotent and has no CV columns',()=>{const sql=fs.readFileSync(path.join(__dirname,'../src/ai/schema-v5.sql'),'utf8');assert.match(sql,/CREATE TABLE IF NOT EXISTS national_ai_external_evidence/);assert.match(sql,/CREATE TABLE IF NOT EXISTS national_ai_capacity_snapshots/);assert.doesNotMatch(sql,/DROP TABLE|TRUNCATE|cv_text|resume_text|api_key/i)});
test('all four v030 models retained after adding research system',()=>{assert.deepEqual(Object.keys(F.SPECS),['scout','verifier','matcher','optimizer']);assert.equal(F.SPECS.matcher.features.length,8);});

test('market vocabulary extracts controlled terms but not raw descriptions',()=>{const T=require('../src/ai/terms');const terms=T.termsFromJob({title:'CNC forgácsoló',description:'Minőségbiztosítás és német nyelv'});assert.deepEqual(terms,['cnc','quality_assurance','german']);assert.ok(!JSON.stringify(terms).includes('Minőségbiztosítás'))});
test('Hungarian and English role synonyms improve match model features',()=>{const f=F.matchFeatures({targetRole:'értékesítő',skills:'ügyfélszolgálat',region:'Budapest'},{title:'Sales representative',description:'Customer support, remote',location_text:'Budapest'});assert.ok(f.role_match>0);assert.ok(f.skill_overlap>0);assert.equal(f.distance_fit,1)});
test('market terms are idempotently stored and not promoted as unreviewed labels',async()=>{const r=await X.researchSeed(seed(),{request:mockRequest({'https://example.org/robots.txt':routes['https://example.org/robots.txt'],'https://example.org/careers/':`<a href="/careers/engineer">Job</a>`,'https://example.org/careers/engineer':job.replace('Gépészmérnök','CNC forgácsoló')})});const db=fakePool();await X.saveResearch(db,X.validateSeed(seed()),r);assert.ok(db.writes.some(x=>x.sql.includes('INSERT INTO national_ai_market_terms')));assert.ok(db.writes.some(x=>x.sql.includes('ON CONFLICT(observation_key,term) DO NOTHING')));assert.ok(!db.writes.some(x=>x.sql.includes('INSERT INTO national_ai_examples')))});
test('seed rotation selects least recently visited first and persists cooldown',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'fv031-'));
 try{
  const all=['a','b','c'].map(x=>({...seed(),url:`https://${x}.example.org/careers/`,owner:'Example '+x}));
  const f=path.join(dir,'seeds.json');fs.writeFileSync(f,JSON.stringify(all));
  const visited=[];const states=[{seed_url:'https://a.example.org/careers/',last_run_at:'2026-11-01T00:00:00Z',next_due_at:'2026-11-01T00:00:00Z'},
   {seed_url:'https://b.example.org/careers/',last_run_at:'2026-11-09T00:00:00Z',next_due_at:'2026-11-09T00:00:00Z'},
   {seed_url:'https://c.example.org/careers/',last_run_at:'2026-11-08T00:00:00Z',next_due_at:'2026-11-08T00:00:00Z'}];
  const db={query:async(sql,args)=>{if(sql.includes('SELECT seed_url'))return {rows:states};if(sql.includes('INSERT INTO national_ai_research_seed_state')){visited.push(args[0]);return {rows:[]}}return {rows:[]}},connect:async()=>fakePool().client};
  const req=async url=>{if(url.endsWith('/robots.txt'))return response('User-agent: *\nDisallow: /private');return response('<html>no JobPosting</html>')};
  const r=await X.research(db,{enabled:true,seedsFile:f,maxSeeds:2,now:new Date('2026-11-10T15:00:00Z'),request:req});
  assert.equal(r.seeds,2);assert.deepEqual(visited,['https://a.example.org/careers/','https://c.example.org/careers/']);assert.equal(r.remainingDue,1);
 }finally{fs.rmSync(dir,{recursive:true,force:true})}
});
test('seed cooldown avoids repeated collection before next_due_at',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'fv031-'));
 try{const f=path.join(dir,'seeds.json');fs.writeFileSync(f,JSON.stringify([seed()]));const db={query:async(sql)=>({rows:sql.includes('SELECT seed_url')?[{seed_url:'https://example.org/careers/',last_run_at:'2026-11-10T14:00:00Z',next_due_at:'2026-11-11T14:00:00Z'}]:[]})};
 let requested=0;const r=await X.research(db,{enabled:true,seedsFile:f,now:new Date('2026-11-10T15:00:00Z'),request:async()=>{requested++}});
 assert.equal(r.status,'all_seeds_on_cooldown');assert.equal(requested,0);
 }finally{fs.rmSync(dir,{recursive:true,force:true})}
});
test('research error stores a retry time instead of immediately hammering failing site',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'fv031-'));
 try{const f=path.join(dir,'seeds.json');fs.writeFileSync(f,JSON.stringify([seed()]));const history=[];const db={query:async(sql,args)=>{if(sql.includes('INSERT INTO national_ai_research_seed_state'))history.push(args);return {rows:[]}}};
 const r=await X.research(db,{enabled:true,seedsFile:f,request:async()=>response('',{status:503}),errorRetryHours:6});
 assert.equal(r.results[0].status,'error');assert.equal(history.length,1);assert.equal(history[0][2],6);
 }finally{fs.rmSync(dir,{recursive:true,force:true})}
});
test('byte quota remains bounded across robots and job pages',async()=>{const long='x'.repeat(1200),page={'https://example.org/robots.txt':'User-agent: *\nAllow: /careers','https://example.org/careers/':'<a href="/careers/a">a</a>'+long,'https://example.org/careers/a':long};const r=await X.researchSeed(seed(),{request:mockRequest(page),maxTotalBytes:2000,maxBytes:1600});assert.ok(r.bytes<=2000)});

test('capacity webhook warns once on newly crossed threshold without leaking private content',async()=>{
 const msgs=[];const pool={query:async(sql,args)=>{if(sql.includes('pg_database_size'))return {rows:[{db_bytes:String(80*1024**2)}]};if(sql.includes('SELECT db_bytes,recorded_at'))return {rows:[{db_bytes:String(45*1024**2),recorded_at:'2026-11-09T12:00:00Z',alert_status:'monitor'}]};return {rows:[]}}};
 const request=async(url,opts)=>{msgs.push({url,opts});return {ok:true}};
 const report=await C.check(pool,{now:new Date('2026-11-10T15:00:00Z'),env:{AI_CAPACITY_DB_LIMIT_GB:'0.1',AI_CAPACITY_RAM_LIMIT_MB:'100',AI_CAPACITY_ALERT_WEBHOOK_URL:'https://alerts.example.org/capacity'},memoryUsage:{rss:50*1024**2},request});
 assert.equal(report.alertDelivery,'delivered');assert.equal(msgs.length,1);assert.equal(msgs[0].opts.redirect,'manual');assert.equal(JSON.parse(msgs[0].opts.body).requiresHumanCostApproval,true);assert.doesNotMatch(msgs[0].opts.body,/DATABASE_URL|OPENAI_API_KEY|password/i);
});
test('capacity webhook refuses non-HTTPS or internal endpoints',async()=>{
 const pool={query:async(sql)=>({rows:sql.includes('pg_database_size')?[{db_bytes:String(95*1024**2)}]:[]})};let called=false;
 const r=await C.check(pool,{env:{AI_CAPACITY_DB_LIMIT_GB:'0.1',AI_CAPACITY_ALERT_WEBHOOK_URL:'http://localhost:8080/private'},memoryUsage:{rss:10},request:async()=>{called=true}});
 assert.equal(r.alertDelivery,'invalid_webhook_url');assert.equal(called,false);
});
test('capacity does not invent utilization percentages without configured limits',()=>{const r=C.evaluate({dbBytes:8000,memoryUsedBytes:3000});assert.equal(r.state,'unconfigured');assert.equal(r.action,'configure_limits')});
