'use strict';
/** All persistent data is public job catalogue data. Never stores CV or user profile. */
const {normalizeJob}=require('./normalize');
const fs=require('node:fs');const path=require('node:path');
function newPool(env=process.env){
 if(!env.DATABASE_URL)throw Error('DATABASE_URL (persistent PostgreSQL) is required');
 const {Pool}=require('pg');return new Pool({connectionString:env.DATABASE_URL,max:Math.min(8,Number(env.DB_POOL_SIZE)||5),connectionTimeoutMillis:7000,idleTimeoutMillis:15000,ssl:env.PGSSLMODE==='require'?{rejectUnauthorized:true}:undefined});
}
async function migrate(pool){await pool.query(fs.readFileSync(path.join(__dirname,'schema.sql'),'utf8'));await pool.query(fs.readFileSync(path.join(__dirname,'schema-v2.sql'),'utf8'));}
async function seed(pool,sources){
 let count=0;
 for(const src of sources){
  await pool.query(`INSERT INTO national_sources(source_key,name,category,engine,board,url,company,enabled,approved,country_scope)
   VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
   ON CONFLICT (source_key) DO UPDATE SET name=EXCLUDED.name,category=EXCLUDED.category,engine=EXCLUDED.engine,
    board=EXCLUDED.board,url=EXCLUDED.url,company=EXCLUDED.company,country_scope=EXCLUDED.country_scope,updated_at=NOW()
    -- Never overwrite enable/approval toggles from the database during re-seed
   `,[src.source_key,src.name,src.category,src.engine,src.board||null,src.url||null,src.company||null,!!src.enabled,!!src.approved,src.country_scope||'mixed']);count++;
 }
 return count;
}
async function upsertSnapshot(pool,src,rawJobs,{complete=true}={}){
 const client=await pool.connect(),seen=[],externalSeen=new Set(),perJob=new Set();
 try{
  await client.query('BEGIN');
  for(const raw of rawJobs){
   const j=normalizeJob(raw,src);if(!j)continue;
   // Do not double-count a repeated source id in a single batch.
   if(externalSeen.has(j.external_id))continue;
   externalSeen.add(j.external_id);seen.push(j.external_id);perJob.add(j.job_key);
   await client.query(`INSERT INTO national_jobs(job_key,canonical_url,company,title,location_text,country_status,description,language,published_at,duplicate_group,content_fingerprint)
     VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
     ON CONFLICT(job_key) DO UPDATE SET company=EXCLUDED.company,title=EXCLUDED.title,
      location_text=EXCLUDED.location_text,country_status=EXCLUDED.country_status,
      description=CASE WHEN length(EXCLUDED.description)>0 THEN EXCLUDED.description ELSE national_jobs.description END,
      language=COALESCE(EXCLUDED.language,national_jobs.language),published_at=COALESCE(EXCLUDED.published_at,national_jobs.published_at),
      duplicate_group=EXCLUDED.duplicate_group,content_fingerprint=EXCLUDED.content_fingerprint,
      state='observed',last_seen_at=NOW(),updated_at=NOW()`,
    [j.job_key,j.url,j.company,j.title,j.location,j.country_status,j.description,j.language,j.published_at,j.duplicate_group,require('node:crypto').createHash('sha256').update([j.title,j.company,j.location,j.description].join('\n')).digest('hex')]);
   await client.query(`INSERT INTO national_observations(source_key,external_id,job_key)
      VALUES($1,$2,$3)
      ON CONFLICT(source_key,external_id) DO UPDATE SET job_key=EXCLUDED.job_key,last_seen_at=NOW(),present=true`,
     [src.source_key,j.external_id,j.job_key]);
  }
  if(complete){
   await client.query(`UPDATE national_observations SET present=false WHERE source_key=$1 AND present=true
     AND NOT (external_id = ANY($2::text[]))`,[src.source_key,seen]);
   await client.query(`UPDATE national_jobs j SET state='closed',updated_at=NOW() WHERE j.state='observed'
     AND EXISTS(SELECT 1 FROM national_observations o WHERE o.job_key=j.job_key AND o.source_key=$1)
     AND NOT EXISTS(SELECT 1 FROM national_observations o WHERE o.job_key=j.job_key AND o.present=true)`,[src.source_key]);
  }
  await client.query(`UPDATE national_sources SET last_checked_at=NOW(),last_success_at=NOW(),last_error=NULL,
    success_count=success_count+1,verified_hu_count=verified_hu_count+$2,fail_count=GREATEST(0,fail_count-1),
    next_due_at=NOW()+($3||' minutes')::interval WHERE source_key=$1`,[src.source_key,rawJobs.filter(j=>normalizeJob(j,src)?.country_status==='hu').length,Math.max(30,Number(process.env.NATIONAL_REFRESH_MINUTES)||240)]);
  await client.query('COMMIT');
  return {total:seen.length,hu:rawJobs.filter(j=>normalizeJob(j,src)?.country_status==='hu').length,complete};
 }catch(e){await client.query('ROLLBACK');throw e}finally{client.release()}
}
async function sourceFailure(pool,src,error){await pool.query(`UPDATE national_sources SET last_checked_at=NOW(),fail_count=fail_count+1,last_error=$2,
 next_due_at=NOW()+interval '60 minutes' WHERE source_key=$1`,[src.source_key,String(error?.message||error).slice(0,300)]);}
async function dueSources(pool,max=150){const r=await pool.query(`SELECT * FROM national_sources WHERE enabled=true AND engine<>'registry' AND next_due_at<=NOW()
 ORDER BY (verified_hu_count+1)::numeric/(success_count+fail_count+5) DESC,last_checked_at NULLS FIRST,source_key LIMIT $1`,[max]);return r.rows;}
async function stats(pool){const r=await pool.query(`SELECT (SELECT COUNT(*)::int FROM national_sources) AS sources,
 (SELECT COUNT(*)::int FROM national_sources WHERE enabled=true) AS enabled_sources,
 (SELECT COUNT(*)::int FROM national_jobs WHERE country_status='hu' AND state='observed' AND last_seen_at>NOW()-INTERVAL '72 hours') AS active_hu_jobs,
 (SELECT COUNT(*)::int FROM national_jobs WHERE country_status='unknown') AS location_review,
 (SELECT MAX(finished_at) FROM national_runs) AS last_run`);return r.rows[0]}
async function search(pool,{q='',region='',limit=40,offset=0}={}){
 limit=Math.min(100,Math.max(1,Number(limit)||40));offset=Math.min(20000,Math.max(0,Number(offset)||0));
 const query=String(q).trim().slice(0,150),place=String(region).trim().slice(0,100);
 const r=await pool.query(`SELECT job_key,title,company,location_text,canonical_url,language,published_at,last_seen_at,
     description,country_status FROM national_jobs WHERE country_status='hu' AND state='observed'
     AND last_seen_at>NOW()-INTERVAL '72 hours'
     AND ($1='' OR to_tsvector('simple',title||' '||company||' '||left(description,2500)) @@ plainto_tsquery('simple',$1)
      OR title ILIKE '%'||$1||'%')
     AND ($2='' OR location_text ILIKE '%'||$2||'%')
     ORDER BY last_seen_at DESC, job_key ASC LIMIT $3 OFFSET $4`,[query,place,limit,offset]);
 return r.rows;
}
module.exports={newPool,migrate,seed,upsertSnapshot,sourceFailure,dueSources,stats,search};
