'use strict';
/** Public ATS endpoints and EXPLICITLY permitted employer feeds/sitemaps.
 * No Brave and no CV in this module. Every source is a separate work unit.
 */
const {canonicalUrl,collapse} = require('./normalize');
const ALLOWED_API_HOSTS=new Set(['boards-api.greenhouse.io','api.lever.co','api.ashbyhq.com','api.smartrecruiters.com']);
function int(raw,fallback,lo,hi){const n=Number(raw);return Number.isInteger(n)&&n>=lo&&n<=hi?n:fallback}
function esc(s){return String(s??'').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#39;/g,"'")}
function plain(s){return collapse(esc(s).replace(/<[^>]*>/g,' '))}
function boardSlug(raw){const s=String(raw||'');if(!/^[a-zA-Z0-9_-]{2,80}$/.test(s))throw Error('Invalid board slug');return s}
function siteUrl(raw){
  const u=new URL(raw); const canon=canonicalUrl(raw);if(!canon)throw Error('Unsafe site URL');
  if(ALLOWED_API_HOSTS.has(u.hostname.toLowerCase()))throw Error('Use official ATS engine for API host');
  return canon;
}
function getPage(url,{request=globalThis.fetch,timeoutMs=11000,maxBytes=1400000,contentType='json'}={}){
 return (async()=>{
  const u=new URL(url); if(!canonicalUrl(url))throw Error('Unsafe outgoing URL');
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),timeoutMs);
  try{
   const response=await request(url,{method:'GET',redirect:'manual',signal:controller.signal,headers:{'Accept':contentType==='json'?'application/json':'application/xml,text/xml,text/plain,text/html','User-Agent':'AI-Fejvadasz-NationalIndexer/0.1 (+public job catalogue)'}});
   if(!response.ok)throw Error('Source HTTP '+response.status);
   const declared=Number(response.headers?.get?.('content-length')||0);if(declared>maxBytes)throw Error('Oversized source response');
   const content=await response.text();if(Buffer.byteLength(content,'utf8')>maxBytes)throw Error('Oversized source response');
   return contentType==='json'?JSON.parse(content):content;
  }finally{clearTimeout(timer)}
 })();
}
const atsUrl=(host,path)=>{if(!ALLOWED_API_HOSTS.has(host))throw Error('Untrusted ATS host');return `https://${host}${path}`};
function greenhouse(source,{request,maxItems=3000}={}){
 const slug=boardSlug(source.board);
 return getPage(atsUrl('boards-api.greenhouse.io',`/v1/boards/${slug}/jobs?content=true`),{request}).then(r=>{
 const list=Array.isArray(r.jobs)?r.jobs:[];
 return {jobs:list.slice(0,maxItems).filter(j=>j.internal_job_id!==null).map(j=>({external_id:String(j.id),title:j.title,url:j.absolute_url,location:j.location?.name||'',company:source.company,description:plain(j.content||''),published_at:j.updated_at,language:j.language})),complete:list.length<=maxItems};
 });
}
/** Lever returns huge company-wide boards. Page requests are intentionally small; a
 * source is incomplete if we hit a safety cap, so missing jobs are NEVER closed.
 * A single oversized batch is automatically retried at half the page size.
 */
async function lever(source,{request,maxItems=3000,maxPages=80,delayMs=120}={}){
 const slug=boardSlug(source.board),all=[];
 let skip=0,pageSize=30,finished=false,pages=0;
 maxItems=int(maxItems,3000,1,3000);maxPages=int(maxPages,80,1,120);
 while(pages<maxPages&&all.length<maxItems){
  const count=Math.min(pageSize,maxItems-all.length);
  let list;
  try{
   list=await getPage(atsUrl('api.lever.co',`/v0/postings/${slug}?mode=json&limit=${count}&skip=${skip}`),{request,maxBytes:1500000,timeoutMs:14000});
  }catch(e){
   if(/Oversized source response/.test(String(e.message))&&pageSize>5){pageSize=Math.max(5,Math.floor(pageSize/2));continue}
   throw e;
  }
  if(!Array.isArray(list))throw Error('Lever response not an array');
  for(const j of list)all.push({external_id:j.id,title:j.text,url:j.hostedUrl||j.applyUrl,location:j.categories?.location||j.categories?.allLocations?.join('; ')||'',company:source.company,description:plain(j.descriptionPlain||j.description||''),published_at:j.createdAt,language:null});
  skip+=list.length;pages++;
  if(list.length<count){finished=true;break}
  if(delayMs&&pages<maxPages&&all.length<maxItems)await new Promise(resolve=>setTimeout(resolve,Math.min(1500,Math.max(0,Number(delayMs)||0))));
 }
 return {jobs:all,complete:finished};
}
/** Public, employer-published Workable widget API (not their authenticated SPI).
 * No CV data, no form submission, and no scraping private job pages.
 */
async function workable(source,{request,maxItems=3000}={}){
 const slug=boardSlug(source.board);
 const payload=await getPage(`https://apply.workable.com/api/v1/widget/accounts/${slug}?details=true`,{request,maxBytes:5000000,timeoutMs:14000});
 if(!Array.isArray(payload?.jobs))throw Error('Workable response missing jobs');
 const list=payload.jobs;
 const jobs=list.slice(0,maxItems).map(j=>{
  const locs=Array.isArray(j.locations)?j.locations:[];
  const loctext=locs.map(x=>typeof x==='string'?x:[x.city,x.state,x.country].filter(Boolean).join(', ')).filter(Boolean).join('; ');
  const fallback=typeof j.location==='string'?j.location:typeof j.location==='object'&&j.location?[j.location.city,j.location.state,j.location.country].filter(Boolean).join(', '):'';
  const location=loctext||[j.city,j.state,j.country].filter(Boolean).join(', ')||fallback;
  const url=j.shortlink||j.application_url||j.url||(j.shortcode?`https://apply.workable.com/${slug}/j/${encodeURIComponent(j.shortcode)}/`:null);
  return {external_id:String(j.shortcode||j.code||j.id||url||''),title:j.title,url,location,company:source.company||payload.name||source.name,description:plain(j.full_description||j.description||''),published_at:j.published_on||j.created_at||null,language:null};
 }).filter(j=>j.title&&j.url);
 return {jobs,complete:list.length<=maxItems};
}
function ashby(source,{request,maxItems=3000}={}){
 const slug=boardSlug(source.board);
 return getPage(atsUrl('api.ashbyhq.com',`/posting-api/job-board/${slug}?includeCompensation=false`),{request}).then(r=>{
 const list=Array.isArray(r.jobs)?r.jobs:[];
 return {jobs:list.filter(j=>j.isListed!==false).slice(0,maxItems).map(j=>({external_id:j.id||j.jobUrl,title:j.title,url:j.jobUrl||j.applyUrl,location:j.location||j.address?.postalAddress?.addressLocality||'',company:source.company,description:plain(j.descriptionPlain||j.descriptionHtml||''),published_at:j.publishedAt||j.createdAt,language:null})),complete:list.length<=maxItems};
 });
}
async function smartrecruiters(source,{request,maxItems=3000,maxPages=30}={}){
 const slug=boardSlug(source.board),all=[];let offset=0,finished=false;
 for(let i=0;i<maxPages&&all.length<maxItems;i++){
  const r=await getPage(atsUrl('api.smartrecruiters.com',`/v1/companies/${slug}/postings?limit=100&offset=${offset}`),{request});
  if(!Array.isArray(r.content))throw Error('SmartRecruiters response missing content');
  all.push(...r.content);offset+=r.content.length;
  if(r.content.length<100 || (Number.isFinite(r.totalFound)&&offset>=r.totalFound)){finished=true;break;}
 }
 return {jobs:all.slice(0,maxItems).map(j=>({external_id:j.id,title:j.name,url:j.ref||j.link||j.jobAdUrl||`https://jobs.smartrecruiters.com/${slug}/${encodeURIComponent(j.id||'')}`,location:[j.location?.city,j.location?.region,j.location?.country].filter(Boolean).join(', '),company:source.company,description:plain(j.jobAd?.sections?.jobDescription?.text||''),published_at:j.releasedDate,language:null})),complete:finished};
}
const xmlValue=(block,tag)=>{const m=new RegExp(`<(?:(?:[\\w-]+):)?${tag}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/(?:(?:[\\w-]+):)?${tag}>`,'i').exec(block);return m?plain(m[1]):''};
const xmlLocs=xml=>[...String(xml).matchAll(/<\s*(?:[\w-]+:)?loc\s*>\s*([^<]{8,2000})\s*<\s*\/\s*(?:[\w-]+:)?loc\s*>/gi)].map(x=>esc(x[1]).trim());
function robotsRules(text){
 // Conservative for own User-Agent and star. Path rules only; robots failures abort entire source.
 const disallow=[],sitemaps=[];let group=[];
 for(let line of String(text).split(/\r?\n/)){
  line=line.replace(/\s*#.*$/,'').trim();const i=line.indexOf(':');if(i<0)continue;
  const k=line.slice(0,i).trim().toLowerCase(),v=line.slice(i+1).trim();
  if(k==='user-agent')group.push(v.toLowerCase());
  else if(k==='sitemap'&&v)sitemaps.push(v);
  else if(k==='disallow'&&v&&(group.includes('*')||group.includes('ai-fejvadasz-nationalindexer')))disallow.push(v);
  else if(k==='allow'){} // don't override a disallow; fail closed
  else if(k!=='crawl-delay')group=[];
 }
 return {disallow,sitemaps};
}
const allowed=(u,rules)=>!rules.disallow.some(v=>v==='/'||u.pathname.startsWith(v.replace(/\*.*$/,'')));
function sameHost(url,base){try{return new URL(url).hostname.toLowerCase()===new URL(base).hostname.toLowerCase()}catch{return false}}
function parseFeed(xml,source){
 const items=[...String(xml).matchAll(/<item\b[^>]*>([\s\S]*?)<\/item>/gi),...String(xml).matchAll(/<entry\b[^>]*>([\s\S]*?)<\/entry>/gi)];
 return items.slice(0,1500).map(m=>{
  const b=m[1],atom=/<link\b[^>]*\bhref=["']([^"']+)["']/i.exec(b)?.[1];
  const url=atom||xmlValue(b,'link');
  const date=xmlValue(b,'pubDate')||xmlValue(b,'published')||xmlValue(b,'updated');
  return {url,title:xmlValue(b,'title'),location:xmlValue(b,'location')||'',company:source.company,description:xmlValue(b,'description')||xmlValue(b,'summary'),published_at:date,external_id:xmlValue(b,'guid')||url};
 }).filter(j=>j.title&&j.url);
}
async function rss(source,{request}={}){
 const url=siteUrl(source.url),robots=await getPage(new URL('/robots.txt',url).href,{request,contentType:'text'});
 const rules=robotsRules(robots); if(!allowed(new URL(url),rules))return {jobs:[],complete:true};
 const xml=await getPage(url,{request,contentType:'text'});
 const jobs=parseFeed(xml,source).filter(j=>sameHost(j.url,url)&&allowed(new URL(j.url),rules));
 return {jobs,complete:true};
}
const LINKLIKE=/(?:\/|[-_])(jobs?|careers?|karrier|allas|allashirdetes|positions?|opportunities|stellen)(?:\/|[-_.]|$)/i;
function parseJobPosting(html,pageUrl,source){
 const jobs=[];
 for(const m of String(html).matchAll(/<script\b[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)){
  let json;try{json=JSON.parse(m[1])}catch{continue}
  const nodes=[];function walk(n,depth=0){if(depth>5||!n||typeof n!=='object')return;if(Array.isArray(n)){n.forEach(x=>walk(x,depth+1));return}if(n['@type']==='JobPosting'||(Array.isArray(n['@type'])&&n['@type'].includes('JobPosting')))nodes.push(n);if(n['@graph'])walk(n['@graph'],depth+1)}walk(json);
  for(const j of nodes){if(j.validThrough&&new Date(j.validThrough).getTime()<Date.now())continue;
   const loc=j.jobLocation,where=(Array.isArray(loc)?loc:[loc]).filter(Boolean).map(v=>[v?.address?.addressLocality,v?.address?.addressRegion,v?.address?.addressCountry?.name||v?.address?.addressCountry].filter(Boolean).join(', ')).join('; ');
   jobs.push({url:pageUrl,title:j.title,company:j.hiringOrganization?.name||source.company,location:where,description:plain(j.description),published_at:j.datePosted,external_id:j.identifier?.value||pageUrl});
  }
 }
 return jobs;
}
async function sitemap(source,{request,maxPages=25}={}){
 const url=siteUrl(source.url),robotsUrl=new URL('/robots.txt',url).href;
 const robots=robotsRules(await getPage(robotsUrl,{request,contentType:'text'}));
 if(!allowed(new URL(url),robots))return {jobs:[],complete:true};
 const xml=await getPage(url,{request,contentType:'text'}),links=xmlLocs(xml).filter(u=>canonicalUrl(u)&&sameHost(u,url)&&LINKLIKE.test(new URL(u).pathname)&&allowed(new URL(u),robots));
 const unique=[...new Set(links)],jobs=[];
 for(const link of unique.slice(0,maxPages)){
  try{const html=await getPage(link,{request,contentType:'text',maxBytes:900000});jobs.push(...parseJobPosting(html,link,source));}
  catch{} // a single job page failure must not close other jobs
 }
 // Never mark missing jobs as closed after a truncated sitemap crawl.
 return {jobs,complete:unique.length<=maxPages};
}
const ENGINES={greenhouse,lever,ashby,smartrecruiters,workable,rss,sitemap};
async function collectSource(source,options={}){
 const fn=ENGINES[source.engine];if(!fn)throw Error('Not a collectable source engine: '+source.engine);
 if(!source.enabled)throw Error('Source not enabled');
 if(source.engine==='rss'||source.engine==='sitemap'){if(!source.approved)throw Error('Site requires reviewed permission');}
 return fn(source,options);
}
module.exports={ENGINES,collectSource,greenhouse,lever,ashby,smartrecruiters,workable,rss,sitemap,parseFeed,parseJobPosting,robotsRules,allowed,xmlLocs,boardSlug,siteUrl,getPage};
