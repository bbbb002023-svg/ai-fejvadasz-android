'use strict';
const crypto = require('node:crypto');
const collapse = x => String(x??'').replace(/\s+/g,' ').trim();
const sha = x => crypto.createHash('sha256').update(x).digest('hex').slice(0,40);
function canonicalUrl(raw) {
  try {
    const u=new URL(raw);
    if(u.protocol!=='https:' || u.username || u.password || u.port) return null;
    const h=u.hostname.toLowerCase();
    if(!h.includes('.')|| /(^|\.)(localhost|local|internal|test|invalid)$/.test(h) || /^\d+\.\d+\.\d+\.\d+$/.test(h) || h.startsWith('['))return null;
    u.hash=''; for(const k of [...u.searchParams.keys()]) if(/^(utm_|fbclid$|gclid$|ref$|source$|tracking$)/i.test(k))u.searchParams.delete(k);
    return u.href;
  } catch{return null}
}
const HU_TOWNS=/(?:budapest|debrecen|szeged|miskolc|p[ée]cs|gy[őo]r|ny[íi]regyh[áa]za|kecskem[ée]t|sz[ée]kesfeh[ée]rv[áa]r|szombathely|zalaegerszeg|nagykanizsa|keszthely|lenti|sopron|tatab[áa]nya|kaposv[áa]r|b[ée]k[ée]scsaba|eger|veszpr[ée]m|szolnok|h[óo]dmez[őo]v[áa]s[áa]rhely|duna[úu]jv[áa]ros|[éE]rd|salg[óo]tarj[áa]n|n[éE]metk[ée]r|[üu]ll[őo]|g[öo]d[öo]ll[őo]|magyarorsz[áa]g|hungary|ungarn)/iu;
const HU_COUNTIES=/(?:zala|vas|baranya|b[ée]k[ée]s|b[áa]cs[- ]kiskun|borsod[- ]aba[úu]j[- ]zempl[ée]n|csongr[áa]d[- ]csan[áa]d|fej[ée]r|gy[őo]r[- ]moson[- ]sopron|hajd[úu][- ]bihar|heves|j[áa]sz[- ]nagykun[- ]szolnok|kom[áa]rom[- ]esztergom|n[óo]gr[áa]d|pest|somogy|szabolcs[- ]szatm[áa]r[- ]bereg|tolna|veszpr[ée]m)\s+(?:v[áa]rmegye|megye)/iu;
const FOREIGN=/(?:vienna|wien|austria|[öo]sterreich|slovakia|slovensko|romania|rom[âa]nia|croatia|deutschland|germany|poland|warsaw|prague|praha|belgrade|serbia|new york|united states|london|united kingdom|bulgaria)/iu;
function countryStatus(location, source) {
  const s=collapse(location);
  if(/\b(?:hungary|magyarorsz[áa]g|ungarn)\b/iu.test(s))return 'hu';
  if(FOREIGN.test(s) && !HU_TOWNS.test(s))return 'foreign';
  if(HU_TOWNS.test(s)||HU_COUNTIES.test(s)||/\bHU\b/u.test(s))return 'hu';
  if(source?.country_scope==='hu_only' && !FOREIGN.test(s))return 'hu';
  return 'unknown'; // don't claim a country for "remote" or unknown city
}
function normalizeJob(raw,source){
  const title=collapse(raw?.title).slice(0,260),company=collapse(raw?.company||source?.company||source?.name).slice(0,200);
  const canonical=canonicalUrl(raw?.url);
  if(!title||!company||!canonical)return null;
  const location=collapse(raw?.location).slice(0,240),description=collapse(raw?.description).slice(0,12000);
  const id=collapse(raw?.external_id).slice(0,240)||sha(canonical);
  let published=null;
  if(raw?.published_at) {const parsed=new Date(raw.published_at);if(Number.isFinite(parsed.getTime())&&parsed.getTime()<Date.now()+86400000)published=parsed.toISOString()}
  const group=sha([company,title,location].map(x=>collapse(x).toLocaleLowerCase('hu-HU').normalize('NFD').replace(/[\u0300-\u036f]/g,'')).join('|'));
  return {job_key:sha(canonical),url:canonical,title,company,location,description,external_id:id,language:collapse(raw?.language).slice(0,15)||null,published_at:published,country_status:countryStatus(location,source),duplicate_group:group};
}
module.exports={collapse,sha,canonicalUrl,countryStatus,normalizeJob};
