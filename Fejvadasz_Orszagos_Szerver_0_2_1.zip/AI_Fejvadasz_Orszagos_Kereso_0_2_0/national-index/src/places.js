'use strict';
const fs=require('node:fs'),crypto=require('node:crypto');
// Header: name,county,latitude,longitude,source_note . Requires trusted gazetteer, no invented coords.
function csvParse(raw){
 const rows=[];let row=[],cell='',quoted=false;
 for(let i=0;i<raw.length;i++){const c=raw[i];if(quoted){if(c==='"'&&raw[i+1]==='"'){cell+='"';i++}else if(c==='"')quoted=false;else cell+=c;}
 else if(c==='"')quoted=true;else if(c===','){row.push(cell);cell=''}else if(c==='\n'){row.push(cell.replace(/\r$/,''));rows.push(row);row=[];cell=''}else cell+=c;}
 if(cell.length||row.length){row.push(cell);rows.push(row)}if(quoted)throw Error('Unclosed CSV quote');return rows;
}
function normalize(s){return String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim()}
async function importPlaces(pool,filename){const csv=csvParse(fs.readFileSync(filename,'utf8'));
 const [header,...rows]=csv,expected=['name','county','latitude','longitude','source_note'];
 if(!header||expected.some((h,i)=>header[i]?.trim()!==h))throw Error('Required CSV headers: '+expected.join(','));
 let count=0;
 for(const row of rows){if(!row.some(x=>x?.trim()))continue;
  const [name,county,latRaw,lonRaw,sourceNote='']=row.map(s=>String(s??'').trim()),lat=Number(latRaw),lon=Number(lonRaw);
  if(!name||!county||!sourceNote||!Number.isFinite(lat)||!Number.isFinite(lon)||lat<45||lat>49||lon<16||lon>23)throw Error('Invalid or undocumented Hungarian place at line '+(count+2));
  const key=crypto.createHash('sha256').update(normalize(name)+'|'+normalize(county)).digest('hex').slice(0,40);
  await pool.query(`INSERT INTO national_places(place_key,name,county,location,source_note)
   VALUES ($1,$2,$3,ST_SetSRID(ST_MakePoint($5,$4),4326)::geography,$6)
   ON CONFLICT (place_key) DO UPDATE SET name=EXCLUDED.name,county=EXCLUDED.county,location=EXCLUDED.location,source_note=EXCLUDED.source_note,updated_at=now()`,[key,name,county,lat,lon,sourceNote]);count++;
 }
 return {imported:count};
}
function distinctPlaceMatches(text,places){
 const lower=normalize(text),results=[];
 for(const place of places){const term=normalize(place.name);if(term.length<3)continue;
  let pos=lower.indexOf(term);while(pos!==-1){const before=lower[pos-1]||'',after=lower[pos+term.length]||'';
   if(!/[\p{L}\p{N}]/u.test(before)&&!/[\p{L}\p{N}]/u.test(after)){results.push(place);break}pos=lower.indexOf(term,pos+1);}
 }
 return results;
}
async function assignJobPlaces(pool,{limit=1000}={}){
 limit=Math.max(1,Math.min(10000,Number(limit)||1000));
 const places=(await pool.query('SELECT place_key,name,county FROM national_places')).rows;
 if(!places.length)return {updated:0,matches:0,note:'Gazetteer empty; import approved coordinates first'};
 const items=(await pool.query(`SELECT j.job_key,j.location_text FROM national_jobs j WHERE j.country_status='hu' AND j.state='observed'
 AND j.last_seen_at>now()-interval '72 hours' ORDER BY j.last_seen_at DESC LIMIT $1`,[limit])).rows;
 let updated=0,matches=0;
 for(const j of items){const hits=distinctPlaceMatches(j.location_text,places);if(!hits.length)continue;
  for(const place of hits){await pool.query('INSERT INTO national_job_places(job_key,place_key) VALUES($1,$2) ON CONFLICT DO NOTHING',[j.job_key,place.place_key]);matches++;}
  updated++;
 }
 return {updated,matches,places:places.length,examined:items.length};
}
module.exports={csvParse,normalize,importPlaces,distinctPlaceMatches,assignJobPlaces};
