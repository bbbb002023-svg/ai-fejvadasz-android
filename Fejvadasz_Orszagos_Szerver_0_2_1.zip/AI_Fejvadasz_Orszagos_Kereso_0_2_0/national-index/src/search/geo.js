'use strict';
function finiteNumber(x){if(x===null||x===undefined||String(x).trim()==='')return null;const n=Number(x);return Number.isFinite(n)?n:null}
function cleanRegion(x){return String(x||'').trim().replace(/\s+(?:vármegye|megye)$/iu,'').slice(0,120)}
function parseGeo(input={}){
 const lat=finiteNumber(input.lat),lon=finiteNumber(input.lon),radius=finiteNumber(input.radius_km??input.radiusKm);
 if([lat,lon,radius].every(x=>x===null))return {hasRadius:false,region:cleanRegion(input.region)};
 if(lat===null||lon===null||radius===null||lat< -90||lat>90||lon< -180||lon>180||radius<1||radius>300)throw Object.assign(Error('Érvénytelen földrajzi paraméterek: lat, lon és radius_km (1–300) együtt szükségesek.'),{status:400});
 return {hasRadius:true,lat,lon,radiusKm:radius,region:cleanRegion(input.region)};
}
function predicates(geo,{jobAlias='j',start=1}={}){
 const params=[],where=[];let k=start;
 if(geo.region){
  // Gazetteer maps county to cities, not string matching on arbitrary job snippets.
  where.push(`(EXISTS (SELECT 1 FROM national_job_places jp JOIN national_places p ON p.place_key=jp.place_key WHERE jp.job_key=${jobAlias}.job_key AND (lower(p.county)=lower($${k}) OR lower(p.name)=lower($${k}))) OR ${jobAlias}.location_text ILIKE '%'||$${k}||'%')`);
  params.push(geo.region);k++;
 }
 if(geo.hasRadius){
  where.push(`EXISTS (SELECT 1 FROM national_job_places jp JOIN national_places p ON p.place_key=jp.place_key WHERE jp.job_key=${jobAlias}.job_key AND ST_DWithin(p.location, ST_SetSRID(ST_MakePoint($${k+1},$${k}),4326)::geography, $${k+2} * 1000))`);
  params.push(geo.lat,geo.lon,geo.radiusKm);k+=3;
 }
 return {sql:where.length?' AND '+where.join(' AND '):'',params,next:k};
}
module.exports={parseGeo,predicates};
