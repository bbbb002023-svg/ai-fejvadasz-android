'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const {normalizeJob,canonicalUrl,countryStatus}=require('../src/normalize');
const E=require('../src/engines'),D=require('../src/db'),C=require('../src/collector');
const catalog=require('../config/sources.json');
const src={source_key:'lever:aleph',engine:'lever',name:'Aleph',company:'Aleph',board:'aleph',enabled:true,country_scope:'mixed',approved:true};
const mock=(callback)=>async(url,options)=>{let x=callback(String(url),options||{});if(x instanceof Error)throw x;return {ok:x?.status===undefined||x.status===200,status:x?.status??200,headers:{get:()=>null},text:async()=>typeof x.body==='string'?x.body:JSON.stringify(x.body)};};
const job=(name='Territory Sales Manager',url='https://jobs.lever.co/aleph/1')=>({title:name,url,location:'Budapest, Hungary',company:'Aleph',external_id:url,description:'Partnerkapcsolatok'});
test('Nationwide source registry has no CV-dependent entries and separates active APIs from candidates',()=>{
 assert.equal(catalog.length,75);assert.equal(catalog.filter(x=>x.enabled).length,14);
 assert.ok(catalog.every(x=>!('cv' in x)&&!('profile' in x)));
 assert.equal(new Set(catalog.map(x=>x.source_key)).size,75);
 assert.ok(catalog.every(x=>x.engine!=='registry'||!x.enabled));
});
test('Hungarian location across non-Hungarian boards is recognised',()=>{
 for(const name of ['Budapest, Hungary','Zalaegerszeg','Nagykanizsa','Szeged','Keszthely','Hungary - Remote'])assert.equal(countryStatus(name,src),'hu',name);
});
test('International-only and unknown remote locations do not become Hungarian active jobs',()=>{
 for(const loc of ['Vienna, Austria','Berlin, Germany','London UK'])assert.equal(countryStatus(loc,src),'foreign',loc);
 for(const loc of ['Remote','Worldwide','Work from anywhere',''])assert.equal(countryStatus(loc,src),'unknown',loc);
});
test('Full text is not CV-derived, invalid address rejected, dedup stable',()=>{
 const a=normalizeJob(job('Sales Representative','https://jobs.lever.co/aleph/1?utm_source=ads'),src);
 const b=normalizeJob(job('Sales Representative','https://jobs.lever.co/aleph/1'),src);
 assert.equal(a.job_key,b.job_key);assert.equal(a.country_status,'hu');assert.equal(a.title,'Sales Representative');
 assert.ok(!canonicalUrl('http://jobs.lever.co/aleph/1'));
 assert.ok(!canonicalUrl('https://localhost/foo'));
 assert.ok(!canonicalUrl('https://127.0.0.1/foo'));
});
test('No invented publication date',()=>{
 const j=normalizeJob(job(),src);assert.equal(j.published_at,null);
 assert.equal(normalizeJob({...job(),published_at:'2099-01-01'},src).published_at,null);
});
test('Lever adapter loads whole board independently of applicant location',async()=>{
 const fetch=mock((url)=>({body:[{id:'3',text:'Sales Representative',hostedUrl:'https://jobs.lever.co/aleph/3',categories:{location:'Zalaegerszeg, Hungary'},descriptionPlain:'B2B sales',createdAt:1771234567000}]}));
 const result=await E.collectSource(src,{request:fetch});
 assert.equal(result.jobs.length,1);assert.equal(result.jobs[0].location,'Zalaegerszeg, Hungary');assert.equal(result.jobs[0].title,'Sales Representative');
 assert.equal(result.complete,true);
});
test('Greenhouse removes non-job prospect posts and uses official board endpoint',async()=>{
 const source={...src,engine:'greenhouse',board:'sample'};
 const fetch=mock(url=>({body:{jobs:[{id:5,title:'Partner Manager',internal_job_id:7,absolute_url:'https://example.com/5',location:{name:'Budapest'}},{id:6,title:'General talent pool',internal_job_id:null,absolute_url:'https://example.com/6'}]}}));
 const r=await E.collectSource(source,{request:fetch});assert.equal(r.jobs.length,1);
 assert.equal(r.jobs[0].title,'Partner Manager');
});
test('Ashby skips unlisted jobs',async()=>{
 const source={...src,engine:'ashby',board:'instructure'};
 const fetch=mock(()=>({body:{jobs:[{id:'a',title:'Manager',jobUrl:'https://jobs.ashbyhq.com/instructure/a',location:'Budapest, Hungary',isListed:true},{id:'b',title:'Internal',jobUrl:'https://jobs.ashbyhq.com/instructure/b',isListed:false}]}}));
 const r=await E.collectSource(source,{request:fetch});assert.equal(r.jobs.length,1);
});
test('SmartRecruiters paginates and does not mark truncated listings complete',async()=>{
 const source={...src,engine:'smartrecruiters',board:'Hiflylabs'};
 let requests=0;
 const fetch=mock(url=>{requests++;const offset=Number(new URL(url).searchParams.get('offset'));return {body:{totalFound:101,content:Array.from({length:offset===0?100:1},(_,i)=>({id:String(offset+i),name:'Role '+(offset+i),location:{city:'Budapest',country:'Hungary'},releasedDate:'2026-11-01'}))}}});
 const r=await E.collectSource(source,{request:fetch,maxPages:3});assert.equal(requests,2);assert.equal(r.jobs.length,101);assert.equal(r.complete,true);
});
test('Invalid board token blocks potential URL injection',async()=>{
 await assert.rejects(()=>E.collectSource({...src,board:'../internal'},{request:mock(()=>({body:[]}))}),/Invalid board slug/);
});
test('Site feeds must be expressly approved before crawling',async()=>{
 await assert.rejects(()=>E.collectSource({...src,engine:'rss',url:'https://jobs.example.hu/feed.xml',approved:false}),/requires reviewed permission/);
});
test('RSS crawler observes robots.txt and does not download disallowed feed',async()=>{
 let count=0;const source={...src,engine:'rss',url:'https://jobs.example.hu/feed.xml'};
 const fetch=mock(url=>{count++;return {body:'User-agent: *\nDisallow: /feed.xml'}});
 const r=await E.collectSource(source,{request:fetch});assert.equal(r.jobs.length,0);assert.equal(count,1);
});
test('RSS content is extracted only from approved same-host links',async()=>{
 const source={...src,engine:'rss',url:'https://jobs.example.hu/feed.xml'};
 const fetch=mock(url=>({body:url.endsWith('robots.txt')?'User-agent: *\nDisallow: /private':`<rss><channel><item><title>Area Sales Manager</title><link>https://jobs.example.hu/jobs/5</link><pubDate>2026-11-01</pubDate></item><item><title>Leak</title><link>https://evil.example/jobs/6</link></item></channel></rss>`}));
 const r=await E.collectSource(source,{request:fetch});assert.equal(r.jobs.length,1);assert.equal(r.jobs[0].title,'Area Sales Manager');
});
test('Sitemap requires verified JobPosting on the original job page',async()=>{
 const source={...src,engine:'sitemap',url:'https://jobs.example.hu/sitemap.xml'};
 const html='<html><script type="application/ld+json">'+JSON.stringify({'@type':'JobPosting',title:'Területi vezető',hiringOrganization:{name:'Example'},datePosted:'2026-11-01',jobLocation:{address:{addressLocality:'Zalaegerszeg',addressCountry:'HU'}}})+'</script></html>';
 const fetch=mock(url=>({body:url.endsWith('robots.txt')?'User-agent: *\nDisallow: /private':url.endsWith('sitemap.xml')?'<urlset><url><loc>https://jobs.example.hu/jobs/area-sales</loc></url></urlset>':html}));
 const r=await E.collectSource(source,{request:fetch,maxPages:10});assert.equal(r.jobs.length,1);assert.equal(r.jobs[0].title,'Területi vezető');
});
test('Expired structured JobPosting is not imported',()=>{
 const html='<script type="application/ld+json">'+JSON.stringify({'@type':'JobPosting',title:'Old job',validThrough:'2020-01-01'})+'</script>';
 assert.equal(E.parseJobPosting(html,'https://jobs.example.hu/jobs/old',src).length,0);
});
test('Collector respects advisory lock - skips duplicate simultaneous run',async()=>{
 let releases=0,queries=0;const pool={connect:async()=>({query:async()=>({rows:[{acquired:false}]}),release:()=>releases++}),query:async()=>queries++};
 const r=await C.runOnce(pool);assert.equal(r.skipped,true);assert.equal(releases,1);assert.equal(queries,0);
});
test('A partial snapshot must never close disappeared jobs',async()=>{
 const calls=[];const pool={connect:async()=>({query:async(q,p)=>{calls.push(q);return {rows:[]}},release:()=>{}})};
 const r=await D.upsertSnapshot(pool,src,[job()],{complete:false});assert.equal(r.total,1);
 assert.ok(!calls.some(q=>q.includes('SET present=false')));
 assert.ok(!calls.some(q=>q.includes("SET state='closed'")));
});
test('A full snapshot closes only missing observations of the same source',async()=>{
 const calls=[];const pool={connect:async()=>({query:async(q,p)=>{calls.push([q,p]);return {rows:[]}},release:()=>{}})};
 await D.upsertSnapshot(pool,src,[job()],{complete:true});const sql=calls.map(x=>x[0]).join('\n');
 assert.ok(sql.includes('SET present=false'));assert.ok(sql.includes('AND NOT EXISTS'));assert.ok(sql.includes('o.source_key=$1'));
});
test('Invalid source URL cannot redirect to arbitrary host',async()=>{
 const source={...src,engine:'rss',url:'http://127.0.0.1/test'};
 await assert.rejects(()=>E.collectSource(source,{request:mock(()=>({body:''}))}),/Unsafe site URL/);
});
