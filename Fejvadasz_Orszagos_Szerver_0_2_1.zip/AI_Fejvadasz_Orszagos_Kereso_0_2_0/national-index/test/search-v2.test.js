'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {expand}=require('../src/search/lexicon'),{textQuery}=require('../src/search/text');
const {parseGeo,predicates}=require('../src/search/geo'),Sem=require('../src/search/semantic');
const {mergeResults,personalize}=require('../src/search/ranking');
const Service=require('../src/search/service'),Places=require('../src/places'),Db=require('../src/db');
const create=title=>({job_key:title,title,company:'Fiktiv ceg',location_text:'Zalaegerszeg',canonical_url:'https://example.org/jobs/'+encodeURIComponent(title),description:'Kereskedelmi munka',last_seen_at:new Date().toISOString()});

test('Lexical engine recognises Hungarian-English-German sales equivalences',()=>{
 const roles=expand('területi képviselő');assert.ok(roles.includes('sales representative'));assert.ok(roles.includes('außendienstmitarbeiter'));
 assert.ok(expand('területi vezető').includes('area sales manager'));
 assert.deepEqual(expand('nem ismert szakma'),['nem ismert szakma']);
});
test('Lexical SQL is fully parameterized and escapes wildcard injection',()=>{
 const q=textQuery({q:'értékesítő%',region:'Zala',limit:9999});assert.equal(q.params[0],'értékesítő!%');
 assert.ok(q.sql.includes("ESCAPE '!'"));assert.ok(q.sql.includes('national_jobs'));
 assert.equal(q.params.at(-1),200);assert.ok(!q.sql.includes('értékesítő%'));
});
test('Text engine filters counties with gazetteer join; no CV anywhere',()=>{
 const q=textQuery({q:'területi vezető',region:'Zala vármegye'});
 assert.ok(q.sql.includes('national_job_places'));assert.ok(q.params.includes('Zala'));assert.ok(!q.sql.includes('profile_patch'));
});
test('Geo engine enforces strict real-distance coordinates',()=>{
 assert.throws(()=>parseGeo({lat:47,lon:19}),/földrajzi/);
 assert.throws(()=>parseGeo({lat:95,lon:19,radius_km:30}),/földrajzi/);
 const geo=parseGeo({lat:46.85,lon:16.85,radius_km:30});let x=predicates(geo,{start:4});
 assert.ok(x.sql.includes('ST_DWithin'));assert.deepEqual(x.params,[46.85,16.85,30]);
});
test('Semantic vector validates all 512 dimensions and builds HNSW-compatible SQL',()=>{
 const v=Array.from({length:512},(_,i)=>i===0?1:0);
 assert.ok(Sem.vectorLiteral(v).startsWith('[1.00000000'));
 assert.throws(()=>Sem.vectorLiteral([0]),/dimension/);
 const query=Sem.semanticQuery({q:'area sales manager',vector:v,region:'Zala',limit:5});
 assert.ok(query.sql.includes('embedding <=> $1::vector'));assert.equal(query.params.length,3);assert.equal(query.params.at(-1),5);
});
test('Semantic engine calls a real embeddings endpoint, mocked for offline test',async()=>{
 let called=0;const request=async(url,opts)=>{called++;assert.equal(url,'https://api.openai.com/v1/embeddings');const body=JSON.parse(opts.body);
 assert.equal(body.model,'text-embedding-3-small');assert.equal(body.dimensions,512);return {ok:true,json:async()=>({data:[{index:0,embedding:Array(512).fill(0.05)}]})};};
 const vectors=await Sem.embeddings(['Területi vezető'],{key:'fake-test-key',request});assert.equal(vectors[0].length,512);assert.equal(called,1);
});
test('Semantic failure remains explicitly disabled; text results still returned',async()=>{
 const pool={query:async()=>({rows:[create('Area Sales Manager')]})};
 const results=await Service.search(pool,{q:'területi vezető',key:'',limit:30});
 assert.equal(results.jobs.length,1);assert.equal(results.meta.semanticStatus,'disabled');
});
test('Search engines combine without duplicate jobs and preserve provenance',()=>{
 const j=create('Sales Representative');const x=mergeResults([j],[j,create('Area Sales Manager')],20);
 assert.equal(x.length,2);assert.deepEqual(x[0].channels,['text','semantic']);
});
test('Ranking respects explicit excluded roles without inventing CV experience',()=>{
 const jobs=personalize([create('Area Sales Manager'),create('Cashier')],{skills:['Sales'],excludedRoles:'Cashier'});
 assert.equal(jobs.length,1);assert.equal(jobs[0].title,'Area Sales Manager');assert.equal(jobs[0].matchedSkillCount,1);
});
test('Malformed geographic inputs fail before database query',async()=>{
 let count=0;const pool={query:async()=>{count++;return {rows:[]}}};
 await assert.rejects(()=>Service.search(pool,{q:'vezető',lat:47,lon:19,radius_km:900,key:''}),/földrajzi/);
 assert.equal(count,0);
});
test('National search works without a profile, recommendation does not write a CV',async()=>{
 let count=0;const pool={query:async(q)=>{count++;assert.ok(!q.includes('INSERT INTO'));return {rows:[create('Területi képviselő')]}}};
 const r=await Service.recommend(pool,{targetRoles:'területi képviselő',skills:['kereskedelem']},{key:''});
 assert.equal(r.jobs.length,1);assert.ok(r.meta.personalization.includes('nem mentjük'));assert.equal(count,1);
});
test('Places importer validates provenance, data and region; fictional import test',async()=>{
 const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),name=path.join(os.tmpdir(),'places-'+process.pid+'.csv');
 fs.writeFileSync(name,'name,county,latitude,longitude,source_note\nPróbahelység,Próbamegye,46.8,16.8,tesztadat\n');
 let queries=0;const pool={query:async(sql,p)=>{queries++;assert.equal(p[1],'Próbahelység');return {rowCount:1}}};
 try{const r=await Places.importPlaces(pool,name);assert.equal(r.imported,1);assert.equal(queries,1)}finally{fs.unlinkSync(name)}
});
test('Only word-boundary city matches can become geo-located',()=>{
 const places=[{place_key:'a',name:'Eger'},{place_key:'b',name:'Zalaegerszeg'}];
 assert.deepEqual(Places.distinctPlaceMatches('Area sales manager Zalaegerszeg, HU',places).map(x=>x.name),['Zalaegerszeg']);
 assert.deepEqual(Places.distinctPlaceMatches('Manager',places),[]);
});
test('Migration includes PostgreSQL vector, geo extensions and indexes',()=>{
 const fs=require('node:fs'),path=require('node:path'),s=fs.readFileSync(path.join(__dirname,'../src/schema-v2.sql'),'utf8');
 for(const name of ['vector','postgis','pg_trgm','national_places','national_job_places','national_jobs_embedding_hnsw'])assert.ok(s.includes(name),name);
 assert.ok(Db.migrate);
});
