'use strict';
const http=require('node:http');const db=require('./db'),S=require('./search/service'),quality=require('./quality');
function reply(res,status,payload){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(payload))}
function bodyJson(req,{maxBytes=18000}={}){return new Promise((resolve,reject)=>{
 let len=0,chunks=[];req.on('data',buf=>{len+=buf.length;if(len>maxBytes){reject(Object.assign(Error('Túl nagy kérés'),{status:413}));req.destroy();return}chunks.push(buf)});
 req.on('end',()=>{try{resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')))}catch{reject(Object.assign(Error('Hibás JSON'),{status:400}))}});req.on('error',reject);
})}
function createApi(pool,{token=process.env.NATIONAL_API_TOKEN,embeddingKey=process.env.OPENAI_API_KEY,request=globalThis.fetch}={}){
 return http.createServer(async(req,res)=>{
  try{
   const u=new URL(req.url,'http://localhost');
   if(req.method==='GET'&&(u.pathname==='/health'||u.pathname==='/ready')){
    try{await pool.query('SELECT 1');const ready=u.pathname==='/ready'?await pool.query("SELECT to_regclass('public.national_jobs') AS jobs, to_regclass('public.national_places') AS places"):null;
     if(ready&&(!ready.rows[0].jobs||!ready.rows[0].places))return reply(res,503,{ok:false,database:'schema_missing'});
     return reply(res,200,{ok:true,service:'AI Fejvadasz National Index',version:require('../package.json').version,database:'connected',engines:['text','geo','ranking',...(embeddingKey?['semantic']:[])]});
    }catch{return reply(res,503,{ok:false,database:'unavailable'})}
   }
   if(!token)return reply(res,503,{error:'NATIONAL_API_TOKEN must be configured'});
   if(req.headers.authorization!==`Bearer ${token}`)return reply(res,401,{error:'Unauthorized'});
   if(req.method==='GET'&&u.pathname==='/api/v1/stats')return reply(res,200,{ok:true,...await db.stats(pool)});
   if(req.method==='GET'&&u.pathname==='/api/v1/audit')return reply(res,200,{ok:true,...await db.audit(pool),engineTargets:await quality.engineTargets(pool)});
   if(req.method==='GET'&&u.pathname==='/api/v1/engine-targets')return reply(res,200,{ok:true,...await quality.engineTargets(pool)});
   if(req.method==='GET'&&u.pathname==='/api/v1/jobs')return reply(res,200,{ok:true,jobs:await db.search(pool,{q:u.searchParams.get('q'),region:u.searchParams.get('region'),limit:u.searchParams.get('limit'),offset:u.searchParams.get('offset')})});
   if(req.method==='GET'&&u.pathname==='/api/v2/search'){
    const get=x=>u.searchParams.get(x);const r=await S.search(pool,{q:get('q'),mode:get('mode')||'hybrid',region:get('region'),lat:get('lat'),lon:get('lon'),radius_km:get('radius_km'),limit:get('limit')||50,key:embeddingKey,request});
    return reply(res,200,{ok:true,...r});
   }
   if(req.method==='POST'&&u.pathname==='/api/v2/recommend'){
    const p=await bodyJson(req);if(!p||typeof p!=='object'||Array.isArray(p))throw Object.assign(Error('Hibás profil'),{status:400});
    const r=await S.recommend(pool,p,{mode:'hybrid',limit:Math.min(100,Number(p.limit)||40),key:embeddingKey,request});
    return reply(res,200,{ok:true,...r});
   }
   return reply(res,404,{error:'Unknown endpoint'});
  }catch(e){const code=Number(e?.status)||500;if(code>=500)console.error('national api:',String(e?.message||e).slice(0,160));reply(res,code>=400&&code<=599?code:500,{error:code>=500?'Internal service error':String(e.message).slice(0,200)})}
 });
}
module.exports={createApi};
