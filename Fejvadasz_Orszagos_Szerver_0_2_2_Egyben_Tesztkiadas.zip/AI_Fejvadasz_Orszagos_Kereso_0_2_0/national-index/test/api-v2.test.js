'use strict';
const test=require('node:test'),assert=require('node:assert/strict');const {createApi}=require('../src/api');
const jobs=[{job_key:'test',title:'Területi képviselő',company:'Próbavállalat',location_text:'Zalaegerszeg',canonical_url:'https://example.org/job/test',description:'B2B kapcsolattartás'}];
async function withApi(pool,fn){const server=createApi(pool,{token:'dev-test-token',embeddingKey:''});await new Promise(r=>server.listen(0,'127.0.0.1',r));try{return await fn('http://127.0.0.1:'+server.address().port)}finally{await new Promise((r,e)=>server.close(err=>err?e(err):r()))}}
test('Health endpoint checks actual PostgreSQL connection',async()=>{
 const pool={query:async()=>({rows:[{}]})};await withApi(pool,async origin=>{const res=await fetch(origin+'/health');assert.equal(res.status,200);const x=await res.json();assert.equal(x.database,'connected');assert.equal(x.version,'0.2.2')});
});
test('Health fails closed when PostgreSQL is down',async()=>{
 const pool={query:async()=>{throw Error('DB offline')}};await withApi(pool,async origin=>{const res=await fetch(origin+'/health');assert.equal(res.status,503);assert.equal((await res.json()).database,'unavailable')});
});
test('Countrywide search API requires backend secret',async()=>{
 let dbReads=0;const pool={query:async()=>{dbReads++;return {rows:jobs}}};
 await withApi(pool,async origin=>{
  const a=await fetch(origin+'/api/v2/search?q=vezető');assert.equal(a.status,401);
  const b=await fetch(origin+'/api/v2/search?q=ter%C3%BCleti%20k%C3%A9pvisel%C5%91',{headers:{Authorization:'Bearer dev-test-token'}});
  assert.equal(b.status,200);const j=await b.json();assert.equal(j.jobs.length,1);assert.equal(j.meta.semanticStatus,'disabled');
 });assert.equal(dbReads,1);
});
test('POST recommendation stays ephemeral and does not write data',async()=>{
 const pool={query:async(sql)=>{assert.ok(!/INSERT|UPDATE/i.test(sql));return {rows:jobs}}};
 await withApi(pool,async origin=>{
  const r=await fetch(origin+'/api/v2/recommend',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer dev-test-token'},body:JSON.stringify({targetRoles:'területi képviselő',skills:['B2B']})});
  assert.equal(r.status,200);const data=await r.json();assert.equal(data.jobs[0].title,'Területi képviselő');
 });
});
test('API rejects invalid radius and has no exposed secret',async()=>{
 const pool={query:async()=>({rows:[]})};await withApi(pool,async origin=>{
  const r=await fetch(origin+'/api/v2/search?q=vezet%C5%91&lat=46.8&lon=17.1&radius_km=900',{headers:{Authorization:'Bearer dev-test-token'}});
  assert.equal(r.status,400);assert.ok(!(await r.text()).includes('dev-test-token'));
 });
});
